import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Seasonal atmosphere: decorations behind pages, interactive overlays on top.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
    this.child,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;
  final Widget? child;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  /// Continuous loop for flake motion / flicker.
  AnimationController? _loop;


  /// Wall-clock climate (continues while the app is backgrounded).
  Timer? _clock;
  double _climate = 0;
  double _loopPhase = 0;
  static const _cycleMs = 17 * 60 * 1000; // 5+5+2+5 min

  int _leftGlow = 0;
  int _rightGlow = 0;
  int _leftTap = 0; // 1..7 cycle for left interactive pumpkin
  int _fieldGlow = 0; // glow level for the 50 field pumpkins
  bool _screamer = false;
  bool _aaaButton = false;
  bool _houseGarlandOn = false;
  bool _houseLightsOn = true;
  bool _castleLightsOn = true;

  // Christmas fireworks (up to several simultaneous shows).
  final List<_FireworkShow> _fireworks = [];
  // Halloween spider: 0=idle, 1=descending, 2=hanging, 3=ascending.
  int _spiderPhase = 0;
  double _spiderProgress = 0; // 0..1 within phase
  double _spiderX = 0.35; // normalized
  Timer? _spiderTimer;

  // Halloween moon ritual: 0 taps → grow 1..8 → 9 flicker → 10 werewolf.
  int _moonTaps = 0;
  bool _moonFlicker = false;
  double _moonFlickerPhase = 0;
  bool _werewolfActive = false;
  double _werewolfT = 0; // 0..1 over sequence
  bool _showFlee = false;

  bool get _seasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark &&
      widget.themeKind != ThemeKind.system;

  bool get _pink => _anim && widget.themeKind == ThemeKind.pink;

  bool get _anim => _seasonal && widget.animationsEnabled;

  bool get _christmas =>
      _anim &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _halloween => _anim && widget.themeKind == ThemeKind.halloween;

  bool get _aurora => _anim && widget.themeKind == ThemeKind.aurora;

  bool get _autumn => _anim && widget.themeKind == ThemeKind.autumn;

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _sync();
      if (widget.themeKind != ThemeKind.halloween) {
        _leftGlow = 0;
        _rightGlow = 0;
        _leftTap = 0;
        _fieldGlow = 0;
        _screamer = false;
        _aaaButton = false;
        _castleLightsOn = true;
      }
      if (widget.themeKind != ThemeKind.christmas) {
        _houseGarlandOn = false;
        _houseLightsOn = true;
        _fireworks.clear();
      }
      if (widget.themeKind != ThemeKind.halloween) {
        _spiderPhase = 0;
        _spiderProgress = 0;
        _spiderTimer?.cancel();
        _spiderTimer = null;
        _moonTaps = 0;
        _moonFlicker = false;
        _werewolfActive = false;
        _werewolfT = 0;
        _showFlee = false;
      }
    }
  }

  void _sync() {
    _clock?.cancel();
    _clock = null;

    if (_anim) {
      // Short duration → more ticks per second (smoother motion up to display Hz).
      _loop ??= AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 200), // ~5 cycles/sec base
      )..repeat();
      if (!_loop!.isAnimating) _loop!.repeat();

      void tick() {
        final ms = DateTime.now().millisecondsSinceEpoch;
        // Climate cycle only meaningful for Christmas; still sample loop always.
        if (_christmas) {
          _climate = (ms % _cycleMs) / _cycleMs;
        }
        _loopPhase = (ms % 5000) / 5000.0;
      }

      tick();
      // Keep cycle advancing even if the vsync ticker pauses (background/resume).
      // Christmas / Halloween / Cosmos: keep painting while tab is open
      // and after resume (wall-clock driven).
      if (_christmas ||
          _halloween ||
          _pink ||
          _aurora ||
          _autumn ||
          widget.themeKind == ThemeKind.cosmos) {
        _clock = Timer.periodic(const Duration(milliseconds: 16), (_) {
          if (!mounted) return;
          final prev = _climate;
          final prevLoop = _loopPhase;
          tick();
          var dirty = (_climate - prev).abs() > 0.00005 ||
              (_loopPhase - prevLoop).abs() > 0.00005;
          if (_christmas && _fireworks.isNotEmpty) {
            final now = DateTime.now().millisecondsSinceEpoch / 1000.0;
            _fireworks.removeWhere((f) => now - f.startSec > f.duration);
            dirty = true;
          }
          if (_halloween) {
            _tickSpider();
            if (_moonFlicker) {
              _moonFlickerPhase += 0.016;
              if (_moonFlickerPhase >= 5.0) {
                _moonFlicker = false;
                _moonFlickerPhase = 0;
              }
              dirty = true;
            }
            if (_werewolfActive) {
              _werewolfT += 0.016 / 9.0; // ~9s full sequence
              if (_werewolfT >= 7.0 / 9.0 && !_showFlee) {
                // after 7s show flee button at ~2s later handled below
              }
              if (_werewolfT >= 9.0 / 9.0) {
                _werewolfT = 1.0;
                _showFlee = true;
              }
              dirty = true;
            }
            dirty = true;
          }
          if (dirty) setState(() {});
        });
      }
    } else {
      _loop?.stop();
      _loop?.value = 0;
      _climate = 0;
      _loopPhase = 0;
    }
  }

  void _tapLeftPumpkin() {
    if (_screamer) return;
    setState(() {
      _leftTap += 1;
      if (_leftTap <= 5) {
        _leftGlow = _leftTap;
      } else if (_leftTap == 6) {
        // All field pumpkins + left to level 3.
        _leftGlow = 3;
        _fieldGlow = 3;
      } else {
        // 7th press: everything off.
        _leftGlow = 0;
        _rightGlow = 0;
        _fieldGlow = 0;
        _leftTap = 0;
      }
    });
  }

  void _tapRightPumpkin() {
    if (_screamer) return;
    setState(() {
      if (_rightGlow < 4) {
        _rightGlow++;
      } else {
        _rightGlow = 4;
        _screamer = true;
        _aaaButton = false;
      }
    });
    if (_screamer) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && _screamer) setState(() => _aaaButton = true);
      });
    }
  }

  void _dismissScreamer() {
    setState(() {
      _screamer = false;
      _aaaButton = false;
      _leftGlow = 0;
      _rightGlow = 0;
      _leftTap = 0;
      _fieldGlow = 0;
    });
  }

  void _tickSpider() {
    if (!_halloween) return;
    // Random start of a spider event.
    if (_spiderPhase == 0) {
      // ~every 12–22s on average when animations on.
      final roll = DateTime.now().millisecondsSinceEpoch % 1000;
      if (roll < 2) {
        _spiderPhase = 1;
        _spiderProgress = 0;
        _spiderX = 0.15 + (DateTime.now().millisecondsSinceEpoch % 700) / 1000.0;
      }
      return;
    }
    final dt = 0.016;
    if (_spiderPhase == 1) {
      // Descend ~2.2s
      _spiderProgress += dt / 2.2;
      if (_spiderProgress >= 1) {
        _spiderProgress = 0;
        _spiderPhase = 2;
      }
    } else if (_spiderPhase == 2) {
      // Hang ~2.5s
      _spiderProgress += dt / 2.5;
      if (_spiderProgress >= 1) {
        _spiderProgress = 0;
        _spiderPhase = 3;
      }
    } else if (_spiderPhase == 3) {
      // Ascend ~1.8s
      _spiderProgress += dt / 1.8;
      if (_spiderProgress >= 1) {
        _spiderProgress = 0;
        _spiderPhase = 0;
      }
    }
  }

  void _onMoonTap() {
    if (!_halloween || _werewolfActive) return;
    setState(() {
      _moonTaps += 1;
      if (_moonTaps <= 8) {
        // grow
      } else if (_moonTaps == 9) {
        _moonFlicker = true;
        _moonFlickerPhase = 0;
      } else if (_moonTaps >= 10) {
        _moonTaps = 10;
        _werewolfActive = true;
        _werewolfT = 0;
        _showFlee = false;
        // Enable flee after 9 seconds (7 dark+jump + 2 wait)
        Future<void>.delayed(const Duration(seconds: 9), () {
          if (mounted && _werewolfActive) {
            setState(() => _showFlee = true);
          }
        });
      }
    });
  }

  void _fleeWerewolf() {
    setState(() {
      _moonTaps = 0;
      _moonFlicker = false;
      _moonFlickerPhase = 0;
      _werewolfActive = false;
      _werewolfT = 0;
      _showFlee = false;
    });
  }

  void _launchFireworks() {
    if (!_christmas) return;
    final rnd = math.Random();
    final now = DateTime.now().millisecondsSinceEpoch / 1000.0;
    // Launch a short barrage of 3–6 random shows from the 50 presets.
    final n = 3 + rnd.nextInt(4);
    for (var i = 0; i < n; i++) {
      final preset = rnd.nextInt(50);
      final delay = i * (0.15 + rnd.nextDouble() * 0.35);
      _fireworks.add(_FireworkShow(
        preset: preset,
        startSec: now + delay,
        x: 0.12 + rnd.nextDouble() * 0.76,
        y: 0.18 + rnd.nextDouble() * 0.28,
        duration: 2.4 + rnd.nextDouble() * 1.4,
      ));
    }
    setState(() {});
  }

  Widget _chipButton({
    required bool on,
    required VoidCallback onTap,
    required IconData iconOn,
    required IconData iconOff,
    required String labelOn,
    required String labelOff,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF2A332E).withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: on
                ? const Color(0xFFFFD080).withValues(alpha: 0.85)
                : const Color(0xFF6A7A70).withValues(alpha: 0.6),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              on ? iconOn : iconOff,
              size: 16,
              color: on ? const Color(0xFFFFD080) : const Color(0xFF9AAA9A),
            ),
            const SizedBox(width: 6),
            Text(
              on ? labelOn : labelOff,
              style: TextStyle(
                color: on ? const Color(0xFFFFF0D0) : const Color(0xFFC8D0C8),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _clock?.cancel();
    _loop?.dispose();
    _spiderTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: Listenable.merge([
        _loop ?? const AlwaysStoppedAnimation(0.0),
      ]),
      builder: (context, _) {
        // Prefer high-freq wall-clock values when animations are on.
        final climate = _anim ? _climate : 0.0;
        final loopVal = _anim ? _loopPhase : (_loop?.value ?? 0.0);
        // Pumpkin grid sits above the input / nav area.
        // 8 field + 2 interactive = 10 total, larger size.
        final fieldTop = size.height * 0.52;
        final gridTop = fieldTop + 28;
        final rowH = math.min(52.0, (size.height * 0.74 - gridTop) / 3);
        final lastRowY = gridTop + rowH * 2;
        final leftPumpkin = Offset(36, lastRowY);
        final rightPumpkin = Offset(size.width - 36, lastRowY);
        const pumpkinSize = 72.0;

        return Stack(
          fit: StackFit.expand,
          clipBehavior: Clip.none,
          children: [
            IgnorePointer(
              child: CustomPaint(
                painter: _AtmospherePainter(
                  kind: widget.themeKind,
                  loop: loopVal,
                  topInset: topInset,
                  animate: _anim,
                  climate: climate,
                  houseGarlandOn: _houseGarlandOn,
                  houseLightsOn: _houseLightsOn,
                  castleLightsOn: _castleLightsOn,
                  fieldGlow: _fieldGlow,
                  fireworks: List<_FireworkShow>.from(_fireworks),
                  spiderPhase: _spiderPhase,
                  spiderProgress: _spiderProgress,
                  spiderX: _spiderX,
                  moonTaps: _moonTaps,
                  moonFlicker: _moonFlicker,
                  moonFlickerPhase: _moonFlickerPhase,
                  werewolfActive: _werewolfActive,
                  werewolfT: _werewolfT,
                ),
                size: size,
              ),
            ),
            if (widget.child != null) widget.child!,

            // Halloween pumpkins — real widgets for reliable taps.
            if (widget.themeKind == ThemeKind.halloween) ...[
              Positioned(
                left: leftPumpkin.dx - pumpkinSize / 2,
                top: leftPumpkin.dy - pumpkinSize / 2,
                width: pumpkinSize,
                height: pumpkinSize,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapLeftPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _leftGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin(loopVal * math.pi * 2)
                          : 0.8,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: rightPumpkin.dx - pumpkinSize / 2,
                top: rightPumpkin.dy - pumpkinSize / 2,
                width: pumpkinSize,
                height: pumpkinSize,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapRightPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _rightGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin(loopVal * math.pi * 2 + 1)
                          : 0.8,
                    ),
                  ),
                ),
              ),
            ],

            // Theme control chips (above chat input / nav).
            if (widget.themeKind == ThemeKind.christmas)
              Positioned(
                right: 14,
                bottom: 96,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _chipButton(
                      on: _houseLightsOn,
                      onTap: () =>
                          setState(() => _houseLightsOn = !_houseLightsOn),
                      iconOn: Icons.home,
                      iconOff: Icons.home_outlined,
                      labelOn: 'Свет вкл',
                      labelOff: 'Свет',
                    ),
                    const SizedBox(height: 8),
                    _chipButton(
                      on: _houseGarlandOn,
                      onTap: () =>
                          setState(() => _houseGarlandOn = !_houseGarlandOn),
                      iconOn: Icons.lightbulb,
                      iconOff: Icons.lightbulb_outline,
                      labelOn: 'Гирлянда вкл',
                      labelOff: 'Гирлянда',
                    ),
                    const SizedBox(height: 8),
                    _chipButton(
                      on: _fireworks.isNotEmpty,
                      onTap: _launchFireworks,
                      iconOn: Icons.auto_awesome,
                      iconOff: Icons.auto_awesome_outlined,
                      labelOn: 'Фейерверк',
                      labelOff: 'Фейерверк',
                    ),
                  ],
                ),
              ),
            if (widget.themeKind == ThemeKind.halloween)
              Positioned(
                right: 14,
                bottom: 96,
                child: _chipButton(
                  on: _castleLightsOn,
                  onTap: () =>
                      setState(() => _castleLightsOn = !_castleLightsOn),
                  iconOn: Icons.nightlight_round,
                  iconOff: Icons.nightlight_outlined,
                  labelOn: 'Свет замка',
                  labelOff: 'Свет замка',
                ),
              ),

            // Halloween moon hit target (invisible button over moon).
            if (widget.themeKind == ThemeKind.halloween && !_werewolfActive)
              Positioned(
                left: size.width * 0.16 - 44,
                top: topInset + 88 - 44,
                width: 88,
                height: 88,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _onMoonTap,
                  child: const SizedBox.expand(),
                ),
              ),

            // Werewolf sequence overlay.
            if (_werewolfActive)
              Positioned.fill(
                child: IgnorePointer(
                  ignoring: !_showFlee,
                  child: CustomPaint(
                    painter: _WerewolfPainter(t: _werewolfT),
                    child: _showFlee
                        ? Center(
                            child: FilledButton(
                              style: FilledButton.styleFrom(
                                backgroundColor: Colors.red.shade900,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 32, vertical: 16),
                              ),
                              onPressed: _fleeWerewolf,
                              child: const Text('Бежать',
                                  style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800)),
                            ),
                          )
                        : null,
                  ),
                ),
              ),

            if (_screamer)
              Positioned.fill(
                child: _ScreamerOverlay(
                  showButton: _aaaButton,
                  onDismiss: _dismissScreamer,
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Pumpkin
// ---------------------------------------------------------------------------

class _PumpkinPainter extends CustomPainter {
  _PumpkinPainter({required this.glow, required this.flicker});
  final int glow;
  final double flicker;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide * 0.42;
    final base = const Color(0xFFB27B54);
    final glowA = 0.08 + glow * 0.16;
    // Soft local light on the ground when lit.
    if (glow > 0) {
      canvas.drawCircle(
        c + Offset(0, r * 0.5),
        r * (2.0 + glow * 0.3),
        Paint()
          ..color = const Color(0xFFFFB040)
              .withValues(alpha: (0.1 + glow * 0.05) * flicker)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
    }
    final fill = Paint()
      ..color = const Color(0xFFFFB040)
          .withValues(alpha: (glowA * 1.35).clamp(0.0, 1.0) * flicker)
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = base.withValues(alpha: 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy, c.dx - r * 0.9,
          c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, stroke);
    canvas.drawLine(
        Offset(c.dx, c.dy - r * 0.7), Offset(c.dx, c.dy - r * 1.05), stroke);
  }

  @override
  bool shouldRepaint(covariant _PumpkinPainter old) =>
      old.glow != glow || old.flicker != flicker;
}

// ---------------------------------------------------------------------------
// Screamer — horror figure with knife
// ---------------------------------------------------------------------------

class _ScreamerOverlay extends StatelessWidget {
  const _ScreamerOverlay({required this.showButton, required this.onDismiss});
  final bool showButton;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.94),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(
              painter: _HorrorFigurePainter(), child: const SizedBox.expand()),
          if (showButton)
            Align(
              alignment: const Alignment(0, 0.62),
              child: _AaaButton(onPressed: onDismiss),
            ),
        ],
      ),
    );
  }
}

class _AaaButton extends StatefulWidget {
  const _AaaButton({required this.onPressed});
  final VoidCallback onPressed;
  @override
  State<_AaaButton> createState() => _AaaButtonState();
}

class _AaaButtonState extends State<_AaaButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          child!,
          SizedBox(
            height: 36,
            width: 160,
            child: CustomPaint(painter: _DripsPainter(_c.value)),
          ),
        ],
      ),
      child: FilledButton(
        onPressed: widget.onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF8B1515),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        ),
        child: const Text('ААААААААААА!',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      ),
    );
  }
}

class _DripsPainter extends CustomPainter {
  _DripsPainter(this.p);
  final double p;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFB01010);
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.15 + i * 0.18);
      final fall = (p + i * 0.17) % 1.0;
      final y = fall * size.height;
      canvas.drawCircle(Offset(x, y), 2.2, paint);
      canvas.drawOval(
        Rect.fromCenter(
            center: Offset(x, y - 4), width: 1.6, height: 6 + fall * 8),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DripsPainter old) => old.p != p;
}

/// Stylized horror silhouette: hooded figure + knife (original vector art).
class _HorrorFigurePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width * 0.5;
    final cy = size.height * 0.42;
    final fill = Paint()..color = const Color(0xFF1A1218);
    final edge = Paint()
      ..color = const Color(0xFF3A2A32)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    // Cloak / body
    final cloak = Path()
      ..moveTo(cx - 70, cy + 160)
      ..lineTo(cx - 55, cy + 20)
      ..quadraticBezierTo(cx - 40, cy - 40, cx - 20, cy - 70)
      ..lineTo(cx + 20, cy - 70)
      ..quadraticBezierTo(cx + 40, cy - 40, cx + 55, cy + 20)
      ..lineTo(cx + 70, cy + 160)
      ..close();
    canvas.drawPath(cloak, fill);
    canvas.drawPath(cloak, edge);

    // Hood
    final hood = Path()
      ..moveTo(cx - 32, cy - 55)
      ..quadraticBezierTo(cx - 38, cy - 110, cx, cy - 125)
      ..quadraticBezierTo(cx + 38, cy - 110, cx + 32, cy - 55)
      ..quadraticBezierTo(cx, cy - 40, cx - 32, cy - 55)
      ..close();
    canvas.drawPath(hood, fill);
    canvas.drawPath(hood, edge);

    // Face void
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy - 78), width: 36, height: 42),
      Paint()..color = const Color(0xFF0A0608),
    );
    // Glowing eyes
    final eye = Paint()..color = const Color(0xFFE8B060).withValues(alpha: 0.9);
    canvas.drawCircle(Offset(cx - 8, cy - 82), 3.2, eye);
    canvas.drawCircle(Offset(cx + 8, cy - 82), 3.2, eye);
    canvas.drawCircle(
      Offset(cx - 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawCircle(
      Offset(cx + 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // Arm raised with knife
    final arm = Path()
      ..moveTo(cx + 30, cy - 20)
      ..lineTo(cx + 75, cy - 90)
      ..lineTo(cx + 85, cy - 82)
      ..lineTo(cx + 42, cy - 5)
      ..close();
    canvas.drawPath(arm, fill);

    // Knife blade
    final blade = Path()
      ..moveTo(cx + 78, cy - 95)
      ..lineTo(cx + 118, cy - 175)
      ..lineTo(cx + 130, cy - 165)
      ..lineTo(cx + 92, cy - 88)
      ..close();
    canvas.drawPath(
      blade,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF0F0F4), Color(0xFF8A8A94)],
        ).createShader(Rect.fromLTWH(cx + 70, cy - 180, 70, 100)),
    );
    // Handle
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
            center: Offset(cx + 82, cy - 80), width: 12, height: 28),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF3A2010),
    );

    // Red slash accents
    final slash = Paint()
      ..color = const Color(0xFFB01010).withValues(alpha: 0.45)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(cx - 90, cy - 40), Offset(cx + 40, cy + 80), slash);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Main painter
// ---------------------------------------------------------------------------

class _AtmospherePainter extends CustomPainter {
  _AtmospherePainter({
    required this.kind,
    required this.loop,
    required this.topInset,
    required this.animate,
    required this.climate,
    required this.houseGarlandOn,
    required this.houseLightsOn,
    required this.castleLightsOn,
    required this.fieldGlow,
    this.fireworks = const [],
    this.spiderPhase = 0,
    this.spiderProgress = 0,
    this.spiderX = 0.35,
    this.moonTaps = 0,
    this.moonFlicker = false,
    this.moonFlickerPhase = 0,
    this.werewolfActive = false,
    this.werewolfT = 0,
  });

  final ThemeKind kind;
  final double loop;
  final double topInset;
  final bool animate;
  final double climate; // 0..1 over 17 min cycle
  final bool houseGarlandOn;
  final bool houseLightsOn;
  final bool castleLightsOn;
  final int fieldGlow;
  final List<_FireworkShow> fireworks;
  final int spiderPhase;
  final double spiderProgress;
  final double spiderX;
  final int moonTaps;
  final bool moonFlicker;
  final double moonFlickerPhase;
  final bool werewolfActive;
  final double werewolfT;

  // Phase boundaries (must match state constants).
  static const snowEnd = 5.0 / 17.0;
  static const meltEnd = 10.0 / 17.0;
  static const dayEnd = 12.0 / 17.0;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.halloween:
        _halloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _christmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _cosmos(canvas, size);
        break;
      case ThemeKind.pink:
        _pink(canvas, size);
        break;
      case ThemeKind.aurora:
        _aurora(canvas, size);
        break;
      case ThemeKind.autumn:
        _autumn(canvas, size);
        break;
      default:
        break;
    }
  }

  // ---- Halloween ----

  void _halloween(Canvas canvas, Size size) {
    final flicker =
        animate ? 0.72 + 0.28 * math.sin(loop * math.pi * 2) : 0.78;

    // Dark sky + stars
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFF080A10).withValues(alpha: 0.55),
    );
    final star = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 60; i++) {
      final x = _hash(i, 0.21) * size.width;
      final y = _hash(i, 0.63) * size.height * 0.55;
      final tw = 0.25 +
          0.55 *
              (0.5 +
                  0.5 *
                      math.sin(loop * math.pi * 2 * (0.7 + _hash(i, 0.4)) + i));
      star.color = const Color(0xFFE8E4D8).withValues(alpha: tw * 0.7);
      canvas.drawCircle(Offset(x, y), 0.6 + _hash(i, 0.9) * 0.9, star);
    }

    // Blood-moon cycle over 10 minutes (wall clock).
    final bloodT = ((DateTime.now().millisecondsSinceEpoch % (10 * 60 * 1000)) /
            (10 * 60 * 1000))
        .clamp(0.0, 1.0);
    final moonColor = Color.lerp(
      const Color(0xFFEDE6CF),
      const Color(0xFFB01020),
      bloodT,
    )!;
    final glowColor = Color.lerp(
      const Color(0xFFE8DCC0),
      const Color(0xFF8B0000),
      bloodT,
    )!;
    final moon = Offset(size.width * 0.16, topInset + 88);
    // Standard soft lunar glow + blood tint over time.
    canvas.drawCircle(
      moon,
      70,
      Paint()
        ..color = glowColor.withValues(alpha: 0.10 + bloodT * 0.10)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
    );
    canvas.drawCircle(
      moon,
      52,
      Paint()
        ..color = glowColor.withValues(alpha: 0.14 + bloodT * 0.12)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
    );
    // Moon grows with taps (1..8), flickers on 9th.
    final grow = 1.0 + (moonTaps.clamp(0, 8) * 0.12);
    var moonAlpha = 0.94;
    if (moonFlicker) {
      moonAlpha = 0.35 + 0.6 * (0.5 + 0.5 * math.sin(moonFlickerPhase * math.pi * 4));
    }
    final moonR = 34.0 * grow;
    canvas.drawCircle(
      moon,
      moonR * 1.6,
      Paint()
        ..color = glowColor.withValues(alpha: (0.10 + bloodT * 0.10) * moonAlpha)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
    );
    canvas.drawCircle(moon, moonR, Paint()..color = moonColor.withValues(alpha: moonAlpha));
    canvas.drawCircle(
      moon + Offset(-6 * grow, 4 * grow),
      7 * grow,
      Paint()
        ..color = Color.lerp(const Color(0xFFC9BFA0), const Color(0xFF6A1018), bloodT)!
            .withValues(alpha: 0.28 * moonAlpha),
    );

    final fieldTop = size.height * 0.52;
    canvas.drawRect(
      Rect.fromLTRB(0, fieldTop, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF2A2420).withValues(alpha: 0.55),
            const Color(0xFF1C1816).withValues(alpha: 0.9),
          ],
        ).createShader(Rect.fromLTRB(0, fieldTop, size.width, size.height)),
    );
    _halloweenFieldDetails(canvas, size, fieldTop);

    final castleBase = Offset(size.width * 0.74, fieldTop);
    final castleW = size.width * 0.32;
    _gothicCastle(canvas, castleBase, castleW, flicker);

    // 8 decorative field pumpkins (+ 2 interactive widgets = 10).
    _fieldPumpkins(canvas, size, fieldTop, castleBase, castleW);
    _drawSpider(canvas, size);
  }

  void _halloweenFieldDetails(Canvas canvas, Size size, double fieldTop) {
    final soil = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 28; i++) {
      final x = _hash(i, 0.11) * size.width;
      final y = fieldTop + 8 + _hash(i, 0.37) * (size.height - fieldTop - 40);
      final w = 18 + _hash(i, 0.55) * 36;
      final h = 6 + _hash(i, 0.72) * 12;
      soil.color = Color.lerp(
        const Color(0xFF1A1612),
        const Color(0xFF3A3028),
        _hash(i, 0.29),
      )!.withValues(alpha: 0.35 + _hash(i, 0.81) * 0.25);
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, y), width: w, height: h),
        soil,
      );
    }
    final grass = Paint()
      ..color = const Color(0xFF3A4A28).withValues(alpha: 0.45)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 40; i++) {
      final x = (i / 39.0) * size.width + (_hash(i, 0.17) - 0.5) * 10;
      final base = fieldTop + 2 + _hash(i, 0.44) * 10;
      final h = 6 + _hash(i, 0.61) * 12;
      canvas.drawLine(Offset(x, base), Offset(x - 2, base - h), grass);
      canvas.drawLine(Offset(x, base), Offset(x + 1.5, base - h * 0.85), grass);
      canvas.drawLine(Offset(x, base), Offset(x + 3, base - h * 0.7), grass);
    }
    for (var i = 0; i < 12; i++) {
      final x = _hash(i, 0.91) * size.width;
      final y = fieldTop + 30 + _hash(i, 0.23) * (size.height - fieldTop - 60);
      final r = 3.0 + _hash(i, 0.48) * 5.0;
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, y), width: r * 2.2, height: r * 1.3),
        Paint()..color = const Color(0xFF4A4540).withValues(alpha: 0.4),
      );
    }
    final pathPaint = Paint()
      ..color = const Color(0xFF2A2218).withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;
    final trail = Path()
      ..moveTo(size.width * 0.42, size.height)
      ..quadraticBezierTo(
        size.width * 0.48,
        fieldTop + (size.height - fieldTop) * 0.55,
        size.width * 0.68,
        fieldTop + 20,
      )
      ..lineTo(size.width * 0.78, fieldTop + 20)
      ..quadraticBezierTo(
        size.width * 0.55,
        fieldTop + (size.height - fieldTop) * 0.55,
        size.width * 0.52,
        size.height,
      )
      ..close();
    canvas.drawPath(trail, pathPaint);
  }

  void _drawSpider(Canvas canvas, Size size) {
    if (spiderPhase == 0) return;
    final originY = topInset + 4;
    final hangY = size.height * 0.28;
    double y;
    if (spiderPhase == 1) {
      y = originY + (hangY - originY) * Curves.easeInOut.transform(spiderProgress);
    } else if (spiderPhase == 2) {
      y = hangY + math.sin(spiderProgress * math.pi * 2) * 3;
    } else {
      y = hangY + (originY - hangY) * Curves.easeIn.transform(spiderProgress);
    }
    final x = spiderX * size.width;
    canvas.drawLine(
      Offset(x, originY),
      Offset(x, y),
      Paint()
        ..color = const Color(0xFFD8D0C8).withValues(alpha: 0.55)
        ..strokeWidth = 1.0,
    );
    final body = Offset(x, y + 6);
    canvas.drawCircle(
      body,
      5.5,
      Paint()..color = const Color(0xFF1A1210).withValues(alpha: 0.92),
    );
    canvas.drawCircle(
      body + const Offset(0, -5),
      3.2,
      Paint()..color = const Color(0xFF221814).withValues(alpha: 0.95),
    );
    final leg = Paint()
      ..color = const Color(0xFF1A1210).withValues(alpha: 0.85)
      ..strokeWidth = 1.15
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 4; i++) {
      final side = i < 2 ? -1.0 : 1.0;
      final k = i % 2;
      final sway = math.sin(loop * math.pi * 2 * 1.4 + i) * 2.0;
      canvas.drawLine(
        body,
        body + Offset(side * (10 + k * 4) + sway, 4.0 + k * 5),
        leg,
      );
      canvas.drawLine(
        body,
        body + Offset(side * (12 + k * 3) + sway, -2.0 - k * 3),
        leg,
      );
    }
  }

  void _fieldPumpkins(Canvas canvas, Size size, double fieldTop,
      Offset castleBase, double castleW) {
    // 8 decorative field pumpkins + 2 interactive widgets = 10 total.
    // Larger sizes; skip outer ends of last row (widgets).
    final gridTop = fieldTop + 28;
    final rowH = math.min(52.0, (size.height * 0.74 - gridTop) / 3);
    final colW = (size.width - 72) / 3;
    final positions = <Offset>[];
    for (var row = 0; row < 3; row++) {
      for (var col = 0; col < 3; col++) {
        if (row == 2 && (col == 0 || col == 2)) continue; // interactive slots
        final x = 36 + colW * col;
        final y = gridTop + rowH * row;
        final castleLeft = castleBase.dx - castleW * 0.45;
        final castleRight = castleBase.dx + castleW * 0.45;
        if (y < fieldTop + 56 && x > castleLeft && x < castleRight) continue;
        positions.add(Offset(x, y));
      }
    }
    // Cap at 8 decorative.
    for (var i = 0; i < positions.length && i < 8; i++) {
      final r = 11.0 + (i % 4) * 2.2;
      _drawFieldPumpkin(canvas, positions[i], r, fieldGlow, flicker: 0.85);
    }
  }

  void _drawFieldPumpkin(Canvas canvas, Offset c, double r, int glow,
      {double flicker = 0.8}) {
    final base = const Color(0xFFB27B54);
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy, c.dx - r * 0.9,
          c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();

    // Soft ground light around the pumpkin when lit (not past a huge radius).
    if (glow > 0) {
      final a = (0.12 + glow * 0.06) * flicker;
      canvas.drawCircle(
        c + Offset(0, r * 0.4),
        r * (1.8 + glow * 0.25),
        Paint()
          ..color = const Color(0xFFFFB040).withValues(alpha: a)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
    }

    final fillA = glow > 0 ? (0.22 + glow * 0.18) * flicker : 0.06;
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFFFB040).withValues(alpha: fillA)
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = base.withValues(alpha: 0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.15,
    );
    canvas.drawLine(
      Offset(c.dx, c.dy - r * 0.7),
      Offset(c.dx, c.dy - r * 1.0),
      Paint()
        ..color = base.withValues(alpha: 0.85)
        ..strokeWidth = 1.15,
    );
  }

  void _gothicCastle(
      Canvas canvas, Offset base, double width, double flicker) {
    final h = width * 1.05;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF2A2228).withValues(alpha: 0.75);
    final roof = Paint()..color = const Color(0xFF1A151A).withValues(alpha: 0.88);
    final lit = castleLightsOn;
    final light = Paint()
      ..color = lit
          ? const Color(0xFFE8B86A).withValues(alpha: 0.7 * flicker)
          : const Color(0xFF2A2018).withValues(alpha: 0.8);

    // Soft window glow on the ground in front of the castle.
    if (lit) {
      canvas.drawCircle(
        Offset(base.dx, bottom + 18),
        width * 0.55,
        Paint()
          ..color = const Color(0xFFE8B86A).withValues(alpha: 0.12 * flicker)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22),
      );
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(base.dx, bottom + 8),
          width: width * 0.85,
          height: 28,
        ),
        Paint()
          ..color = const Color(0xFFFFD080).withValues(alpha: 0.08 * flicker)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12),
      );
    }

    canvas.drawRect(
        Rect.fromLTRB(
            left + width * 0.28, top + h * 0.36, left + width * 0.72, bottom),
        body);
    canvas.drawPath(
      Path()
        ..moveTo(left + width * 0.26, top + h * 0.36)
        ..lineTo(left + width * 0.5, top + h * 0.06)
        ..lineTo(left + width * 0.74, top + h * 0.36)
        ..close(),
      roof,
    );

    // Keep windows in the main body too.
    if (lit) {
      for (final wx in [0.38, 0.50, 0.62]) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromCenter(
              center: Offset(left + width * wx, top + h * 0.55),
              width: width * 0.06,
              height: h * 0.08,
            ),
            const Radius.circular(1),
          ),
          light,
        );
      }
    }

    void tower(double cx, double tw, double th) {
      final tLeft = cx - tw / 2;
      final tTop = bottom - th;
      canvas.drawRect(
          Rect.fromLTWH(tLeft, tTop + th * 0.16, tw, th * 0.84), body);
      canvas.drawPath(
        Path()
          ..moveTo(tLeft - 1, tTop + th * 0.2)
          ..lineTo(cx, tTop - th * 0.12)
          ..lineTo(tLeft + tw + 1, tTop + th * 0.2)
          ..close(),
        roof,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: Offset(cx, tTop + th * 0.5),
              width: tw * 0.14,
              height: th * 0.07),
          const Radius.circular(1),
        ),
        light,
      );
    }

    tower(left + width * 0.12, width * 0.15, h * 0.52);
    tower(left + width * 0.28, width * 0.13, h * 0.6);
    tower(left + width * 0.72, width * 0.13, h * 0.6);
    tower(left + width * 0.88, width * 0.15, h * 0.52);
  }

  // ---- Christmas climate cycle ----
  // 0..snowEnd  : night, snow falls, moon center, drift grows
  // snowEnd..meltEnd : no new snow, moon→left, sun↑, melt
  // meltEnd..dayEnd  : day hold, sun center
  // dayEnd..1        : sun→left, moon from right→center, then snow again

  void _christmas(Canvas canvas, Size size) {
    final groundY = size.height * 0.70;
    final c = climate;
    // Day factor 0=night, 1=full day — smooth transitions, never a hard cut.
    double dayFactor;
    if (c < snowEnd) {
      dayFactor = 0;
    } else if (c < meltEnd) {
      dayFactor = Curves.easeInOut.transform(
          ((c - snowEnd) / (meltEnd - snowEnd)).clamp(0.0, 1.0));
    } else if (c < dayEnd) {
      dayFactor = 1;
    } else {
      dayFactor = 1 -
          Curves.easeInOut
              .transform(((c - dayEnd) / (1 - dayEnd)).clamp(0.0, 1.0));
    }

    final nightTop = const Color(0xFF070A12);
    final nightBot = const Color(0xFF101820);
    final dayTop = const Color(0xFF7EC8E8);
    final dayBot = const Color(0xFFB8DCF0);
    Color lerpC(Color a, Color b, double t) => Color.lerp(a, b, t)!;

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            lerpC(nightTop, dayTop, dayFactor),
            lerpC(nightBot, dayBot, dayFactor),
          ],
        ).createShader(Offset.zero & size),
    );

    // Stars fade out as day arrives.
    if (dayFactor < 0.95) {
      final star = Paint()..style = PaintingStyle.fill;
      for (var i = 0; i < 70; i++) {
        final x = _hash(i, 0.31) * size.width;
        final y = _hash(i, 0.77) * size.height * 0.58;
        final tw = 0.2 +
            0.6 *
                (0.5 +
                    0.5 *
                        math.sin(
                            loop * math.pi * 2 * (0.6 + _hash(i, 0.2)) + i));
        star.color = const Color(0xFFEDE8D8)
            .withValues(alpha: tw * 0.75 * (1 - dayFactor));
        canvas.drawCircle(Offset(x, y), 0.55 + _hash(i, 0.5) * 1.0, star);
      }
    }

    // Constellations only at night; one random pattern per local night.
    if (dayFactor < 0.35) {
      _constellations(canvas, size, 1.0 - dayFactor);
    }

    // Clouds only visible by day; opacity follows dayFactor.
    if (dayFactor > 0.05) {
      _clouds(canvas, size, dayFactor);
    }

    // Forest behind the house (silhouette band).
    _forest(canvas, size, groundY);

    // Snow field: dimmer at night, brighter by day — smooth via dayFactor.
    final groundColor = Color.lerp(
      const Color(0xFF9AA29E),
      const Color(0xFFE8EEF0),
      dayFactor,
    )!;
    canvas.drawRect(
      Rect.fromLTRB(0, groundY * 0.92, size.width, size.height),
      Paint()..color = groundColor,
    );
    _detailedGround(canvas, size, groundY, dayFactor);

    // Celestial bodies from screen edges.
    _celestial(canvas, size);

    // Soft moon light pool only near the house at night.
    final houseBase = Offset(size.width * 0.5, groundY);
    if (dayFactor < 0.85) {
      canvas.drawCircle(
        Offset(houseBase.dx, groundY + 8),
        size.width * 0.28,
        Paint()
          ..color = const Color(0xFFD8D0B8)
              .withValues(alpha: 0.10 * (1 - dayFactor))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
      );
    }

    // Drift on top of the field.
    final drift = _driftAmount(c);
    _snowdrift(canvas, size, groundY, drift);

    // Local garland reflection on snow under the house only.
    if (houseGarlandOn && animate) {
      final shimmer = 0.03 +
          0.04 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 * 2.3));
      canvas.drawCircle(
        Offset(houseBase.dx, groundY + 6),
        size.width * 0.2,
        Paint()
          ..color = const Color(0xFFFFE0A0).withValues(alpha: shimmer)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16),
      );
    }

    _twoStoryHouse(canvas, houseBase, size.width * 0.34);

    _fir(canvas, Offset(30, groundY), 40, const Color(0xFF2E4A34));
    _fir(canvas, Offset(size.width - 30, groundY), 34, const Color(0xFF2A4430));

    _snowfall(canvas, size, groundY, c, houseBase);
    _drawFireworks(canvas, size, groundY);
  }

  void _drawFireworks(Canvas canvas, Size size, double groundY) {
    if (fireworks.isEmpty) return;
    final now = DateTime.now().millisecondsSinceEpoch / 1000.0;
    double groundLight = 0;
    for (final fw in fireworks) {
      final age = now - fw.startSec;
      if (age < 0 || age > fw.duration) continue;
      final t = (age / fw.duration).clamp(0.0, 1.0);
      final cx = fw.x * size.width;
      final cy = fw.y * size.height;
      // 50 presets → palette, shape, particle count, trail style.
      final preset = fw.preset;
      final palette = _fireworkPalette(preset);
      final shape = preset % 5; // 0 sphere, 1 ring, 2 chrysanthemum, 3 willow, 4 palm
      final particles = 28 + (preset % 10) * 4;
      final burstPeak = 0.18 + (preset % 7) * 0.02;
      final expand = Curves.easeOut.transform((t / 0.55).clamp(0.0, 1.0));
      final fade = t < 0.45 ? 1.0 : (1 - (t - 0.45) / 0.55).clamp(0.0, 1.0);
      final radius = (36.0 + (preset % 12) * 6.0) * expand;

      // Rising spark before burst.
      if (t < burstPeak) {
        final rise = t / burstPeak;
        final sy = groundY - 20 - rise * (groundY - cy - 20);
        canvas.drawCircle(
          Offset(cx, sy),
          2.2,
          Paint()..color = palette[0].withValues(alpha: 0.9 * (1 - rise * 0.3)),
        );
        canvas.drawLine(
          Offset(cx, sy + 10),
          Offset(cx, sy),
          Paint()
            ..color = palette[0].withValues(alpha: 0.45)
            ..strokeWidth = 1.5,
        );
        continue;
      }

      final localT = ((t - burstPeak) / (1 - burstPeak)).clamp(0.0, 1.0);
      for (var i = 0; i < particles; i++) {
        final ang = (i / particles) * math.pi * 2 + preset * 0.17;
        var dist = radius;
        if (shape == 1) {
          // ring
          dist = radius * (0.85 + 0.15 * math.sin(i * 1.7));
        } else if (shape == 2) {
          dist = radius * (0.55 + 0.45 * ((i * 7) % 5) / 4);
        } else if (shape == 3) {
          // willow — droops
          dist = radius * (0.7 + 0.3 * localT);
        } else if (shape == 4) {
          // palm — upward bias
          dist = radius * (0.6 + 0.5 * math.cos(ang).abs());
        }
        var px = cx + math.cos(ang) * dist * (0.4 + 0.6 * expand);
        var py = cy + math.sin(ang) * dist * (0.4 + 0.6 * expand);
        if (shape == 3) {
          py += localT * localT * 50; // gravity droop
        } else if (shape == 4) {
          py -= localT * 18;
        } else {
          py += localT * localT * 22;
        }
        final col = palette[i % palette.length];
        final a = fade * (0.55 + 0.45 * (1 - localT));
        canvas.drawCircle(
          Offset(px, py),
          1.4 + (preset % 3) * 0.4,
          Paint()..color = col.withValues(alpha: a),
        );
        if (shape == 3 || shape == 2) {
          canvas.drawLine(
            Offset(px, py),
            Offset(px - math.cos(ang) * 6, py - math.sin(ang) * 6 + 4),
            Paint()
              ..color = col.withValues(alpha: a * 0.45)
              ..strokeWidth = 1.0,
          );
        }
      }
      // Core flash
      if (localT < 0.25) {
        canvas.drawCircle(
          Offset(cx, cy),
          10 * (1 - localT * 4),
          Paint()
            ..color = Colors.white.withValues(alpha: 0.55 * (1 - localT * 4))
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
        );
      }
      groundLight = math.max(groundLight, fade * 0.35 * (1 - localT * 0.5));
    }
    // Illuminate the whole ground.
    if (groundLight > 0.02) {
      canvas.drawRect(
        Rect.fromLTRB(0, groundY * 0.9, size.width, size.height),
        Paint()
          ..color = const Color(0xFFFFE8C0).withValues(alpha: groundLight * 0.55)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30),
      );
      canvas.drawCircle(
        Offset(size.width * 0.5, groundY + 10),
        size.width * 0.55,
        Paint()
          ..color = const Color(0xFFFFD080).withValues(alpha: groundLight * 0.4)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
      );
    }
  }

  List<Color> _fireworkPalette(int preset) {
    const all = <List<Color>>[
      [Color(0xFFFF5252), Color(0xFFFF8A80), Color(0xFFFFD180)],
      [Color(0xFF82B1FF), Color(0xFFB388FF), Color(0xFFEA80FC)],
      [Color(0xFF69F0AE), Color(0xFFB2FF59), Color(0xFFFFFF8D)],
      [Color(0xFFFFAB40), Color(0xFFFFD740), Color(0xFFFF8A65)],
      [Color(0xFF80D8FF), Color(0xFFA7FFEB), Color(0xFFE0F7FA)],
      [Color(0xFFFF80AB), Color(0xFFFF4081), Color(0xFFF8BBD0)],
      [Color(0xFFFFFF00), Color(0xFFFFEA00), Color(0xFFFFF59D)],
      [Color(0xFFE040FB), Color(0xFF7C4DFF), Color(0xFFB388FF)],
      [Color(0xFFFF6E40), Color(0xFFFF3D00), Color(0xFFFFAB91)],
      [Color(0xFF64FFDA), Color(0xFF00E5FF), Color(0xFF18FFFF)],
    ];
    return all[preset % all.length];
  }


  void _constellations(Canvas canvas, Size size, double night) {
    // Pick constellation by local date so it stays stable through the night.
    final dayIndex = DateTime.now().difference(DateTime(2020)).inDays;
    final seed = dayIndex % 8;
    final origin = Offset(size.width * (0.25 + (seed % 3) * 0.2),
        topInset + 70 + (seed % 4) * 18.0);
    final patterns = <List<Offset>>[
      // Big dipper-ish
      [Offset(0, 20), Offset(18, 10), Offset(36, 8), Offset(52, 14), Offset(60, 30), Offset(42, 38), Offset(24, 34)],
      // Cassiopeia W
      [Offset(0, 20), Offset(16, 4), Offset(32, 22), Offset(48, 2), Offset(64, 18)],
      // Orion belt + shoulders
      [Offset(10, 0), Offset(50, 6), Offset(20, 28), Offset(32, 30), Offset(44, 28), Offset(16, 55), Offset(48, 58)],
      // Triangle
      [Offset(0, 40), Offset(30, 0), Offset(60, 40), Offset(0, 40)],
      // Cross decimated
      [Offset(30, 0), Offset(30, 50), Offset(0, 22), Offset(60, 22), Offset(30, 22)],
      // Arc
      [Offset(0, 30), Offset(12, 14), Offset(28, 6), Offset(44, 8), Offset(58, 18), Offset(68, 34)],
      // House
      [Offset(10, 40), Offset(10, 18), Offset(30, 0), Offset(50, 18), Offset(50, 40), Offset(10, 40)],
      // Spiral points
      [Offset(30, 30), Offset(42, 22), Offset(48, 34), Offset(36, 44), Offset(22, 38), Offset(20, 24), Offset(34, 18)],
    ];
    final pts = patterns[seed];
    final line = Paint()
      ..color = const Color(0xFFD8E0F0).withValues(alpha: 0.22 * night)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    final star = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < pts.length - 1; i++) {
      canvas.drawLine(origin + pts[i], origin + pts[i + 1], line);
    }
    for (var i = 0; i < pts.length; i++) {
      final tw = 0.55 +
          0.45 *
              (0.5 +
                  0.5 *
                      math.sin(loop * math.pi * 2 * (0.7 + i * 0.05) + i));
      star.color =
          const Color(0xFFE8EEFF).withValues(alpha: tw * 0.85 * night);
      canvas.drawCircle(origin + pts[i], 1.6 + (i % 3) * 0.4, star);
    }
  }

  void _detailedGround(Canvas canvas, Size size, double groundY, double dayFactor) {
    // Soft undulating snow banks.
    final bank = Paint()
      ..color = Color.lerp(
        const Color(0xFF8A9290),
        const Color(0xFFDCE4E8),
        dayFactor,
      )!.withValues(alpha: 0.35);
    for (var i = 0; i < 7; i++) {
      final x = size.width * (i / 6);
      final y = groundY + 6 + _hash(i, 0.2) * 18;
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(x, y),
          width: 80 + _hash(i, 0.5) * 60,
          height: 16 + _hash(i, 0.7) * 10,
        ),
        bank,
      );
    }
    // Tiny sparkles / crystals on snow by day.
    if (dayFactor > 0.3) {
      final spark = Paint()..style = PaintingStyle.fill;
      for (var i = 0; i < 40; i++) {
        final x = _hash(i, 0.11) * size.width;
        final y = groundY + 4 + _hash(i, 0.33) * (size.height - groundY - 8);
        spark.color = const Color(0xFFFFFFFF)
            .withValues(alpha: 0.12 * dayFactor * (0.5 + 0.5 * math.sin(loop * 4 + i)));
        canvas.drawCircle(Offset(x, y), 0.8 + _hash(i, 0.9), spark);
      }
    }
    // Footprints / path near house
    final pathPaint = Paint()
      ..color = Color.lerp(
        const Color(0xFF7A8480),
        const Color(0xFFC8D0D4),
        dayFactor,
      )!.withValues(alpha: 0.25);
    for (var i = 0; i < 8; i++) {
      final t = i / 7.0;
      final x = size.width * (0.35 + t * 0.15);
      final y = groundY + 10 + t * 40 + math.sin(t * 6) * 3;
      canvas.drawOval(
        Rect.fromCenter(center: Offset(x, y), width: 7, height: 4),
        pathPaint,
      );
    }
  }

  void _clouds(Canvas canvas, Size size, double opacity) {
    final cloud = Paint()
      ..color = const Color(0xFFFFFFFF).withValues(alpha: 0.5 * opacity);
    void puff(double x, double y, double s) {
      // Only draw while fully/partially on screen; never pop mid-frame.
      if (x < -80 || x > size.width + 80) return;
      canvas.drawCircle(Offset(x, y), 14 * s, cloud);
      canvas.drawCircle(Offset(x + 12 * s, y + 2 * s), 12 * s, cloud);
      canvas.drawCircle(Offset(x - 12 * s, y + 3 * s), 11 * s, cloud);
      canvas.drawCircle(Offset(x + 4 * s, y - 6 * s), 10 * s, cloud);
    }

    // Travel fully off-screen, then a short gap, then re-enter from the opposite edge.
    // periodSec = time to cross (screen + margins) + gap off-screen.
    final sec = animate
        ? DateTime.now().millisecondsSinceEpoch / 1000.0
        : 0.0;

    void driftCloud(int id, double y, double s, double pxPerSec, double phase) {
      final margin = 90.0;
      final travel = size.width + margin * 2;
      final travelSec = travel / pxPerSec;
      final gapSec = 3.5 + _hash(id, 0.4) * 4.0;
      final period = travelSec + gapSec;
      final t = (sec / period + phase) % 1.0;
      // Visible only during the travel portion.
      if (t > travelSec / period) return;
      final u = t / (travelSec / period);
      // Alternate direction by id.
      final leftToRight = id.isEven;
      final x = leftToRight
          ? -margin + u * travel
          : size.width + margin - u * travel;
      puff(x, y, s);
    }

    driftCloud(0, topInset + 70, 1.1, 8.0, 0.00);
    driftCloud(1, topInset + 100, 0.9, 5.5, 0.22);
    driftCloud(2, topInset + 60, 1.0, 7.0, 0.47);
    driftCloud(3, topInset + 85, 0.85, 4.0, 0.71);
  }

  void _forest(Canvas canvas, Size size, double groundY) {
    // Fully opaque night forest band (no transparency).
    final fill = Paint()
      ..color = const Color(0xFF152218)
      ..style = PaintingStyle.fill;
    final fill2 = Paint()
      ..color = const Color(0xFF0E1812)
      ..style = PaintingStyle.fill;
    // Solid undergrowth so sky never shows through.
    canvas.drawRect(
      Rect.fromLTRB(0, groundY - 28, size.width, groundY + 2),
      fill2,
    );
    for (var i = 0; i < 32; i++) {
      final x = size.width * (i / 31.0);
      final h = 42.0 + _hash(i, 0.44) * 56.0;
      final top = groundY - h;
      final half = 11.0 + _hash(i, 0.2) * 9.0;
      final path = Path()
        ..moveTo(x, groundY)
        ..lineTo(x - half, groundY)
        ..lineTo(x, top)
        ..lineTo(x + half, groundY)
        ..close();
      canvas.drawPath(path, fill);
      canvas.drawPath(
        Path()
          ..moveTo(x, top + h * 0.28)
          ..lineTo(x - half * 0.7, top + h * 0.5)
          ..lineTo(x + half * 0.7, top + h * 0.5)
          ..close(),
        fill2,
      );
    }
  }

  double _driftAmount(double c) {
    if (c < snowEnd) {
      // Land delay + slow ease-in so the drift grows gradually.
      final t = ((c / snowEnd) - 0.12) / 0.88;
      return Curves.easeIn.transform(t.clamp(0.0, 1.0));
    }
    if (c < meltEnd) {
      final t = (c - snowEnd) / (meltEnd - snowEnd);
      return (1.0 - Curves.easeInOut.transform(t)).clamp(0.0, 1.0);
    }
    return 0.0;
  }

  void _celestial(Canvas canvas, Size size) {
    final c = climate;
    final center = Offset(size.width * 0.5, topInset + 90);
    final leftOff = Offset(-60, topInset + 105);
    final rightOff = Offset(size.width + 60, topInset + 105);
    final sunBottomRight = Offset(size.width + 50, size.height * 0.9);

    Offset? moonPos;
    Offset? sunPos;
    double moonA = 0;
    double sunA = 0;

    if (c < snowEnd) {
      // Night only — moon centered, no sun.
      moonPos = center;
      moonA = 1;
    } else if (c < meltEnd) {
      // Split melt: first half moon exits, second half sun enters.
      // Never both visible.
      final t = ((c - snowEnd) / (meltEnd - snowEnd)).clamp(0.0, 1.0);
      if (t < 0.5) {
        final u = Curves.easeInOut.transform(t * 2);
        moonPos = Offset.lerp(center, leftOff, u)!;
        moonA = 1 - u * 0.15; // still solid until past edge
        sunPos = null;
      } else {
        final u = Curves.easeInOut.transform((t - 0.5) * 2);
        moonPos = null;
        sunPos = Offset.lerp(sunBottomRight, center, u)!;
        sunA = u;
      }
    } else if (c < dayEnd) {
      // Day hold — sun only.
      sunPos = center;
      sunA = 1;
    } else {
      // Split return: first half sun exits left, second half moon enters right.
      final t = ((c - dayEnd) / (1 - dayEnd)).clamp(0.0, 1.0);
      if (t < 0.5) {
        final u = Curves.easeInOut.transform(t * 2);
        sunPos = Offset.lerp(center, leftOff, u)!;
        sunA = 1 - u * 0.15;
        moonPos = null;
      } else {
        final u = Curves.easeInOut.transform((t - 0.5) * 2);
        sunPos = null;
        moonPos = Offset.lerp(rightOff, center, u)!;
        moonA = u;
      }
    }

    if (moonPos != null && moonA > 0.04) {
      canvas.drawCircle(
        moonPos,
        42,
        Paint()
          ..color = const Color(0xFFD8D0B0).withValues(alpha: 0.07 * moonA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22),
      );
      canvas.drawCircle(
        moonPos,
        24,
        Paint()
          ..color = const Color(0xFFDCD6C0).withValues(alpha: 0.75 * moonA),
      );
      canvas.drawCircle(
        moonPos + const Offset(-5, 3),
        6,
        Paint()
          ..color = const Color(0xFFB8B09A).withValues(alpha: 0.18 * moonA),
      );
    }

    if (sunPos != null && sunA > 0.04) {
      canvas.drawCircle(
        sunPos,
        55,
        Paint()
          ..color = const Color(0xFFFFE0A0).withValues(alpha: 0.18 * sunA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30),
      );
      canvas.drawCircle(
        sunPos,
        26,
        Paint()
          ..color = const Color(0xFFFFD060).withValues(alpha: 0.9 * sunA),
      );
    }
  }

  void _snowfall(
      Canvas canvas, Size size, double groundY, double c, Offset houseBase) {
    // Night snow phase only for *new* flakes. After sunrise, flakes already
    // on screen keep falling until they leave the bottom — no pop-out.
    const count = 200;
    const fallPx = 28.0;
    const cycleMs = 17 * 60 * 1000;
    final span = size.height + 24.0;

    final ms = DateTime.now().millisecondsSinceEpoch;
    final posInCycle = ms % cycleMs;
    final snowEndMs = (snowEnd * cycleMs).round();
    final inSnow = posInCycle < snowEndMs;
    // After snow ends, keep drawing until flakes could finish one screen.
    final afterMs = inSnow ? 0 : (posInCycle - snowEndMs);
    final maxCoastMs = (span / fallPx * 1000).ceil() + 500;
    if (!inSnow && afterMs > maxCoastMs) return;

    final sec = ms / 1000.0;
    final endSec = (ms - afterMs) / 1000.0; // clock second at snow-end (or now)

    final paint = Paint()..style = PaintingStyle.fill;
    final houseTop = houseBase.dy - size.width * 0.34 * 0.9;
    final houseLeft = houseBase.dx - size.width * 0.34 / 2;
    final houseRight = houseBase.dx + size.width * 0.34 / 2;

    for (var i = 0; i < count; i++) {
      final h2 = _hash(i, 0.791);
      final h3 = _hash(i, 0.457);
      final h4 = _hash(i, 0.913);

      late double y;
      if (inSnow) {
        // Continuous fall with wrap only at bottom → re-enter from top.
        y = (sec * fallPx + h2 * span) % span - 12.0;
      } else {
        // Position at the moment snow stopped, then keep falling (no wrap).
        final yAtEnd = (endSec * fallPx + h2 * span) % span - 12.0;
        y = yAtEnd + (afterMs / 1000.0) * fallPx;
        if (y > size.height + 16) continue; // already landed / off-screen
      }

      var x = h3 * size.width + math.sin(sec * 0.7 + h2 * math.pi * 2) * 6.0;
      if (x < 0) x += size.width;
      if (x >= size.width) x -= size.width;

      if (y > houseTop &&
          y < houseTop + 28 &&
          x > houseLeft &&
          x < houseRight) {
        final side = x >= houseBase.dx ? 1.0 : -1.0;
        x += side * 1.5;
        y += 0.8;
      }

      paint.color = const Color(0xFFE8EEF0).withValues(alpha: 0.45 + h4 * 0.2);
      canvas.drawCircle(Offset(x, y), 0.7 + h2 * 0.5, paint);
    }
  }

  double _hash(int i, double salt) {
    final v = math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
    return v - v.floorToDouble();
  }

  void _snowdrift(Canvas canvas, Size size, double groundY, double level) {
    if (level <= 0.001) return;
    // Cover the field, not only a thin strip at the very bottom.
    // Compact drift — still fills over 5 minutes, but stays low.
    final maxH = (size.height - groundY) * 0.22;
    final h = maxH * level;
    final bottom = size.height;
    final path = Path()
      ..moveTo(0, bottom - h * 0.35)
      ..cubicTo(size.width * 0.18, bottom - h * 0.75, size.width * 0.32,
          bottom - h * 0.25, size.width * 0.48, bottom - h * 0.6)
      ..cubicTo(size.width * 0.62, bottom - h * 0.9, size.width * 0.78,
          bottom - h * 0.3, size.width, bottom - h * 0.45)
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x99B0B8B6), Color(0xAA8A9290)],
        ).createShader(Rect.fromLTWH(0, bottom - h, size.width, h)),
    );
  }

  void _twoStoryHouse(Canvas canvas, Offset base, double w) {
    final h = w * 0.95;
    final left = base.dx - w / 2;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF4A3A2A); // fully opaque
    final roofP = Paint()..color = const Color(0xFF3A2A22);
    final trim = Paint()..color = const Color(0xFF2A1E18);

    // Ground floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(left, top + h * 0.48, left + w, bottom),
        const Radius.circular(2),
      ),
      body,
    );
    // Second floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(
            left + w * 0.06, top + h * 0.22, left + w * 0.94, top + h * 0.5),
        const Radius.circular(2),
      ),
      body,
    );
    // Roof
    canvas.drawPath(
      Path()
        ..moveTo(left - 8, top + h * 0.26)
        ..lineTo(base.dx, top)
        ..lineTo(left + w + 8, top + h * 0.26)
        ..close(),
      roofP,
    );
    // Chimney + smoke
    final ch = Rect.fromLTWH(left + w * 0.72, top + h * 0.02, w * 0.1, h * 0.22);
    canvas.drawRect(ch, trim);
    if (animate) {
      for (var i = 0; i < 5; i++) {
        final sy = ch.top - 6 - i * 9 - (loop * 28 + i * 4) % 18;
        final sx = ch.center.dx + math.sin(loop * math.pi * 2 + i) * 3.5;
        canvas.drawCircle(
          Offset(sx, sy),
          3 + i * 0.7,
          Paint()
            ..color = const Color(0xFFB0B0B0).withValues(alpha: 0.18 - i * 0.025),
        );
      }
    }

    // Windows — lit only when house lights are on.
    final winLight = Paint()
      ..color = houseLightsOn
          ? const Color(0xFFFFD080).withValues(alpha: 0.88)
          : const Color(0xFF2A2218).withValues(alpha: 0.9);
    final glow = Paint()
      ..color = const Color(0xFFFFD080).withValues(alpha: 0.14)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    void window(Offset c, double ww, double hh) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: c, width: ww, height: hh),
          const Radius.circular(1.5),
        ),
        winLight,
      );
      if (houseLightsOn) {
        canvas.drawCircle(c + Offset(0, hh), ww * 1.6, glow);
      }
    }

    // 2nd floor windows
    window(Offset(base.dx - w * 0.22, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.05, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.28, top + h * 0.34), w * 0.1, h * 0.1);
    // 1st floor windows
    window(Offset(base.dx - w * 0.28, top + h * 0.68), w * 0.13, h * 0.12);
    window(Offset(base.dx + w * 0.22, top + h * 0.68), w * 0.13, h * 0.12);

    // Field illumination pool — only with lights on.
    if (houseLightsOn) {
      canvas.drawCircle(
        Offset(base.dx, bottom + 12),
        w * 0.7,
        Paint()
          ..color = const Color(0xFFFFD080).withValues(alpha: 0.1)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
      );
    }

    // Door (static)
    final door = Rect.fromLTWH(
        base.dx - w * 0.06, bottom - h * 0.28, w * 0.12, h * 0.28);
    canvas.drawRect(door, Paint()..color = const Color(0xFF2A1A12));
    canvas.drawCircle(Offset(door.right - 4, door.center.dy), 1.4,
        Paint()..color = const Color(0xFFC9A86A));

    // House garland always hangs on the house; bulbs light only when enabled.
    {
      final bulbs = <Offset>[];
      for (var i = 0; i < 12; i++) {
        final t = i / 11.0;
        bulbs.add(Offset(
          left + w * (0.06 + t * 0.88),
          top + h * (0.22 + math.sin(t * math.pi) * -0.04),
        ));
      }
      for (var i = 0; i < 8; i++) {
        final t = i / 7.0;
        bulbs.add(Offset(left + w * (0.1 + t * 0.8), top + h * 0.48));
      }
      for (var i = 0; i < 6; i++) {
        final t = i / 5.0;
        bulbs.add(Offset(left + w * (0.12 + t * 0.76), top + h * 0.72));
      }

      final wire = Paint()
        ..color = const Color(0xFF6A7068).withValues(alpha: 0.55)
        ..strokeWidth = 0.9
        ..style = PaintingStyle.stroke;
      for (var i = 0; i < 11; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }
      for (var i = 12; i < 19; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }
      for (var i = 20; i < 25; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }

      const cols = [
        Color(0xFFFFE0A0),
        Color(0xFFFFB0B0),
        Color(0xFFB0E0FF),
        Color(0xFFC0FFC0),
        Color(0xFFE0C0FF),
        Color(0xFFFFD0A0),
      ];
      for (var i = 0; i < bulbs.length; i++) {
        if (houseGarlandOn) {
          final rate = 0.9 + _hash(i, 0.33) * 2.8;
          final phase = _hash(i, 0.71) * math.pi * 2;
          final wave = math.sin(loop * math.pi * 2 * rate + phase);
          final on = !animate || wave > -0.35;
          final pulse = on ? (0.75 + 0.25 * ((wave + 1) * 0.5)) : 0.12;
          final col = cols[i % cols.length];
          if (on) {
            canvas.drawCircle(
              bulbs[i],
              6,
              Paint()
                ..color = col.withValues(alpha: 0.2 * pulse)
                ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
            );
          }
          canvas.drawCircle(
            bulbs[i],
            2.4,
            Paint()..color = col.withValues(alpha: (on ? 0.9 : 0.15) * pulse),
          );
        } else {
          // Unlit bulbs still visible on the wire.
          canvas.drawCircle(
            bulbs[i],
            2.2,
            Paint()..color = const Color(0xFF3A4038).withValues(alpha: 0.85),
          );
        }
      }
    }
  }

  void _fir(Canvas canvas, Offset bottom, double height, Color color) {
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.28, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.12)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.12)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx + height * 0.28, bottom.dy - height * 0.5)
      ..close();
    // Opaque body so trees don't look transparent at night.
    canvas.drawPath(
      path,
      Paint()
        ..color = color.withValues(alpha: 1.0)
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF0E1A12)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );
    canvas.drawLine(
      bottom,
      Offset(bottom.dx, bottom.dy - height * 0.12),
      Paint()
        ..color = const Color(0xFF3A2A18)
        ..strokeWidth = 2.2,
    );
  }

  void _pink(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFFFFF0F5).withValues(alpha: 0.35),
    );

    // 30s window: motifs ease in smoothly, then hold until the next set.
    final ms = DateTime.now().millisecondsSinceEpoch;
    final slot = ms ~/ 30000;
    final progress = ((ms % 30000) / 30000.0).clamp(0.0, 1.0);
    final darkPink = const Color(0xFFC2185B);
    final midPink = const Color(0xFFD81B60);

    final count = 12 + (slot % 4);
    // Draw-in occupies the first ~70% of the window for a softer pace.
    final drawProgress = (progress / 0.70).clamp(0.0, 1.0);

    for (var i = 0; i < count; i++) {
      final start = i / count * 0.85;
      final raw = ((drawProgress - start) / 0.25).clamp(0.0, 1.0);
      final local = Curves.easeInOutCubic.transform(raw);
      if (local <= 0.001) continue;

      final hx = _hash(i + slot * 17, 0.21);
      final hy = _hash(i + slot * 17, 0.67);
      final kind = _hash(i + slot * 17, 0.43);
      final x = hx * size.width;
      final y = hy * size.height;
      // Larger motifs.
      final s = (18.0 + _hash(i, 0.88) * 28.0) * (0.25 + 0.75 * local);
      final a = (0.22 + _hash(i, 0.12) * 0.28) * local;
      final paint = Paint()
        ..color = (kind < 0.5 ? darkPink : midPink).withValues(alpha: a)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0;

      if (kind < 0.45) {
        _drawHeart(canvas, Offset(x, y), s, paint);
      } else if (kind < 0.7) {
        final path = Path();
        for (var k = 0; k < 5; k++) {
          final ang = k * math.pi * 2 / 5;
          final px = x + math.cos(ang) * s * 0.55 * local;
          final py = y + math.sin(ang) * s * 0.55 * local;
          if (k == 0) {
            path.moveTo(px, py);
          } else {
            path.lineTo(px, py);
          }
        }
        path.close();
        canvas.drawPath(path, paint);
        canvas.drawCircle(Offset(x, y), s * 0.18 * local, paint);
      } else {
        final path = Path()
          ..moveTo(x, y - s * 0.5 * local)
          ..lineTo(x + s * 0.4 * local, y)
          ..lineTo(x, y + s * 0.5 * local)
          ..lineTo(x - s * 0.4 * local, y)
          ..close();
        canvas.drawPath(path, paint);
        canvas.drawCircle(Offset(x, y), s * 0.12 * local, paint);
      }
    }
  }

  void _drawHeart(Canvas canvas, Offset c, double s, Paint paint) {
    final path = Path();
    path.moveTo(c.dx, c.dy + s * 0.35);
    path.cubicTo(
      c.dx - s * 0.6, c.dy - s * 0.05,
      c.dx - s * 0.55, c.dy - s * 0.55,
      c.dx, c.dy - s * 0.25,
    );
    path.cubicTo(
      c.dx + s * 0.55, c.dy - s * 0.55,
      c.dx + s * 0.6, c.dy - s * 0.05,
      c.dx, c.dy + s * 0.35,
    );
    canvas.drawPath(path, paint);
  }

  void _cosmos(Canvas canvas, Size size) {
    // Deep space background.
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFF070714).withValues(alpha: 0.35),
    );

    // Nebulae (soft color clouds).
    final nebulaCenters = [
      (Offset(size.width * 0.25, size.height * 0.3), const Color(0xFF6A4A8A)),
      (Offset(size.width * 0.75, size.height * 0.45), const Color(0xFF4A6A9A)),
      (Offset(size.width * 0.5, size.height * 0.7), const Color(0xFF8A5A6A)),
    ];
    for (final n in nebulaCenters) {
      canvas.drawCircle(
        n.$1,
        size.width * 0.22,
        Paint()
          ..color = n.$2.withValues(alpha: 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
      );
      canvas.drawCircle(
        n.$1 + const Offset(20, -10),
        size.width * 0.12,
        Paint()
          ..color = n.$2.withValues(alpha: 0.08)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 24),
      );
    }

    // Field stars.
    for (var i = 0; i < 70; i++) {
      final x = _hash(i, 0.11) * size.width;
      final y = _hash(i, 0.37) * size.height;
      final tw = animate
          ? 0.2 + 0.4 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 * (0.5 + _hash(i, 0.2)) + i))
          : 0.3;
      canvas.drawCircle(
        Offset(x, y),
        0.6 + _hash(i, 0.5) * 1.1,
        Paint()..color = const Color(0xFFD8D0F0).withValues(alpha: tw),
      );
    }

    // Constellations rotate every 10 minutes (wall clock, works in background).
    final tenMin = DateTime.now().millisecondsSinceEpoch ~/ (10 * 60 * 1000);
    final setIdx = tenMin % 4;
    final constellations = <List<Offset>>[
      // Orion-like
      [
        const Offset(0.35, 0.25),
        const Offset(0.42, 0.28),
        const Offset(0.38, 0.36),
        const Offset(0.40, 0.42),
        const Offset(0.36, 0.48),
        const Offset(0.44, 0.48),
        const Offset(0.40, 0.55),
      ],
      // Big dipper-like
      [
        const Offset(0.55, 0.20),
        const Offset(0.62, 0.18),
        const Offset(0.68, 0.22),
        const Offset(0.72, 0.28),
        const Offset(0.70, 0.35),
        const Offset(0.62, 0.36),
        const Offset(0.58, 0.30),
      ],
      // Cassiopeia-like
      [
        const Offset(0.20, 0.35),
        const Offset(0.28, 0.30),
        const Offset(0.34, 0.36),
        const Offset(0.40, 0.28),
        const Offset(0.48, 0.34),
      ],
      // Southern cross-like
      [
        const Offset(0.65, 0.55),
        const Offset(0.65, 0.62),
        const Offset(0.65, 0.70),
        const Offset(0.60, 0.62),
        const Offset(0.70, 0.62),
      ],
    ];
    final stars = constellations[setIdx];
    final line = Paint()
      ..color = const Color(0xFFB0A8D8).withValues(alpha: 0.35)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    final pts = [for (final s in stars) Offset(s.dx * size.width, s.dy * size.height)];
    for (var i = 0; i < pts.length - 1; i++) {
      canvas.drawLine(pts[i], pts[i + 1], line);
    }
    for (final p in pts) {
      canvas.drawCircle(
        p,
        2.2,
        Paint()..color = const Color(0xFFE8E0FF).withValues(alpha: 0.9),
      );
      canvas.drawCircle(
        p,
        5,
        Paint()
          ..color = const Color(0xFFC0B8F0).withValues(alpha: 0.15)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
    }

    // Comets enter from screen edges (never spawn mid-air).
    final sec = DateTime.now().millisecondsSinceEpoch / 1000.0;
    for (var i = 0; i < 5; i++) {
      final period = 7.0 + _hash(i, 0.19) * 12.0;
      final phase = _hash(i, 0.61);
      final cycle = (sec / period + phase) % 1.0;
      // Visible for first ~28% of period, then rest = gap.
      if (cycle > 0.28) continue;
      final t = cycle / 0.28;
      // Edge: 0=top, 1=left, 2=right (slightly varied).
      final edge = (_hash(i, 0.07) * 3).floor() % 3;
      late Offset start;
      late Offset end;
      if (edge == 0) {
        start = Offset(size.width * (0.1 + _hash(i, 0.3) * 0.8), -12);
        end = Offset(start.dx + size.width * 0.25, size.height + 12);
      } else if (edge == 1) {
        start = Offset(-12, size.height * (0.05 + _hash(i, 0.4) * 0.4));
        end = Offset(size.width + 12, start.dy + size.height * 0.45);
      } else {
        start = Offset(size.width + 12, size.height * (0.05 + _hash(i, 0.5) * 0.35));
        end = Offset(-12, start.dy + size.height * 0.5);
      }
      final pos = Offset.lerp(start, end, t)!;
      final prev = Offset.lerp(start, end, (t - 0.04).clamp(0.0, 1.0))!;
      canvas.drawLine(
        prev,
        pos,
        Paint()
          ..color = const Color(0xFFD0C8F8).withValues(alpha: 0.55 * (1 - t * 0.5))
          ..strokeWidth = 2.0
          ..strokeCap = StrokeCap.round,
      );
      canvas.drawCircle(
        pos,
        2.2 + _hash(i, 0.4),
        Paint()..color = const Color(0xFFF0ECFF).withValues(alpha: 0.9),
      );
    }

    // Star-dust drifts in from top edge only.
    for (var i = 0; i < 18; i++) {
      final period = 14.0 + _hash(i, 0.27) * 18.0;
      final t = (sec / period + _hash(i, 0.73)) % 1.0;
      final x = _hash(i, 0.41) * size.width +
          math.sin(t * math.pi * 2 + i) * 12;
      final y = -6 + t * (size.height + 12);
      canvas.drawCircle(
        Offset(x, y),
        0.7 + _hash(i, 0.9) * 0.8,
        Paint()
          ..color = const Color(0xFFD8D0F0).withValues(alpha: 0.35 + 0.25 * (1 - t)),
      );
    }
  }

  void _aurora(Canvas canvas, Size size) {
    // Deep polar night sky.
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF050A12), Color(0xFF0A1520), Color(0xFF0C1820)],
        ).createShader(Offset.zero & size),
    );
    // Stars
    for (var i = 0; i < 80; i++) {
      final x = _hash(i, 0.21) * size.width;
      final y = _hash(i, 0.63) * size.height * 0.7;
      final tw = 0.25 +
          0.55 *
              (0.5 +
                  0.5 *
                      math.sin(loop * math.pi * 2 * (0.5 + _hash(i, 0.4)) + i));
      canvas.drawCircle(
        Offset(x, y),
        0.55 + _hash(i, 0.9) * 0.9,
        Paint()..color = const Color(0xFFE8F0F8).withValues(alpha: tw * 0.75),
      );
    }
    // Aurora curtains
    final bands = [
      (const Color(0xFF40E0A0), 0.0),
      (const Color(0xFF50C8FF), 0.15),
      (const Color(0xFFA070E0), 0.3),
      (const Color(0xFF40E0A0), 0.45),
    ];
    for (var b = 0; b < bands.length; b++) {
      final col = bands[b].$1;
      final phase = bands[b].$2;
      final path = Path();
      final baseY = size.height * (0.12 + b * 0.06);
      path.moveTo(-10, size.height);
      path.lineTo(-10, baseY);
      for (var x = 0.0; x <= size.width + 10; x += 12) {
        final wave = math.sin(x / 70 + loop * math.pi * 2 + phase * math.pi * 2) *
                18 +
            math.sin(x / 40 + loop * math.pi * 3.1 + b) * 10;
        path.lineTo(x, baseY + wave);
      }
      path.lineTo(size.width + 10, size.height);
      path.close();
      canvas.drawPath(
        path,
        Paint()
          ..shader = LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              col.withValues(alpha: 0.28),
              col.withValues(alpha: 0.05),
              col.withValues(alpha: 0.0),
            ],
          ).createShader(Rect.fromLTRB(0, 0, size.width, size.height * 0.75)),
      );
    }
    // Frozen ground
    final groundY = size.height * 0.78;
    canvas.drawRect(
      Rect.fromLTRB(0, groundY, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF1A2830).withValues(alpha: 0.7),
            const Color(0xFF0E181E).withValues(alpha: 0.95),
          ],
        ).createShader(Rect.fromLTRB(0, groundY, size.width, size.height)),
    );
    // Soft aurora reflection on ice
    canvas.drawCircle(
      Offset(size.width * 0.5, groundY + 20),
      size.width * 0.4,
      Paint()
        ..color = const Color(0xFF40E0A0).withValues(alpha: 0.06 + 0.04 * math.sin(loop * math.pi * 2))
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
    );
  }

  void _autumn(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF2A1810), Color(0xFF3A2418), Color(0xFF1A120E)],
        ).createShader(Offset.zero & size),
    );
    // Warm haze sun
    final sun = Offset(size.width * 0.78, topInset + 90);
    canvas.drawCircle(
      sun,
      50,
      Paint()
        ..color = const Color(0xFFFFB060).withValues(alpha: 0.12)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30),
    );
    canvas.drawCircle(
      sun,
      22,
      Paint()..color = const Color(0xFFFFC070).withValues(alpha: 0.55),
    );
    // Tree silhouettes
    final groundY = size.height * 0.68;
    for (var i = 0; i < 9; i++) {
      final x = size.width * (0.05 + i * 0.11) + (_hash(i, 0.3) - 0.5) * 20;
      final h = 70 + _hash(i, 0.5) * 90;
      _autumnTree(canvas, Offset(x, groundY), h);
    }
    // Ground
    canvas.drawRect(
      Rect.fromLTRB(0, groundY, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF3A2818).withValues(alpha: 0.75),
            const Color(0xFF241810).withValues(alpha: 0.95),
          ],
        ).createShader(Rect.fromLTRB(0, groundY, size.width, size.height)),
    );
    // Falling leaves
    final sec = animate
        ? DateTime.now().millisecondsSinceEpoch / 1000.0
        : 0.0;
    const leafColors = [
      Color(0xFFD4652A),
      Color(0xFFC84020),
      Color(0xFFD4A030),
      Color(0xFF8A3020),
      Color(0xFFE07030),
    ];
    for (var i = 0; i < 36; i++) {
      final period = 9.0 + _hash(i, 0.2) * 10.0;
      final t = (sec / period + _hash(i, 0.7)) % 1.0;
      final x = _hash(i, 0.41) * size.width +
          math.sin(t * math.pi * 2 + i) * 28;
      final y = -10 + t * (size.height + 20);
      final rot = t * math.pi * 4 + i;
      final col = leafColors[i % leafColors.length]
          .withValues(alpha: 0.55 + 0.3 * (1 - t));
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(rot);
      final leaf = Path()
        ..moveTo(0, -5)
        ..quadraticBezierTo(5, -1, 0, 6)
        ..quadraticBezierTo(-5, -1, 0, -5)
        ..close();
      canvas.drawPath(leaf, Paint()..color = col);
      canvas.restore();
    }
  }

  void _autumnTree(Canvas canvas, Offset base, double h) {
    final trunk = Paint()
      ..color = const Color(0xFF2A1C12).withValues(alpha: 0.85)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(base, base + Offset(0, -h * 0.55), trunk);
    final crown = Paint()..color = const Color(0xFF8A3A18).withValues(alpha: 0.55);
    canvas.drawCircle(base + Offset(0, -h * 0.7), h * 0.28, crown);
    canvas.drawCircle(
      base + Offset(-h * 0.12, -h * 0.55),
      h * 0.18,
      Paint()..color = const Color(0xFFC06020).withValues(alpha: 0.4),
    );
    canvas.drawCircle(
      base + Offset(h * 0.14, -h * 0.6),
      h * 0.16,
      Paint()..color = const Color(0xFFD08030).withValues(alpha: 0.35),
    );
  }

  @override
  bool shouldRepaint(covariant _AtmospherePainter old) =>
      old.loop != loop ||
      old.climate != climate ||
      old.houseGarlandOn != houseGarlandOn ||
      old.houseLightsOn != houseLightsOn ||
      old.castleLightsOn != castleLightsOn ||
      old.fieldGlow != fieldGlow ||
      old.kind != kind ||
      old.spiderPhase != spiderPhase ||
      old.spiderProgress != spiderProgress ||
      old.fireworks.length != fireworks.length ||
      old.moonTaps != moonTaps ||
      old.moonFlicker != moonFlicker ||
      old.moonFlickerPhase != moonFlickerPhase ||
      old.werewolfActive != werewolfActive ||
      old.werewolfT != werewolfT;
}


class _FireworkShow {
  const _FireworkShow({
    required this.preset,
    required this.startSec,
    required this.x,
    required this.y,
    required this.duration,
  });

  final int preset; // 0..49
  final double startSec;
  final double x; // 0..1
  final double y; // 0..1
  final double duration;
}


class _WerewolfPainter extends CustomPainter {
  _WerewolfPainter({required this.t});
  final double t; // 0..1

  @override
  void paint(Canvas canvas, Size size) {
    // Darken screen
    final dark = (t * 3).clamp(0.0, 0.92);
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = Colors.black.withValues(alpha: dark),
    );
    if (t < 0.15) return;

    // Red eyes in distance (after dark starts)
    final eyeProgress = ((t - 0.15) / 0.25).clamp(0.0, 1.0);
    final eyeY = size.height * 0.42;
    final eyeX = size.width * 0.5;
    final eyeA = eyeProgress * 0.9;
    final eyePaint = Paint()
      ..color = const Color(0xFFFF2020).withValues(alpha: eyeA)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    canvas.drawCircle(Offset(eyeX - 18, eyeY), 5, eyePaint);
    canvas.drawCircle(Offset(eyeX + 18, eyeY), 5, eyePaint);
    canvas.drawCircle(Offset(eyeX - 18, eyeY), 2.2,
        Paint()..color = const Color(0xFFFF6666).withValues(alpha: eyeA));
    canvas.drawCircle(Offset(eyeX + 18, eyeY), 2.2,
        Paint()..color = const Color(0xFFFF6666).withValues(alpha: eyeA));

    // Jump werewolf after ~7/9 of sequence
    if (t < 0.78) return;
    final jump = ((t - 0.78) / 0.12).clamp(0.0, 1.0);
    final cy = size.height * (0.2 + (1 - Curves.easeOutBack.transform(jump)) * 0.7);
    final cx = size.width * 0.5;
    final scale = 0.6 + jump * 0.9;

    // Body
    final fur = Paint()..color = const Color(0xFF2A1A12);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy + 30 * scale), width: 90 * scale, height: 110 * scale),
      fur,
    );
    // Head
    canvas.drawCircle(Offset(cx, cy - 20 * scale), 36 * scale, fur);
    // Ears
    final ear = Path()
      ..moveTo(cx - 28 * scale, cy - 40 * scale)
      ..lineTo(cx - 18 * scale, cy - 70 * scale)
      ..lineTo(cx - 8 * scale, cy - 38 * scale)
      ..close();
    canvas.drawPath(ear, fur);
    final ear2 = Path()
      ..moveTo(cx + 28 * scale, cy - 40 * scale)
      ..lineTo(cx + 18 * scale, cy - 70 * scale)
      ..lineTo(cx + 8 * scale, cy - 38 * scale)
      ..close();
    canvas.drawPath(ear2, fur);
    // Eyes
    canvas.drawCircle(Offset(cx - 12 * scale, cy - 24 * scale), 5 * scale,
        Paint()..color = const Color(0xFFFF1A1A));
    canvas.drawCircle(Offset(cx + 12 * scale, cy - 24 * scale), 5 * scale,
        Paint()..color = const Color(0xFFFF1A1A));
    // Snout + bloody teeth
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy - 6 * scale), width: 34 * scale, height: 22 * scale),
      Paint()..color = const Color(0xFF3A2418),
    );
    final mouth = Paint()..color = const Color(0xFF1A0808);
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy + 4 * scale), width: 28 * scale, height: 14 * scale),
      mouth,
    );
    final tooth = Paint()..color = const Color(0xFFE8E0D0);
    for (final dx in [-8.0, -3.0, 3.0, 8.0]) {
      canvas.drawPath(
        Path()
          ..moveTo(cx + dx * scale, cy * 1 + 0 * scale)
          ..lineTo(cx + (dx - 2) * scale, cy + 12 * scale)
          ..lineTo(cx + (dx + 2) * scale, cy + 12 * scale)
          ..close(),
        tooth,
      );
    }
    // Blood
    final blood = Paint()..color = const Color(0xFF8B0000);
    canvas.drawCircle(Offset(cx - 4 * scale, cy + 14 * scale), 3 * scale, blood);
    canvas.drawCircle(Offset(cx + 6 * scale, cy + 16 * scale), 2.4 * scale, blood);
    // Scream text
    if (jump > 0.6) {
      final tp = TextPainter(
        text: const TextSpan(
          text: 'ААГХР',
          style: TextStyle(
            color: Color(0xFFFF2222),
            fontSize: 42,
            fontWeight: FontWeight.w900,
            letterSpacing: 4,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(cx - tp.width / 2, cy + 80 * scale));
    }
  }

  @override
  bool shouldRepaint(covariant _WerewolfPainter old) => old.t != t;
}
