#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -d android ]]; then
  echo "Android platform folder already exists; skipping bootstrap."
  exit 0
fi

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

flutter create \
  --platforms=android \
  --org com.astronuit \
  --project-name astronuit \
  --android-language kotlin \
  "$TEMP_DIR/astronuit"

cp -R "$TEMP_DIR/astronuit/android" "$ROOT_DIR/android"

MANIFEST="$ROOT_DIR/android/app/src/main/AndroidManifest.xml"
if [[ -f "$MANIFEST" ]]; then
  sed -i 's/android:label="astronuit"/android:label="AstroNuit"/' "$MANIFEST"
  if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
    sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET" />' "$MANIFEST"
  fi
fi

echo "Android platform scaffold created."
