import 'dart:async';

import 'package:flutter/material.dart';\nimport 'dart:io';\nimport 'package:file_picker/file_picker.dart';\nimport '../core/document_importer.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';
import '../core/local_core.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.strings,
    required this.themeKind,
    required this.animationsEnabled,
  });

  final AppStrings strings;
  final ThemeKind themeKind;
  final bool animationsEnabled;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatEntry {
  const _ChatEntry({required this.text, required this.fromUser});
  final String text;
  final bool fromUser;
}

class _ChatScreenState extends State<ChatScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<_ChatEntry> _messages = [];
  late final AnimationController _halloweenGlowController;
  bool _isProcessingPreview = false;

  bool get _shouldGlow =>
      widget.themeKind == ThemeKind.halloween &&
      widget.animationsEnabled &&
      _isProcessingPreview;

  @override
  void initState() {
    super.initState();
    _halloweenGlowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled) {
      if (_shouldGlow) {
        _halloweenGlowController.repeat(reverse: true);
      } else {
        _halloweenGlowController.stop();
        _halloweenGlowController.value = 0;
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _halloweenGlowController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _isProcessingPreview) return;
    setState(() {
      _messages.add(_ChatEntry(text: text, fromUser: true));
      _controller.clear();
      _isProcessingPreview = true;
    });
    if (_shouldGlow) _halloweenGlowController.repeat(reverse: true);
    _scrollToBottom();

    final lang = widget.strings.isRussian ? 'ru' : 'en';
    final reply = await LocalCore.instance.reply(text, languageCode: lang);
    if (!mounted) return;
    setState(() {
      _isProcessingPreview = false;
      _messages.add(_ChatEntry(text: reply, fromUser: false));
    });
    _halloweenGlowController.stop();
    _halloweenGlowController.value = 0;
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 360),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  Future<void> _showAttachmentNotice() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'txt', 'md', 'csv', 'json'],
        withData: false,
      );
      if (result == null || result.files.single.path == null) return;
      final file = File(result.files.single.path!);
      final imported = await DocumentImporter.importFile(file);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Добавлено в базу знаний: ${imported.title} (${imported.chars} символов)')),
      );
      setState(() {
        _messages.add(_ChatEntry(text: 'Файл «${imported.title}» загружен и проиндексирован. Теперь можно задавать вопросы по его содержимому.', fromUser: false));
      });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка импорта: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final s = widget.strings;
    final isEmpty = _messages.isEmpty;

    return Column(
      children: [
        Expanded(
          child: isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          s.appGreeting,
                          style: theme.textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            letterSpacing: -0.6,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          s.greetingSubtitle,
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.68),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                  itemCount: _messages.length + (_isProcessingPreview ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) {
                      return Padding(
                        padding: const EdgeInsets.only(top: 14, bottom: 10),
                        child: Text(
                          s.foxWorking,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
                          ),
                        ),
                      );
                    }
                    final message = _messages[index];
                    return Align(
                      alignment: message.fromUser
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 310),
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 11,
                        ),
                        decoration: BoxDecoration(
                          color: message.fromUser
                              ? theme.colorScheme.primary.withValues(alpha: 0.12)
                              : theme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(message.text),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
            child: AnimatedBuilder(
              animation: _halloweenGlowController,
              builder: (context, child) {
                final glow = _shouldGlow
                    ? _halloweenGlowController.value
                    : 0.0;
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(32),
                    boxShadow: glow > 0
                        ? [
                            BoxShadow(
                              color: const Color(0xFFB7784E)
                                  .withValues(alpha: 0.06 + glow * 0.16),
                              blurRadius: 5 + glow * 15,
                              spreadRadius: glow * 1.2,
                            ),
                          ]
                        : const [],
                  ),
                  child: child,
                );
              },
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    tooltip: s.attach,
                    onPressed: _showAttachmentNotice,
                    icon: const Icon(Icons.add),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      minLines: 1,
                      maxLines: 5,
                      textCapitalization: TextCapitalization.sentences,
                      onSubmitted: (_) => _sendMessage(),
                      decoration: InputDecoration(
                        hintText: s.messageHint,
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 7),
                  IconButton.filled(
                    tooltip: s.send,
                    onPressed: _sendMessage,
                    icon: const Icon(Icons.arrow_upward_rounded),
                  ),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
