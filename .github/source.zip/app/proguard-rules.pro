# No shrinker rules required for the offline WebView shell.
