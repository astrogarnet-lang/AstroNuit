package com.astronuit.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.GeomagneticField;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.CancellationSignal;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.graphics.Color;
import android.view.Surface;
import android.view.WindowManager;

import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int LOCATION_REQUEST = 1707;
    private static final int CAMERA_REQUEST = 1708;
    private WebView web;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private Sensor accelerometerSensor;
    private Sensor magneticSensor;
    private final float[] gravity = new float[3];
    private final float[] magnetic = new float[3];
    private boolean haveGravity = false, haveMagnetic = false;
    private long lastPosePushNs = 0;
    private LocationManager locationManager;
    private boolean sensorsActive = false;
    private Location lastLocation;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final List<CancellationSignal> currentLocationSignals = new ArrayList<>();
    private Runnable locationTimeout;
    private boolean waitingForLocation = false;
    private final float[] rotation = new float[9];
    private final float[] remapped = new float[9];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 23));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 23));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        rotationSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) : null;
        accelerometerSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
        magneticSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) : null;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5, 8, 23));
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        request.deny();
                        return;
                    }
                    java.util.ArrayList<String> grants = new java.util.ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) grants.add(resource);
                    }
                    if (grants.isEmpty()) request.deny();
                    else request.grant(grants.toArray(new String[0]));
                });
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public String appVersion() { return "1.0.0"; }
        @JavascriptInterface public boolean hasOrientationSensor() {
            return rotationSensor != null || (accelerometerSensor != null && magneticSensor != null);
        }
        @JavascriptInterface public boolean startSensors() {
            if (sensorManager == null || (rotationSensor == null && (accelerometerSensor == null || magneticSensor == null))) {
                postJs("window.onSensorError && window.onSensorError('Для точного AR нужны компас и акселерометр')");
                return false;
            }
            runOnUiThread(() -> {
                if (sensorsActive) return;
                haveGravity = false; haveMagnetic = false;
                if (rotationSensor != null) {
                    sensorsActive = sensorManager.registerListener(MainActivity.this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
                } else {
                    boolean a = sensorManager.registerListener(MainActivity.this, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
                    boolean m = sensorManager.registerListener(MainActivity.this, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
                    sensorsActive = a && m;
                }
                if (!sensorsActive) postJs("window.onSensorError && window.onSensorError('Не удалось запустить датчики ориентации')");
            });
            // The UI thread owns sensor registration; the first pose/error callback confirms the result.
            return true;
        }
        @JavascriptInterface public void requestCameraPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                    checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    postJs("window.onCameraPermission && window.onCameraPermission(true)");
                } else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
            });
        }
        @JavascriptInterface public void stopSensors() { runOnUiThread(MainActivity.this::stopSensorsInternal); }
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                } else {
                    fetchLocation();
                }
            });
        }
        @JavascriptInterface public void getLastLocation() {
            runOnUiThread(() -> {
                if (hasLocationPermission()) {
                    Location loc = bestLastKnownLocation();
                    if (loc != null) deliverLocation(loc, "cached");
                }
            });
        }
    }

    private void postJs(String js) {
        if (web == null) return;
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private Location bestLastKnownLocation() {
        if (locationManager == null || !hasLocationPermission()) return null;
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        Location best = null;
        long now = System.currentTimeMillis();
        try {
            for (String provider : locationManager.getProviders(true)) {
                if (!fine && LocationManager.GPS_PROVIDER.equals(provider)) continue;
                Location candidate;
                try { candidate = locationManager.getLastKnownLocation(provider); }
                catch (SecurityException | IllegalArgumentException ignored) { continue; }
                if (candidate == null) continue;
                long age = Math.max(0L, now - candidate.getTime());
                if (age > 24L * 60L * 60L * 1000L) continue;
                if (best == null) { best = candidate; continue; }
                float candidateAccuracy = candidate.hasAccuracy() ? candidate.getAccuracy() : 100000f;
                float bestAccuracy = best.hasAccuracy() ? best.getAccuracy() : 100000f;
                // Prefer a meaningfully more accurate fix; otherwise prefer the newer one.
                if (candidateAccuracy < bestAccuracy * 0.85f ||
                    (candidateAccuracy <= bestAccuracy * 1.15f && candidate.getTime() > best.getTime())) {
                    best = candidate;
                }
            }
        } catch (SecurityException ignored) { }
        return best;
    }

    private void stopLocationRequest() {
        waitingForLocation = false;
        if (locationTimeout != null) {
            mainHandler.removeCallbacks(locationTimeout);
            locationTimeout = null;
        }
        for (CancellationSignal signal : currentLocationSignals) {
            try { signal.cancel(); } catch (Exception ignored) { }
        }
        currentLocationSignals.clear();
        if (locationManager != null) {
            try { locationManager.removeUpdates(this); } catch (SecurityException ignored) { }
        }
    }

    private void fetchLocation() {
        if (locationManager == null || !hasLocationPermission()) {
            postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение не предоставлено')");
            return;
        }
        stopLocationRequest();
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        Location cached = bestLastKnownLocation();
        lastLocation = cached;
        waitingForLocation = true;
        postJs("window.onLocationPending && window.onLocationPending()");
        // Show a recent fix after the pending state so the UI never gets stuck on "locating".
        if (cached != null) deliverLocation(cached, "cached");
        locationTimeout = () -> {
            if (!waitingForLocation) return;
            stopLocationRequest();
            if (lastLocation != null) {
                postJs("window.onLocationTimeout && window.onLocationTimeout(true)");
            } else {
                postJs("window.onLocationTimeout && window.onLocationTimeout(false)");
            }
        };
        mainHandler.postDelayed(locationTimeout, 30000L);

        boolean requested = false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                String[] providers = fine
                    ? new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}
                    : new String[]{LocationManager.NETWORK_PROVIDER};
                for (String provider : providers) {
                    boolean enabled;
                    try { enabled = locationManager.isProviderEnabled(provider); }
                    catch (SecurityException | IllegalArgumentException ignored) { continue; }
                    if (!enabled) continue;
                    CancellationSignal signal = new CancellationSignal();
                    currentLocationSignals.add(signal);
                    try {
                        locationManager.getCurrentLocation(provider, signal, getMainExecutor(), location -> {
                            if (location == null || !waitingForLocation) return;
                            deliverLocation(location, provider);
                            if (!location.hasAccuracy() || location.getAccuracy() <= 70f) stopLocationRequest();
                        });
                        requested = true;
                    } catch (SecurityException | IllegalArgumentException ignored) {
                        currentLocationSignals.remove(signal);
                        signal.cancel();
                    }
                }
            } else {
                // Try each legacy provider independently. A broken GPS provider must not
                // prevent the network provider from delivering a usable location.
                if (fine) {
                    try {
                        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
                            requested = true;
                        }
                    } catch (IllegalArgumentException ignored) {
                        // Continue to network positioning below.
                    }
                }
                try {
                    if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, this, Looper.getMainLooper());
                        requested = true;
                    }
                } catch (IllegalArgumentException ignored) {
                    // No network provider on this device; timeout/error reporting is handled below.
                }
            }
        } catch (SecurityException e) {
            stopLocationRequest();
            postJs("window.onLocationError && window.onLocationError('Нет разрешения на геолокацию')");
            return;
        }
        if (!requested && cached == null) {
            stopLocationRequest();
            postJs("window.onLocationError && window.onLocationError('Провайдеры местоположения выключены или недоступны. Включи геолокацию и попробуй ещё раз.')");
        } else if (!requested && cached != null) {
            stopLocationRequest();
            postJs("window.onLocationTimeout && window.onLocationTimeout(true)");
        }
    }

    private void deliverLocation(Location location, String source) {
        if (location == null) return;
        lastLocation = location;
        String provider = source == null ? "unknown" : source;
        String js = String.format(Locale.US,
            "window.onLocationChanged && window.onLocationChanged(%.7f,%.7f,%.1f,'%s',%d)",
            location.getLatitude(), location.getLongitude(),
            location.hasAccuracy() ? location.getAccuracy() : 0f,
            provider.replace("'", ""), location.getTime());
        postJs(js);
    }

    private void deliverLocation(Location location) {
        deliverLocation(location, location == null ? "unknown" : location.getProvider());
    }

    @Override public void onLocationChanged(Location location) {
        deliverLocation(location, location == null ? "unknown" : location.getProvider());
        if (location != null && location.hasAccuracy() && location.getAccuracy() <= 70f) stopLocationRequest();
    }
    @Override public void onProviderEnabled(String provider) {
        if (hasLocationPermission() && !waitingForLocation) fetchLocation();
    }
    @Override public void onProviderDisabled(String provider) {
        postJs("window.onLocationProviderDisabled && window.onLocationProviderDisabled()");
    }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override public void onSensorChanged(SensorEvent event) {
        if (!sensorsActive || web == null) return;
        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            for (int i = 0; i < 3; i++) gravity[i] = gravity[i] * 0.82f + event.values[i] * 0.18f;
            haveGravity = true;
        } else if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            for (int i = 0; i < 3; i++) magnetic[i] = magnetic[i] * 0.82f + event.values[i] * 0.18f;
            haveMagnetic = true;
        } else if (type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotation, event.values);
        } else return;
        if (rotationSensor == null && (!haveGravity || !haveMagnetic || !SensorManager.getRotationMatrix(rotation, null, gravity, magnetic))) return;
        long nowNs = System.nanoTime();
        if (nowNs - lastPosePushNs < 33_333_333L) return;
        lastPosePushNs = nowNs;
        int axisX = SensorManager.AXIS_X, axisY = SensorManager.AXIS_Y;
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        if (displayRotation == Surface.ROTATION_90) { axisX = SensorManager.AXIS_Y; axisY = SensorManager.AXIS_MINUS_X; }
        else if (displayRotation == Surface.ROTATION_180) { axisX = SensorManager.AXIS_MINUS_X; axisY = SensorManager.AXIS_MINUS_Y; }
        else if (displayRotation == Surface.ROTATION_270) { axisX = SensorManager.AXIS_MINUS_Y; axisY = SensorManager.AXIS_X; }
        SensorManager.remapCoordinateSystem(rotation, axisX, axisY, remapped);

        // Device screen normal (forward), screen right, and screen up, expressed in local ENU axes.
        float[] forward = new float[]{-remapped[2], -remapped[5], -remapped[8]};
        float[] right = new float[]{remapped[0], remapped[3], remapped[6]};
        float[] up = new float[]{-remapped[1], -remapped[4], -remapped[7]};

        // Rotation-vector heading is referenced to magnetic north. Correct to true north if GPS is available.
        Location loc = lastLocation;
        if (loc != null) {
            GeomagneticField field = new GeomagneticField((float)loc.getLatitude(), (float)loc.getLongitude(),
                (float)(loc.hasAltitude() ? loc.getAltitude() : 0), System.currentTimeMillis());
            double d = Math.toRadians(field.getDeclination());
            forward = rotateHorizontal(forward, d);
            right = rotateHorizontal(right, d);
            up = rotateHorizontal(up, d);
        }
        String js = String.format(Locale.US,
            "window.onDevicePose && window.onDevicePose({forward:[%.6f,%.6f,%.6f],right:[%.6f,%.6f,%.6f],up:[%.6f,%.6f,%.6f]})",
            forward[0],forward[1],forward[2],right[0],right[1],right[2],up[0],up[1],up[2]);
        postJs(js);
    }

    private float[] rotateHorizontal(float[] v, double declination) {
        float c = (float)Math.cos(declination), s = (float)Math.sin(declination);
        return new float[]{c*v[0] + s*v[1], -s*v[0] + c*v[1], v[2]};
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void stopSensorsInternal() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        sensorsActive = false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST) {
            if (hasLocationPermission()) fetchLocation();
            else postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение отклонено')");
        } else if (requestCode == CAMERA_REQUEST) {
            boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
            postJs("window.onCameraPermission && window.onCameraPermission(" + granted + ")");
        }
    }

    @Override protected void onPause() {
        postJs("window.onNativePause && window.onNativePause()");
        stopSensorsInternal();
        stopLocationRequest();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopSensorsInternal();
        stopLocationRequest();
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
