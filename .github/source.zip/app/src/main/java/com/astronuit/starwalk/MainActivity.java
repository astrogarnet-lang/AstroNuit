package com.astronuit.starwalk;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.GeomagneticField;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.graphics.Color;
import android.view.Surface;
import android.view.WindowManager;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int LOCATION_REQUEST = 1707;
    private static final int CAMERA_REQUEST = 1708;
    private WebView web;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private Sensor accelerometerSensor;
    private Sensor magneticSensor;
    private final float[] gravity = new float[3];
    private final float[] magnetic = new float[3];
    private boolean haveGravity = false, haveMagnetic = false;
    private long lastPosePushNs = 0;
    private LocationManager locationManager;
    private boolean sensorsActive = false;
    private Location lastLocation;
    private final float[] rotation = new float[9];
    private final float[] remapped = new float[9];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 23));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 23));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        rotationSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) : null;
        accelerometerSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) : null;
        magneticSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) : null;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5, 8, 23));
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                        checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        request.deny();
                        return;
                    }
                    java.util.ArrayList<String> grants = new java.util.ArrayList<>();
                    for (String resource : request.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) grants.add(resource);
                    }
                    if (grants.isEmpty()) request.deny();
                    else request.grant(grants.toArray(new String[0]));
                });
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public String appVersion() { return "2.0.0"; }
        @JavascriptInterface public boolean hasOrientationSensor() {
            return rotationSensor != null || (accelerometerSensor != null && magneticSensor != null);
        }
        @JavascriptInterface public boolean startSensors() {
            if (sensorManager == null || (rotationSensor == null && (accelerometerSensor == null || magneticSensor == null))) {
                postJs("window.onSensorError && window.onSensorError('Для точного AR нужны компас и акселерометр')");
                return false;
            }
            runOnUiThread(() -> {
                if (sensorsActive) return;
                haveGravity = false; haveMagnetic = false;
                if (rotationSensor != null) {
                    sensorsActive = sensorManager.registerListener(MainActivity.this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
                } else {
                    boolean a = sensorManager.registerListener(MainActivity.this, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
                    boolean m = sensorManager.registerListener(MainActivity.this, magneticSensor, SensorManager.SENSOR_DELAY_GAME);
                    sensorsActive = a && m;
                }
                if (!sensorsActive) postJs("window.onSensorError && window.onSensorError('Не удалось запустить датчики ориентации')");
            });
            // The UI thread owns sensor registration; the first pose/error callback confirms the result.
            return true;
        }
        @JavascriptInterface public void requestCameraPermission() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                    checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    postJs("window.onCameraPermission && window.onCameraPermission(true)");
                } else requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
            });
        }
        @JavascriptInterface public void stopSensors() { runOnUiThread(MainActivity.this::stopSensorsInternal); }
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                } else {
                    fetchLocation();
                }
            });
        }
        @JavascriptInterface public void getLastLocation() {
            runOnUiThread(() -> {
                if (hasLocationPermission()) {
                    Location loc = bestLastKnownLocation();
                    if (loc != null) deliverLocation(loc);
                }
            });
        }
    }

    private void postJs(String js) {
        if (web == null) return;
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private Location bestLastKnownLocation() {
        if (locationManager == null || !hasLocationPermission()) return null;
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        java.util.ArrayList<Location> candidates = new java.util.ArrayList<>();
        if (fine) {
            try { Location l = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); if (l != null) candidates.add(l); }
            catch (SecurityException | IllegalArgumentException ignored) {}
        }
        try { Location l = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); if (l != null) candidates.add(l); }
        catch (SecurityException | IllegalArgumentException ignored) {}
        long now = System.currentTimeMillis();
        Location best = null;
        for (Location candidate : candidates) {
            if (now - candidate.getTime() > 30L * 60L * 1000L) continue;
            if (best == null) best = candidate;
            else {
                float ca = candidate.hasAccuracy() ? candidate.getAccuracy() : 99999f;
                float ba = best.hasAccuracy() ? best.getAccuracy() : 99999f;
                if (ca < ba * 0.8f || (ca <= ba * 1.2f && candidate.getTime() > best.getTime())) best = candidate;
            }
        }
        return best;
    }

    private void fetchLocation() {
        if (locationManager == null || !hasLocationPermission()) {
            postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение не предоставлено')");
            return;
        }
        Location old = bestLastKnownLocation();
        if (old != null) deliverLocation(old);
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        try {
            boolean requested = false;
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
                requested = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 0f, this, Looper.getMainLooper());
                requested = true;
            }
            if (!requested && old == null) {
                postJs("window.onLocationError && window.onLocationError('Включи геолокацию в настройках телефона')");
            }
        } catch (SecurityException e) {
            postJs("window.onLocationError && window.onLocationError('Нет разрешения на геолокацию')");
        } catch (IllegalArgumentException e) {
            postJs("window.onLocationError && window.onLocationError('Провайдер геолокации недоступен на этом устройстве')");
        }
    }

    private void deliverLocation(Location location) {
        if (location == null) return;
        lastLocation = location;
        String js = String.format(Locale.US,
            "window.onLocationChanged && window.onLocationChanged(%.7f,%.7f,%.1f)",
            location.getLatitude(), location.getLongitude(), location.hasAccuracy() ? location.getAccuracy() : 0f);
        postJs(js);
    }

    @Override public void onLocationChanged(Location location) {
        deliverLocation(location);
        if (location != null && location.hasAccuracy() && location.getAccuracy() <= 80f && locationManager != null) {
            locationManager.removeUpdates(this);
        }
    }
    @Override public void onProviderEnabled(String provider) { if (hasLocationPermission()) fetchLocation(); }
    @Override public void onProviderDisabled(String provider) { postJs("window.onLocationProviderDisabled && window.onLocationProviderDisabled()"); }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override public void onSensorChanged(SensorEvent event) {
        if (!sensorsActive || web == null) return;
        int type = event.sensor.getType();
        if (type == Sensor.TYPE_ACCELEROMETER) {
            for (int i = 0; i < 3; i++) gravity[i] = gravity[i] * 0.82f + event.values[i] * 0.18f;
            haveGravity = true;
        } else if (type == Sensor.TYPE_MAGNETIC_FIELD) {
            for (int i = 0; i < 3; i++) magnetic[i] = magnetic[i] * 0.82f + event.values[i] * 0.18f;
            haveMagnetic = true;
        } else if (type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotation, event.values);
        } else return;
        if (rotationSensor == null && (!haveGravity || !haveMagnetic || !SensorManager.getRotationMatrix(rotation, null, gravity, magnetic))) return;
        long nowNs = System.nanoTime();
        if (nowNs - lastPosePushNs < 50_000_000L) return;
        lastPosePushNs = nowNs;
        int axisX = SensorManager.AXIS_X, axisY = SensorManager.AXIS_Y;
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        if (displayRotation == Surface.ROTATION_90) { axisX = SensorManager.AXIS_Y; axisY = SensorManager.AXIS_MINUS_X; }
        else if (displayRotation == Surface.ROTATION_180) { axisX = SensorManager.AXIS_MINUS_X; axisY = SensorManager.AXIS_MINUS_Y; }
        else if (displayRotation == Surface.ROTATION_270) { axisX = SensorManager.AXIS_MINUS_Y; axisY = SensorManager.AXIS_X; }
        SensorManager.remapCoordinateSystem(rotation, axisX, axisY, remapped);

        // Device screen normal (forward), screen right, and screen up, expressed in local ENU axes.
        float[] forward = new float[]{-remapped[2], -remapped[5], -remapped[8]};
        float[] right = new float[]{remapped[0], remapped[3], remapped[6]};
        float[] up = new float[]{-remapped[1], -remapped[4], -remapped[7]};

        // Rotation-vector heading is referenced to magnetic north. Correct to true north if GPS is available.
        Location loc = lastLocation;
        if (loc != null) {
            GeomagneticField field = new GeomagneticField((float)loc.getLatitude(), (float)loc.getLongitude(),
                (float)(loc.hasAltitude() ? loc.getAltitude() : 0), System.currentTimeMillis());
            double d = Math.toRadians(field.getDeclination());
            forward = rotateHorizontal(forward, d);
            right = rotateHorizontal(right, d);
            up = rotateHorizontal(up, d);
        }
        String js = String.format(Locale.US,
            "window.onDevicePose && window.onDevicePose({forward:[%.6f,%.6f,%.6f],right:[%.6f,%.6f,%.6f],up:[%.6f,%.6f,%.6f]})",
            forward[0],forward[1],forward[2],right[0],right[1],right[2],up[0],up[1],up[2]);
        postJs(js);
    }

    private float[] rotateHorizontal(float[] v, double declination) {
        float c = (float)Math.cos(declination), s = (float)Math.sin(declination);
        return new float[]{c*v[0] + s*v[1], -s*v[0] + c*v[1], v[2]};
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void stopSensorsInternal() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
        sensorsActive = false;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST) {
            if (hasLocationPermission()) fetchLocation();
            else postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение отклонено')");
        } else if (requestCode == CAMERA_REQUEST) {
            boolean granted = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
            postJs("window.onCameraPermission && window.onCameraPermission(" + granted + ")");
        }
    }

    @Override protected void onPause() {
        postJs("window.onNativePause && window.onNativePause()");
        stopSensorsInternal();
        if (locationManager != null) locationManager.removeUpdates(this);
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopSensorsInternal();
        if (locationManager != null) locationManager.removeUpdates(this);
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
