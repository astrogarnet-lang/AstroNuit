package com.astronuit.starwalk;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.GeomagneticField;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.view.Surface;
import android.view.WindowManager;

import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener, LocationListener {
    private static final int LOCATION_REQUEST = 1707;
    private WebView web;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private LocationManager locationManager;
    private boolean sensorsActive = false;
    private Location lastLocation;
    private final float[] rotation = new float[9];
    private final float[] remapped = new float[9];

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 23));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 23));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        rotationSensor = sensorManager != null ? sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) : null;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5, 8, 23));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class Bridge {
        @JavascriptInterface public String appVersion() { return "2.0.0"; }
        @JavascriptInterface public boolean hasOrientationSensor() { return rotationSensor != null; }
        @JavascriptInterface public boolean startSensors() {
            if (sensorManager == null || rotationSensor == null) {
                postJs("window.onSensorError && window.onSensorError('На устройстве нет датчика ориентации')");
                return false;
            }
            runOnUiThread(() -> {
                if (!sensorsActive) {
                    sensorsActive = sensorManager.registerListener(MainActivity.this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
                }
                if (!sensorsActive) postJs("window.onSensorError && window.onSensorError('Не удалось запустить датчик ориентации')");
            });
            return true;
        }
        @JavascriptInterface public void stopSensors() { runOnUiThread(MainActivity.this::stopSensorsInternal); }
        @JavascriptInterface public void requestLocation() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
                } else {
                    fetchLocation();
                }
            });
        }
        @JavascriptInterface public void getLastLocation() {
            runOnUiThread(() -> {
                if (hasLocationPermission()) {
                    Location loc = bestLastKnownLocation();
                    if (loc != null) deliverLocation(loc);
                }
            });
        }
    }

    private void postJs(String js) {
        if (web == null) return;
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
               checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private Location bestLastKnownLocation() {
        if (locationManager == null || !hasLocationPermission()) return null;
        Location best = null;
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (fine) {
            try { Location l = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); if (l != null) best = l; }
            catch (SecurityException ignored) {}
        }
        try {
            Location l = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
        } catch (SecurityException ignored) {}
        return best;
    }

    private void fetchLocation() {
        if (locationManager == null || !hasLocationPermission()) {
            postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение не предоставлено')");
            return;
        }
        Location old = bestLastKnownLocation();
        if (old != null) deliverLocation(old);
        boolean fine = Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        try {
            boolean requested = false;
            if (fine && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 8000L, 100f, this, Looper.getMainLooper());
                requested = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 8000L, 100f, this, Looper.getMainLooper());
                requested = true;
            }
            if (!requested && old == null) {
                postJs("window.onLocationError && window.onLocationError('Включи геолокацию в настройках телефона')");
            }
        } catch (SecurityException e) {
            postJs("window.onLocationError && window.onLocationError('Нет разрешения на геолокацию')");
        }
    }

    private void deliverLocation(Location location) {
        if (location == null) return;
        lastLocation = location;
        String js = String.format(Locale.US,
            "window.onLocationChanged && window.onLocationChanged(%.7f,%.7f,%.1f)",
            location.getLatitude(), location.getLongitude(), location.hasAccuracy() ? location.getAccuracy() : 0f);
        postJs(js);
    }

    @Override public void onLocationChanged(Location location) { deliverLocation(location); }
    @Override public void onProviderEnabled(String provider) {}
    @Override public void onProviderDisabled(String provider) {}
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    @Override public void onSensorChanged(SensorEvent event) {
        if (!sensorsActive || event.sensor.getType() != Sensor.TYPE_ROTATION_VECTOR || web == null) return;
        SensorManager.getRotationMatrixFromVector(rotation, event.values);
        int axisX = SensorManager.AXIS_X, axisY = SensorManager.AXIS_Y;
        int displayRotation = getWindowManager().getDefaultDisplay().getRotation();
        if (displayRotation == Surface.ROTATION_90) { axisX = SensorManager.AXIS_Y; axisY = SensorManager.AXIS_MINUS_X; }
        else if (displayRotation == Surface.ROTATION_180) { axisX = SensorManager.AXIS_MINUS_X; axisY = SensorManager.AXIS_MINUS_Y; }
        else if (displayRotation == Surface.ROTATION_270) { axisX = SensorManager.AXIS_MINUS_Y; axisY = SensorManager.AXIS_X; }
        SensorManager.remapCoordinateSystem(rotation, axisX, axisY, remapped);

        // Device screen normal (forward), screen right, and screen up, expressed in local ENU axes.
        float[] forward = new float[]{remapped[2], remapped[5], remapped[8]};
        float[] right = new float[]{remapped[0], remapped[3], remapped[6]};
        float[] up = new float[]{remapped[1], remapped[4], remapped[7]};

        // Rotation-vector heading is referenced to magnetic north. Correct to true north if GPS is available.
        Location loc = lastLocation;
        if (loc != null) {
            GeomagneticField field = new GeomagneticField((float)loc.getLatitude(), (float)loc.getLongitude(),
                (float)(loc.hasAltitude() ? loc.getAltitude() : 0), System.currentTimeMillis());
            double d = Math.toRadians(field.getDeclination());
            forward = rotateHorizontal(forward, d);
            right = rotateHorizontal(right, d);
            up = rotateHorizontal(up, d);
        }
        String js = String.format(Locale.US,
            "window.onDevicePose && window.onDevicePose({forward:[%.6f,%.6f,%.6f],right:[%.6f,%.6f,%.6f],up:[%.6f,%.6f,%.6f]})",
            forward[0],forward[1],forward[2],right[0],right[1],right[2],up[0],up[1],up[2]);
        postJs(js);
    }

    private float[] rotateHorizontal(float[] v, double declination) {
        float c = (float)Math.cos(declination), s = (float)Math.sin(declination);
        return new float[]{c*v[0] + s*v[1], -s*v[0] + c*v[1], v[2]};
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    private void stopSensorsInternal() {
        if (sensorManager != null && sensorsActive) sensorManager.unregisterListener(this);
        sensorsActive = false;
    }

    @Override protected void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST) {
            if (hasLocationPermission()) fetchLocation();
            else postJs("window.onLocationError && window.onLocationError('Разрешение на местоположение отклонено')");
        }
    }

    @Override protected void onPause() {
        postJs("window.onNativePause && window.onNativePause()");
        stopSensorsInternal();
        if (locationManager != null) locationManager.removeUpdates(this);
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopSensorsInternal();
        if (locationManager != null) locationManager.removeUpdates(this);
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
