package com.astronuit.starwalk;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.graphics.Color;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(7,16,35));
    getWindow().setNavigationBarColor(Color.rgb(7,16,35));
    web=new WebView(this); web.setBackgroundColor(Color.rgb(7,16,35));
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setAllowFileAccessFromFileURLs(true); s.setDatabaseEnabled(true); s.setSupportZoom(false);
    web.setWebChromeClient(new WebChromeClient()); web.addJavascriptInterface(new Bridge(), "AndroidBridge");
    web.loadUrl("file:///android_asset/index.html"); setContentView(web);
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  public class Bridge { @JavascriptInterface public String appVersion(){ return "1.0.0"; } }
  @Override protected void onDestroy(){ if(web!=null) web.destroy(); super.onDestroy(); }
}
