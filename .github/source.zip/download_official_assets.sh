#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
A="$ROOT/app/src/main/assets"
D="$A/data"
T="$A/textures"
mkdir -p "$A/gallery" "$A/gallery/nebulae" "$T" "$D" "$ROOT/data-source"

fetch_required() {
  local url="$1" out="$2" signature="$3" min_bytes="${4:-25000}"
  local tmp="${out}.download"
  rm -f "$tmp"
  echo "Downloading verified visual asset: $(basename "$out")"
  curl -fL --connect-timeout 25 --max-time 420 --retry 4 --retry-delay 2 "$url" -o "$tmp"
  local size
  size=$(wc -c < "$tmp")
  if [[ "$size" -lt "$min_bytes" ]]; then echo "Asset too small: $url ($size bytes)" >&2; rm -f "$tmp"; return 1; fi
  case "$signature" in
    jpeg) head -c 3 "$tmp" | od -An -tx1 | tr -d ' \n' | grep -qi '^ffd8ff$' || { echo "Not a JPEG: $url" >&2; rm -f "$tmp"; return 1; } ;;
    png) head -c 8 "$tmp" | od -An -tx1 | tr -d ' \n' | grep -qi '^89504e470d0a1a0a$' || { echo "Not a PNG: $url" >&2; rm -f "$tmp"; return 1; } ;;
  esac
  mv "$tmp" "$out"
}

# High/ultra-resolution equirectangular maps from Solar System Scope.
# The maps are 3D surface/atmosphere textures based on NASA imagery/elevation datasets,
# not a claim that each pixel is a raw camera photograph.
BASE='https://play.solarsystemscope.com/textures/download'
fetch_required "$BASE/8k_mercury.jpg" "$T/mercury.jpg" jpeg 500000
fetch_required "$BASE/4k_venus_atmosphere.jpg" "$T/venus_clouds.jpg" jpeg 250000
fetch_required "$BASE/8k_venus_surface.jpg" "$T/venus_surface.jpg" jpeg 500000
fetch_required "$BASE/8k_earth_daymap.jpg" "$T/earth.jpg" jpeg 500000
fetch_required "$BASE/8k_earth_nightmap.jpg" "$T/earth_night.jpg" jpeg 250000
fetch_required "$BASE/8k_earth_clouds.jpg" "$T/earth_clouds.jpg" jpeg 250000
fetch_required "$BASE/8k_mars.jpg" "$T/mars.jpg" jpeg 500000
fetch_required "$BASE/8k_jupiter.jpg" "$T/jupiter.jpg" jpeg 500000
fetch_required "$BASE/8k_saturn.jpg" "$T/saturn.jpg" jpeg 500000
fetch_required "$BASE/8k_saturn_ring_alpha.png" "$T/saturn_ring_alpha.png" png 100000
# These maps are only offered in high-res 2K on the official source page.
fetch_required "$BASE/2k_uranus.jpg" "$T/uranus.jpg" jpeg 100000
fetch_required "$BASE/2k_neptune.jpg" "$T/neptune.jpg" jpeg 100000
fetch_required "$BASE/8k_sun.jpg" "$T/sun.jpg" jpeg 500000
fetch_required "$BASE/8k_moon.jpg" "$T/moon.jpg" jpeg 500000

# Pluto global colour map from the New Horizons / NASA image archive.
python3 - "$T/pluto.jpg" <<'PY2'
import json, sys, urllib.request
out=sys.argv[1]
headers={'User-Agent':'AstroNuit-asset-builder/1.0'}
with urllib.request.urlopen(urllib.request.Request('https://images-api.nasa.gov/asset/PIA11707',headers=headers),timeout=45) as r:
    data=json.load(r)
urls=[]
for item in data.get('collection',{}).get('items',[]):
    url=item.get('href','')
    if url.lower().endswith(('.jpg','.jpeg')): urls.append(url)
urls.sort(key=lambda x:(0 if '~large.' in x else 1 if '~orig.' in x else 2 if '~medium.' in x else 3))
last=None
for url in urls:
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=90) as r:
            blob=r.read(18*1024*1024+1)
        if len(blob)>18*1024*1024 or len(blob)<50000 or not blob.startswith(b'\xff\xd8\xff'):
            raise ValueError('invalid or oversized Pluto map')
        open(out,'wb').write(blob)
        print('Pluto map verified:',len(blob),'bytes')
        break
    except Exception as exc: last=exc
else:
    raise SystemExit(f'Could not download a valid Pluto map: {last}')
PY2

# Decode small thumbnails separately so the UI never opens every 8K map at launch.
python3 "$ROOT/make_planet_thumbnails.py"

# Distinct NASA/Hubble image for every deep-sky object where a matching source exists.
python3 "$ROOT/tools_download_nasa_visuals.py"

# HYG v4.0 catalogue: immutable upstream file, cryptographically pinned.
HYG_GZ="$ROOT/data-source/hygdata_v40.csv.gz"
HYG_SHA256='8e3ff9e67445e558a759b117910850cff1b1d4d492f45f715c2ee2db3d869bac'
if [[ ! -s "$HYG_GZ" ]] || [[ "$(sha256sum "$HYG_GZ" | awk '{print $1}')" != "$HYG_SHA256" ]]; then
  curl -fL --connect-timeout 25 --max-time 420 --retry 4 --retry-delay 2 \
    'https://raw.githubusercontent.com/astronexus/HYG-Database/main/hyg/CURRENT/hygdata_v40.csv.gz' -o "$HYG_GZ"
fi
actual="$(sha256sum "$HYG_GZ" | awk '{print $1}')"
[[ "$actual" == "$HYG_SHA256" ]] || { echo 'HYG catalogue checksum mismatch.' >&2; exit 1; }
gzip -t "$HYG_GZ"
gzip -dc "$HYG_GZ" > "$ROOT/data-source/hygdata_v40.csv"
head -n 1 "$ROOT/data-source/hygdata_v40.csv" | grep -q 'hip' || { echo 'HYG CSV header is invalid.' >&2; exit 1; }

# Stellarium western skyculture supplies HIP chains for the official 88 constellations.
CONST_JSON="$ROOT/data-source/stellarium_western_index.json"
curl -fL --connect-timeout 25 --max-time 180 --retry 4 --retry-delay 2 \
  'https://raw.githubusercontent.com/Stellarium/stellarium-skycultures/master/western/index.json' -o "$CONST_JSON"
python3 - "$CONST_JSON" <<'PY2'
import json,sys
x=json.load(open(sys.argv[1],encoding='utf-8'))
rows=[c for c in x.get('constellations',[]) if c.get('iau') and str(c.get('id','')).startswith('CON ')]
assert len(rows)>=80, f'Expected at least 80 Stellarium constellations, got {len(rows)}'
PY2

# Independent NASA gallery frames. Missing optional gallery shots are not replaced by artwork.
for entry in \
  'art002e021278:artemis_ii_earthrise.jpg' \
  'art002e009301:artemis_ii_eclipse.jpg' \
  'art002e012588:artemis_ii_milky_way.jpg' \
  'art002e009288:artemis_ii_earthset.jpg' \
  'art002e016354:artemis_ii_moon_crescent.jpg' \
  'art002e014225:artemis_ii_earth_crescent.jpg'; do
  id="${entry%%:*}"; name="${entry#*:}"; tmp="$A/gallery/$name.download"
  if curl -fL --connect-timeout 20 --max-time 180 --retry 2 "https://images-assets.nasa.gov/image/$id/${id}~large.jpg" -o "$tmp"; then
    if [[ "$(head -c 3 "$tmp" | od -An -tx1 | tr -d ' \n')" == 'ffd8ff' ]] && [[ "$(wc -c < "$tmp")" -gt 25000 ]]; then mv "$tmp" "$A/gallery/$name"; else rm -f "$tmp"; fi
  else rm -f "$tmp"; fi
done

# A current offline snapshot of the NASA Exoplanet Archive is optional.
URL='https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select%20pl_name,hostname,disc_year,discoverymethod,pl_orbper,pl_rade,pl_bmasse,sy_dist%20from%20pscomppars&format=json'
if curl -fL --connect-timeout 20 --max-time 180 --retry 2 "$URL" -o "$D/exoplanets_offline.json"; then
  python3 -m json.tool "$D/exoplanets_offline.json" >/dev/null || rm -f "$D/exoplanets_offline.json"
fi

echo 'Official planetary maps, star catalogue and constellation data passed download checks.'
