#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
A="$ROOT/app/src/main/assets"
D="$A/data"
mkdir -p "$A/gallery" "$A/textures" "$D" "$ROOT/data-source"

fetch_file() {
  local url="$1" out="$2" min_bytes="${3:-25000}"
  rm -f "$out"
  if ! curl -fL --connect-timeout 20 --max-time 240 --retry 3 --retry-delay 2 "$url" -o "$out"; then
    rm -f "$out"; echo "Optional asset download skipped: $url" >&2; return 0
  fi
  local size
  size=$(wc -c < "$out" 2>/dev/null || echo 0)
  if [[ "$size" -lt "$min_bytes" ]]; then
    rm -f "$out"; echo "Rejected undersized asset: $url" >&2; return 0
  fi
  return 0
}

# HYG v4.0 star positions / magnitudes. Use the verified OpenAstro mirror because
# the original GitHub archive now serves an LFS pointer for large CSV files.
# SHA-256 is pinned so an unexpected HTML/error payload cannot silently enter the APK.
HYG_GZ="$ROOT/data-source/hygdata_v40.csv.gz"
HYG_SHA256="8e3ff9e67445e558a759b117910850cff1b1d4d492f45f715c2ee2db3d869bac"
if [[ ! -s "$HYG_GZ" ]] || [[ "$(sha256sum "$HYG_GZ" 2>/dev/null | awk '{print $1}')" != "$HYG_SHA256" ]]; then
  fetch_file "https://raw.githubusercontent.com/open-astro/sky-data/main/hygdata_v40.csv.gz" "$HYG_GZ" 1000000
fi
if [[ -s "$HYG_GZ" ]]; then
  actual="$(sha256sum "$HYG_GZ" | awk '{print $1}')"
  if [[ "$actual" == "$HYG_SHA256" ]] && gzip -t "$HYG_GZ"; then
    gzip -dc "$HYG_GZ" > "$ROOT/data-source/hygdata_v40.csv"
    if ! head -n 1 "$ROOT/data-source/hygdata_v40.csv" | grep -q 'hip'; then
      rm -f "$ROOT/data-source/hygdata_v40.csv"
    fi
  else
    echo "HYG catalogue download failed checksum/integrity validation; using bundled bright stars." >&2
    rm -f "$HYG_GZ"
  fi
fi


# Stellarium western skyculture (all standard constellation HIP chains).
CONST_JSON="$ROOT/data-source/stellarium_western_index.json"
CONST_URL="https://raw.githubusercontent.com/Stellarium/stellarium-skycultures/master/western/index.json"
if [[ ! -s "$CONST_JSON" ]] || ! python3 - "$CONST_JSON" <<'PYCHK' >/dev/null 2>&1
import json,sys
x=json.load(open(sys.argv[1],encoding='utf-8'))
assert len(x.get('constellations',[])) >= 80
PYCHK
then
  fetch_file "$CONST_URL" "$CONST_JSON" 30000
fi
if [[ -s "$CONST_JSON" ]] && ! python3 - "$CONST_JSON" <<'PYCHK'
import json,sys
x=json.load(open(sys.argv[1],encoding='utf-8'))
assert len(x.get('constellations',[])) >= 80
assert all(isinstance(c.get('lines',[]),list) for c in x['constellations'])
PYCHK
then rm -f "$CONST_JSON"; fi

# Official Artemis II photographs. Each NASA ID has its own target filename.
fetch_file "https://images-assets.nasa.gov/image/art002e021278/art002e021278~large.jpg" "$A/gallery/artemis_ii_earthrise.jpg" 25000
fetch_file "https://images-assets.nasa.gov/image/art002e009301/art002e009301~large.jpg" "$A/gallery/artemis_ii_eclipse.jpg" 25000
fetch_file "https://images-assets.nasa.gov/image/art002e012588/art002e012588~large.jpg" "$A/gallery/artemis_ii_milky_way.jpg" 25000
fetch_file "https://images-assets.nasa.gov/image/art002e009288/art002e009288~large.jpg" "$A/gallery/artemis_ii_earthset.jpg" 25000
fetch_file "https://images-assets.nasa.gov/image/art002e016354/art002e016354~large.jpg" "$A/gallery/artemis_ii_moon_crescent.jpg" 25000
fetch_file "https://images-assets.nasa.gov/image/art002e014225/art002e014225~large.jpg" "$A/gallery/artemis_ii_earth_crescent.jpg" 25000
for f in "$A"/gallery/artemis_ii_*.jpg; do
  [[ -f "$f" ]] || continue
  if ! head -c 3 "$f" | od -An -tx1 | tr -d ' \n' | grep -qi '^ffd8ff$'; then rm -f "$f"; fi
done

# NASA Exoplanet Archive snapshot is optional. The project includes a small curated offline fallback.
URL='https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select%20pl_name,hostname,disc_year,discoverymethod,pl_orbper,pl_rade,pl_bmasse,sy_dist%20from%20pscomppars&format=json'
fetch_file "$URL" "$D/exoplanets_offline.json" 100
if [[ -f "$D/exoplanets_offline.json" ]] && ! python3 -m json.tool "$D/exoplanets_offline.json" >/dev/null 2>&1; then rm -f "$D/exoplanets_offline.json"; fi

# A failed optional download must not break the APK build: prepare_catalog.py falls back to bundled datasets.
exit 0
