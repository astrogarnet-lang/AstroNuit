#!/usr/bin/env bash
set -euo pipefail
A="app/src/main/assets"
mkdir -p "$A/gallery" "$A/models" "$A/data"
# NASA SVS LRO lunar globe (small web-optimized edition, free according to NASA 3D-resource guidance).
if curl -fL --retry 3 "https://svs.gsfc.nasa.gov/vis/a010000/a014900/a014959/moon_small.glb" -o "$A/models/moon_nasa_lro.glb"; then cp "$A/models/moon_nasa_lro.glb" "$A/models/moon.glb"; else echo "NASA GLB download skipped; original generated Moon GLB remains bundled."; fi
# Two official Artemis II lunar-flyby photographs. Credit NASA; see LICENSES.txt for source pages.
curl -fL --retry 3 "https://images-assets.nasa.gov/image/art002e021278/art002e021278~large.jpg" -o "$A/gallery/moon_artemis_ii_earthset.jpg" || echo "Artemis II image 1 download skipped."
curl -fL --retry 3 "https://images-assets.nasa.gov/image/art002e009301/art002e009301~large.jpg" -o "$A/gallery/artemis_ii_eclipse.jpg" || echo "Artemis II image 2 download skipped."
curl -fL --retry 3 "https://images-assets.nasa.gov/image/art002e012588/art002e012588~large.jpg" -o "$A/gallery/artemis_ii_milky_way.jpg" || echo "Artemis II Milky Way image download skipped."
# Optional cached confirmed-exoplanet catalogue; if the archive is unreachable, the bundled sample remains available.
URL='https://exoplanetarchive.ipac.caltech.edu/TAP/sync?query=select%20pl_name,hostname,disc_year,discoverymethod,pl_orbper,pl_rade,pl_bmasse,sy_dist%20from%20pscomppars&format=json'
curl -fL --retry 2 "$URL" -o "$A/data/exoplanets_offline.json" || echo 'Exoplanet bulk snapshot skipped; curated local data remains available.'
