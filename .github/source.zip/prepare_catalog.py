#!/usr/bin/env python3
"""Build AstroNuit's local sky catalogue from verified astronomy data and media."""
from __future__ import annotations
import csv, gzip, json, math, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'app/src/main/assets'
DATA = ASSETS / 'data'
CATALOG_PATH = DATA / 'catalog.json'
HTML_PATH = ASSETS / 'index.html'

catalog = json.loads(CATALOG_PATH.read_text(encoding='utf-8'))

# Retain the HIP stars required by the official constellation diagrams even when
# their apparent magnitude is fainter than the ordinary sky-map cutoff.
constellation_hips = set()
stellarium_path = ROOT / 'data-source/stellarium_western_index.json'
if stellarium_path.is_file():
    try:
        _sky = json.loads(stellarium_path.read_text(encoding='utf-8'))
        for _item in _sky.get('constellations') or []:
            if not str(_item.get('id') or '').startswith('CON ') or not _item.get('iau'):
                continue
            for _chain in _item.get('lines') or []:
                for _hip in _chain:
                    if isinstance(_hip, (int, float)) and not isinstance(_hip, bool):
                        constellation_hips.add(str(int(_hip)))
    except Exception as exc:
        print(f'WARNING: constellation HIP list skipped: {exc}')

def number(value, default=None):
    try:
        x = float(value)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default

# HYG v4.0 contains the combined Hipparcos/Yale/Gliese star catalogue.
# Retain the curated Russian display names first, then add catalogue rows to V=6.5.
curated = list(catalog.get('stars') or [])
stars = []
seen_hip = set()
seen_proper = set()
seen_names = set()
seen_coords = set()
for s in curated:
    row = dict(s)
    ra = number(row.get('ra'), 0.0)
    dec = number(row.get('dec'), 0.0)
    row['ra'], row['dec'] = ra, dec
    row['mag'] = number(row.get('mag', row.get('magnitude')), 5.0)
    row['ci'] = number(row.get('ci'), 0.4)
    proper_raw = str(row.get('proper') or '').strip()
    display_name = str(row.get('name') or proper_raw).strip().casefold()
    if proper_raw.casefold() == 'sun' or row.get('name') == 'Солнце':
        continue
    hip = str(row.get('hip') or '').strip()
    if not row.get('_id'):
        row['_id'] = ('HIP-' + hip if hip else
                      ('HD-' + str(row.get('hd')) if row.get('hd') else
                       ('HR-' + str(row.get('hr')) if row.get('hr') else 'CURATED-' + str(len(stars) + 1))))
    proper = proper_raw.casefold()
    coord_key = (round(ra, 3), round(dec, 3))
    if (hip and hip in seen_hip) or (proper and proper in seen_proper) or (display_name and display_name in seen_names) or coord_key in seen_coords:
        continue
    if hip: seen_hip.add(hip)
    if proper: seen_proper.add(proper)
    if display_name: seen_names.add(display_name)
    seen_coords.add(coord_key)
    stars.append(row)

hyg_path = ROOT / 'data-source/hygdata_v40.csv'
hyg_gz_path = ROOT / 'data-source/hygdata_v40.csv.gz'
if not hyg_path.is_file() and hyg_gz_path.is_file():
    try:
        with gzip.open(hyg_gz_path, 'rt', encoding='utf-8-sig', newline='') as src, hyg_path.open('w', encoding='utf-8', newline='') as dst:
            dst.write(src.read())
    except Exception as exc:
        print(f'WARNING: HYG gzip unpack skipped: {exc}')
hyg_added = 0
# O(1) indexes avoid repeated linear scans while merging tens of thousands of HYG rows.
by_hip = {str(x.get('hip') or '').strip(): x for x in stars if str(x.get('hip') or '').strip()}
by_proper = {str(x.get('proper') or '').strip().casefold(): x for x in stars if str(x.get('proper') or '').strip()}
by_coords = {(round(number(x.get('ra'), 999), 3), round(number(x.get('dec'), 999), 3)): x for x in stars}
if hyg_path.is_file():
    try:
        with hyg_path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            for r in reader:
                mag = number(r.get('mag'))
                ra = number(r.get('ra'))
                dec = number(r.get('dec'))
                hip = str(r.get('hip') or '').strip()
                if mag is None or (mag > 6.5 and hip not in constellation_hips) or ra is None or dec is None or not -90 <= dec <= 90:
                    continue
                if not 0 <= ra <= 24:
                    continue
                proper = str(r.get('proper') or '').strip()
                if proper.casefold() == 'sun' or number(r.get('dist'), 1.0) == 0:
                    continue
                coord_key = (round(ra, 3), round(dec, 3))
                existing = by_hip.get(hip) if hip else None
                proper_key = proper.casefold()
                if existing is None and proper_key:
                    existing = by_proper.get(proper_key)
                if existing is None:
                    existing = by_coords.get(coord_key)
                ci = number(r.get('ci'), 0.45)
                dist_pc = number(r.get('dist'))
                dist = dist_pc * 3.26156 if dist_pc is not None else None
                spect = str(r.get('spect') or '').strip()
                con = str(r.get('con') or '').strip()
                hd = str(r.get('hd') or '').strip()
                hr = str(r.get('hr') or '').strip()
                bf = str(r.get('bf') or '').strip()
                pmra = number(r.get('pmra'), 0.0)
                pmdec = number(r.get('pmdec'), 0.0)
                star_data = {
                    'name': '', 'proper': proper, 'con': con,
                    'mag': mag, 'ci': ci, 'ra': ra, 'dec': dec,
                    'dist': dist, 'spect': spect, 'hip': hip or None,
                    'hd': hd or None, 'hr': hr or None, 'bf': bf or None,
                    '_id': ('HIP-' + hip if hip else ('HD-' + hd if hd else ('HR-' + hr if hr else 'HYG-' + str(len(stars) + 1)))),
                    'pmra': pmra, 'pmdec': pmdec, 'epoch': 2000.0,
                    'absmag': number(r.get('absmag')), 'lum': number(r.get('lum')),
                    'rv': number(r.get('rv')), 'var': str(r.get('var') or '').strip() or None,
                    'var_min': number(r.get('var_min')), 'var_max': number(r.get('var_max')),
                    'bayer': str(r.get('bayer') or '').strip() or None,
                    'flam': str(r.get('flam') or '').strip() or None,
                    'catalog_id': ('HIP '+hip) if hip else (('HD '+hd) if hd else ('HR '+hr if hr else 'HYG')),
                    'generatedBackground': False,
                    'description': ('Каталог HYG v4.0. Спектральный класс: '+spect+'. Собственное движение: RA '+f'{pmra:.1f}'+', Dec '+f'{pmdec:.1f}'+' mas/год.' if spect else 'Запись звёздного каталога HYG v4.0 с координатами эпохи J2000.')
                }
                if existing is not None:
                    # Keep hand-written Russian name/description but attach real HIP and astrometry.
                    authoritative = {
                        'hip','hd','hr','bf','pmra','pmdec','epoch','con','spect','dist',
                        'ra','dec','mag','ci','absmag','lum','rv','var','var_min','var_max','bayer','flam',
                        'catalog_id','generatedBackground','_id'
                    }
                    for key, value in star_data.items():
                        if key not in ('name','description') and (key in authoritative or existing.get(key) in (None, '', 0)):
                            existing[key] = value
                else:
                    stars.append(star_data)
                    hyg_added += 1
                    if hip: by_hip[hip] = star_data
                    if proper_key: by_proper[proper_key] = star_data
                    by_coords[coord_key] = star_data
                if hip: seen_hip.add(hip)
                if proper:
                    seen_proper.add(proper_key)
                    seen_names.add(proper_key)
                seen_coords.add(coord_key)
    except Exception as exc:
        print(f'WARNING: HYG import skipped: {exc}')
else:
    raise SystemExit('HYG catalogue is missing. Refusing to ship an incomplete star field.')
if hyg_added < 5000:
    raise SystemExit(f'HYG catalogue import is incomplete: only {hyg_added} new records were added.')
catalog['stars'] = stars
catalog['star_catalog_source'] = 'HYG Database v4.0 + curated bright-star display names'
catalog['star_catalog_note'] = 'HYG v4.0 snapshot; build imports verified catalogue entries to visual magnitude 6.5.'
catalog['star_catalog_limit'] = 'HYG v4.0 entries with visual magnitude <= 6.5; HIP identifiers and proper motions merged into named bright-star records.'
catalog['hyg_rows_added'] = hyg_added


# Stellarium western skyculture: official HIP-based line chains for all standard constellations.
# The download step validates the JSON before this script consumes it.
RU_CONST = {
'And':'Андромеда','Ant':'Насос','Aps':'Райская Птица','Aqr':'Водолей','Aql':'Орёл','Ara':'Жертвенник','Ari':'Овен','Aur':'Возничий',
'Boo':'Волопас','Cael':'Резец','Cam':'Жираф','Cnc':'Рак','CVn':'Гончие Псы','CMa':'Большой Пёс','CMi':'Малый Пёс','Cap':'Козерог',
'Car':'Киль','Cas':'Кассиопея','Cen':'Центавр','Cep':'Цефей','Cet':'Кит','Cha':'Хамелеон','Cir':'Циркуль','Col':'Голубь','Com':'Волосы Вероники',
'CrA':'Южная Корона','CrB':'Северная Корона','Crt':'Чаша','Cru':'Южный Крест','Crv':'Ворон','Cyg':'Лебедь','Del':'Дельфин','Dor':'Золотая Рыба',
'Dra':'Дракон','Equ':'Малый Конь','Eri':'Эридан','For':'Печь','Gem':'Близнецы','Gru':'Журавль','Her':'Геркулес','Hor':'Часы','Hya':'Гидра',
'Hyi':'Малая Гидра','Ind':'Индеец','Lac':'Ящерица','Leo':'Лев','Lep':'Заяц','Lib':'Весы','Lup':'Волк','Lyn':'Рысь','Lyr':'Лира',
'Men':'Столовая Гора','Mic':'Микроскоп','Mon':'Единорог','Mus':'Муха','Nor':'Наугольник','Oct':'Октант','Oph':'Змееносец','Ori':'Орион',
'Pav':'Павлин','Peg':'Пегас','Per':'Персей','Phe':'Феникс','Pic':'Живописец','Psc':'Рыбы','PsA':'Южная Рыба','Pup':'Корма','Pyx':'Компас',
'Ret':'Сетка','Sct':'Щит','Sge':'Стрела','Sgr':'Стрелец','Sco':'Скорпион','Scl':'Скульптор','Ser':'Змея','Sex':'Секстант','Tau':'Телец','Tel':'Телескоп',
'Tri':'Треугольник','TrA':'Южный Треугольник','Tuc':'Тукан','UMa':'Большая Медведица','UMi':'Малая Медведица','Vel':'Паруса','Vir':'Дева','Vol':'Летучая Рыба','Vul':'Лисичка'
}
stellarium_path = ROOT / 'data-source/stellarium_western_index.json'
constellation_lines = []
if stellarium_path.is_file():
    try:
        sky = json.loads(stellarium_path.read_text(encoding='utf-8'))
        entries = sky.get('constellations') or []
        if len(entries) >= 80:
            for item in entries:
                # Ignore Stellarium asterisms (AST records); only the 88 IAU constellations
                # belong in the constellation layer shown on the real sky map.
                if not str(item.get('id') or '').startswith('CON '):
                    continue
                iau = str(item.get('iau') or '').strip()
                if not iau:
                    continue
                paths = []
                for raw in item.get('lines') or []:
                    chain = [int(x) for x in raw if isinstance(x, (int, float)) and not isinstance(x, bool)]
                    if len(chain) >= 2:
                        paths.append(chain)
                if paths:
                    name = RU_CONST.get(iau) or (item.get('common_name') or {}).get('native') or iau
                    constellation_lines.append({'iau': iau, 'name': name, 'lines': paths})
        if len(constellation_lines) < 80:
            constellation_lines = []
    except Exception as exc:
        print(f'WARNING: Stellarium constellation index skipped: {exc}')
if constellation_lines:
    catalog['constellation_lines'] = constellation_lines
    catalog['constellations'] = [{'iau': c['iau'], 'name': c['name'], 'lines': c['lines'],
        'description': f"{c['name']} — одно из 88 официальных созвездий небесной сферы. На карте показаны звёзды и соединительные линии по западной skyculture Stellarium; координаты звёзд привязаны к каталогу HYG/HIP и пересчитываются для даты наблюдения. Видимость созвездия зависит от широты наблюдателя, времени года и положения над горизонтом."}
        for c in constellation_lines]
else:
    catalog['constellation_lines'] = catalog.get('constellation_lines') or []
if len(catalog.get('constellation_lines') or []) < 80:
    raise SystemExit('Stellarium constellation import incomplete: fewer than 80 constellation definitions.')

# Merge real image files only; invalid/placeholder downloads are never listed as photographs.
manifest_path = DATA / 'images_manifest.json'
image_items = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else []
images = []
for item in image_items:
    rel = str(item.get('file') or '')
    path = ASSETS / rel
    try:
        valid = path.is_file() and path.stat().st_size > 25_000
        if valid:
            with path.open('rb') as f: valid = f.read(3) == b'\xff\xd8\xff'
    except OSError:
        valid = False
    if valid:
        images.append({k: item[k] for k in ('title','file','credit','caption','source') if k in item})
# Add separately matched NASA deep-sky photographs. Never reuse one nebula's
# image for a different object; absent imagery remains absent rather than fabricated.
nebula_manifest_path = DATA / 'nebula_photo_manifest.json'
nebula_images = []
if nebula_manifest_path.exists():
    try:
        nebula_images = json.loads(nebula_manifest_path.read_text(encoding='utf-8'))
    except Exception as exc:
        print(f'WARNING: NASA nebula-photo manifest skipped: {exc}')
nebula_by_catalog = {str(x.get('catalog')): x for x in nebula_images if x.get('catalog')}
for nebula in catalog.get('nebulae') or []:
    media = nebula_by_catalog.get(str(nebula.get('catalog')))
    if not media:
        nebula.pop('image', None)
        nebula.pop('photoCredit', None)
        nebula.pop('photoSource', None)
        nebula.pop('nasaId', None)
        continue
    media_path = ASSETS / str(media.get('file') or '')
    try:
        valid = media_path.is_file() and media_path.stat().st_size >= 45_000
        if valid:
            with media_path.open('rb') as f:
                head = f.read(12)
                valid = head.startswith(b'\xff\xd8\xff') or head.startswith(b'\x89PNG\r\n\x1a\n') or (head[:4] == b'RIFF' and head[8:12] == b'WEBP')
    except OSError:
        valid = False
    if not valid:
        print(f'WARNING: invalid nebula image skipped: {media_path}')
        continue
    nebula['image'] = str(media['file'])
    nebula['photoCredit'] = str(media.get('credit') or 'NASA')
    nebula['photoSource'] = str(media.get('source') or '')
    nebula['nasaId'] = str(media.get('nasaId') or '')
    nebula_images.append({k: media[k] for k in ('title','file','credit','caption','source') if k in media})
# De-duplicate if the same media record was already added by a previous run.
seen_files = set()
combined_images = []
for item in images + nebula_images:
    rel = str(item.get('file') or '')
    if rel and rel not in seen_files:
        seen_files.add(rel)
        combined_images.append(item)
catalog['images'] = combined_images
catalog['nebula_photo_count'] = len([n for n in catalog.get('nebulae', []) if n.get('image')])
catalog['image_snapshot_date'] = '2026-11-15'

# NASA Exoplanet Archive TAP snapshot. Keep a small offline fallback if it is unreachable.
exo_path = DATA / 'exoplanets_offline.json'
exoplanets = []
if exo_path.exists():
    try:
        for row in json.loads(exo_path.read_text(encoding='utf-8')):
            if not row or not row.get('pl_name'): continue
            exoplanets.append({
                'name': row.get('pl_name'), 'host': row.get('hostname') or '—',
                'year': row.get('disc_year'), 'method': row.get('discoverymethod') or '—',
                'period': row.get('pl_orbper'), 'radius': row.get('pl_rade'),
                'mass': row.get('pl_bmasse'), 'distance': row.get('sy_dist')
            })
    except Exception as exc:
        print(f'WARNING: exoplanet snapshot parse failed: {exc}')
if not exoplanets:
    exoplanets = [
        {'name':'Proxima Centauri b','host':'Proxima Centauri','year':2016,'method':'Radial velocity'},
        {'name':'TRAPPIST-1 e','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'TRAPPIST-1 f','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'TRAPPIST-1 g','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'51 Pegasi b','host':'51 Pegasi','year':1995,'method':'Radial velocity'},
        {'name':'HD 209458 b','host':'HD 209458','year':1999,'method':'Transit'},
        {'name':'Kepler-186 f','host':'Kepler-186','year':2014,'method':'Transit'},
        {'name':'Kepler-452 b','host':'Kepler-452','year':2015,'method':'Transit'},
        {'name':'WASP-12 b','host':'WASP-12','year':2008,'method':'Transit'},
        {'name':'LHS 1140 b','host':'LHS 1140','year':2017,'method':'Transit'}
    ]
catalog['exoplanets'] = exoplanets
catalog['exoplanet_snapshot_count'] = len(exoplanets)

# Keep the catalogue, the standalone offline JSON files and inline WebView data in sync.
# The standalone files are also useful to inspection/import tools and must not keep
# stale references to the former identical GLB placeholder models.
def write_json(name, value):
    (DATA / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

write_json('stars.json', catalog.get('stars', []))
write_json('constellations.json', catalog.get('constellations', []))
write_json('constellation_lines.json', catalog.get('constellation_lines', []))
write_json('planets.json', catalog.get('planets', []))
write_json('nebulae.json', catalog.get('nebulae', []))
write_json('comets.json', catalog.get('comets', []))
write_json('missions.json', catalog.get('missions', []))
write_json('future_missions.json', catalog.get('future_missions', []))
write_json('exoplanets.json', catalog.get('exoplanets', []))
CATALOG_PATH.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding='utf-8')
html = HTML_PATH.read_text(encoding='utf-8')
start_tag = '<script id="catalog-data" type="application/json">'
start = html.find(start_tag)
if start < 0: raise SystemExit('catalog-data script element not found')
start += len(start_tag)
end = html.find('</script>', start)
if end < 0: raise SystemExit('catalog-data closing tag not found')
html = html[:start] + json.dumps(catalog, ensure_ascii=False, separators=(',', ':')) + html[end:]
HTML_PATH.write_text(html, encoding='utf-8')
print(f'Prepared AstroNuit catalogue: {len(stars)} stars ({hyg_added} HYG rows), {len(images)} NASA images, {len(exoplanets)} exoplanets, {len(catalog.get("missions", []))} mission records.')
