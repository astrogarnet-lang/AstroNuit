#!/usr/bin/env python3
"""Merge a build-time NASA Exoplanet Archive snapshot into Starwalk's offline catalogue."""
import json
from pathlib import Path
assets=Path("app/src/main/assets")
catalog_path=assets/"data/catalog.json"
catalog=json.loads(catalog_path.read_text(encoding="utf-8"))
exo_path=assets/"data/exoplanets_offline.json"
items=[]
if exo_path.exists():
    try:
        rows=json.loads(exo_path.read_text(encoding="utf-8"))
        for row in rows:
            if not row or not row.get("pl_name"): continue
            items.append({
                "name":row.get("pl_name"),"host":row.get("hostname") or "—",
                "year":row.get("disc_year"),"method":row.get("discoverymethod") or "—",
                "period":row.get("pl_orbper"),"radius":row.get("pl_rade"),
                "mass":row.get("pl_bmasse"),"distance":row.get("sy_dist")
            })
    except Exception as exc:
        print(f"Could not parse NASA exoplanet snapshot: {exc}")
catalog["exoplanets"]=items
catalog["exoplanet_snapshot_count"]=len(items)
catalog_path.write_text(json.dumps(catalog,ensure_ascii=False,separators=(",",":")),encoding="utf-8")
html_path=assets/"index.html"
html=html_path.read_text(encoding="utf-8")
start=html.find('<script id="catalog-data" type="application/json">')
if start<0: raise SystemExit("catalog-data script element not found")
start += len('<script id="catalog-data" type="application/json">')
end=html.find('</script>',start)
if end<0: raise SystemExit("catalog-data end tag not found")
html=html[:start]+json.dumps(catalog,ensure_ascii=False,separators=(",",":"))+html[end:]
html_path.write_text(html,encoding="utf-8")
print(f"Bundled {len(items)} NASA Exoplanet Archive rows in offline catalogue")
