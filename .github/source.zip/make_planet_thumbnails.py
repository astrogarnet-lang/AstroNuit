#!/usr/bin/env python3
"""Generate small planet-card images and lighter Earth overlay maps from verified originals."""
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent
TEXTURES = ROOT / 'app/src/main/assets/textures'
THUMBS = TEXTURES / 'thumbs'
REDUCED = TEXTURES / 'reduced'
RUNTIME = TEXTURES / 'runtime'
THUMBS.mkdir(parents=True, exist_ok=True)
REDUCED.mkdir(parents=True, exist_ok=True)
RUNTIME.mkdir(parents=True, exist_ok=True)
files = [
    'mercury.jpg', 'venus_clouds.jpg', 'venus_surface.jpg', 'earth.jpg',
    'mars.jpg', 'jupiter.jpg', 'saturn.jpg', 'uranus.jpg', 'neptune.jpg', 'pluto.jpg',
    'sun.jpg', 'moon.jpg', 'earth_clouds.jpg', 'earth_night.jpg'
]
for name in files:
    src = TEXTURES / name
    if not src.is_file():
        raise SystemExit(f'Missing verified planet texture: {src}')
    with Image.open(src) as im:
        if im.width < 1024 or im.height < 512 or not 1.8 <= im.width / im.height <= 2.2:
            raise SystemExit(f'Planet map is not a usable equirectangular image (expected ~2:1): {src} ({im.width}x{im.height})')
        im = im.convert('RGB')
        # Keep a 2K runtime map: the viewport is only ~380 px tall on phones,
        # so decoding 8K JPEGs wastes RAM and causes WebView texture stalls.
        # Exact power-of-two dimensions keep WebGL 1 textures complete (repeat + mipmaps).
        runtime = im.resize((2048, 1024), Image.Resampling.LANCZOS)
        runtime_path = RUNTIME / name
        runtime.save(runtime_path, 'JPEG', quality=91, optimize=True, progressive=True)
        # 512x256 thumbnails are only for the small planet cards and parade.
        im = im.resize((512, 256), Image.Resampling.LANCZOS)
        thumb = THUMBS / (Path(name).stem + '.jpg')
        im.save(thumb, 'JPEG', quality=88, optimize=True, progressive=True)
        if name in ('earth_clouds.jpg', 'earth_night.jpg'):
            runtime_path.replace(REDUCED / f'{Path(name).stem}_2k.jpg')
        print(f'{thumb.relative_to(ROOT)} {thumb.stat().st_size:,} bytes; runtime {runtime_path.stat().st_size if runtime_path.exists() else (REDUCED / f"{Path(name).stem}_2k.jpg").stat().st_size:,} bytes')

# Saturn's alpha ring map is large too; scale it once before WebView decodes it.
ring_src = TEXTURES / 'saturn_ring_alpha.png'
if ring_src.is_file():
    with Image.open(ring_src) as ring:
        ring = ring.convert('RGBA')
        if ring.width > 2048:
            h = max(1, round(ring.height * 2048 / ring.width))
            ring = ring.resize((2048, h), Image.Resampling.LANCZOS)
        ring.save(RUNTIME / 'saturn_ring_alpha.png', 'PNG', optimize=True)
        print(f'{(RUNTIME / 'saturn_ring_alpha.png').relative_to(ROOT)} {(RUNTIME / 'saturn_ring_alpha.png').stat().st_size:,} bytes')
