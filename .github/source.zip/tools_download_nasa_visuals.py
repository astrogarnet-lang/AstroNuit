#!/usr/bin/env python3
"""Fetch object-specific NASA imagery for the offline AstroNuit catalogue."""
from __future__ import annotations
import json, re, sys, time, urllib.parse, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'app/src/main/assets'
OUT = ASSETS / 'gallery/nebulae'
DATA = ASSETS / 'data'
OUT.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)

OBJECTS = [
    ('m42_orion', 'M42', 'Orion Nebula Hubble', ['orion', 'm42']),
    ('m57_ring', 'M57', 'Ring Nebula M57 Hubble', ['ring nebula', 'm57']),
    ('ngc7293_helix', 'NGC 7293', 'Helix Nebula NGC 7293 Hubble', ['helix nebula', 'ngc 7293']),
    ('m1_crab', 'M1', 'Crab Nebula M1 Hubble', ['crab nebula', 'm1']),
    ('m16_eagle', 'M16', 'Eagle Nebula Pillars of Creation Hubble', ['eagle nebula', 'pillars of creation', 'm16']),
    ('m8_lagoon', 'M8', 'Lagoon Nebula M8 Hubble', ['lagoon nebula', 'm8']),
    ('30dor_tarantula', '30 Doradus', 'Tarantula Nebula 30 Doradus Hubble', ['tarantula nebula', '30 doradus']),
    ('ngc2237_rosette', 'NGC 2237', 'Rosette Nebula NGC 2237 NASA', ['rosette nebula', 'ngc 2237']),
    ('ngc7000_north_america', 'NGC 7000', 'North America Nebula NGC 7000 NASA', ['north america nebula', 'ngc 7000']),
    ('barnard33_horsehead', 'Barnard 33', 'Horsehead Nebula Barnard 33 NASA Hubble', ['horsehead nebula', 'barnard 33']),
    ('m31_andromeda', 'M31', 'Andromeda Galaxy M31 Hubble NASA', ['andromeda galaxy', 'm31']),
]

HEADERS = {'User-Agent': 'AstroNuit-offline-catalogue/1.0 (NASA public media API)'}
def get_json(url: str, timeout: int = 35):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode('utf-8'))

def get_bytes(url: str, max_bytes: int = 16 * 1024 * 1024):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=90) as response:
        data = response.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise ValueError('image is larger than the allowed offline asset size')
    if data.startswith(b'\xff\xd8\xff'):
        ext = '.jpg'
    elif data.startswith(b'\x89PNG\r\n\x1a\n'):
        ext = '.png'
    elif data.startswith(b'RIFF') and data[8:12] == b'WEBP':
        ext = '.webp'
    else:
        raise ValueError('downloaded media is not a JPEG, PNG or WebP image')
    if len(data) < 45_000:
        raise ValueError('image is too small to be a useful deep-sky photograph')
    return data, ext

def choose_item(items, phrases, used_ids):
    ranked = []
    for item in items:
        data = (item.get('data') or [{}])[0]
        if data.get('media_type') != 'image':
            continue
        nasa_id = str(data.get('nasa_id') or '').strip()
        if not nasa_id or nasa_id in used_ids:
            continue
        title = str(data.get('title') or '').casefold()
        desc = str(data.get('description') or '').casefold()
        keywords = ' '.join(str(x.get('name') or '') for x in (data.get('keywords') or [])).casefold()
        corpus = title + ' ' + desc + ' ' + keywords
        hits = [p for p in phrases if re.search(r'(?<![a-z0-9])' + re.escape(p) + r'(?![a-z0-9])', corpus)]
        if not hits:
            continue
        if any(term in title for term in ('artist concept', 'illustration', 'diagram', 'infographic', 'poster')):
            continue
        score = sum(8 if p in title else 3 for p in hits)
        if 'hubble' in corpus: score += 2
        ranked.append((score, data, item.get('links') or []))
    ranked.sort(key=lambda x: (x[0], len(x[1].get('title') or '')), reverse=True)
    return ranked[0] if ranked else None

def asset_urls(nasa_id: str, preview_links):
    urls = []
    try:
        manifest = get_json('https://images-api.nasa.gov/asset/' + urllib.parse.quote(nasa_id, safe=''))
        for item in (manifest.get('collection') or {}).get('items') or []:
            href = str(item.get('href') or '')
            if re.search(r'\.(jpg|jpeg|png|webp)(\?|$)', href, re.I):
                urls.append(href)
    except Exception as exc:
        print(f'  asset manifest unavailable for {nasa_id}: {exc}', file=sys.stderr)
    for link in preview_links:
        href = str(link.get('href') or '')
        if re.search(r'\.(jpg|jpeg|png|webp)(\?|$)', href, re.I):
            urls.append(href)
    # Prefer the NASA large rendition; only use original if large is absent.
    def rank(url):
        s = url.casefold()
        if '~large.' in s: return 0
        if '~medium.' in s: return 1
        if '~orig.' in s: return 2
        if '~small.' in s: return 3
        return 4
    return sorted(dict.fromkeys(urls), key=rank)

manifest_rows = []
used = set()
for key, catalog, query, phrases in OBJECTS:
    print(f'NASA image search: {catalog} — {query}')
    try:
        endpoint = 'https://images-api.nasa.gov/search?' + urllib.parse.urlencode({'q': query, 'media_type': 'image', 'page_size': 60})
        result = get_json(endpoint)
        items = (result.get('collection') or {}).get('items') or []
        selected = choose_item(items, phrases, used)
        if not selected:
            print(f'  no well-matched NASA image found for {catalog}', file=sys.stderr)
            continue
        score, data, preview_links = selected
        nasa_id = str(data['nasa_id'])
        saved = None
        for url in asset_urls(nasa_id, preview_links):
            try:
                blob, ext = get_bytes(url)
                filename = key + ext
                (OUT / filename).write_bytes(blob)
                saved = (filename, url, len(blob), ext)
                break
            except Exception as exc:
                print(f'  rendition rejected for {nasa_id}: {exc}', file=sys.stderr)
        if not saved:
            print(f'  no valid image rendition for {nasa_id}', file=sys.stderr)
            continue
        filename, url, size, ext = saved
        used.add(nasa_id)
        photographer = data.get('photographer') or ''
        creator = data.get('secondary_creator') or ''
        center = data.get('center') or 'NASA'
        credit = ' / '.join(x for x in (center, creator, photographer) if x) or 'NASA'
        title = str(data.get('title') or catalog)
        description = re.sub(r'\s+', ' ', str(data.get('description') or '')).strip()
        manifest_rows.append({
            'catalog': catalog, 'key': key, 'file': 'gallery/nebulae/' + filename,
            'title': title, 'caption': description[:900], 'credit': credit,
            'source': 'https://images.nasa.gov/details/' + nasa_id,
            'nasaId': nasa_id, 'bytes': size, 'format': ext.lstrip('.').upper(),
            'sourceUrl': url,
        })
        print(f'  saved {filename} ({size:,} bytes), NASA ID {nasa_id}')
        time.sleep(.15)
    except Exception as exc:
        print(f'  skipped {catalog}: {exc}', file=sys.stderr)

(DATA / 'nebula_photo_manifest.json').write_text(json.dumps(manifest_rows, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'Validated {len(manifest_rows)} object-specific NASA deep-sky images.')
if len(manifest_rows) < 6:
    raise SystemExit('NASA image catalogue returned fewer than six distinct, validated deep-sky photographs; refusing to build a misleading generic nebula gallery.')
