import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({
    super.key,
    required this.onFinished,
    this.languageCode,
  });

  final VoidCallback onFinished;
  final String? languageCode;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const Duration _totalDuration = Duration(seconds: 14);

  late final AnimationController _controller;
  late final Animation<double> _welcomeOpacity;
  bool _completed = false;

  double get _elapsedSeconds => _controller.value * 14.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: _totalDuration,
    );
    _welcomeOpacity = CurvedAnimation(
      parent: _controller,
      curve: const Interval(
        8 / 14,
        10 / 14,
        curve: Curves.easeOutCubic,
      ),
    );
    // Complete from the controller status itself instead of relying on an
    // async continuation. This keeps the hand-off deterministic at the exact
    // end of the 14-second animation, including in widget tests.
    _controller.addStatusListener(_handleAnimationStatus);
    _controller.forward();
  }

  void _handleAnimationStatus(AnimationStatus status) {
    if (status != AnimationStatus.completed || !mounted || _completed) return;
    _completed = true;
    widget.onFinished();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // The app passes its selected language. If the splash is used on its own,
    // fall back to the device language.
    final languageCode = widget.languageCode ??
        WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    final isRussian = languageCode.toLowerCase().startsWith('ru');
    final tagline = isRussian
        ? 'Твой спутник во тьме'
        : 'Your companion in the dark';
    final welcome = isRussian
        ? 'Добро пожаловать во тьму'
        : 'Welcome to the darkness';

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final elapsed = _elapsedSeconds;
        // Avoid floating-point drift at exact phase boundaries (e.g. 7.999999).
        const boundaryTolerance = 0.001;
        final liquidProgress =
            ((elapsed - 4.0) / 4.0).clamp(0.0, 1.0).toDouble();
        final isDark = elapsed >= 4.0 - boundaryTolerance;

        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: isDark
              ? SystemUiOverlayStyle.light.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.black,
                  systemNavigationBarIconBrightness: Brightness.light,
                )
              : SystemUiOverlayStyle.dark.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.white,
                  systemNavigationBarIconBrightness: Brightness.dark,
                ),
          child: Scaffold(
            backgroundColor: Colors.white,
            body: SizedBox.expand(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // 0–8 s: the first phrase stays on the white canvas and is
                  // physically covered by the growing black liquid shape.
                  if (elapsed < 8.0 - boundaryTolerance)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 28),
                        child: Text(
                          tagline,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Color(0xFF17181B),
                            fontSize: 22,
                            fontWeight: FontWeight.w500,
                            letterSpacing: -0.3,
                          ),
                        ),
                      ),
                    ),

                  // 4–8 s: organic dark liquid grows inward from every edge
                  // and corner until the whole display is completely black.
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _LiquidDarknessPainter(
                          progress: liquidProgress,
                        ),
                      ),
                    ),
                  ),

                  // 8–10 s: only after the liquid has covered the full screen,
                  // the welcome phrase slowly emerges. It remains for 4 s.
                  if (elapsed > 8.0 + boundaryTolerance)
                    Center(
                      child: FadeTransition(
                        opacity: _welcomeOpacity,
                        child: AnimatedBuilder(
                          animation: _welcomeOpacity,
                          builder: (context, child) => Transform.translate(
                            offset: Offset(
                              0,
                              9 * (1 - _welcomeOpacity.value),
                            ),
                            child: child,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 28),
                            child: Text(
                              welcome,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w500,
                                letterSpacing: -0.3,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Expanding, overlapping liquid pools create an irregular front that grows
/// from all four corners and all four edges. At progress 1 every pixel is black.
class _LiquidDarknessPainter extends CustomPainter {
  const _LiquidDarknessPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty || progress <= 0) return;

    final p = Curves.easeInOutCubic.transform(
      progress.clamp(0.0, 1.0).toDouble(),
    );
    final diagonal = math.sqrt(size.width * size.width + size.height * size.height);
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    // The corner pools are deliberately larger than the screen diagonal at
    // the final frame, guaranteeing that no white corner or text fragment
    // remains visible at the end of the 4-second absorption.
    final corners = <Offset>[
      Offset.zero,
      Offset(size.width, 0),
      Offset(size.width, size.height),
      Offset(0, size.height),
    ];
    for (var i = 0; i < corners.length; i++) {
      final ripple = 1.075 + 0.035 * math.sin(i * 2.1 + p * math.pi * 1.4);
      canvas.drawCircle(corners[i], diagonal * p * ripple, paint);
    }

    // Secondary pools along each edge make the advancing boundary more like
    // spreading ink/liquid than four simple circular wipes.
    final edgePools = <Offset>[
      Offset(size.width * 0.28, 0),
      Offset(size.width * 0.72, 0),
      Offset(size.width, size.height * 0.30),
      Offset(size.width, size.height * 0.72),
      Offset(size.width * 0.28, size.height),
      Offset(size.width * 0.72, size.height),
      Offset(0, size.height * 0.30),
      Offset(0, size.height * 0.72),
    ];
    for (var i = 0; i < edgePools.length; i++) {
      final ripple = 0.72 + 0.08 * math.sin(i * 1.63 + p * math.pi * 1.8);
      canvas.drawCircle(edgePools[i], diagonal * p * ripple, paint);
    }

    // Smaller drops add a softer, uneven liquid edge in the middle of the
    // transition without changing the final fully-black state.
    final drops = <Offset>[
      Offset(size.width * 0.12, size.height * 0.12),
      Offset(size.width * 0.88, size.height * 0.15),
      Offset(size.width * 0.86, size.height * 0.86),
      Offset(size.width * 0.14, size.height * 0.84),
    ];
    for (var i = 0; i < drops.length; i++) {
      final phase = 0.86 + 0.08 * math.sin(i * 2.0 + p * math.pi);
      canvas.drawCircle(drops[i], diagonal * p * phase, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _LiquidDarknessPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
