package com.astronuit.smartfridge;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.util.Base64;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web;
  private ValueCallback<Uri[]> fileCallback;
  private static final int FILE_REQ=4107;
  private final ExecutorService work = Executors.newSingleThreadExecutor();
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(android.graphics.Color.rgb(7,16,35));
    getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,16,35));
    web=new WebView(this); web.setBackgroundColor(android.graphics.Color.rgb(7,16,35));
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setDatabaseEnabled(true); s.setMediaPlaybackRequiresUserGesture(true);
    s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
        if(fileCallback!=null) fileCallback.onReceiveValue(null);
        fileCallback=callback;
        Intent intent=params.createIntent();
        try { startActivityForResult(intent, FILE_REQ); return true; }
        catch(Exception e){ fileCallback=null; return false; }
      }
    }); web.addJavascriptInterface(new Bridge(), "AndroidBridge");
    web.loadUrl("file:///android_asset/index.html"); setContentView(web);
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_REQ && fileCallback!=null){ Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data); fileCallback.onReceiveValue(result); fileCallback=null; }
  }
  @Override public void onBackPressed(){ if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  public class Bridge {
    @JavascriptInterface public void scanImage(String base64) {
      work.execute(() -> {
        try {
          byte[] bytes=Base64.decode(base64, Base64.DEFAULT); Bitmap bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
          if(bmp==null) throw new IllegalArgumentException("Не удалось прочитать изображение");
          InputImage img=InputImage.fromBitmap(bmp,0);
          JSONObject out=new JSONObject();
          TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(img)
            .addOnSuccessListener(text -> {
              try { out.put("text", text.getText()); } catch(Exception ignored){}
              BarcodeScanning.getClient().process(img).addOnSuccessListener(codes -> {
                try { if(!codes.isEmpty()) out.put("barcode", codes.get(0).getRawValue()); } catch(Exception ignored){}
                final String result=out.toString(); runOnUiThread(() -> web.evaluateJavascript("window.onNativeScan && window.onNativeScan("+JSONObject.quote(result)+")", null));
              }).addOnFailureListener(e -> { final String result=out.toString(); runOnUiThread(() -> web.evaluateJavascript("window.onNativeScan && window.onNativeScan("+JSONObject.quote(result)+")", null)); });
            }).addOnFailureListener(e -> runOnUiThread(() -> web.evaluateJavascript("window.onNativeScan && window.onNativeScan(JSON.stringify({error:"+JSONObject.quote(e.getMessage())+"}))", null)));
        } catch(Exception e){ runOnUiThread(() -> web.evaluateJavascript("window.onNativeScan && window.onNativeScan(JSON.stringify({error:"+JSONObject.quote(e.getMessage())+"}))", null)); }
      });
    }
    @JavascriptInterface public String appVersion(){ return "1.0.0"; }
  }
  @Override protected void onDestroy(){ work.shutdown(); if(web!=null) web.destroy(); super.onDestroy(); }
}
