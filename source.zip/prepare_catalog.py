#!/usr/bin/env python3
"""Build Starwalk's local sky catalogue from curated records and the verified HYG v4.0 snapshot."""
from __future__ import annotations
import csv, gzip, json, math, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / 'app/src/main/assets'
DATA = ASSETS / 'data'
CATALOG_PATH = DATA / 'catalog.json'
HTML_PATH = ASSETS / 'index.html'

catalog = json.loads(CATALOG_PATH.read_text(encoding='utf-8'))

def number(value, default=None):
    try:
        x = float(value)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default

# HYG v4.0 contains the combined Hipparcos/Yale/Gliese star catalogue.
# Retain the curated Russian display names first, then add catalogue rows to V=6.5.
curated = list(catalog.get('stars') or [])
stars = []
seen_hip = set()
seen_proper = set()
seen_names = set()
seen_coords = set()
for s in curated:
    row = dict(s)
    ra = number(row.get('ra'), 0.0)
    dec = number(row.get('dec'), 0.0)
    row['ra'], row['dec'] = ra, dec
    row['mag'] = number(row.get('mag', row.get('magnitude')), 5.0)
    row['ci'] = number(row.get('ci'), 0.4)
    proper_raw = str(row.get('proper') or '').strip()
    display_name = str(row.get('name') or proper_raw).strip().casefold()
    if proper_raw.casefold() == 'sun' or row.get('name') == 'Солнце':
        continue
    hip = str(row.get('hip') or '').strip()
    proper = proper_raw.casefold()
    coord_key = (round(ra, 3), round(dec, 3))
    if (hip and hip in seen_hip) or (proper and proper in seen_proper) or (display_name and display_name in seen_names) or coord_key in seen_coords:
        continue
    if hip: seen_hip.add(hip)
    if proper: seen_proper.add(proper)
    if display_name: seen_names.add(display_name)
    seen_coords.add(coord_key)
    stars.append(row)

hyg_path = ROOT / 'data-source/hygdata_v40.csv'
hyg_gz_path = ROOT / 'data-source/hygdata_v40.csv.gz'
if not hyg_path.is_file() and hyg_gz_path.is_file():
    try:
        with gzip.open(hyg_gz_path, 'rt', encoding='utf-8-sig', newline='') as src, hyg_path.open('w', encoding='utf-8', newline='') as dst:
            dst.write(src.read())
    except Exception as exc:
        print(f'WARNING: HYG gzip unpack skipped: {exc}')
hyg_added = 0
if hyg_path.is_file():
    try:
        with hyg_path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            for r in reader:
                mag = number(r.get('mag'))
                ra = number(r.get('ra'))
                dec = number(r.get('dec'))
                if mag is None or mag > 6.5 or ra is None or dec is None or not -90 <= dec <= 90:
                    continue
                if not 0 <= ra <= 24:
                    continue
                hip = str(r.get('hip') or '').strip()
                proper = str(r.get('proper') or '').strip()
                if proper.casefold() == 'sun' or number(r.get('dist'), 1.0) == 0:
                    continue
                coord_key = (round(ra, 3), round(dec, 3))
                if (hip and hip in seen_hip) or (proper and (proper.casefold() in seen_proper or proper.casefold() in seen_names)) or coord_key in seen_coords:
                    continue
                ci = number(r.get('ci'), 0.45)
                dist_pc = number(r.get('dist'))
                dist = dist_pc * 3.26156 if dist_pc is not None else None
                spect = str(r.get('spect') or '').strip()
                con = str(r.get('con') or '').strip()
                hd = str(r.get('hd') or '').strip()
                hr = str(r.get('hr') or '').strip()
                bf = str(r.get('bf') or '').strip()
                stars.append({
                    'name': '', 'proper': proper, 'con': con,
                    'mag': mag, 'ci': ci, 'ra': ra, 'dec': dec,
                    'dist': dist, 'spect': spect, 'hip': hip or None,
                    'hd': hd or None, 'hr': hr or None, 'bf': bf or None,
                    'catalog_id': ('HIP '+hip) if hip else (('HD '+hd) if hd else ('HR '+hr if hr else 'HYG')),
                    'generatedBackground': False,
                    'description': ('Запись HYG v4.0. Спектральный тип: '+spect+'.' if spect else 'Запись звёздного каталога HYG v4.0.')
                })
                if hip: seen_hip.add(hip)
                if proper:
                    seen_proper.add(proper.casefold())
                    seen_names.add(proper.casefold())
                seen_coords.add(coord_key)
                hyg_added += 1
    except Exception as exc:
        print(f'WARNING: HYG import skipped: {exc}')
else:
    print('WARNING: HYG CSV not downloaded; keeping the bundled curated bright-star set.')
catalog['stars'] = stars
catalog['star_catalog_source'] = 'HYG Database v4.0 + curated bright-star display names'
catalog['star_catalog_note'] = 'HYG v4.0 snapshot; build imports verified catalogue entries to visual magnitude 6.5.'
catalog['star_catalog_limit'] = 'HYG v4.0 entries with visual magnitude <= 6.5, plus the bundled named bright stars.'
catalog['hyg_rows_added'] = hyg_added

# Merge real image files only; invalid/placeholder downloads are never listed as photographs.
manifest_path = DATA / 'images_manifest.json'
image_items = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else []
images = []
for item in image_items:
    rel = str(item.get('file') or '')
    path = ASSETS / rel
    try:
        valid = path.is_file() and path.stat().st_size > 25_000
        if valid:
            with path.open('rb') as f: valid = f.read(3) == b'\xff\xd8\xff'
    except OSError:
        valid = False
    if valid:
        images.append({k: item[k] for k in ('title','file','credit','caption','source') if k in item})
catalog['images'] = images
catalog['image_snapshot_date'] = '2026-11-15'

# NASA Exoplanet Archive TAP snapshot. Keep a small offline fallback if it is unreachable.
exo_path = DATA / 'exoplanets_offline.json'
exoplanets = []
if exo_path.exists():
    try:
        for row in json.loads(exo_path.read_text(encoding='utf-8')):
            if not row or not row.get('pl_name'): continue
            exoplanets.append({
                'name': row.get('pl_name'), 'host': row.get('hostname') or '—',
                'year': row.get('disc_year'), 'method': row.get('discoverymethod') or '—',
                'period': row.get('pl_orbper'), 'radius': row.get('pl_rade'),
                'mass': row.get('pl_bmasse'), 'distance': row.get('sy_dist')
            })
    except Exception as exc:
        print(f'WARNING: exoplanet snapshot parse failed: {exc}')
if not exoplanets:
    exoplanets = [
        {'name':'Proxima Centauri b','host':'Proxima Centauri','year':2016,'method':'Radial velocity'},
        {'name':'TRAPPIST-1 e','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'TRAPPIST-1 f','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'TRAPPIST-1 g','host':'TRAPPIST-1','year':2017,'method':'Transit'},
        {'name':'51 Pegasi b','host':'51 Pegasi','year':1995,'method':'Radial velocity'},
        {'name':'HD 209458 b','host':'HD 209458','year':1999,'method':'Transit'},
        {'name':'Kepler-186 f','host':'Kepler-186','year':2014,'method':'Transit'},
        {'name':'Kepler-452 b','host':'Kepler-452','year':2015,'method':'Transit'},
        {'name':'WASP-12 b','host':'WASP-12','year':2008,'method':'Transit'},
        {'name':'LHS 1140 b','host':'LHS 1140','year':2017,'method':'Transit'}
    ]
catalog['exoplanets'] = exoplanets
catalog['exoplanet_snapshot_count'] = len(exoplanets)

# Keep the catalogue, the standalone offline JSON files and inline WebView data in sync.
# The standalone files are also useful to inspection/import tools and must not keep
# stale references to the former identical GLB placeholder models.
def write_json(name, value):
    (DATA / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

write_json('stars.json', catalog.get('stars', []))
write_json('planets.json', catalog.get('planets', []))
write_json('nebulae.json', catalog.get('nebulae', []))
write_json('comets.json', catalog.get('comets', []))
write_json('missions.json', catalog.get('missions', []))
write_json('future_missions.json', catalog.get('future_missions', []))
write_json('exoplanets.json', catalog.get('exoplanets', []))
CATALOG_PATH.write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding='utf-8')
html = HTML_PATH.read_text(encoding='utf-8')
start_tag = '<script id="catalog-data" type="application/json">'
start = html.find(start_tag)
if start < 0: raise SystemExit('catalog-data script element not found')
start += len(start_tag)
end = html.find('</script>', start)
if end < 0: raise SystemExit('catalog-data closing tag not found')
html = html[:start] + json.dumps(catalog, ensure_ascii=False, separators=(',', ':')) + html[end:]
HTML_PATH.write_text(html, encoding='utf-8')
print(f'Prepared Starwalk catalogue: {len(stars)} stars ({hyg_added} HYG rows), {len(images)} NASA photos, {len(exoplanets)} exoplanets, {len(catalog.get("missions", []))} mission records.')
