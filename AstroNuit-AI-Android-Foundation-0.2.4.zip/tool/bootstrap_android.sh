#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ ! -d android ]]; then
  TEMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TEMP_DIR"' EXIT

  flutter create \
    --platforms=android \
    --org com.astronuit \
    --project-name astronuit \
    --android-language kotlin \
    "$TEMP_DIR/astronuit"

  cp -R "$TEMP_DIR/astronuit/android" "$ROOT_DIR/android"

  echo "Android platform scaffold created."
else
  echo "Android platform folder already exists."
fi

# Enforce offline-only permissions in every build variant and remove cleartext HTTP.
python3 - "$ROOT_DIR/android/app/src" <<'PYXML'
from pathlib import Path
import re, sys
src = Path(sys.argv[1])
main = src / 'main' / 'AndroidManifest.xml'
main.parent.mkdir(parents=True, exist_ok=True)
if not main.exists():
    raise SystemExit('Android main manifest not found after Flutter scaffold')
text = main.read_text(encoding='utf-8')
text = re.sub(r'\s+android:usesCleartextTraffic="[^"]*"', '', text)
text = re.sub(r'<uses-permission\b[^>]*android:name="android\.permission\.(?:INTERNET|ACCESS_NETWORK_STATE)"[^>]*/>\s*', '', text)
if 'xmlns:tools=' not in text:
    text = text.replace('<manifest ', '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)
remove_nodes = '''    <uses-permission android:name="android.permission.INTERNET" tools:node="remove" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" tools:node="remove" />
'''
if 'tools:node="remove"' not in text:
    text = text.replace('<application', remove_nodes + '    <application', 1)
main.write_text(text, encoding='utf-8')
for variant in ('debug', 'profile'):
    manifest = src / variant / 'AndroidManifest.xml'
    if manifest.exists():
        data = manifest.read_text(encoding='utf-8')
        data = re.sub(r'<uses-permission\b[^>]*android:name="android\.permission\.(?:INTERNET|ACCESS_NETWORK_STATE)"[^>]*/>\s*', '', data)
        manifest.write_text(data, encoding='utf-8')
PYXML

# Native Android document/image picker. This avoids relying on a file_picker
# MethodChannel plugin that may be absent from an already-installed APK.
MAIN_ACTIVITY_DIR="$ROOT_DIR/android/app/src/main/kotlin/com/astronuit/astronuit"
mkdir -p "$MAIN_ACTIVITY_DIR"
cat > "$MAIN_ACTIVITY_DIR/MainActivity.kt" <<'KOTLIN'
package com.astronuit.astronuit

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.OpenableColumns
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import com.tekartik.sqflite.SqflitePlugin
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class MainActivity : FlutterActivity() {
    private val channelName = "com.astronuit/document_picker"
    private val documentRequest = 9015
    private val imageRequest = 9016
    private var pendingPickerResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        // Register SQLite first. Flutter's generated registrar may stop when a
        // different native plugin throws an UnsatisfiedLinkError during attach.
        if (!flutterEngine.plugins.has(SqflitePlugin::class.java)) {
            flutterEngine.plugins.add(SqflitePlugin())
        }
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickDocument" -> openPicker("document", result)
                    "pickImage" -> openPicker("image", result)
                    "extractBundledModel" -> {
                        Thread {
                            try {
                                val model = extractBundledModel()
                                runOnUiThread { result.success(model.absolutePath) }
                            } catch (error: Exception) {
                                runOnUiThread { result.error("MODEL_EXTRACT_FAILED", error.message, null) }
                            }
                        }.start()
                    }
                    "getMemoryInfo" -> {
                        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
                        val memory = ActivityManager.MemoryInfo()
                        manager.getMemoryInfo(memory)
                        result.success(mapOf(
                            "totalBytes" to memory.totalMem,
                            "availableBytes" to memory.availMem,
                            "lowMemory" to memory.lowMemory
                        ))
                    }
                    else -> result.notImplemented()
                }
            }
    }

    /** Copy the APK asset to private storage without buffering the 347 MB model in RAM. */
    private fun extractBundledModel(): File {
        val modelName = "qwen3_0.6b_q4_block32_ekv1280.litertlm"
        val modelDir = File(filesDir, "models")
        if (!modelDir.exists() && !modelDir.mkdirs()) {
            throw IOException("Не удалось создать закрытую папку модели")
        }
        val destination = File(modelDir, modelName)
        if (destination.exists() && destination.length() in (300L * 1024 * 1024)..(400L * 1024 * 1024)) {
            return destination
        }

        val temporary = File(modelDir, "$modelName.partial")
        if (temporary.exists()) temporary.delete()
        assets.open("flutter_assets/assets/models/$modelName").use { source ->
            FileOutputStream(temporary).buffered().use { sink ->
                source.copyTo(sink, 1024 * 1024)
                sink.flush()
            }
        }
        if (temporary.length() !in (300L * 1024 * 1024)..(400L * 1024 * 1024)) {
            temporary.delete()
            throw IOException("Встроенная модель имеет неверный размер")
        }
        if (destination.exists() && !destination.delete()) {
            temporary.delete()
            throw IOException("Не удалось заменить старый файл модели")
        }
        if (!temporary.renameTo(destination)) {
            temporary.delete()
            throw IOException("Не удалось сохранить встроенную модель")
        }
        return destination
    }

    private fun openPicker(kind: String, result: MethodChannel.Result) {
        if (pendingPickerResult != null) {
            result.error("PICKER_BUSY", "Another file picker is already open.", null)
            return
        }
        val request = if (kind == "image") imageRequest else documentRequest
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = when (kind) {
                "image" -> "image/*"
                "document" -> "*/*"
                else -> "application/octet-stream"
            }
            if (kind == "document") {
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/pdf", "text/plain", "text/markdown", "text/csv", "application/json"
                ))
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        pendingPickerResult = result
        try {
            startActivityForResult(intent, request)
        } catch (error: Exception) {
            pendingPickerResult = null
            result.error("PICKER_START_FAILED", error.message, null)
        }
    }

    @Deprecated("Deprecated by Android; retained for FlutterActivity picker results")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val kind = when (requestCode) {
            documentRequest -> "document"
            imageRequest -> "image"
            else -> return
        }
        val callback = pendingPickerResult ?: return
        pendingPickerResult = null
        if (resultCode != Activity.RESULT_OK) {
            callback.success(null)
            return
        }
        val uri = data?.data
        if (uri == null) {
            callback.success(null)
            return
        }
        Thread {
            try {
                val displayName = resolveDisplayName(uri)
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "file" }
                val destination = File(cacheDir, "astronuit_${System.currentTimeMillis()}_$safeName")
                val temp = File(destination.parentFile, destination.name + ".partial")
                val input = contentResolver.openInputStream(uri) ?: throw IOException("Unable to open selected file")
                input.use { source -> temp.outputStream().buffered().use { sink -> source.copyTo(sink, 1024 * 1024) } }
                if (destination.exists() && !destination.delete()) throw IOException("Cannot replace previous file")
                if (!temp.renameTo(destination)) throw IOException("Cannot finalize copied file")
                runOnUiThread {
                    callback.success(mapOf("path" to destination.absolutePath, "name" to displayName))
                }
            } catch (error: Exception) {
                runOnUiThread { callback.error("IMPORT_FAILED", error.message, null) }
            }
        }.start()
    }

    private fun resolveDisplayName(uri: Uri): String {
        var cursor: Cursor? = null
        return try {
            cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            if (cursor != null && cursor.moveToFirst()) {
                cursor.getString(0)?.takeIf { it.isNotBlank() } ?: "file"
            } else {
                uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "file"
            }
        } finally {
            cursor?.close()
        }
    }
}

KOTLIN

# ---------------------------------------------------------------------------
# Force API 36 everywhere for compatibility with current Android plugins.
# ---------------------------------------------------------------------------

force_props() {
  local f="$1"
  mkdir -p "$(dirname "$f")"
  touch "$f"
  # strip old keys then append
  if grep -q 'flutter.compileSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.compileSdkVersion/d' "$f"
  fi
  if grep -q 'flutter.targetSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.targetSdkVersion/d' "$f"
  fi
  if grep -q 'flutter.minSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.minSdkVersion/d' "$f"
  fi
  printf '\nflutter.compileSdkVersion=36\nflutter.targetSdkVersion=36\nflutter.minSdkVersion=30\n' >> "$f"
}

force_props "$ROOT_DIR/android/local.properties"
force_props "$ROOT_DIR/android/gradle.properties"

# Harden app build script: replace ANY compileSdk / targetSdk assignment with 36
patch_app_build() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  # Kotlin DSL
  sed -i -E 's/minSdk\s*=\s*flutter\.minSdkVersion/minSdk = 30/' "$f" || true
  sed -i -E 's/minSdk\s*=\s*[0-9]+/minSdk = 30/' "$f" || true
  sed -i -E 's/minSdkVersion\s+flutter\.minSdkVersion/minSdkVersion 30/' "$f" || true
  sed -i -E 's/compileSdk\s*=\s*flutter\.compileSdkVersion/compileSdk = 36/' "$f" || true
  sed -i -E 's/targetSdk\s*=\s*flutter\.targetSdkVersion/targetSdk = 36/' "$f" || true
  sed -i -E 's/compileSdk\s*=\s*[0-9]+/compileSdk = 36/' "$f" || true
  sed -i -E 's/targetSdk\s*=\s*[0-9]+/targetSdk = 36/' "$f" || true
  # Groovy
  sed -i -E 's/compileSdkVersion\s+flutter\.compileSdkVersion/compileSdkVersion 36/' "$f" || true
  sed -i -E 's/targetSdkVersion\s+flutter\.targetSdkVersion/targetSdkVersion 36/' "$f" || true
  sed -i -E 's/compileSdkVersion\s+[0-9]+/compileSdkVersion 36/' "$f" || true
  sed -i -E 's/targetSdkVersion\s+[0-9]+/targetSdkVersion 36/' "$f" || true
  sed -i -E 's/compileSdk\s+[0-9]+/compileSdk 36/' "$f" || true
  sed -i -E 's/targetSdk\s+[0-9]+/targetSdk 36/' "$f" || true
}

patch_app_build "$ROOT_DIR/android/app/build.gradle.kts"
patch_app_build "$ROOT_DIR/android/app/build.gradle"

# LiteRT-LM and its vision encoder ship arm64-v8a native libraries only.
for f in "$ROOT_DIR/android/app/build.gradle.kts" "$ROOT_DIR/android/app/build.gradle"; do
  [[ -f "$f" ]] || continue
  if ! grep -q 'arm64-v8a' "$f"; then
    if [[ "$f" == *.kts ]]; then
      sed -i '0,/defaultConfig[[:space:]]*{/s//defaultConfig {\n        ndk { abiFilters += listOf("arm64-v8a") }/' "$f"
    else
      sed -i "0,/defaultConfig[[:space:]]*{/s//defaultConfig {\n        ndk { abiFilters 'arm64-v8a' }/" "$f"
    fi
  fi
done

# If compileSdk line is still a flutter.* reference or missing, inject hard value.
ensure_compile_sdk_line() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  if ! grep -qE 'compileSdk\s*=\s*36|compileSdkVersion\s+36|compileSdk\s+36' "$f"; then
    # Insert after `android {`
    if grep -q 'android\s*{' "$f"; then
      sed -i '0,/android\s*{/s//android {\n    compileSdk = 36/' "$f"
    fi
  fi
  if ! grep -qE 'targetSdk\s*=\s*36|targetSdkVersion\s+36|targetSdk\s+36' "$f"; then
    if grep -q 'defaultConfig\s*{' "$f"; then
      sed -i '0,/defaultConfig\s*{/s//defaultConfig {\n        targetSdk = 36/' "$f"
    fi
  fi
}
ensure_compile_sdk_line "$ROOT_DIR/android/app/build.gradle.kts"
ensure_compile_sdk_line "$ROOT_DIR/android/app/build.gradle"

# Force every Android library subproject onto compileSdk 36.
# CRITICAL: never register afterEvaluate from inside pluginManager.withPlugin — that runs
# mid-evaluation and causes:
#   "Cannot run Project.afterEvaluate(Action) when the project is already evaluated."
# Instead register via gradle.beforeProject (fires before a project is evaluated).

FORCE_GROOVY=$(cat <<'GROOVY'
// AstroNuit: force API 36 for all Android subprojects.
def astronuitForceCompileSdk36(Project p) {
    def android = p.extensions.findByName("android")
    if (android == null) return
    try {
        android.compileSdk = 36
    } catch (Throwable t1) {
        try {
            android.compileSdkVersion = 36
        } catch (Throwable t2) {
            try {
                android.compileSdkVersion(36)
            } catch (Throwable t3) {
                try {
                    def m = android.class.methods.find {
                        it.name in ["setCompileSdk", "setCompileSdkVersion"] && it.parameterCount == 1
                    }
                    m?.invoke(android, 36)
                } catch (Throwable t4) {}
            }
        }
    }
}
gradle.beforeProject { proj ->
    if (proj == rootProject) return
    proj.afterEvaluate {
        astronuitForceCompileSdk36(proj)
    }
}
GROOVY
)

FORCE_KTS=$(cat <<'KTS'
// AstroNuit: force API 36 for all Android subprojects.
// Registered via beforeProject so afterEvaluate is never called on an already-evaluated project.
fun Project.astronuitForceCompileSdk36() {
    val androidExt = extensions.findByName("android") ?: return
    try {
        androidExt.javaClass.methods
            .firstOrNull { it.name == "setCompileSdk" && it.parameterCount == 1 }
            ?.invoke(androidExt, 36)
    } catch (_: Throwable) {
    }
    try {
        androidExt.javaClass.methods
            .firstOrNull { it.name == "setCompileSdkVersion" && it.parameterCount == 1 }
            ?.invoke(androidExt, 36)
    } catch (_: Throwable) {
    }
}
gradle.beforeProject {
    if (this == rootProject) return@beforeProject
    afterEvaluate {
        astronuitForceCompileSdk36()
    }
}
KTS
)

ROOT_G="$ROOT_DIR/android/build.gradle"
ROOT_KTS="$ROOT_DIR/android/build.gradle.kts"

# Strip any previous AstroNuit force blocks from both files
for f in "$ROOT_G" "$ROOT_KTS"; do
  if [[ -f "$f" ]] && grep -q 'AstroNuit: force API 36' "$f"; then
    sed -i '/AstroNuit: force API 36/,$d' "$f"
  fi
done

if [[ -f "$ROOT_G" ]]; then
  printf '\n%s\n' "$FORCE_GROOVY" >> "$ROOT_G"
elif [[ -f "$ROOT_KTS" ]]; then
  printf '\n%s\n' "$FORCE_KTS" >> "$ROOT_KTS"
else
  printf 'allprojects { repositories { google(); mavenCentral() } }\n%s\n' "$FORCE_GROOVY" > "$ROOT_G"
fi

# gradle.properties: force Flutter SDK levels
GRADLE_PROPS="$ROOT_DIR/android/gradle.properties"
mkdir -p "$ROOT_DIR/android"
touch "$GRADLE_PROPS"
for key in android.suppressUnsupportedCompileSdk flutter.compileSdkVersion flutter.targetSdkVersion flutter.minSdkVersion; do
  if grep -q "^${key}=" "$GRADLE_PROPS" 2>/dev/null; then
    sed -i "/^${key}=/d" "$GRADLE_PROPS"
  fi
done
cat >> "$GRADLE_PROPS" << 'PROPS'
android.suppressUnsupportedCompileSdk=36
flutter.compileSdkVersion=36
flutter.targetSdkVersion=36
flutter.minSdkVersion=30
PROPS

echo "compileSdk/targetSdk forced to 36 (app + subprojects via beforeProject)."

# Install B&W milky-way launcher icons when provided in the package.
ICON_SRC="$ROOT_DIR/android_icons"
if [[ -d "$ICON_SRC" ]]; then
  for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    dest="$ROOT_DIR/android/app/src/main/res/mipmap-$density"
    mkdir -p "$dest"
    if [[ -f "$ICON_SRC/mipmap-$density/ic_launcher.png" ]]; then
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher.png"
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher_round.png"
    fi
  done
  echo "Launcher icons installed."
fi
