#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ ! -d android ]]; then
  TEMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TEMP_DIR"' EXIT

  flutter create \
    --platforms=android \
    --org com.astronuit \
    --project-name astronuit \
    --android-language kotlin \
    "$TEMP_DIR/astronuit"

  cp -R "$TEMP_DIR/astronuit/android" "$ROOT_DIR/android"

  MANIFEST="$ROOT_DIR/android/app/src/main/AndroidManifest.xml"
  if [[ -f "$MANIFEST" ]]; then
    sed -i 's/android:label="astronuit"/android:label="AstroNuit"/' "$MANIFEST"
    if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
      sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET" />' "$MANIFEST"
    fi
  fi
  echo "Android platform scaffold created."
else
  echo "Android platform folder already exists."
fi

# ---------------------------------------------------------------------------
# Force API 36 everywhere — required by flutter_plugin_android_lifecycle /
# file_picker (they refuse to build when the consumer is on compileSdk < 36).
# ---------------------------------------------------------------------------

force_props() {
  local f="$1"
  mkdir -p "$(dirname "$f")"
  touch "$f"
  # strip old keys then append
  if grep -q 'flutter.compileSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.compileSdkVersion/d' "$f"
  fi
  if grep -q 'flutter.targetSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.targetSdkVersion/d' "$f"
  fi
  if grep -q 'flutter.minSdkVersion' "$f" 2>/dev/null; then
    sed -i '/flutter\.minSdkVersion/d' "$f"
  fi
  printf '\nflutter.compileSdkVersion=36\nflutter.targetSdkVersion=36\nflutter.minSdkVersion=24\n' >> "$f"
}

force_props "$ROOT_DIR/android/local.properties"
force_props "$ROOT_DIR/android/gradle.properties"

# Harden app build script: replace ANY compileSdk / targetSdk assignment with 36
patch_app_build() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  # Kotlin DSL
  sed -i -E 's/compileSdk\s*=\s*flutter\.compileSdkVersion/compileSdk = 36/' "$f" || true
  sed -i -E 's/targetSdk\s*=\s*flutter\.targetSdkVersion/targetSdk = 36/' "$f" || true
  sed -i -E 's/compileSdk\s*=\s*[0-9]+/compileSdk = 36/' "$f" || true
  sed -i -E 's/targetSdk\s*=\s*[0-9]+/targetSdk = 36/' "$f" || true
  # Groovy
  sed -i -E 's/compileSdkVersion\s+flutter\.compileSdkVersion/compileSdkVersion 36/' "$f" || true
  sed -i -E 's/targetSdkVersion\s+flutter\.targetSdkVersion/targetSdkVersion 36/' "$f" || true
  sed -i -E 's/compileSdkVersion\s+[0-9]+/compileSdkVersion 36/' "$f" || true
  sed -i -E 's/targetSdkVersion\s+[0-9]+/targetSdkVersion 36/' "$f" || true
  sed -i -E 's/compileSdk\s+[0-9]+/compileSdk 36/' "$f" || true
  sed -i -E 's/targetSdk\s+[0-9]+/targetSdk 36/' "$f" || true
}

patch_app_build "$ROOT_DIR/android/app/build.gradle.kts"
patch_app_build "$ROOT_DIR/android/app/build.gradle"

# If compileSdk line is still a flutter.* reference or missing, inject hard value.
ensure_compile_sdk_line() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  if ! grep -qE 'compileSdk\s*=\s*36|compileSdkVersion\s+36|compileSdk\s+36' "$f"; then
    # Insert after `android {`
    if grep -q 'android\s*{' "$f"; then
      sed -i '0,/android\s*{/s//android {\n    compileSdk = 36/' "$f"
    fi
  fi
  if ! grep -qE 'targetSdk\s*=\s*36|targetSdkVersion\s+36|targetSdk\s+36' "$f"; then
    if grep -q 'defaultConfig\s*{' "$f"; then
      sed -i '0,/defaultConfig\s*{/s//defaultConfig {\n        targetSdk = 36/' "$f"
    fi
  fi
}
ensure_compile_sdk_line "$ROOT_DIR/android/app/build.gradle.kts"
ensure_compile_sdk_line "$ROOT_DIR/android/app/build.gradle"

# Force every Android library subproject (plugins like file_picker) onto compileSdk 36.
# Use pluginManager.withPlugin (runs when plugin is applied) — never afterEvaluate,
# which fails with "Cannot run Project.afterEvaluate when the project is already evaluated"
# on modern AGP / Flutter Gradle plugin.
SUBPROJECTS_BLOCK='
// AstroNuit: force API 36 for all Android subprojects (file_picker / lifecycle).
subprojects { sub ->
    def forceCompileSdk36 = {
        def android = sub.extensions.findByName("android")
        if (android == null) return
        try {
            android.compileSdkVersion(36)
        } catch (Throwable ignored) {
            try {
                android.compileSdk = 36
            } catch (Throwable ignored2) {
                try {
                    android.metaClass.setProperty(android, "compileSdk", 36)
                } catch (Throwable ignored3) {}
            }
        }
    }
    sub.pluginManager.withPlugin("com.android.library", forceCompileSdk36)
    sub.pluginManager.withPlugin("com.android.application", forceCompileSdk36)
}
'

# Prefer Groovy root build.gradle for the subprojects hook (works for both).
ROOT_G="$ROOT_DIR/android/build.gradle"
ROOT_KTS="$ROOT_DIR/android/build.gradle.kts"
if [[ -f "$ROOT_G" ]]; then
  # Remove any previous broken afterEvaluate force block, then append the fixed one.
  if grep -q 'AstroNuit: force API 36' "$ROOT_G"; then
    # Drop from the marker to EOF (previous injection) and re-append.
    sed -i '/AstroNuit: force API 36/,$d' "$ROOT_G"
  fi
  printf '\n%s\n' "$SUBPROJECTS_BLOCK" >> "$ROOT_G"
elif [[ -f "$ROOT_KTS" ]]; then
  if grep -q 'AstroNuit: force API 36' "$ROOT_KTS"; then
    sed -i '/AstroNuit: force API 36/,$d' "$ROOT_KTS"
  fi
  cat >> "$ROOT_KTS" << 'KTS'

// AstroNuit: force API 36 for all Android subprojects (file_picker / lifecycle).
// pluginManager.withPlugin is safe; afterEvaluate is not (already-evaluated projects).
subprojects {
    fun forceCompileSdk36() {
        val androidExt = extensions.findByName("android") ?: return
        try {
            val m = androidExt.javaClass.methods.firstOrNull {
                (it.name == "setCompileSdkVersion" || it.name == "setCompileSdk") &&
                    it.parameterCount == 1
            }
            m?.invoke(androidExt, 36)
        } catch (_: Throwable) {
        }
    }
    pluginManager.withPlugin("com.android.library") { forceCompileSdk36() }
    pluginManager.withPlugin("com.android.application") { forceCompileSdk36() }
}
KTS
else
  # Create a minimal Groovy root file with the force block
  printf 'allprojects { repositories { google(); mavenCentral() } }\n%s\n' "$SUBPROJECTS_BLOCK" > "$ROOT_G"
fi

# settings.gradle — ensure pluginManagement repos exist (no-op if already fine)
echo "compileSdk/targetSdk forced to 36 (app + subprojects)."

# Install B&W milky-way launcher icons when provided in the package.
ICON_SRC="$ROOT_DIR/android_icons"
if [[ -d "$ICON_SRC" ]]; then
  for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    dest="$ROOT_DIR/android/app/src/main/res/mipmap-$density"
    mkdir -p "$dest"
    if [[ -f "$ICON_SRC/mipmap-$density/ic_launcher.png" ]]; then
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher.png"
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher_round.png"
    fi
  done
  echo "Launcher icons installed."
fi
