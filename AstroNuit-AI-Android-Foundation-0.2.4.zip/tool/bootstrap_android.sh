#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ ! -d android ]]; then
  TEMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TEMP_DIR"' EXIT

  flutter create \
    --platforms=android \
    --org com.astronuit \
    --project-name astronuit \
    --android-language kotlin \
    "$TEMP_DIR/astronuit"

  cp -R "$TEMP_DIR/astronuit/android" "$ROOT_DIR/android"

  MANIFEST="$ROOT_DIR/android/app/src/main/AndroidManifest.xml"
  if [[ -f "$MANIFEST" ]]; then
    sed -i 's/android:label="astronuit"/android:label="AstroNuit"/' "$MANIFEST"
    if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
      sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET" />' "$MANIFEST"
    fi
  fi
  echo "Android platform scaffold created."
else
  echo "Android platform folder already exists."
fi

# Force compileSdk / targetSdk 36 so plugins (file_picker, lifecycle) that
# require API 36 pass checkReleaseAarMetadata.
patch_sdk() {
  local f="$1"
  [[ -f "$f" ]] || return 0
  # Groovy build.gradle
  if grep -q 'compileSdk' "$f"; then
    sed -i -E 's/compileSdk\s*=?\s*[0-9]+/compileSdk = 36/' "$f" || true
    sed -i -E 's/compileSdkVersion\s+[0-9]+/compileSdkVersion 36/' "$f" || true
    sed -i -E 's/targetSdk\s*=?\s*[0-9]+/targetSdk = 36/' "$f" || true
    sed -i -E 's/targetSdkVersion\s+[0-9]+/targetSdkVersion 36/' "$f" || true
  fi
  # Kotlin DSL often uses flutter.compileSdkVersion — override after flutter block
  if grep -q 'flutter.compileSdkVersion\|compileSdk\s*=' "$f"; then
    # Ensure explicit integers win over flutter.* placeholders when present as numbers
    sed -i -E 's/compileSdk\s*=\s*flutter\.compileSdkVersion/compileSdk = 36/' "$f" || true
    sed -i -E 's/targetSdk\s*=\s*flutter\.targetSdkVersion/targetSdk = 36/' "$f" || true
  fi
}

# Also write/update local gradle property overrides if flutter.* is used.
for candidate in \
  "$ROOT_DIR/android/app/build.gradle" \
  "$ROOT_DIR/android/app/build.gradle.kts" \
  "$ROOT_DIR/android/build.gradle" \
  "$ROOT_DIR/android/build.gradle.kts"
do
  patch_sdk "$candidate"
done

# local.properties / gradle.properties helper: force SDK levels used by Flutter plugin
PROP="$ROOT_DIR/android/local.properties"
if [[ -f "$PROP" ]]; then
  grep -q 'flutter.compileSdkVersion' "$PROP" 2>/dev/null || echo 'flutter.compileSdkVersion=36' >> "$PROP"
  grep -q 'flutter.targetSdkVersion' "$PROP" 2>/dev/null || echo 'flutter.targetSdkVersion=36' >> "$PROP"
fi
GP="$ROOT_DIR/android/gradle.properties"
if [[ -f "$GP" ]]; then
  grep -q 'flutter.compileSdkVersion' "$GP" 2>/dev/null || echo 'flutter.compileSdkVersion=36' >> "$GP"
  grep -q 'flutter.targetSdkVersion' "$GP" 2>/dev/null || echo 'flutter.targetSdkVersion=36' >> "$GP"
fi

# Stronger: if app/build.gradle.kts still references flutter.compileSdkVersion, inject after android {
APP_KTS="$ROOT_DIR/android/app/build.gradle.kts"
if [[ -f "$APP_KTS" ]]; then
  if grep -q 'compileSdk' "$APP_KTS"; then
    # Replace any compileSdk / targetSdk assignment with 36
    sed -i -E 's/compileSdk\s*=.*/compileSdk = 36/' "$APP_KTS"
    sed -i -E 's/targetSdk\s*=.*/targetSdk = 36/' "$APP_KTS"
  fi
fi
APP_G="$ROOT_DIR/android/app/build.gradle"
if [[ -f "$APP_G" ]]; then
  if grep -q 'compileSdk' "$APP_G"; then
    sed -i -E 's/compileSdk\s*.*/compileSdk 36/' "$APP_G"
    sed -i -E 's/targetSdk\s*.*/targetSdk 36/' "$APP_G"
  fi
fi

echo "compileSdk/targetSdk forced to 36."

# Install B&W milky-way launcher icons when provided in the package.
ICON_SRC="$ROOT_DIR/android_icons"
if [[ -d "$ICON_SRC" ]]; then
  for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    dest="$ROOT_DIR/android/app/src/main/res/mipmap-$density"
    mkdir -p "$dest"
    if [[ -f "$ICON_SRC/mipmap-$density/ic_launcher.png" ]]; then
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher.png"
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher_round.png"
    fi
  done
  echo "Launcher icons installed."
fi
