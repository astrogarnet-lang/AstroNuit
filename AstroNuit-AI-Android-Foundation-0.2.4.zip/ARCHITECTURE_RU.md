# Архитектура AstroNuit 0.2.6

- `lib/core/document_importer.dart`: импорт PDF/TXT/MD/CSV/JSON и добавление текста в базу.
- `lib/data/knowledge_db.dart`: локальная SQLite-база документов и фрагментов, полнотекстовый поиск по ключевым словам.
- `lib/core/local_core.dart`: retrieval-ответы по найденным фрагментам и калькулятор на `math_expressions`.
- `lib/screens/chat_screen.dart`: выбор файла в чате, фаза «Думаю…» и вывод результата.

## PDF

Используется `flutter_pdf_text: ^0.9.0`, импорт `package:flutter_pdf_text/flutter_pdf_text.dart`. Текст документа читается через `PDFDoc.fromFile(file)` и `await doc.text`. OCR сканов без текстового слоя пока отсутствует.

## Ограничение модели

Генеративная LLM не входит в эту версию. Поиск по документам не является полноценной генеративной нейросетью: ответ показывает найденные фрагменты и встроенные справочные заметки.
