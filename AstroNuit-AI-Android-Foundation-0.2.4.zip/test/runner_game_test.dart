import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/screens/runner_game_screen.dart';

void main() {
  testWidgets('runner mini-game shows the lower start button', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: RunnerGameScreen(isRussian: true),
      ),
    );

    expect(find.text('Бежать'), findsOneWidget);
    expect(find.text('Лунный забег'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}
