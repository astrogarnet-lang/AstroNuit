import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/core/equation_solver.dart';

void main() {
  final solver = EquationSolver();

  test('solves a linear equation with implicit multiplication', () {
    final result = solver.solve('2x + 3 = 7');
    expect(result.kind, 'roots');
    expect(result.roots, hasLength(1));
    expect(result.roots.single, closeTo(2, 1e-7));
  });

  test('solves a quadratic with two real roots', () {
    final result = solver.solve('x² - 5x + 6 = 0');
    expect(result.kind, 'roots');
    expect(result.roots, hasLength(2));
    expect(result.roots[0], closeTo(2, 1e-6));
    expect(result.roots[1], closeTo(3, 1e-6));
  });

  test('solves cubic and quartic polynomials', () {
    final cubic = solver.solve('x^3 - x = 0');
    expect(cubic.kind, 'roots');
    expect(cubic.roots, hasLength(3));
    expect(cubic.roots[0], closeTo(-1, 1e-5));
    expect(cubic.roots[1], closeTo(0, 1e-5));
    expect(cubic.roots[2], closeTo(1, 1e-5));

    final quartic = solver.solve('x^4 - 5x² + 4 = 0');
    expect(quartic.kind, 'roots');
    expect(quartic.roots, hasLength(4));
    expect(quartic.roots[0], closeTo(-2, 1e-5));
    expect(quartic.roots[1], closeTo(-1, 1e-5));
    expect(quartic.roots[2], closeTo(1, 1e-5));
    expect(quartic.roots[3], closeTo(2, 1e-5));
  });

  test('uses bounded numerical fallback for a fifth-degree polynomial', () {
    final result = solver.solve('x^5 - 32 = 0');
    expect(result.kind, 'roots');
    expect(result.roots.any((root) => (root - 2).abs() < 1e-3), isTrue);
  });

  test('uses numeric search for a transcendental equation', () {
    final result = solver.solve('sin(x) = 0');
    expect(result.kind, 'roots');
    expect(result.roots.any((root) => root.abs() < 1e-5), isTrue);
  });

  test('reports no real roots for a negative discriminant', () {
    final result = solver.solve('x² + 1 = 0');
    expect(result.kind, 'none');
  });

  test('does not strip zeroes from integer results', () {
    final result = solver.solve('x - 100 = 0');
    expect(result.formatted, contains('100'));
  });
}
