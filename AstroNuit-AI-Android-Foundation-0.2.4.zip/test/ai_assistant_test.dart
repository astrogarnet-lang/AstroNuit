import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/core/ai_assistant.dart';

void main() {
  group('AiAssistant offline contract', () {
    test('is a singleton', () {
      expect(identical(AiAssistant.instance, AiAssistant.instance), isTrue);
    });
  });
}
