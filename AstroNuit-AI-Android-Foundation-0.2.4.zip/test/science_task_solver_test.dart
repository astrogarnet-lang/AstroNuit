import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/core/science_task_solver.dart';

void main() {
  const solver = ScienceTaskSolver();

  test('solves basic physics calculations without a model', () {
    final speed = solver.calculate('speed', {'s': 100, 't': 20});
    expect(speed?.result, '5 м/с');

    final force = solver.calculate('newton_force', {'m': 4, 'a': 3});
    expect(force?.result, '12 Н');

    final pressure = solver.calculate('pressure', {'F': 20, 'S': 2});
    expect(pressure?.result, '10 Па');
  });

  test('solves chemistry calculations without a model', () {
    final amount = solver.calculate('moles', {'m': 18, 'M': 18});
    expect(amount?.result, '1 моль');

    final ph = solver.calculate('ph', {'H': 1e-7});
    expect(double.parse(ph!.result), closeTo(7, 1e-6));

    final molarVolume = solver.calculate('gas_molar_volume', {'n': 1});
    expect(double.parse(molarVolume!.result.split(' ').first), closeTo(22.414, 0.001));
  });

  test('rejects invalid division and missing inputs', () {
    expect(solver.calculate('speed', {'s': 10, 't': 0}), isNull);
    expect(solver.calculate('moles', {'m': 10}), isNull);
  });
}
