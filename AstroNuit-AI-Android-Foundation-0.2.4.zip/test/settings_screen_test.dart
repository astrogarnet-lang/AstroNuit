import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:astronuit/app/app_strings.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/screens/settings_screen.dart';
import 'package:astronuit/widgets/neural_network_switch.dart';
import 'package:astronuit/core/offline_model_manager.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('theme selection is handled by RadioGroup', (tester) async {
    SharedPreferences.setMockInitialValues({});
    var selectedTheme = ThemeKind.light;

    await tester.pumpWidget(
      MaterialApp(
        theme: AstroNuitTheme.build(selectedTheme),
        home: Scaffold(
          body: StatefulBuilder(
            builder: (context, setState) {
              return SettingsScreen(
                strings: const AppStrings('ru'),
                themeKind: selectedTheme,
                languageCode: 'ru',
                animationsEnabled: true,
                onThemeChanged: (value) {
                  setState(() => selectedTheme = value);
                },
                onLanguageChanged: (_) {},
                onAnimationsChanged: (_) {},
              );
            },
          ),
        ),
      ),
    );

    await tester.pumpAndSettle();
    expect(find.text('Включить нейросеть'), findsOneWidget);
    expect(find.text('Встроенная офлайн-нейросеть'), findsNothing);
    expect(find.textContaining('оценочно'), findsNothing);

    await tester.tap(find.text('Тёмная'));
    await tester.pumpAndSettle();

    expect(selectedTheme, ThemeKind.dark);
  });


  testWidgets('neural switch displays only the supplied error', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final manager = OfflineModelManager.instance;
    manager.clearError();

    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: NeuralNetworkSwitch(isRussian: true),
        ),
      ),
    );
    await tester.pumpAndSettle();

    final hiddenModelName = String.fromCharCodes([81, 119, 101, 110, 51]);
    manager.reportError(Exception('$hiddenModelName native runtime failed'));
    await tester.pump();

    expect(find.text('Включить нейросеть'), findsOneWidget);
    expect(find.text('Exception: нейросеть native runtime failed'), findsOneWidget);
    expect(find.textContaining('Подготовить сейчас'), findsNothing);
    expect(find.textContaining('Модель уже'), findsNothing);

    manager.clearError();
  });

}
