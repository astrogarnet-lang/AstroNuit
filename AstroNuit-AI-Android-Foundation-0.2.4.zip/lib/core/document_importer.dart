import 'dart:io';

import 'package:flutter_pdf_text/flutter_pdf_text.dart';

import '../data/knowledge_db.dart';
import 'text_codec.dart';

class ImportResult {
  const ImportResult({
    required this.title,
    required this.chars,
    required this.documentId,
  });
  final String title;
  final int chars;
  final int documentId;
}

class DocumentImporter {
  /// Import raw text (from file picker bytes or paste).
  static Future<ImportResult> importText({
    required String title,
    required String content,
    String sourcePath = '',
    String mime = 'text/plain',
  }) async {
    final cleaned = TextCodecFix.repair(content).trim();
    if (cleaned.isEmpty) {
      throw Exception('Пустой документ');
    }
    if (TextCodecFix.looksGarbled(cleaned) && cleaned.length > 80) {
      // Still store, but warn via exception only when almost no letters.
      if (TextCodecFix.letterCount(cleaned) < 20) {
        throw Exception(
          'Не удалось прочитать текст документа «$title». '
          'Попробуйте сохранить как TXT (UTF-8) или вставить текст вручную.',
        );
      }
    }
    final id = await KnowledgeDb.instance.addDocument(
      title: title,
      content: cleaned,
      sourcePath: sourcePath,
      mime: mime,
    );
    return ImportResult(title: title, chars: cleaned.length, documentId: id);
  }

  static Future<ImportResult> importFile(
    File file, {
    String? displayName,
  }) async {
    final name = displayName?.trim().isNotEmpty == true
        ? displayName!.trim()
        : (file.uri.pathSegments.isNotEmpty
            ? file.uri.pathSegments.last
            : 'document');
    final lower = name.toLowerCase();
    if (lower.endsWith('.pdf')) {
      try {
        final doc = await PDFDoc.fromFile(file);
        var text = (await doc.text).trim();
        text = TextCodecFix.repair(text);
        // Some PDFs yield empty text via the plugin; fall back to raw bytes decode.
        if (text.isEmpty || TextCodecFix.looksGarbled(text)) {
          final bytes = await file.readAsBytes();
          // Extract printable streams heuristically from PDF binary.
          final fallback = _extractPdfStrings(bytes);
          final repaired = TextCodecFix.repair(fallback);
          if (repaired.trim().length > text.length &&
              !TextCodecFix.looksGarbled(repaired)) {
            text = repaired;
          }
        }
        if (text.trim().isEmpty) {
          throw Exception(
            'В PDF не найден текст (возможно, это скан без OCR). '
            'Сохраните текст в TXT/MD или вставьте вручную.',
          );
        }
        return await importText(
          title: name,
          content: text,
          sourcePath: file.path,
          mime: 'application/pdf',
        );
      } catch (e) {
        if (e is Exception) rethrow;
        throw Exception('Не удалось извлечь текст из PDF: $e');
      }
    }
    if (lower.endsWith('.txt') ||
        lower.endsWith('.md') ||
        lower.endsWith('.csv') ||
        lower.endsWith('.json') ||
        lower.endsWith('.dart') ||
        lower.endsWith('.py') ||
        lower.endsWith('.tex') ||
        lower.endsWith('.html') ||
        lower.endsWith('.htm') ||
        lower.endsWith('.xml')) {
      final bytes = await file.readAsBytes();
      final content = TextCodecFix.decodeBytes(bytes);
      return importText(title: name, content: content, sourcePath: file.path);
    }

    final bytes = await file.readAsBytes();
    final printable = TextCodecFix.decodeBytes(bytes)
        .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), ' ');

    if (printable.trim().length < 40) {
      throw Exception(
        'Формат «$name» пока читается ограниченно. Сохраните как TXT/MD или вставьте текст.',
      );
    }

    return importText(
      title: name,
      content: printable,
      sourcePath: file.path,
      mime: 'application/octet-stream',
    );
  }

  /// Pull long literal strings from PDF content streams (best-effort).
  static String _extractPdfStrings(List<int> bytes) {
    final raw = String.fromCharCodes(bytes);
    final buffer = StringBuffer();
    // Parentheses strings: (....) with basic escape handling.
    final paren = RegExp(r'\((?:\\.|[^\\)]){4,}\)');
    for (final m in paren.allMatches(raw)) {
      var s = m.group(0)!;
      s = s.substring(1, s.length - 1);
      s = s
          .replaceAll(r'\n', '\n')
          .replaceAll(r'\r', '\n')
          .replaceAll(r'\t', ' ')
          .replaceAll(RegExp(r'\\(.)'), r'$1');
      if (TextCodecFix.letterCount(s) >= 3) {
        buffer.writeln(s);
      }
    }
    // Hex strings <...>
    final hex = RegExp(r'<([0-9A-Fa-f \r\n]{8,})>');
    for (final m in hex.allMatches(raw)) {
      final hexBody = m.group(1)!.replaceAll(RegExp(r'\s'), '');
      if (hexBody.length % 2 != 0) continue;
      final decoded = <int>[];
      for (var i = 0; i + 1 < hexBody.length; i += 2) {
        decoded.add(int.parse(hexBody.substring(i, i + 2), radix: 16));
      }
      final s = TextCodecFix.decodeBytes(decoded);
      if (TextCodecFix.letterCount(s) >= 3) buffer.writeln(s);
    }
    return buffer.toString();
  }
}
