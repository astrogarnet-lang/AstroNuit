import 'dart:convert';

/// Helpers to repair common PDF / file encoding issues (especially Cyrillic).
class TextCodecFix {
  TextCodecFix._();

  static final _cyrillic = RegExp(r'[А-Яа-яЁё]');
  static final _letters = RegExp(r'[A-Za-zА-Яа-яЁё]');
  static final _noise = RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]');

  static int cyrillicCount(String s) => _cyrillic.allMatches(s).length;

  static int letterCount(String s) => _letters.allMatches(s).length;

  /// True when the string looks like mojibake / binary noise rather than prose.
  static bool looksGarbled(String s) {
    final compact = s.replaceAll(RegExp(r'\s+'), '');
    if (compact.isEmpty) return true;
    final letters = letterCount(compact);
    final ratio = letters / compact.length;
    // PDF mojibake often has few real letters and many symbols.
    if (ratio < 0.35) return true;
    // High density of replacement / rare control-like glyphs.
    final weird = RegExp(r'[¶§¤¥©®°±µ·¿×÷øđħŧ]').allMatches(s).length;
    if (weird > compact.length * 0.08) return true;
    return false;
  }

  /// Try to recover readable text from a possibly mis-decoded string.
  static String repair(String input) {
    var text = input.replaceAll(_noise, ' ');
    text = text.replaceAll(RegExp(r'[ \t]+\n'), '\n');
    text = text.replaceAll(RegExp(r'\n{3,}'), '\n\n');
    text = text.trim();
    if (text.isEmpty) return text;

    final baselineCyr = cyrillicCount(text);
    final baselineLetters = letterCount(text);

    // Classic mojibake: UTF-8 bytes were read as Latin-1 / Windows-1252.
    final candidates = <String>[text];
    try {
      final asLatin = latin1.encode(text);
      candidates.add(utf8.decode(asLatin, allowMalformed: true));
    } catch (_) {}

    // Reverse: Latin-1 interpretation of UTF-8 bytes (less common).
    try {
      final asUtf8 = utf8.encode(text);
      candidates.add(latin1.decode(asUtf8, allowInvalid: true));
    } catch (_) {}

    // Windows-1251 single-byte Cyrillic (common in older Russian PDFs).
    try {
      final bytes = latin1.encode(text);
      candidates.add(_decodeWindows1251(bytes));
    } catch (_) {}

    // Also try treating original file-style: map only high bytes via CP1251
    // when the string is mostly in 0x80–0xFF range characters.
    String best = text;
    var bestScore = baselineCyr * 3 + baselineLetters;
    for (final c in candidates) {
      final cleaned = c.replaceAll(_noise, ' ').trim();
      if (cleaned.isEmpty) continue;
      final score = cyrillicCount(cleaned) * 3 + letterCount(cleaned);
      if (score > bestScore && !looksGarbled(cleaned)) {
        bestScore = score;
        best = cleaned;
      } else if (score > bestScore + 20) {
        bestScore = score;
        best = cleaned;
      }
    }
    return best;
  }

  /// Decode bytes as Windows-1251 (Cyrillic).
  static String _decodeWindows1251(List<int> bytes) {
    final out = StringBuffer();
    for (final b in bytes) {
      if (b < 0x80) {
        out.writeCharCode(b);
        continue;
      }
      // Map 0x80–0xFF → Unicode Cyrillic / punctuation (CP1251).
      final mapped = _cp1251[b];
      out.writeCharCode(mapped ?? b);
    }
    return out.toString();
  }

  /// Windows-1251 high-byte map (0x80–0xFF).
  static final Map<int, int> _cp1251 = {
    0x80: 0x0402, 0x81: 0x0403, 0x82: 0x201A, 0x83: 0x0453, 0x84: 0x201E,
    0x85: 0x2026, 0x86: 0x2020, 0x87: 0x2021, 0x88: 0x20AC, 0x89: 0x2030,
    0x8A: 0x0409, 0x8B: 0x2039, 0x8C: 0x040A, 0x8D: 0x040C, 0x8E: 0x040B,
    0x8F: 0x040F, 0x90: 0x0452, 0x91: 0x2018, 0x92: 0x2019, 0x93: 0x201C,
    0x94: 0x201D, 0x95: 0x2022, 0x96: 0x2013, 0x97: 0x2014, 0x99: 0x2122,
    0x9A: 0x0459, 0x9B: 0x203A, 0x9C: 0x045A, 0x9D: 0x045C, 0x9E: 0x045B,
    0x9F: 0x045F, 0xA0: 0x00A0, 0xA1: 0x040E, 0xA2: 0x045E, 0xA3: 0x0408,
    0xA4: 0x00A4, 0xA5: 0x0490, 0xA6: 0x00A6, 0xA7: 0x00A7, 0xA8: 0x0401,
    0xA9: 0x00A9, 0xAA: 0x0404, 0xAB: 0x00AB, 0xAC: 0x00AC, 0xAD: 0x00AD,
    0xAE: 0x00AE, 0xAF: 0x0407, 0xB0: 0x00B0, 0xB1: 0x00B1, 0xB2: 0x0406,
    0xB3: 0x0456, 0xB4: 0x0491, 0xB5: 0x00B5, 0xB6: 0x00B6, 0xB7: 0x00B7,
    0xB8: 0x0451, 0xB9: 0x2116, 0xBA: 0x0454, 0xBB: 0x00BB, 0xBC: 0x0458,
    0xBD: 0x0405, 0xBE: 0x0455, 0xBF: 0x0457,
    0xC0: 0x0410, 0xC1: 0x0411, 0xC2: 0x0412, 0xC3: 0x0413, 0xC4: 0x0414,
    0xC5: 0x0415, 0xC6: 0x0416, 0xC7: 0x0417, 0xC8: 0x0418, 0xC9: 0x0419,
    0xCA: 0x041A, 0xCB: 0x041B, 0xCC: 0x041C, 0xCD: 0x041D, 0xCE: 0x041E,
    0xCF: 0x041F, 0xD0: 0x0420, 0xD1: 0x0421, 0xD2: 0x0422, 0xD3: 0x0423,
    0xD4: 0x0424, 0xD5: 0x0425, 0xD6: 0x0426, 0xD7: 0x0427, 0xD8: 0x0428,
    0xD9: 0x0429, 0xDA: 0x042A, 0xDB: 0x042B, 0xDC: 0x042C, 0xDD: 0x042D,
    0xDE: 0x042E, 0xDF: 0x042F, 0xE0: 0x0430, 0xE1: 0x0431, 0xE2: 0x0432,
    0xE3: 0x0433, 0xE4: 0x0434, 0xE5: 0x0435, 0xE6: 0x0436, 0xE7: 0x0437,
    0xE8: 0x0438, 0xE9: 0x0439, 0xEA: 0x043A, 0xEB: 0x043B, 0xEC: 0x043C,
    0xED: 0x043D, 0xEE: 0x043E, 0xEF: 0x043F, 0xF0: 0x0440, 0xF1: 0x0441,
    0xF2: 0x0442, 0xF3: 0x0443, 0xF4: 0x0444, 0xF5: 0x0445, 0xF6: 0x0446,
    0xF7: 0x0447, 0xF8: 0x0448, 0xF9: 0x0449, 0xFA: 0x044A, 0xFB: 0x044B,
    0xFC: 0x044C, 0xFD: 0x044D, 0xFE: 0x044E, 0xFF: 0x044F,
  };

  /// Prefer the best decoding of raw file bytes for text-like files.
  static String decodeBytes(List<int> bytes) {
    final attempts = <String>[];
    try {
      attempts.add(utf8.decode(bytes, allowMalformed: true));
    } catch (_) {}
    try {
      attempts.add(_decodeWindows1251(bytes));
    } catch (_) {}
    try {
      attempts.add(latin1.decode(bytes, allowInvalid: true));
    } catch (_) {}

    if (attempts.isEmpty) return '';
    String best = attempts.first;
    var bestScore = cyrillicCount(best) * 3 + letterCount(best);
    for (final a in attempts.skip(1)) {
      final score = cyrillicCount(a) * 3 + letterCount(a);
      if (score > bestScore) {
        bestScore = score;
        best = a;
      }
    }
    return repair(best);
  }
}
