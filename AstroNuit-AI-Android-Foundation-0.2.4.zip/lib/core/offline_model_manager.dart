import 'dart:io';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_edge_ai/flutter_edge_ai.dart';
import 'package:flutter_edge_ai_litertlm/flutter_edge_ai_litertlm.dart';

/// The model weights are bundled in the APK and extracted by Android using a
/// streaming copy. The model is never downloaded by the installed app.
class OfflineModelManager {
  OfflineModelManager._();
  static final OfflineModelManager instance = OfflineModelManager._();

  static const MethodChannel _platform = MethodChannel('com.astronuit/document_picker');
  static const String _installedKey = 'qwen3_0_6b_model_installed';
  bool _initialized = false;
  bool _installed = false;
  Future<void>? _initializing;
  Future<void>? _bundledInstallTask;
  dynamic _model;
  Future<dynamic>? _loading;

  bool get hasInstalledModel {
    try {
      return FlutterEdgeAi.activeModelSpec?.modelType == ModelType.qwen3 || _installed;
    } catch (_) {
      return _installed;
    }
  }

  bool get isLoaded => _model != null;
  String get modelName => 'Qwen3-0.6B INT4';

  Future<bool> refreshInstalledState() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      _installed = preferences.getBool(_installedKey) ?? false;
    } catch (_) {}
    try {
      _installed = _installed ||
          FlutterEdgeAi.activeModelSpec?.modelType == ModelType.qwen3;
    } catch (_) {}
    return _installed;
  }

  Future<void> initialize() async {
    if (_initialized) return;
    final pending = _initializing;
    if (pending != null) {
      try {
        await pending;
        _initialized = true;
        return;
      } catch (error) {
        throw OfflineModelException(
          'Не удалось инициализировать офлайн-движок Qwen3. Проверьте совместимость Android/ARM64 и повторите установку обновлённого APK. Ошибка: $error',
        );
      }
    }

    final task = FlutterEdgeAi.initialize(
      inferenceEngines: const [LiteRtLmEngine(thinkingTokenBudget: 48)],
    );
    _initializing = task;
    try {
      await task;
      _initialized = true;
      await refreshInstalledState();
    } catch (error) {
      throw OfflineModelException(
        'Не удалось инициализировать офлайн-движок Qwen3. Проверьте совместимость Android/ARM64 и повторите установку обновлённого APK. Ошибка: $error',
      );
    } finally {
      if (identical(_initializing, task)) _initializing = null;
    }
  }

  /// Ensures the APK-bundled model is copied to app-private storage and
  /// registered with LiteRT-LM. Native Android performs a bounded-memory
  /// streaming copy, so Dart does not allocate a 347 MB byte array.
  Future<void> ensureBundledModelInstalled() async {
    if (_bundledInstallTask != null) return _bundledInstallTask!;
    final task = _ensureBundledModelInstalledInternal();
    _bundledInstallTask = task;
    try {
      await task;
    } finally {
      _bundledInstallTask = null;
    }
  }

  Future<void> _ensureBundledModelInstalledInternal() async {
    await initialize();
    await refreshInstalledState();

    String? modelPath;
    try {
      modelPath = await _platform.invokeMethod<String>('extractBundledModel');
    } catch (error) {
      throw OfflineModelException(
        'Android не смог извлечь встроенную модель Qwen3 во внутреннюю память: $error',
      );
    }
    if (modelPath == null || modelPath.isEmpty) {
      throw const OfflineModelException('Android не вернул путь к встроенной модели Qwen3.');
    }
    final file = File(modelPath);
    if (!await file.exists()) {
      throw const OfflineModelException('Не удалось извлечь встроенную модель Qwen3 из APK.');
    }
    final bytes = await file.length();
    if (bytes < 300 * 1024 * 1024 || bytes > 400 * 1024 * 1024) {
      throw OfflineModelException('Размер встроенной модели (${_mb(bytes)} МБ) неверен. Переустановите APK из последней успешной сборки.');
    }

    if (!hasInstalledModel) {
      await _installModelFile(file);
    }
  }

  /// Kept as a recovery API for local development; the released UI no longer
  /// asks the user to import a separate model file.
  Future<void> importModelFromFile(String path) async {
    await initialize();
    final file = File(path);
    if (!await file.exists()) {
      throw const OfflineModelException('Выбранный файл модели не найден.');
    }
    if (!path.toLowerCase().endsWith('.litertlm')) {
      throw const OfflineModelException('Нужен файл Qwen3-0.6B формата .litertlm.');
    }
    final bytes = await file.length();
    if (bytes < 300 * 1024 * 1024 || bytes > 400 * 1024 * 1024) {
      throw OfflineModelException('Размер файла ${_mb(bytes)} МБ не соответствует Qwen3-0.6B INT4.');
    }
    await _installModelFile(file);
  }

  Future<void> _installModelFile(File file) async {
    await closeModel();
    try {
      await FlutterEdgeAi.installModel(
        modelType: ModelType.qwen3,
        fileType: ModelFileType.litertlm,
      ).fromFile(file.path).install();
      _installed = true;
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool(_installedKey, true);
    } catch (error) {
      throw OfflineModelException('Не удалось зарегистрировать Qwen3-0.6B: $error');
    }
  }

  Future<dynamic> loadModel() async {
    await initialize();
    if (_model != null) return _model;
    if (_loading != null) return _loading!;
    final task = _loadModelInternal();
    _loading = task;
    try {
      _model = await task;
      return _model;
    } finally {
      _loading = null;
    }
  }

  Future<dynamic> _loadModelInternal() async {
    try {
      await ensureBundledModelInstalled();
      await _ensureEnoughMemory();
      // 1024 is the minimum context supported by the current LiteRT bundles.
      return await FlutterEdgeAi.getActiveModel(
        maxTokens: 1024,
        preferredBackend: PreferredBackend.cpu,
        supportImage: false,
      );
    } on OfflineModelException {
      rethrow;
    } catch (error) {
      throw OfflineModelException(
        'Qwen3-0.6B не смогла запуститься. На телефоне с 2 ГБ ОЗУ это может быть ограничение свободной памяти Android. Перезагрузите устройство, закройте другие приложения и попробуйте ещё раз. Встроенные формулы и решатель уравнений при этом продолжат работать. Ошибка: $error',
      );
    }
  }

  Future<void> _ensureEnoughMemory() async {
    try {
      final info = await _platform.invokeMapMethod<String, dynamic>('getMemoryInfo');
      final totalBytes = (info?['totalBytes'] as num?)?.toInt() ?? 0;
      final availableBytes = (info?['availableBytes'] as num?)?.toInt() ?? 0;
      final lowMemory = info?['lowMemory'] == true;
      const mib = 1024 * 1024;
      if (totalBytes < 1700 * mib || availableBytes < 1150 * mib || lowMemory) {
        throw const OfflineModelException(
          'Сейчас недостаточно свободной памяти для безопасного запуска Qwen3-0.6B. Закройте остальные приложения и повторите запрос. На телефоне с 2 ГБ ОЗУ успешный запуск не гарантируется. Справочник, поиск, история, калькуляторы и решатель уравнений продолжат работать без генеративной модели.'
        );
      }
    } on OfflineModelException {
      rethrow;
    } catch (error) {
      throw OfflineModelException('Не удалось проверить доступную память Android; запуск модели отменён для защиты приложения. $error');
    }
  }

  Future<void> closeModel() async {
    final current = _model;
    _model = null;
    if (current != null) {
      try { await current.close(); } catch (_) {}
    }
  }

  static int _mb(int bytes) => (bytes / (1024 * 1024)).round();
}

class OfflineModelException implements Exception {
  const OfflineModelException(this.message);
  final String message;
  @override
  String toString() => message;
}
