import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_edge_ai/flutter_edge_ai.dart';
import 'package:flutter_edge_ai_litertlm/flutter_edge_ai_litertlm.dart';

/// Manages the neural runtime and the model bundled into the application.
class OfflineModelManager {
  OfflineModelManager._();
  static final OfflineModelManager instance = OfflineModelManager._();

  static const MethodChannel _platform = MethodChannel('com.astronuit/document_picker');
  static const String _installedKey = 'offline_model_installed';
  static const String _enabledKey = 'neural_network_enabled';

  bool _initialized = false;
  bool _installed = false;
  Future<void>? _initializing;
  Future<void>? _bundledInstallTask;
  dynamic _model;
  Future<dynamic>? _loading;

  final ValueNotifier<String?> lastError = ValueNotifier<String?>(null);

  void reportError(Object error) {
    lastError.value = _cleanErrorText(error.toString());
  }

  void clearError() {
    lastError.value = null;
  }

  bool get hasInstalledModel {
    try {
      return FlutterEdgeAi.activeModelSpec?.modelType == ModelType.qwen3 || _installed;
    } catch (_) {
      return _installed;
    }
  }

  bool get isLoaded => _model != null;

  Future<bool> isNeuralNetworkEnabled() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      return preferences.getBool(_enabledKey) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Enables the switch only after the native runtime and model load succeed.
  /// The model is closed immediately afterwards to release memory.
  Future<void> enableNeuralNetwork() async {
    clearError();
    try {
      await ensureBundledModelInstalled();
      await loadModel();
      await closeModel();
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool(_enabledKey, true);
      clearError();
    } catch (error) {
      await closeModel();
      reportError(error);
      if (error is OfflineModelException) rethrow;
      throw OfflineModelException(error.toString());
    }
  }

  Future<void> disableNeuralNetwork() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool(_enabledKey, false);
      clearError();
    } catch (error) {
      reportError(error);
      rethrow;
    } finally {
      await closeModel();
    }
  }

  Future<bool> refreshInstalledState() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      _installed = preferences.getBool(_installedKey) ?? false;
    } catch (_) {}
    try {
      _installed = _installed ||
          FlutterEdgeAi.activeModelSpec?.modelType == ModelType.qwen3;
    } catch (_) {}
    return _installed;
  }

  Future<void> initialize() async {
    if (_initialized) return;
    final pending = _initializing;
    if (pending != null) {
      try {
        await pending;
        _initialized = true;
        return;
      } catch (error) {
        throw _asOfflineException(error);
      }
    }

    final task = FlutterEdgeAi.initialize(
      inferenceEngines: const [LiteRtLmEngine(thinkingTokenBudget: 48)],
    );
    _initializing = task;
    try {
      await task;
      _initialized = true;
      await refreshInstalledState();
    } catch (error) {
      throw _asOfflineException(error);
    } finally {
      if (identical(_initializing, task)) _initializing = null;
    }
  }

  Future<void> ensureBundledModelInstalled() async {
    final pending = _bundledInstallTask;
    if (pending != null) return pending;
    final task = _ensureBundledModelInstalledInternal();
    _bundledInstallTask = task;
    try {
      await task;
    } catch (error) {
      throw _asOfflineException(error);
    } finally {
      if (identical(_bundledInstallTask, task)) _bundledInstallTask = null;
    }
  }

  Future<void> _ensureBundledModelInstalledInternal() async {
    await initialize();
    await refreshInstalledState();

    final modelPath = await _platform.invokeMethod<String>('extractBundledModel');
    if (modelPath == null || modelPath.isEmpty) {
      throw const OfflineModelException('Android не вернул путь к встроенной модели.');
    }
    final file = File(modelPath);
    if (!await file.exists()) {
      throw const OfflineModelException('Не удалось извлечь модель из APK.');
    }
    final bytes = await file.length();
    if (bytes < 300 * 1024 * 1024 || bytes > 400 * 1024 * 1024) {
      throw OfflineModelException(
        'Размер встроенного файла (${_mb(bytes)} МБ) неверен. Проверьте установочный APK.',
      );
    }

    if (!hasInstalledModel) {
      await _installModelFile(file);
    }
  }

  Future<void> _installModelFile(File file) async {
    await closeModel();
    try {
      await FlutterEdgeAi.installModel(
        modelType: ModelType.qwen3,
        fileType: ModelFileType.litertlm,
      ).fromFile(file.path).install();
      _installed = true;
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool(_installedKey, true);
    } catch (error) {
      throw OfflineModelException(error.toString());
    }
  }

  Future<dynamic> loadModel() async {
    await initialize();
    if (_model != null) return _model;
    final pending = _loading;
    if (pending != null) return pending;
    final task = _loadModelInternal();
    _loading = task;
    try {
      _model = await task;
      clearError();
      return _model;
    } catch (error) {
      reportError(error);
      throw _asOfflineException(error);
    } finally {
      if (identical(_loading, task)) _loading = null;
    }
  }

  Future<dynamic> _loadModelInternal() async {
    await ensureBundledModelInstalled();
    await _ensureEnoughMemory();
    return FlutterEdgeAi.getActiveModel(
      maxTokens: 1024,
      preferredBackend: PreferredBackend.cpu,
      supportImage: false,
    );
  }

  Future<void> _ensureEnoughMemory() async {
    try {
      final info = await _platform.invokeMapMethod<String, dynamic>('getMemoryInfo');
      final totalBytes = (info?['totalBytes'] as num?)?.toInt() ?? 0;
      final availableBytes = (info?['availableBytes'] as num?)?.toInt() ?? 0;
      final lowMemory = info?['lowMemory'] == true;
      const mib = 1024 * 1024;
      if (totalBytes < 1700 * mib || availableBytes < 1150 * mib || lowMemory) {
        throw const OfflineModelException(
          'Недостаточно свободной оперативной памяти для запуска нейросети.',
        );
      }
    } on OfflineModelException {
      rethrow;
    } catch (error) {
      throw OfflineModelException(error.toString());
    }
  }

  Future<void> closeModel() async {
    final current = _model;
    _model = null;
    if (current != null) {
      try {
        await current.close();
      } catch (_) {}
    }
  }

  OfflineModelException _asOfflineException(Object error) =>
      error is OfflineModelException
          ? error
          : OfflineModelException(error.toString());

  static int _mb(int bytes) => (bytes / (1024 * 1024)).round();
}

class OfflineModelException implements Exception {
  const OfflineModelException(this.message);
  final String message;

  @override
  String toString() => _cleanErrorText(message);
}

String _cleanErrorText(String value) => value
    .replaceAll(RegExp(r'qwen[\w.-]*', caseSensitive: false), 'нейросеть')
    .trim();
