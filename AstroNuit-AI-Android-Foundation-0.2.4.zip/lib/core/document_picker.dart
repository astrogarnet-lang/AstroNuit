import 'package:flutter/services.dart';

class PickedDocument {
  const PickedDocument({required this.path, required this.name});
  final String path;
  final String name;
}

/// Android Storage Access Framework bridge. Files are copied into app-private
/// storage before returning, so later reads do not depend on temporary URI grants.
class DocumentPicker {
  static const MethodChannel _channel =
      MethodChannel('com.astronuit/document_picker');

  static Future<PickedDocument?> _pick(String method) async {
    final result = await _channel.invokeMapMethod<String, dynamic>(method);
    if (result == null) return null;
    final path = result['path'] as String?;
    final name = result['name'] as String?;
    if (path == null || path.isEmpty) return null;
    return PickedDocument(path: path, name: name ?? 'document');
  }

  static Future<PickedDocument?> pickDocument() => _pick('pickDocument');

  static Future<PickedDocument?> pickImage() => _pick('pickImage');

}
