import 'dart:math' as math;

/// Deterministic, model-free calculators for explicitly supported formulas.
/// Every calculation uses numeric input supplied by the user; no LLM is used.
class ScienceTaskSolver {
  const ScienceTaskSolver();

  static const Map<String, List<ScienceInput>> inputs = {
    'percent_of': [ScienceInput('A', 'Исходное число'), ScienceInput('p', 'Процент')],
    'percent_change': [ScienceInput('A', 'Начальное значение'), ScienceInput('B', 'Конечное значение')],
    'quadratic': [ScienceInput('a', 'Коэффициент a'), ScienceInput('b', 'Коэффициент b'), ScienceInput('c', 'Коэффициент c')],
    'pythagorean': [ScienceInput('a', 'Катет a'), ScienceInput('b', 'Катет b')],
    'rectangle_area': [ScienceInput('a', 'Длина a'), ScienceInput('b', 'Ширина b')],
    'triangle_area': [ScienceInput('a', 'Основание a'), ScienceInput('h', 'Высота h')],
    'circle_area': [ScienceInput('r', 'Радиус')],
    'circumference': [ScienceInput('r', 'Радиус')],
    'speed': [ScienceInput('s', 'Путь, м'), ScienceInput('t', 'Время, с')],
    'distance': [ScienceInput('v', 'Скорость, м/с'), ScienceInput('t', 'Время, с')],
    'acceleration': [ScienceInput('dv', 'Изменение скорости, м/с'), ScienceInput('dt', 'Время, с')],
    'velocity_final': [ScienceInput('v0', 'Начальная скорость, м/с'), ScienceInput('a', 'Ускорение, м/с²'), ScienceInput('t', 'Время, с')],
    'displacement': [ScienceInput('v0', 'Начальная скорость, м/с'), ScienceInput('a', 'Ускорение, м/с²'), ScienceInput('t', 'Время, с')],
    'newton_force': [ScienceInput('m', 'Масса, кг'), ScienceInput('a', 'Ускорение, м/с²')],
    'momentum': [ScienceInput('m', 'Масса, кг'), ScienceInput('v', 'Скорость, м/с')],
    'kinetic_energy': [ScienceInput('m', 'Масса, кг'), ScienceInput('v', 'Скорость, м/с')],
    'potential_energy': [ScienceInput('m', 'Масса, кг'), ScienceInput('h', 'Высота, м')],
    'work': [ScienceInput('F', 'Сила, Н'), ScienceInput('s', 'Путь, м'), ScienceInput('angle', 'Угол между силой и перемещением, °')],
    'power': [ScienceInput('W', 'Работа, Дж'), ScienceInput('t', 'Время, с')],
    'density': [ScienceInput('m', 'Масса, кг'), ScienceInput('V', 'Объём, м³')],
    'pressure': [ScienceInput('F', 'Сила, Н'), ScienceInput('S', 'Площадь, м²')],
    'hydrostatic_pressure': [ScienceInput('rho', 'Плотность, кг/м³'), ScienceInput('h', 'Глубина, м')],
    'archimedes': [ScienceInput('rho', 'Плотность жидкости, кг/м³'), ScienceInput('V', 'Объём погружённой части, м³')],
    'heat': [ScienceInput('m', 'Масса, кг'), ScienceInput('c', 'Удельная теплоёмкость, Дж/(кг·К)'), ScienceInput('dT', 'Изменение температуры, К')],
    'ohm_current': [ScienceInput('U', 'Напряжение, В'), ScienceInput('R', 'Сопротивление, Ом')],
    'electrical_power': [ScienceInput('U', 'Напряжение, В'), ScienceInput('I', 'Ток, А')],
    'charge': [ScienceInput('I', 'Ток, А'), ScienceInput('t', 'Время, с')],
    'moles': [ScienceInput('m', 'Масса, г'), ScienceInput('M', 'Молярная масса, г/моль')],
    'particles': [ScienceInput('n', 'Количество вещества, моль')],
    'molarity': [ScienceInput('n', 'Количество вещества, моль'), ScienceInput('V', 'Объём раствора, л')],
    'mass_fraction': [ScienceInput('m', 'Масса вещества, г'), ScienceInput('mTotal', 'Масса раствора, г')],
    'dilution': [ScienceInput('C1', 'Начальная концентрация'), ScienceInput('V1', 'Начальный объём'), ScienceInput('V2', 'Конечный объём')],
    'gas_molar_volume': [ScienceInput('n', 'Количество вещества, моль')],
    'ideal_gas_pressure': [ScienceInput('n', 'Количество вещества, моль'), ScienceInput('T', 'Температура, K'), ScienceInput('V', 'Объём, м³')],
    'ph': [ScienceInput('H', 'Концентрация H⁺, моль/л')],
    'reaction_yield': [ScienceInput('actual', 'Практический выход, г'), ScienceInput('theoretical', 'Теоретический выход, г')],
    'wave_speed': [ScienceInput('f', 'Частота, Гц'), ScienceInput('lambda', 'Длина волны, м')],
    'frequency_from_period': [ScienceInput('T', 'Период, с')],
    'spring_force': [ScienceInput('k', 'Жёсткость пружины, Н/м'), ScienceInput('x', 'Удлинение, м')],
  };

  ScienceCalculation? calculate(String id, Map<String, double> values) {
    double v(String key) => values[key] ?? double.nan;
    if (inputs[id] == null || inputs[id]!.any((field) => !v(field.key).isFinite)) return null;

    late double result;
    late String expression;
    late String unit;
    switch (id) {
      case 'percent_of':
        result = v('A') * v('p') / 100;
        expression = 'A · p / 100';
        unit = '';
        break;
      case 'percent_change':
        if (v('A') == 0) return null;
        result = (v('B') - v('A')) / v('A') * 100;
        expression = '(B − A) / A · 100%';
        unit = '%';
        break;
      case 'quadratic':
        final a = v('a'), b = v('b'), c = v('c');
        if (a == 0) return null;
        final d = b * b - 4 * a * c;
        if (d < 0) return ScienceCalculation('D = ${_fmt(d)}; действительных корней нет.', 'D = b² − 4ac', '');
        final root = math.sqrt(d);
        final x1 = (-b + root) / (2 * a);
        final x2 = (-b - root) / (2 * a);
        final text = d == 0 ? 'x = ${_fmt(x1)}' : 'x₁ = ${_fmt(x1)}; x₂ = ${_fmt(x2)}';
        return ScienceCalculation('D = ${_fmt(d)}; $text', 'D = b² − 4ac; x = (−b ± √D)/(2a)', '');
      case 'pythagorean':
        result = math.sqrt(v('a') * v('a') + v('b') * v('b'));
        expression = '√(a² + b²)';
        unit = '';
        break;
      case 'rectangle_area':
        result = v('a') * v('b');
        expression = 'a · b';
        unit = 'ед.²';
        break;
      case 'triangle_area':
        result = v('a') * v('h') / 2;
        expression = 'a · h / 2';
        unit = 'ед.²';
        break;
      case 'circle_area':
        result = math.pi * v('r') * v('r');
        expression = 'πr²';
        unit = 'ед.²';
        break;
      case 'circumference':
        result = 2 * math.pi * v('r');
        expression = '2πr';
        unit = 'ед.';
        break;
      case 'speed':
        if (v('t') == 0) return null;
        result = v('s') / v('t');
        expression = 's / t';
        unit = 'м/с';
        break;
      case 'distance':
        result = v('v') * v('t');
        expression = 'v · t';
        unit = 'м';
        break;
      case 'acceleration':
        if (v('dt') == 0) return null;
        result = v('dv') / v('dt');
        expression = 'Δv / Δt';
        unit = 'м/с²';
        break;
      case 'velocity_final':
        result = v('v0') + v('a') * v('t');
        expression = 'v₀ + a · t';
        unit = 'м/с';
        break;
      case 'displacement':
        result = v('v0') * v('t') + 0.5 * v('a') * v('t') * v('t');
        expression = 'v₀t + at²/2';
        unit = 'м';
        break;
      case 'newton_force':
        result = v('m') * v('a');
        expression = 'm · a';
        unit = 'Н';
        break;
      case 'momentum':
        result = v('m') * v('v');
        expression = 'm · v';
        unit = 'кг·м/с';
        break;
      case 'kinetic_energy':
        result = 0.5 * v('m') * v('v') * v('v');
        expression = 'mv² / 2';
        unit = 'Дж';
        break;
      case 'potential_energy':
        result = v('m') * 9.80665 * v('h');
        expression = 'mgh (g = 9,80665 м/с²)';
        unit = 'Дж';
        break;
      case 'work':
        result = v('F') * v('s') * math.cos(v('angle') * math.pi / 180);
        expression = 'F · s · cos(α)';
        unit = 'Дж';
        break;
      case 'power':
        if (v('t') == 0) return null;
        result = v('W') / v('t');
        expression = 'W / t';
        unit = 'Вт';
        break;
      case 'density':
        if (v('V') == 0) return null;
        result = v('m') / v('V');
        expression = 'm / V';
        unit = 'кг/м³';
        break;
      case 'pressure':
        if (v('S') == 0) return null;
        result = v('F') / v('S');
        expression = 'F / S';
        unit = 'Па';
        break;
      case 'hydrostatic_pressure':
        result = v('rho') * 9.80665 * v('h');
        expression = 'ρgh (g = 9,80665 м/с²)';
        unit = 'Па';
        break;
      case 'archimedes':
        result = v('rho') * 9.80665 * v('V');
        expression = 'ρgV';
        unit = 'Н';
        break;
      case 'heat':
        result = v('m') * v('c') * v('dT');
        expression = 'mcΔT';
        unit = 'Дж';
        break;
      case 'ohm_current':
        if (v('R') == 0) return null;
        result = v('U') / v('R');
        expression = 'U / R';
        unit = 'А';
        break;
      case 'electrical_power':
        result = v('U') * v('I');
        expression = 'U · I';
        unit = 'Вт';
        break;
      case 'charge':
        result = v('I') * v('t');
        expression = 'I · t';
        unit = 'Кл';
        break;
      case 'moles':
        if (v('M') == 0) return null;
        result = v('m') / v('M');
        expression = 'm / M';
        unit = 'моль';
        break;
      case 'particles':
        result = v('n') * 6.02214076e23;
        expression = 'N = n · Nₐ';
        unit = 'частиц';
        break;
      case 'molarity':
        if (v('V') == 0) return null;
        result = v('n') / v('V');
        expression = 'n / V';
        unit = 'моль/л';
        break;
      case 'mass_fraction':
        if (v('mTotal') == 0) return null;
        result = v('m') / v('mTotal') * 100;
        expression = 'm / mTotal · 100%';
        unit = '%';
        break;
      case 'dilution':
        if (v('V2') == 0) return null;
        result = v('C1') * v('V1') / v('V2');
        expression = 'C₁V₁ / V₂';
        unit = 'ед. концентрации';
        break;
      case 'gas_molar_volume':
        result = v('n') * 22.413969545;
        expression = 'V = n · 22,414 л/моль (0 °C, 1 атм)';
        unit = 'л';
        break;
      case 'ideal_gas_pressure':
        if (v('V') == 0) return null;
        result = v('n') * 8.314462618 * v('T') / v('V');
        expression = 'p = nRT/V (R = 8,314462618 Дж/(моль·К))';
        unit = 'Па';
        break;
      case 'ph':
        if (v('H') <= 0) return null;
        result = -math.log(v('H')) / math.ln10;
        expression = 'pH = −log₁₀[H⁺]';
        unit = '';
        break;
      case 'reaction_yield':
        if (v('theoretical') == 0) return null;
        result = v('actual') / v('theoretical') * 100;
        expression = 'm(практ.) / m(теор.) · 100%';
        unit = '%';
        break;
      case 'wave_speed':
        result = v('f') * v('lambda');
        expression = 'v = fλ';
        unit = 'м/с';
        break;
      case 'frequency_from_period':
        if (v('T') == 0) return null;
        result = 1 / v('T');
        expression = 'f = 1/T';
        unit = 'Гц';
        break;
      case 'spring_force':
        result = v('k') * v('x');
        expression = 'F = kx';
        unit = 'Н';
        break;
      default:
        return null;
    }
    if (!result.isFinite) return null;
    return ScienceCalculation('${_fmt(result)}${unit.isEmpty ? '' : ' $unit'}', expression, unit);
  }

  static String _fmt(double value) {
    if (value == value.roundToDouble() && value.abs() < 1e12) return value.toInt().toString();
    final text = value.toStringAsPrecision(8);
    if (text.contains('e')) {
      final parts = text.split('e');
      return '${_trimDecimal(parts.first)}e${parts.last}';
    }
    return _trimDecimal(text);
  }

  static String _trimDecimal(String value) {
    if (!value.contains('.')) return value;
    return value.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
}

class ScienceInput {
  const ScienceInput(this.key, this.label);
  final String key;
  final String label;
}

class ScienceCalculation {
  const ScienceCalculation(this.result, this.expression, this.unit);
  final String result;
  final String expression;
  final String unit;
}
