import 'package:math_expressions/math_expressions.dart';

import '../data/knowledge_db.dart';

/// Local retrieval assistant and calculator.
/// A generative on-device language model is not bundled yet.
class LocalCore {
  LocalCore._();
  static final LocalCore instance = LocalCore._();

  bool get modelLoaded => false;

  String get statusRu => modelLoaded
      ? 'Локальная модель загружена'
      : 'Режим базы знаний + локальный ассистент (генеративная модель подключается отдельно)';

  String get statusEn => modelLoaded
      ? 'Local model loaded'
      : 'Knowledge-base assistant mode (a generative model is not connected yet)';

  Future<String> reply(String userMessage, {String languageCode = 'ru'}) async {
    final query = userMessage.trim();
    if (query.isEmpty) {
      return languageCode == 'ru' ? 'Пустой запрос.' : 'Empty request.';
    }

    final calculation = _calculate(query);
    if (calculation != null) {
      // ChatScreen displays the "Думаю…" / "Thinking…" phase while this runs.
      await Future<void>.delayed(const Duration(milliseconds: 2500));
      return languageCode == 'ru'
          ? '### Ответ\n\n**$query = $calculation**'
          : '### Answer\n\n**$query = $calculation**';
    }

    final hits = await KnowledgeDb.instance.search(query, limit: 5);
    final builtin = _builtinNotes(query, languageCode);
    final buffer = StringBuffer();
    final isRussian = languageCode == 'ru';

    buffer.writeln(isRussian ? '### Ответ AstroNuit' : '### AstroNuit answer');
    buffer.writeln();
    if (hits.isNotEmpty) {
      buffer.writeln(isRussian
          ? 'Нашёл релевантные фрагменты в вашей библиотеке (${hits.length}):'
          : 'Relevant fragments from your library (${hits.length}):');
      buffer.writeln();
      for (var i = 0; i < hits.length; i++) {
        final hit = hits[i];
        final title = hit['title'] ?? (isRussian ? 'документ' : 'document');
        final content = (hit['content'] as String).trim();
        final snippet = content.length > 700
            ? '${content.substring(0, 700)}…'
            : content;
        buffer.writeln('**[${i + 1}] $title**');
        buffer.writeln(snippet);
        buffer.writeln();
      }
      buffer.writeln(isRussian
          ? '_Ответ основан на найденных фрагментах. Для более точного результата задайте уточняющий вопрос._'
          : '_This response is based on the retrieved fragments. Ask a more specific question for a narrower answer._');
    } else {
      buffer.writeln(builtin);
      buffer.writeln();
      buffer.writeln(isRussian
          ? '_В библиотеке пока нет подходящих фрагментов. Импортируйте PDF, TXT или MD в разделе «Файлы» — AstroNuit сможет искать ответы в их содержимом._'
          : '_No matching fragments were found. Import PDF, TXT or MD files in Files so AstroNuit can retrieve relevant passages._');
    }

    if (!modelLoaded) {
      buffer.writeln();
      buffer.writeln(isRussian
          ? '⚙️ Сейчас работает локальный поиск по базе знаний и встроенные заметки. Генеративная языковая модель пока не подключена.'
          : '⚙️ Retrieval over your local knowledge base and built-in notes is active. A generative language model is not connected yet.');
    }
    return buffer.toString().trim();
  }

  String? _calculate(String input) {
    final expression = input
        .trim()
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll(',', '.');

    // Accept only a complete arithmetic expression, not arbitrary prose.
    if (!RegExp(r'^[0-9\s.+\-*/()%^]+$').hasMatch(expression) ||
        !RegExp(r'[+*/%^-]').hasMatch(expression)) {
      return null;
    }

    try {
      final parser = GrammarParser();
      final parsed = parser.parse(expression.replaceAll('%', '/100'));
      final value = RealEvaluator(ContextModel()).evaluate(parsed);
      if (!value.isFinite) return 'ошибка: результат не конечен';
      if (value == value.roundToDouble()) return value.toInt().toString();
      return value.toStringAsPrecision(12).replaceAll(RegExp(r'\.?0+$'), '');
    } catch (_) {
      return null;
    }
  }

  String _builtinNotes(String query, String languageCode) {
    final lower = query.toLowerCase();
    final isRussian = languageCode == 'ru';
    if (lower.contains('интеграл') || lower.contains('integral')) {
      return isRussian
          ? 'Интеграл — математический объект, который обобщает суммирование непрерывных величин. Пришлите конкретную формулу, и я помогу разобрать её по шагам.'
          : 'An integral generalizes summation over a continuous quantity. Share a specific expression and I can help work through it.';
    }
    if (lower.contains('квадратн') || lower.contains('quadratic')) {
      return isRussian
          ? 'Для ax² + bx + c = 0 дискриминант равен D = b² − 4ac. При D ≥ 0 корни равны (−b ± √D) / (2a). Пришлите коэффициенты — подставим их.'
          : 'For ax² + bx + c = 0, the discriminant is D = b² − 4ac. For D ≥ 0, roots are (−b ± √D) / (2a). Share the coefficients to calculate them.';
    }
    if (lower.contains('python') || lower.contains('код') || lower.contains('code')) {
      return isRussian
          ? 'Могу помочь разобраться в структуре алгоритма, найти ошибку и предложить исправление. Пришлите код и текст ошибки.'
          : 'I can help explain an algorithm, find a bug and suggest a fix. Share the code and error message.';
    }
    return isRussian
        ? 'Я AstroNuit — локальный научно-технический помощник. Сейчас я ищу информацию в добавленных документах и встроенных заметках. Для ответов по вашим материалам загрузите PDF или текстовый файл.'
        : 'I am AstroNuit, a local science and technology assistant. I search your imported documents and built-in notes. Upload a PDF or text file to ask questions about your materials.';
  }
}
