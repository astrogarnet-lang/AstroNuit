import 'package:math_expressions/math_expressions.dart';

import '../data/knowledge_db.dart';
import 'equation_solver.dart';
import 'text_codec.dart';

/// Local, deterministic knowledge retrieval, arithmetic and equation solver.
/// These paths work without loading any language model.
class LocalCore {
  LocalCore._();
  static final LocalCore instance = LocalCore._();

  bool get modelLoaded => false;

  String get statusRu => modelLoaded
      ? 'Локальная модель загружена'
      : 'Локальный поиск по базе знаний и встроенные инструменты';

  String get statusEn => modelLoaded
      ? 'Local model loaded'
      : 'Local knowledge-base search and built-in tools';

  Future<String> reply(String userMessage, {String languageCode = 'ru'}) async {
    final query = userMessage.trim();
    if (query.isEmpty) {
      return languageCode == 'ru' ? 'Пустой запрос.' : 'Empty request.';
    }

    final deterministicAnswer = solveDeterministic(query, languageCode: languageCode);
    if (deterministicAnswer != null) return deterministicAnswer;

    final hits = await KnowledgeDb.instance.search(query, limit: 8);
    final usable = hits.where((h) {
      final c = (h['content'] as String?) ?? '';
      return c.trim().isNotEmpty && !TextCodecFix.looksGarbled(c);
    }).toList();

    final isRussian = languageCode == 'ru';
    final buffer = StringBuffer();

    if (usable.isNotEmpty) {
      final answer = _composeAnswerFromHits(query, usable, isRussian);
      buffer.writeln(isRussian ? '### Ответ по вашим документам' : '### Answer from your documents');
      buffer.writeln();
      buffer.writeln(answer);
      buffer.writeln();
      buffer.writeln(isRussian ? '**Источники**' : '**Sources**');
      buffer.writeln();
      final seen = <String>{};
      for (var i = 0; i < usable.length && seen.length < 4; i++) {
        final hit = usable[i];
        final title = (hit['title'] as String?) ?? (isRussian ? 'документ' : 'document');
        if (!seen.add(title)) continue;
        final content = TextCodecFix.repair((hit['content'] as String).trim());
        final snippet = _bestSnippet(content, query, maxLen: 320);
        buffer.writeln('**[${seen.length}] $title**');
        buffer.writeln(snippet);
        buffer.writeln();
      }
      buffer.writeln(isRussian
          ? '_Ответ составлен по найденным фрагментам библиотеки. Уточните вопрос, если нужен другой раздел документа._'
          : '_This answer is built from retrieved library fragments. Ask a more specific question if you need another section._');
    } else {
      final allHitsGarbled = hits.isNotEmpty && usable.isEmpty;
      buffer.writeln(isRussian ? '### Ответ AstroNuit' : '### AstroNuit answer');
      buffer.writeln();
      buffer.writeln(_builtinNotes(query, languageCode));
      buffer.writeln();
      if (allHitsGarbled) {
        buffer.writeln(isRussian
            ? '_В библиотеке есть документы, но их текст прочитан с ошибкой кодировки. Удалите файл в «Файлы» и загрузите снова как TXT (UTF-8) или пересохраните PDF с текстовым слоем._'
            : '_Library documents were found, but their text looks corrupted. Delete the file in Files and re-import as UTF-8 TXT or a text-based PDF._');
      } else {
        buffer.writeln(isRussian
            ? '_В библиотеке пока нет подходящих фрагментов. Импортируйте PDF, TXT или MD в разделе «Файлы» — AstroNuit сможет искать ответы в их содержимом._'
            : '_No matching fragments were found. Import PDF, TXT or MD files in Files so AstroNuit can retrieve relevant passages._');
      }
    }

    if (!modelLoaded) {
      buffer.writeln();
      buffer.writeln(isRussian
          ? '⚙️ Сейчас работают локальный поиск, справочник и детерминированные решатели. Qwen3-0.6B встроена в APK и подготавливается автоматически; если памяти Android недостаточно, локальные инструменты продолжат работать без генерации. Модель не анализирует изображения.'
          : '⚙️ Local retrieval, reference data and deterministic solvers are active. Qwen3-0.6B is bundled in the APK and prepared automatically; if Android has insufficient RAM, local tools remain available without generation. The model does not analyze images.');
    }
    return buffer.toString().trim();
  }

  /// Build a short answer that prioritizes sentences matching the query.
  String _composeAnswerFromHits(
    String query,
    List<Map<String, dynamic>> hits,
    bool isRussian,
  ) {
    final terms = query
        .toLowerCase()
        .split(RegExp(r'[^a-zA-Zа-яА-ЯёЁ0-9]+'))
        .where((t) => t.length > 2)
        .toSet();

    final sentences = <String>[];
    for (final hit in hits) {
      final content = TextCodecFix.repair((hit['content'] as String).trim());
      for (final sentence in content.split(RegExp(r'(?<=[.!?…])\s+|\n+'))) {
        final s = sentence.trim();
        if (s.length < 25 || s.length > 400) continue;
        if (TextCodecFix.looksGarbled(s)) continue;
        final lower = s.toLowerCase();
        var score = 0;
        for (final t in terms) {
          if (lower.contains(t)) score += 1;
        }
        if (score > 0) sentences.add(s);
        if (sentences.length >= 6) break;
      }
      if (sentences.length >= 6) break;
    }

    if (sentences.isEmpty) {
      // Fallback: first clean snippet.
      for (final hit in hits) {
        final content = TextCodecFix.repair((hit['content'] as String).trim());
        final snippet = _bestSnippet(content, query, maxLen: 450);
        if (snippet.isNotEmpty && !TextCodecFix.looksGarbled(snippet)) {
          return isRussian
              ? 'По вашим документам:\n\n$snippet'
              : 'From your documents:\n\n$snippet';
        }
      }
      return isRussian
          ? 'Нашёл совпадения в библиотеке, но не удалось выделить читаемый текст. Перезагрузите документ в формате TXT (UTF-8).'
          : 'Matches were found, but the text is not readable. Re-import the document as UTF-8 TXT.';
    }

    final unique = <String>[];
    for (final s in sentences) {
      if (unique.every((u) => u != s && !u.contains(s) && !s.contains(u))) {
        unique.add(s);
      }
      if (unique.length >= 4) break;
    }

    final body = unique.map((s) => '• $s').join('\n\n');
    return isRussian
        ? 'Кратко по найденным фрагментам:\n\n$body'
        : 'Summary from retrieved fragments:\n\n$body';
  }

  String _bestSnippet(String content, String query, {int maxLen = 320}) {
    final clean = content.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.length <= maxLen) return clean;
    final terms = query
        .toLowerCase()
        .split(RegExp(r'[^a-zA-Zа-яА-ЯёЁ0-9]+'))
        .where((t) => t.length > 2);
    final lower = clean.toLowerCase();
    var bestIdx = 0;
    for (final t in terms) {
      final i = lower.indexOf(t);
      if (i >= 0) {
        bestIdx = (i - 40).clamp(0, clean.length - 1);
        break;
      }
    }
    var end = (bestIdx + maxLen).clamp(0, clean.length);
    var snippet = clean.substring(bestIdx, end);
    if (bestIdx > 0) snippet = '…$snippet';
    if (end < clean.length) snippet = '$snippet…';
    return snippet;
  }


  /// Returns a result only when a deterministic local solver handled the input.
  /// A null result means the request should continue to document retrieval or LLM.
  String? solveDeterministic(String query, {String languageCode = 'ru'}) {
    final equationAnswer = _solveEquation(query, languageCode);
    if (equationAnswer != null) return equationAnswer;
    final calculation = _calculate(query);
    if (calculation == null) return null;
    return languageCode == 'ru'
        ? '### Ответ без нейросети\n\n**$query = $calculation**'
        : '### Answer without AI\n\n**$query = $calculation**';
  }

  String? _solveEquation(String raw, String languageCode) {
    var candidate = raw.trim().toLowerCase().replaceAll('х', 'x');
    candidate = candidate.replaceFirst(
      RegExp(r'^(?:реши(?:те)?|решить|найди|solve|find)\s*(?:(?:уравнение|equation)\s*)?[:：]?\s*'),
      '',
    );
    candidate = candidate.replaceFirst(RegExp(r'[?;]+$'), '').trim();
    if (candidate.isEmpty || !RegExp(r'[x=]').hasMatch(candidate)) return null;
    if (!RegExp(r'^[0-9a-z()+\-*/^=.,\s²³⁴×·÷−–]+$').hasMatch(candidate)) return null;

    final result = EquationSolver().solve(candidate);
    final isRussian = languageCode == 'ru';
    if (result.kind == 'error') {
      return isRussian
          ? '### Решение уравнения\n\n${result.message}\n\nТочно обрабатываются действительные полиномы до 4-й степени. Для некоторых функций (sin, cos, tan, ln, log, sqrt) и более высоких степеней применяется приближённый численный поиск на интервале [-100; 100]; он может пропустить кратные корни и корни за пределами интервала. Системы и дифференциальные уравнения не поддерживаются.'
          : '### Equation solver\n\n${result.message}\n\nReal polynomials through degree 4 are solved directly. Some functions (sin, cos, tan, ln, log, sqrt) and higher powers use approximate numerical search on [-100, 100], which may miss repeated roots and roots outside the interval. Systems and differential equations are not supported.';
    }
    final out = StringBuffer()..writeln(isRussian ? '### Решение без нейросети' : '### Solved without AI')..writeln()..writeln('**${result.formatted}**');
    if (result.steps.isNotEmpty) {
      out.writeln();
      for (final step in result.steps) {
        out.writeln('- $step');
      }
    }
    return out.toString().trim();
  }

  String? _calculate(String input) {
    final expression = input
        .trim()
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll(',', '.');

    if (!RegExp(r'^[0-9\s.+\-*/()%^]+$').hasMatch(expression) ||
        !RegExp(r'[+*/%^-]').hasMatch(expression)) {
      return null;
    }

    try {
      final parser = ShuntingYardParser();
      final Expression exp = parser.parse(expression.replaceAll('%', '/100'));
      final dynamic raw = exp.evaluate(EvaluationType.REAL, ContextModel());
      final double value = (raw as num).toDouble();
      if (!value.isFinite) return 'ошибка: результат не конечен';
      if (value == value.roundToDouble()) return value.toInt().toString();
      return value.toStringAsPrecision(12).replaceAll(RegExp(r'\.?0+$'), '');
    } catch (_) {
      return null;
    }
  }

  String _builtinNotes(String query, String languageCode) {
    final lower = query.toLowerCase();
    final isRussian = languageCode == 'ru';
    if (lower.contains('интеграл') || lower.contains('integral')) {
      return isRussian
          ? 'Интеграл — математический объект, который обобщает суммирование непрерывных величин. Пришлите конкретную формулу, и я помогу разобрать её по шагам.'
          : 'An integral generalizes summation over a continuous quantity. Share a specific expression and I can help work through it.';
    }
    if (lower.contains('квадратн') || lower.contains('quadratic')) {
      return isRussian
          ? 'Квадратное уравнение имеет вид ax² + bx + c = 0. Дискриминант D = b² − 4ac. Если D > 0 — два корня, D = 0 — один, D < 0 — нет действительных корней.'
          : 'A quadratic equation is ax² + bx + c = 0. Discriminant D = b² − 4ac. D > 0 two roots, D = 0 one root, D < 0 no real roots.';
    }
    if (lower.contains('привет') ||
        lower.contains('hello') ||
        lower.contains('здравств')) {
      return isRussian
          ? 'Здравствуйте! Я AstroNuit. Встроенная Qwen3-0.6B подготавливается автоматически при первом использовании. Уже сейчас можно искать сведения во встроенной подборке Конституции РФ и в импортированных документах.'
          : 'Hello! I am AstroNuit, a local assistant. The bundled Qwen3 model is prepared automatically; import documents in Files, use the science solvers, or enter an equation.';
    }
    if (lower.contains('конституц') || lower.contains('constitution')) {
      return isRussian
          ? 'В библиотеку уже добавлена стартовая подборка Конституции РФ. Можно спросить, например, о статье 15, правах человека или устройстве государства. Учтите: это не полный текст; для точного юридического анализа импортируйте полную действующую редакцию.'
          : 'To answer about a constitution or statute, import a PDF/TXT in Files, then ask (e.g. “article 15”). I will retrieve matching passages.';
    }
    return isRussian
        ? 'Доступны локальный поиск, научный справочник, 39 калькуляторов и решатель уравнений: точные действительные корни полиномов до 4-й степени и численный поиск для некоторых функций/высших степеней. Qwen3-0.6B уже включена в APK; генерация зависит от свободной памяти устройства.'
        : 'I can search local documents, use the science reference, run 39 formula calculators, solve real polynomials through degree 4, and numerically search some equations with functions or higher powers. Qwen3-0.6B is already included in the APK; free-form generation depends on available device memory.';
  }
}
