import 'dart:math' as math;

import 'package:math_expressions/math_expressions.dart';

/// Deterministic real-root solver for polynomial equations through degree 4.
/// It does not use an LLM. Supported syntax: + - * / ^, parentheses,
/// implicit products (2x, 3(x+1)), x/х, and superscript ²/³/⁴.
class EquationSolver {
  static const int maxDegree = 4;
  static const double _epsilon = 1e-9;

  EquationSolution solve(String input) {
    final source = _normalize(input);
    if (source.isEmpty) return EquationSolution.error('Введите уравнение.');
    final equalParts = source.split('=');
    if (equalParts.length > 2) {
      return EquationSolution.error('Поддерживается одно равенство в строке.');
    }

    try {
      final left = _PolynomialParser(equalParts.first).parse();
      final right = equalParts.length == 2
          ? _PolynomialParser(equalParts.last).parse()
          : const <double>[0];
      final polynomial = _trim(_subtract(left, right));

      if (polynomial.length == 1) {
        if (polynomial.first.abs() < _epsilon) {
          return EquationSolution.infinite('Любое действительное x является решением.');
        }
        return EquationSolution.none('Действительных корней нет.');
      }

      final roots = _realRoots(polynomial);
      if (roots.isEmpty) {
        return EquationSolution.none('Действительных корней нет.');
      }
      final cleaned = _unique(roots.map(_cleanZero).toList())..sort();
      final steps = _explain(polynomial, cleaned);
      return EquationSolution.roots(cleaned, steps);
    } on FormatException catch (error) {
      final numeric = _tryNumericalSolve(source, equalParts);
      return numeric ?? EquationSolution.error(error.message.toString());
    } catch (error) {
      return EquationSolution.error('Не удалось разобрать уравнение: $error');
    }
  }

  String _normalize(String value) => value
      .toLowerCase()
      .replaceAll('х', 'x')
      .replaceAll('×', '*')
      .replaceAll('·', '*')
      .replaceAll('÷', '/')
      .replaceAll('−', '-')
      .replaceAll('–', '-')
      .replaceAll('²', '^2')
      .replaceAll('³', '^3')
      .replaceAll('⁴', '^4')
      .replaceAll(',', '.')
      .replaceAll(' ', '');

  List<String> _explain(List<double> coefficients, List<double> roots) {
    final degree = coefficients.length - 1;
    final out = <String>['Степень уравнения: $degree.'];
    if (degree == 1) {
      out.add('Линейное уравнение: ax + b = 0, x = −b/a.');
    } else if (degree == 2) {
      final a = coefficients[2];
      final b = coefficients[1];
      final c = coefficients[0];
      final d = b * b - 4 * a * c;
      out.add('Квадратное уравнение: D = b² − 4ac = ${_fmt(d)}.');
      out.add(d > _epsilon
          ? 'D > 0: два действительных корня.'
          : (d.abs() <= _epsilon ? 'D = 0: один кратный корень.' : 'D < 0: действительных корней нет.'));
    } else {
      out.add('Корни найдены численно методом изоляции интервалов и бисекции.');
    }
    out.add('Проверка подстановкой: ${roots.map((x) => 'x=${_fmt(x)}').join('; ')}.');
    return out;
  }

  EquationSolution? _tryNumericalSolve(String source, List<String> equalParts) {
    if (!source.contains('x')) return null;
    try {
      final parser = ShuntingYardParser();
      final left = parser.parse(equalParts.first);
      final right = equalParts.length == 2 ? parser.parse(equalParts.last) : Number(0);
      double evaluate(double x) {
        final context = ContextModel()..bindVariableName('x', Number(x));
        final a = (left.evaluate(EvaluationType.REAL, context) as num).toDouble();
        final b = (right.evaluate(EvaluationType.REAL, context) as num).toDouble();
        return a - b;
      }

      const minX = -100.0;
      const maxX = 100.0;
      const steps = 4000;
      const step = (maxX - minX) / steps;
      final roots = <double>[];
      var previousX = minX;
      double? previousValue;
      try { previousValue = evaluate(previousX); } catch (_) { previousValue = null; }

      for (var i = 1; i <= steps; i++) {
        final x = minX + step * i;
        double? value;
        try {
          value = evaluate(x);
          if (!value.isFinite || value.abs() > 1e7) value = null;
        } catch (_) {
          value = null;
        }

        if (value != null && value.abs() <= 1e-7) {
          roots.add(x);
        }
        if (previousValue != null && value != null &&
            previousValue.isFinite && value.isFinite &&
            previousValue.sign != value.sign &&
            previousValue.abs() < 1e7 && value.abs() < 1e7) {
          var a = previousX;
          var b = x;
          var fa = previousValue;
          for (var iteration = 0; iteration < 80; iteration++) {
            final mid = (a + b) / 2;
            double fm;
            try {
              fm = evaluate(mid);
            } catch (_) {
              break;
            }
            if (!fm.isFinite || fm.abs() > 1e7) break;
            if (fm.abs() <= 1e-10 || (b - a).abs() <= 1e-9) {
              a = mid;
              b = mid;
              break;
            }
            if (fa.sign == fm.sign) {
              a = mid;
              fa = fm;
            } else {
              b = mid;
            }
          }
          final root = (a + b) / 2;
          try {
            if (evaluate(root).abs() <= 1e-5) roots.add(root);
          } catch (_) {}
        }
        previousX = x;
        previousValue = value;
      }

      final cleaned = _unique(roots.map(_cleanZero).toList())..sort();
      if (cleaned.isEmpty) {
        return EquationSolution.none(
          'На интервале [$minX; $maxX] действительные корни не найдены. Это не доказывает, что корней нет вне интервала или что не пропущен кратный корень.',
        );
      }
      return EquationSolution.roots(
        cleaned,
        [
          'Использован численный поиск для уравнения с функциями или степенью выше 4.',
          'Проверен интервал [$minX; $maxX] с шагом ${_fmt(step)}.',
          'Корни приближённые; при касании оси без смены знака или вне интервала корень может быть пропущен.',
        ],
      );
    } catch (_) {
      return null;
    }
  }

  List<double> _realRoots(List<double> raw) {
    final p = _trim(raw);
    final degree = p.length - 1;
    if (degree <= 0) return const [];
    if (degree == 1) return [-p[0] / p[1]];

    final derivative = <double>[];
    for (var i = 1; i < p.length; i++) {
      derivative.add(p[i] * i);
    }
    final critical = _realRoots(_trim(derivative));
    final leading = p.last.abs();
    final bound = 1 + p.take(p.length - 1).fold<double>(0, (m, c) => math.max(m, c.abs() / leading).toDouble());
    final points = <double>[-bound, ...critical.where((x) => x > -bound && x < bound), bound]..sort();
    final roots = <double>[];

    for (final x in critical) {
      if (x >= -bound && x <= bound && _eval(p, x).abs() <= _scaledTolerance(p, x)) {
        roots.add(x);
      }
    }

    for (var i = 0; i < points.length - 1; i++) {
      var a = points[i];
      var b = points[i + 1];
      var fa = _eval(p, a);
      final fb = _eval(p, b);
      if (fa.abs() <= _scaledTolerance(p, a)) roots.add(a);
      if (fb.abs() <= _scaledTolerance(p, b)) roots.add(b);
      if (fa == 0 || fb == 0 || fa.sign == fb.sign) continue;
      for (var iteration = 0; iteration < 120; iteration++) {
        final mid = (a + b) / 2;
        final fm = _eval(p, mid);
        if (fm.abs() <= 1e-12 || (b - a).abs() <= 1e-11) {
          a = mid;
          b = mid;
          break;
        }
        if (fa.sign == fm.sign) {
          a = mid;
          fa = fm;
        } else {
          b = mid;
        }
      }
      roots.add((a + b) / 2);
    }
    return _unique(roots);
  }

  double _scaledTolerance(List<double> p, double x) {
    var scale = 1.0;
    var power = 1.0;
    for (final coefficient in p) {
      scale += coefficient.abs() * power;
      power *= x.abs();
    }
    return 1e-8 * scale;
  }

  double _eval(List<double> p, double x) {
    var value = 0.0;
    for (var i = p.length - 1; i >= 0; i--) {
      value = value * x + p[i];
    }
    return value;
  }

  List<double> _unique(List<double> roots) {
    final out = <double>[];
    for (final root in roots) {
      if (root.isFinite && out.every((old) => (old - root).abs() > 1e-6 * math.max(1.0, root.abs()).toDouble())) {
        out.add(root);
      }
    }
    return out;
  }

  double _cleanZero(double value) => value.abs() < 1e-10 ? 0 : value;

  String _trimDecimal(String value) {
    if (!value.contains('.')) return value;
    return value.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }

  String _fmt(double value) {
    final v = _cleanZero(value);
    if (v == v.roundToDouble() && v.abs() < 1e12) return v.toInt().toString();
    final text = v.toStringAsPrecision(8);
    if (text.contains('e')) {
      final parts = text.split('e');
      return '${_trimDecimal(parts.first)}e${parts.last}';
    }
    return _trimDecimal(text);
  }

  static List<double> _trim(List<double> values) {
    final result = List<double>.from(values);
    while (result.length > 1 && result.last.abs() < 1e-12) {
      result.removeLast();
    }
    return result;
  }

  static List<double> _subtract(List<double> a, List<double> b) {
    final length = a.length > b.length ? a.length : b.length;
    final out = List<double>.filled(length, 0);
    for (var i = 0; i < out.length; i++) {
      out[i] = (i < a.length ? a[i] : 0) - (i < b.length ? b[i] : 0);
    }
    return _trim(out);
  }
}

class EquationSolution {
  const EquationSolution._({
    required this.kind,
    required this.message,
    this.roots = const [],
    this.steps = const [],
  });

  factory EquationSolution.roots(List<double> roots, List<String> steps) =>
      EquationSolution._(kind: 'roots', message: '', roots: roots, steps: steps);
  factory EquationSolution.none(String message) =>
      EquationSolution._(kind: 'none', message: message);
  factory EquationSolution.infinite(String message) =>
      EquationSolution._(kind: 'infinite', message: message);
  factory EquationSolution.error(String message) =>
      EquationSolution._(kind: 'error', message: message);

  final String kind;
  final String message;
  final List<double> roots;
  final List<String> steps;

  String get formatted {
    if (kind != 'roots') return message;
    return 'Корни: ${roots.map(_formatRoot).join(', ')}';
  }

  static String _formatRoot(double value) {
    if (value.abs() < 1e-10) return '0';
    if (value == value.roundToDouble() && value.abs() < 1e12) return value.toInt().toString();
    final text = value.toStringAsPrecision(8);
    if (text.contains('e')) {
      final parts = text.split('e');
      return '${_trimRootDecimal(parts.first)}e${parts.last}';
    }
    return _trimRootDecimal(text);
  }

  static String _trimRootDecimal(String value) {
    if (!value.contains('.')) return value;
    return value.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
}

class _PolynomialParser {
  _PolynomialParser(String source) : _tokens = _tokenize(source);
  final List<String> _tokens;
  int _index = 0;

  List<double> parse() {
    if (_tokens.isEmpty) throw const FormatException('Пустая часть уравнения.');
    final value = _expression();
    if (_index != _tokens.length) throw FormatException('Неожиданный символ «${_tokens[_index]}».');
    return _trim(value);
  }

  List<double> _expression() {
    var value = _term();
    while (_peek('+') || _peek('-')) {
      final operator = _next();
      final right = _term();
      value = operator == '+' ? _add(value, right) : _sub(value, right);
    }
    return value;
  }

  List<double> _term() {
    var value = _unary();
    while (_peek('*') || _peek('/')) {
      final operator = _next();
      final right = _unary();
      if (operator == '*') {
        value = _multiply(value, right);
      } else {
        if (right.length != 1 || right.first.abs() < 1e-12) {
          throw const FormatException('Деление допускается только на ненулевую константу.');
        }
        value = value.map((v) => v / right.first).toList();
      }
    }
    return value;
  }

  List<double> _power() {
    var value = _primary();
    if (_peek('^')) {
      _next();
      final sign = _peek('-') ? (_next() == '-' ? -1 : 1) : 1;
      if (_index >= _tokens.length || !RegExp(r'^\d+$').hasMatch(_tokens[_index])) {
        throw const FormatException('Степень должна быть целым числом от 0 до 4.');
      }
      final exponent = int.parse(_next()) * sign;
      if (exponent < 0 || exponent > EquationSolver.maxDegree) {
        throw const FormatException('Поддерживаются целые степени от 0 до 4.');
      }
      final original = value;
      value = [1];
      for (var i = 0; i < exponent; i++) {
        value = _multiply(value, original);
      }
    }
    return value;
  }

  List<double> _unary() {
    if (_peek('+')) {
      _next();
      return _unary();
    }
    if (_peek('-')) {
      _next();
      return _unary().map((v) => -v).toList();
    }
    return _power();
  }

  List<double> _primary() {
    if (_peek('(')) {
      _next();
      final value = _expression();
      if (!_peek(')')) throw const FormatException('Не закрыта скобка.');
      _next();
      return value;
    }
    if (_peek('x')) {
      _next();
      return [0, 1];
    }
    if (_index < _tokens.length && RegExp(r'^\d+(?:\.\d+)?(?:e[+-]?\d+)?$', caseSensitive: false).hasMatch(_tokens[_index])) {
      return [double.parse(_next())];
    }
    throw FormatException('Ожидалось число, x или скобка рядом с ${_index < _tokens.length ? _tokens[_index] : 'концом строки'}.');
  }

  bool _peek(String value) => _index < _tokens.length && _tokens[_index] == value;
  String _next() => _tokens[_index++];

  static List<String> _tokenize(String source) {
    final raw = <String>[];
    final regex = RegExp(r'\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|[x]|[()+\-*/^]');
    var cursor = 0;
    for (final match in regex.allMatches(source)) {
      if (match.start != cursor) {
        throw FormatException('Неподдерживаемый фрагмент «${source.substring(cursor, match.start)}».');
      }
      raw.add(match.group(0)!);
      cursor = match.end;
    }
    if (cursor != source.length) throw FormatException('Неподдерживаемый фрагмент «${source.substring(cursor)}».');

    final out = <String>[];
    for (final token in raw) {
      if (out.isNotEmpty) {
        final previous = out.last;
        final previousCanEnd = previous == 'x' || previous == ')' || RegExp(r'^\d').hasMatch(previous);
        final currentCanStart = token == 'x' || token == '(' || RegExp(r'^\d').hasMatch(token);
        if (previousCanEnd && currentCanStart) out.add('*');
      }
      out.add(token);
    }
    return out;
  }

  static List<double> _add(List<double> a, List<double> b) {
    final length = a.length > b.length ? a.length : b.length;
    final result = List<double>.filled(length, 0);
    for (var i = 0; i < result.length; i++) {
      result[i] = (i < a.length ? a[i] : 0) + (i < b.length ? b[i] : 0);
    }
    return _trim(result);
  }

  static List<double> _sub(List<double> a, List<double> b) {
    final length = a.length > b.length ? a.length : b.length;
    final result = List<double>.filled(length, 0);
    for (var i = 0; i < result.length; i++) {
      result[i] = (i < a.length ? a[i] : 0) - (i < b.length ? b[i] : 0);
    }
    return _trim(result);
  }

  static List<double> _multiply(List<double> a, List<double> b) {
    if (a.length + b.length - 2 > EquationSolver.maxDegree) {
      throw const FormatException('Поддерживаются полиномы не выше четвёртой степени.');
    }
    final result = List<double>.filled(a.length + b.length - 1, 0);
    for (var i = 0; i < a.length; i++) {
      for (var j = 0; j < b.length; j++) {
        result[i + j] += a[i] * b[j];
      }
    }
    return _trim(result);
  }

  static List<double> _trim(List<double> values) {
    final result = List<double>.from(values);
    while (result.length > 1 && result.last.abs() < 1e-12) {
      result.removeLast();
    }
    return result;
  }
}
