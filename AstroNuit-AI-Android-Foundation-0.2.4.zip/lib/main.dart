import 'package:flutter/material.dart';

import 'app/astronuit_app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Do not initialize LiteRT-LM at startup. Low-memory phones use the local
  // reference, database and deterministic solvers without allocating model RAM.
  runApp(const AstroNuitApp());
}
