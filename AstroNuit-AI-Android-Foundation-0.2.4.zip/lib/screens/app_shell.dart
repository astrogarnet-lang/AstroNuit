import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';
import '../widgets/theme_atmosphere.dart';
import 'chat_screen.dart';
import 'settings_screen.dart';
import 'library_screen.dart';
import 'files_screen.dart';
import 'agent_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    required this.themeKind,
    required this.selectedThemeKind,
    required this.strings,
    required this.languageCode,
    required this.animationsEnabled,
    required this.onThemeChanged,
    required this.onLanguageChanged,
    required this.onAnimationsChanged,
  });

  /// Resolved theme used for atmosphere and visuals.
  final ThemeKind themeKind;
  /// User selection (may be [ThemeKind.system]).
  final ThemeKind selectedThemeKind;
  final AppStrings strings;
  final String languageCode;
  final bool animationsEnabled;
  final ValueChanged<ThemeKind> onThemeChanged;
  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<bool> onAnimationsChanged;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final pages = <Widget>[
      ChatScreen(
        strings: s,
        themeKind: widget.themeKind,
        animationsEnabled: widget.animationsEnabled,
      ),
      LibraryScreen(strings: s),
      AgentScreen(
        strings: s,
        isVisible: _selectedIndex == 2,
        onOpenSettings: () => setState(() => _selectedIndex = 4),
      ),
      FilesScreen(strings: s),
      SettingsScreen(
        strings: s,
        themeKind: widget.selectedThemeKind,
        languageCode: widget.languageCode,
        animationsEnabled: widget.animationsEnabled,
        onThemeChanged: widget.onThemeChanged,
        onLanguageChanged: widget.onLanguageChanged,
        onAnimationsChanged: widget.onAnimationsChanged,
      ),
    ];

    return Scaffold(
      // Atmosphere wraps the page so pumpkin hit-targets sit ABOVE content
      // on every tab, while decorations still paint behind.
      body: ThemeAtmosphere(
        themeKind: widget.themeKind,
        animationsEnabled: widget.animationsEnabled,
        child: SafeArea(
          bottom: false,
          child: IndexedStack(index: _selectedIndex, children: pages),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.chat_bubble_outline),
            selectedIcon: const Icon(Icons.chat_bubble),
            label: s.chat,
          ),
          NavigationDestination(
            icon: const Icon(Icons.menu_book_outlined),
            selectedIcon: const Icon(Icons.menu_book),
            label: s.library,
          ),
          NavigationDestination(
            icon: const Icon(Icons.code),
            selectedIcon: const Icon(Icons.code_rounded),
            label: s.agent,
          ),
          NavigationDestination(
            icon: const Icon(Icons.folder_outlined),
            selectedIcon: const Icon(Icons.folder),
            label: s.files,
          ),
          NavigationDestination(
            icon: const Icon(Icons.settings_outlined),
            selectedIcon: const Icon(Icons.settings),
            label: s.settings,
          ),
        ],
      ),
    );
  }
}
