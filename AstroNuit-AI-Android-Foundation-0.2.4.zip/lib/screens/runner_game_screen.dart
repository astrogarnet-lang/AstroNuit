import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

class RunnerGameScreen extends StatefulWidget {
  const RunnerGameScreen({super.key, required this.isRussian});
  final bool isRussian;

  @override
  State<RunnerGameScreen> createState() => _RunnerGameScreenState();
}

class _RunnerGameScreenState extends State<RunnerGameScreen>
    with TickerProviderStateMixin {
  late final Ticker _ticker;
  late final AnimationController _moonPulse;
  final math.Random _random = math.Random();
  final List<_RunnerObstacle> _obstacles = [];

  Duration? _lastTick;
  double _worldWidth = 360;
  double _worldHeight = 300;
  double _jumpHeight = 0;
  double _verticalVelocity = 0;
  double _spawnCountdown = 1.2;
  double _animationTime = 0;
  double _speed = 245;
  int _score = 0;
  bool _running = false;
  bool _gameOver = false;

  bool get _ru => widget.isRussian;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_tick);
    _moonPulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
      lowerBound: 0.15,
      upperBound: 1,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _moonPulse.dispose();
    super.dispose();
  }

  void _startOrJump() {
    if (!_running || _gameOver) {
      setState(() {
        _obstacles.clear();
        _jumpHeight = 0;
        _verticalVelocity = 0;
        _spawnCountdown = 1.0;
        _speed = 245;
        _score = 0;
        _animationTime = 0;
        _gameOver = false;
        _running = true;
      });
      _lastTick = null;
      _ticker.start();
      return;
    }
    _jump();
  }

  void _jump() {
    if (!_running || _gameOver || _jumpHeight > 0.5) return;
    setState(() => _verticalVelocity = 635);
  }

  void _tick(Duration elapsed) {
    if (!_running || !mounted) return;
    final previous = _lastTick ?? elapsed;
    _lastTick = elapsed;
    final dt = ((elapsed - previous).inMicroseconds / 1000000)
        .clamp(0.0, 0.045)
        .toDouble();
    if (dt <= 0) return;

    setState(() {
      _animationTime += dt;
      _speed = math.min(540.0, 245 + _score * 4.0).toDouble();

      if (_jumpHeight > 0 || _verticalVelocity > 0) {
        _verticalVelocity -= 1650 * dt;
        _jumpHeight += _verticalVelocity * dt;
        if (_jumpHeight <= 0) {
          _jumpHeight = 0;
          _verticalVelocity = 0;
        }
      }

      for (final obstacle in _obstacles) {
        obstacle.x -= _speed * dt;
      }
      _obstacles.removeWhere((obstacle) => obstacle.x + obstacle.width < 0);

      _spawnCountdown -= dt;
      if (_spawnCountdown <= 0) {
        final height = 28 + _random.nextDouble() * 22;
        _obstacles.add(_RunnerObstacle(
          x: _worldWidth + 12,
          width: 18 + _random.nextDouble() * 13,
          height: height,
        ));
        _spawnCountdown = 1.05 + _random.nextDouble() * 0.85;
      }

      const playerX = 62.0;
      const playerWidth = 28.0;
      const playerHeight = 49.0;
      final floorY = _worldHeight - 38;
      final playerTop = floorY - playerHeight - _jumpHeight;
      for (final obstacle in _obstacles) {
        final overlapsX = playerX + playerWidth - 5 > obstacle.x &&
            playerX + 5 < obstacle.x + obstacle.width;
        final obstacleTop = floorY - obstacle.height;
        final overlapsY = playerTop + playerHeight - 4 > obstacleTop;
        if (overlapsX && overlapsY) {
          _running = false;
          _gameOver = true;
          _ticker.stop();
          break;
        }
        if (!obstacle.counted && obstacle.x + obstacle.width < playerX) {
          obstacle.counted = true;
          _score++;
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080B13),
      appBar: AppBar(
        backgroundColor: const Color(0xFF080B13),
        foregroundColor: Colors.white,
        title: Text(_ru ? 'Лунный забег' : 'Moonlight Run'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
              child: Row(
                children: [
                  Text(
                    _ru ? 'СЧЁТ' : 'SCORE',
                    style: const TextStyle(
                      color: Color(0xFFAAB6CF),
                      fontSize: 12,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '$_score',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  _worldWidth = constraints.maxWidth;
                  _worldHeight = constraints.maxHeight;
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _jump,
                    child: CustomPaint(
                      painter: _RunnerPainter(
                        score: _score,
                        jumpHeight: _jumpHeight,
                        animationTime: _animationTime,
                        obstacles: List<_RunnerObstacle>.of(_obstacles),
                        gameOver: _gameOver,
                        running: _running,
                      ),
                      child: SizedBox.expand(
                        child: Center(
                          child: !_running && !_gameOver
                              ? Text(
                                  _ru
                                      ? 'Нажмите «Бежать» и прыгайте по экрану'
                                      : 'Press “Run” and tap to jump',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: Color(0xFFABB6CC),
                                    fontSize: 14,
                                  ),
                                )
                              : _gameOver
                                  ? Text(
                                      _ru ? 'Столкновение!' : 'Game over!',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 22,
                                        shadows: [
                                          Shadow(
                                            color: Color(0xFF7FA7FF),
                                            blurRadius: 18,
                                          ),
                                        ],
                                      ),
                                    )
                                  : const SizedBox.shrink(),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 24, 28),
              child: AnimatedBuilder(
                animation: _moonPulse,
                builder: (context, child) {
                  final glow = _moonPulse.value;
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(36),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFB7D4FF).withValues(alpha: 0.08 + glow * 0.25),
                          blurRadius: 8 + glow * 22,
                          spreadRadius: glow * 2,
                        ),
                      ],
                    ),
                    child: child,
                  );
                },
                child: SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: _startOrJump,
                    icon: Icon(_running ? Icons.arrow_upward_rounded : Icons.directions_run),
                    label: Text(
                      _gameOver
                          ? (_ru ? 'Ещё раз' : 'Try again')
                          : _running
                              ? (_ru ? 'Прыгать' : 'Jump')
                              : (_ru ? 'Бежать' : 'Run'),
                      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFE7EEF9),
                      foregroundColor: const Color(0xFF17243A),
                      padding: const EdgeInsets.symmetric(vertical: 17),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(36)),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RunnerObstacle {
  _RunnerObstacle({required this.x, required this.width, required this.height});
  double x;
  final double width;
  final double height;
  bool counted = false;
}

class _RunnerPainter extends CustomPainter {
  const _RunnerPainter({
    required this.score,
    required this.jumpHeight,
    required this.animationTime,
    required this.obstacles,
    required this.gameOver,
    required this.running,
  });

  final int score;
  final double jumpHeight;
  final double animationTime;
  final List<_RunnerObstacle> obstacles;
  final bool gameOver;
  final bool running;

  @override
  void paint(Canvas canvas, Size size) {
    final background = Paint()..color = const Color(0xFF080B13);
    canvas.drawRect(Offset.zero & size, background);
    if (size.width < 1 || size.height < 1) return;
    final starPaint = Paint()..color = const Color(0xFFB5C7E8).withValues(alpha: 0.55);
    for (var i = 0; i < 34; i++) {
      final x = ((i * 79 + 23) % size.width.toInt()).toDouble();
      final y = ((i * 43 + 19) % (size.height * 0.7).toInt()).toDouble();
      canvas.drawCircle(Offset(x, y), i % 5 == 0 ? 1.6 : 0.8, starPaint);
    }

    final moonPaint = Paint()..color = const Color(0xFFE8F0FF).withValues(alpha: 0.92);
    canvas.drawCircle(Offset(size.width - 56, 54), 23, moonPaint);
    final moonShade = Paint()..color = const Color(0xFF080B13);
    canvas.drawCircle(Offset(size.width - 45, 45), 20, moonShade);

    final floorY = size.height - 38;
    final floorPaint = Paint()
      ..color = const Color(0xFF5C6B88)
      ..strokeWidth = 2;
    canvas.drawLine(Offset(0, floorY), Offset(size.width, floorY), floorPaint);
    final dashPaint = Paint()
      ..color = const Color(0xFF263652)
      ..strokeWidth = 2;
    final offset = (animationTime * 160) % 54;
    for (double x = -54 + offset; x < size.width; x += 54) {
      canvas.drawLine(Offset(x, floorY + 11), Offset(x + 23, floorY + 11), dashPaint);
    }

    for (final obstacle in obstacles) {
      final cactus = Paint()..color = const Color(0xFF82B7A5);
      final rect = RRect.fromRectAndRadius(
        Rect.fromLTWH(obstacle.x, floorY - obstacle.height, obstacle.width, obstacle.height),
        const Radius.circular(7),
      );
      canvas.drawRRect(rect, cactus);
      final armPaint = Paint()
        ..color = const Color(0xFF82B7A5)
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round;
      if (obstacle.height > 36) {
        canvas.drawLine(
          Offset(obstacle.x + obstacle.width * 0.2, floorY - obstacle.height * 0.55),
          Offset(obstacle.x - 5, floorY - obstacle.height * 0.55),
          armPaint,
        );
      }
    }

    _drawRunner(canvas, Offset(72, floorY - 49 - jumpHeight), animationTime, !running || gameOver);
  }

  void _drawRunner(Canvas canvas, Offset topLeft, double time, bool idle) {
    final line = Paint()
      ..color = const Color(0xFFE8EDF8)
      ..strokeWidth = 4.2
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    final fill = Paint()..color = const Color(0xFFE8EDF8);
    final head = Offset(topLeft.dx + 14, topLeft.dy + 7);
    canvas.drawCircle(head, 6.2, fill);
    canvas.drawLine(Offset(topLeft.dx + 14, topLeft.dy + 14), Offset(topLeft.dx + 14, topLeft.dy + 30), line);
    canvas.drawLine(Offset(topLeft.dx + 14, topLeft.dy + 19), Offset(topLeft.dx + 3, topLeft.dy + 25), line);
    canvas.drawLine(Offset(topLeft.dx + 14, topLeft.dy + 19), Offset(topLeft.dx + 25, topLeft.dy + 23), line);

    final stride = idle ? 0.0 : math.sin(time * 13) * 9;
    canvas.drawLine(
      Offset(topLeft.dx + 14, topLeft.dy + 30),
      Offset(topLeft.dx + 7 + stride, topLeft.dy + 45),
      line,
    );
    canvas.drawLine(
      Offset(topLeft.dx + 14, topLeft.dy + 30),
      Offset(topLeft.dx + 22 - stride, topLeft.dy + 45),
      line,
    );
  }

  @override
  bool shouldRepaint(covariant _RunnerPainter oldDelegate) =>
      score != oldDelegate.score ||
      jumpHeight != oldDelegate.jumpHeight ||
      animationTime != oldDelegate.animationTime ||
      obstacles.length != oldDelegate.obstacles.length ||
      _positionsChanged(oldDelegate.obstacles) ||
      gameOver != oldDelegate.gameOver ||
      running != oldDelegate.running;

  bool _positionsChanged(List<_RunnerObstacle> old) {
    if (old.length != obstacles.length) return true;
    for (var i = 0; i < old.length; i++) {
      if (old[i].x != obstacles[i].x) return true;
    }
    return false;
  }
}
