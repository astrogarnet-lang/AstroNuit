import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_markdown_plus/flutter_markdown_plus.dart';

import '../core/document_importer.dart';
import '../core/document_picker.dart';
import '../core/ai_assistant.dart';
import '../data/knowledge_db.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.strings,
    required this.themeKind,
    required this.animationsEnabled,
  });

  final AppStrings strings;
  final ThemeKind themeKind;
  final bool animationsEnabled;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatEntry {
  const _ChatEntry({required this.text, required this.fromUser});
  final String text;
  final bool fromUser;
}

class _ChatScreenState extends State<ChatScreen>
    with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<_ChatEntry> _messages = [];
  late final AnimationController _halloweenGlowController;
  bool _isProcessingPreview = false;
  Uint8List? _selectedImageBytes;
  String? _selectedImageName;

  bool get _shouldGlow =>
      widget.themeKind == ThemeKind.halloween &&
      widget.animationsEnabled &&
      _isProcessingPreview;

  @override
  void initState() {
    super.initState();
    _halloweenGlowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 850),
    );
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      final rows = await KnowledgeDb.instance.loadChatMessages();
      // Do not overwrite a message typed immediately after the screen opened.
      if (!mounted || rows.isEmpty || _messages.isNotEmpty) return;
      setState(() {
        _messages.addAll(rows.map((row) => _ChatEntry(
              text: row['content'] as String,
              fromUser: row['role'] == 'user',
            )));
      });
      _scrollToBottom();
    } catch (_) {
      // The chat remains usable even if a previous database needs recovery.
    }
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled) {
      if (_shouldGlow) {
        _halloweenGlowController.repeat(reverse: true);
      } else {
        _halloweenGlowController.stop();
        _halloweenGlowController.value = 0;
      }
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    _halloweenGlowController.dispose();
    super.dispose();
  }

  Future<void> _sendMessage() async {
    final text = _controller.text.trim();
    final imageBytes = _selectedImageBytes;
    final imageName = _selectedImageName;
    if ((text.isEmpty && imageBytes == null) || _isProcessingPreview) return;
    final visibleText = imageBytes == null
        ? text
        : (text.isEmpty ? '📷 $imageName' : '$text\n📷 $imageName');

    final previousHistory = _messages
        .map((message) => <String, String>{
              'role': message.fromUser ? 'user' : 'assistant',
              'content': message.text,
            })
        .toList(growable: false);

    setState(() {
      _messages.add(_ChatEntry(text: visibleText, fromUser: true));
      _controller.clear();
      _selectedImageBytes = null;
      _selectedImageName = null;
      _isProcessingPreview = true;
    });
    if (_shouldGlow) _halloweenGlowController.repeat(reverse: true);
    _scrollToBottom();

    try {
      await KnowledgeDb.instance.saveChatMessage(role: 'user', content: visibleText);
    } catch (_) {}

    final lang = widget.strings.isRussian ? 'ru' : 'en';
    String reply;
    try {
      reply = await AiAssistant.instance.reply(
        userMessage: text,
        history: previousHistory,
        languageCode: lang,
        imageBytes: imageBytes,
      );
    } catch (error) {
      reply = widget.strings.isRussian
          ? 'Не удалось получить ответ от модели.\n$error'
          : 'The model did not return an answer.\n$error';
    }

    if (!mounted) return;
    try {
      await KnowledgeDb.instance.saveChatMessage(
        role: 'assistant',
        content: reply,
      );
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _isProcessingPreview = false;
      _messages.add(_ChatEntry(text: reply, fromUser: false));
    });
    _halloweenGlowController.stop();
    _halloweenGlowController.value = 0;
    _scrollToBottom();
  }

  Future<void> _clearHistory() async {
    final isRussian = widget.strings.isRussian;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(isRussian ? 'Очистить историю?' : 'Clear chat history?'),
        content: Text(isRussian
            ? 'Все сохранённые сообщения AstroNuit будут удалены с устройства.'
            : 'All saved AstroNuit messages will be removed from this device.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(isRussian ? 'Отмена' : 'Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(isRussian ? 'Очистить' : 'Clear'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await KnowledgeDb.instance.clearChatMessages();
    if (!mounted) return;
    setState(_messages.clear);
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 360),
          curve: Curves.easeOutCubic,
        );
      }
    });
  }

  Future<void> _showAttachmentNotice() async {
    try {
      final picked = await DocumentPicker.pickDocument();
      if (picked == null) return;
      final file = File(picked.path);
      final imported = await DocumentImporter.importFile(file, displayName: picked.name);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            widget.strings.isRussian
                ? 'Добавлено в базу знаний: ${imported.title} (${imported.chars} символов)'
                : 'Added to knowledge base: ${imported.title} (${imported.chars} characters)',
          ),
        ),
      );
      setState(() {
        _messages.add(_ChatEntry(
          text: widget.strings.isRussian
              ? 'Файл «${imported.title}» загружен и проиндексирован. Теперь можно задавать вопросы по его содержимому.'
              : 'File “${imported.title}” was imported and indexed. You can now ask questions about its contents.',
          fromUser: false,
        ));
      });
      _scrollToBottom();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            widget.strings.isRussian
                ? 'Ошибка импорта: $error'
                : 'Import error: $error',
          ),
        ),
      );
    }
  }

  Future<void> _pickImage() async {
    if (_isProcessingPreview) return;
    try {
      final picked = await DocumentPicker.pickImage();
      if (picked == null) return;
      final file = File(picked.path);
      final length = await file.length();
      if (length > 18 * 1024 * 1024) {
        throw Exception(widget.strings.isRussian ? 'Изображение больше 18 МБ.' : 'Image is larger than 18 MB.');
      }
      final bytes = await file.readAsBytes();
      if (!mounted) return;
      setState(() {
        _selectedImageBytes = bytes;
        _selectedImageName = picked.name;
      });
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${widget.strings.isRussian ? 'Не удалось открыть изображение' : 'Could not open image'}: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final s = widget.strings;
    final isEmpty = _messages.isEmpty;

    return Column(
      children: [
        if (_messages.isNotEmpty)
          Align(
            alignment: Alignment.centerRight,
            child: IconButton(
              tooltip: s.isRussian ? 'Очистить историю' : 'Clear history',
              onPressed: _isProcessingPreview ? null : _clearHistory,
              icon: const Icon(Icons.delete_sweep_outlined),
            ),
          ),
        Expanded(
          child: isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          s.appGreeting,
                          style: theme.textTheme.headlineMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            letterSpacing: -0.6,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          s.greetingSubtitle,
                          style: theme.textTheme.titleMedium?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.68),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                  itemCount: _messages.length + (_isProcessingPreview ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) {
                      return Padding(
                        padding: const EdgeInsets.only(top: 14, bottom: 10),
                        child: Text(
                          s.isRussian ? 'Думаю…' : 'Thinking…',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
                          ),
                        ),
                      );
                    }
                    final message = _messages[index];
                    return Align(
                      alignment: message.fromUser
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: 310),
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 11,
                        ),
                        decoration: BoxDecoration(
                          color: message.fromUser
                              ? theme.colorScheme.primary.withValues(alpha: 0.12)
                              : theme.colorScheme.surface,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: MarkdownBody(
                          data: message.text,
                          styleSheet: MarkdownStyleSheet.fromTheme(theme).copyWith(
                            p: theme.textTheme.bodyMedium?.copyWith(
                              color: theme.colorScheme.onSurface,
                              height: 1.35,
                            ),
                            h1: theme.textTheme.titleLarge?.copyWith(
                              color: theme.colorScheme.onSurface,
                              fontWeight: FontWeight.w700,
                            ),
                            h2: theme.textTheme.titleMedium?.copyWith(
                              color: theme.colorScheme.onSurface,
                              fontWeight: FontWeight.w700,
                            ),
                            code: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurface,
                              backgroundColor: theme.colorScheme.surfaceContainerHighest,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (_selectedImageBytes != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Image.memory(_selectedImageBytes!, width: 58, height: 58, fit: BoxFit.cover),
                        ),
                        const SizedBox(width: 10),
                        Expanded(child: Text(_selectedImageName ?? 'image', maxLines: 1, overflow: TextOverflow.ellipsis)),
                        IconButton(
                          tooltip: s.isRussian ? 'Убрать изображение' : 'Remove image',
                          onPressed: () => setState(() { _selectedImageBytes = null; _selectedImageName = null; }),
                          icon: const Icon(Icons.close),
                        ),
                      ],
                    ),
                  ),
                AnimatedBuilder(
                  animation: _halloweenGlowController,
                  builder: (context, child) {
                    final glow = _shouldGlow ? _halloweenGlowController.value : 0.0;
                    return Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(32),
                        boxShadow: glow > 0 ? [
                          BoxShadow(
                            color: const Color(0xFFB7784E).withValues(alpha: 0.06 + glow * 0.16),
                            blurRadius: 5 + glow * 15,
                            spreadRadius: glow * 1.2,
                          ),
                        ] : const [],
                      ),
                      child: child,
                    );
                  },
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      IconButton(tooltip: s.attach, onPressed: _showAttachmentNotice, icon: const Icon(Icons.add)),
                      IconButton(
                        tooltip: s.isRussian ? 'Добавить изображение' : 'Attach image',
                        onPressed: _pickImage,
                        icon: const Icon(Icons.image_outlined),
                      ),
                      Expanded(
                        child: TextField(
                          controller: _controller,
                          minLines: 1,
                          maxLines: 5,
                          textCapitalization: TextCapitalization.sentences,
                          onSubmitted: (_) => _sendMessage(),
                          decoration: InputDecoration(hintText: s.messageHint, isDense: true),
                        ),
                      ),
                      const SizedBox(width: 7),
                      IconButton.filled(
                        tooltip: s.send,
                        onPressed: _sendMessage,
                        icon: const Icon(Icons.arrow_upward_rounded),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
