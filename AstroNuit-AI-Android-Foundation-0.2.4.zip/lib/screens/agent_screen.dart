import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../core/offline_model_manager.dart';
import 'runner_game_screen.dart';
import 'study_screen.dart';

class AgentScreen extends StatefulWidget {
  const AgentScreen({
    super.key,
    required this.strings,
    required this.onOpenSettings,
    required this.isVisible,
  });

  final AppStrings strings;
  final VoidCallback onOpenSettings;
  final bool isVisible;

  @override
  State<AgentScreen> createState() => _AgentScreenState();
}

class _AgentScreenState extends State<AgentScreen> {
  late Future<bool> _configured;

  @override
  void initState() {
    super.initState();
    _configured = OfflineModelManager.instance.refreshInstalledState();
  }

  @override
  void didUpdateWidget(covariant AgentScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!oldWidget.isVisible && widget.isVisible) {
      setState(() => _configured = OfflineModelManager.instance.refreshInstalledState());
    }
  }

  @override
  Widget build(BuildContext context) {
    final isRussian = widget.strings.isRussian;
    final scheme = Theme.of(context).colorScheme;

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 22, 18, 110),
      children: [
        Text(
          isRussian ? 'AstroNuit AI' : 'AstroNuit AI',
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
        ),
        const SizedBox(height: 7),
        Text(
          isRussian
              ? 'Интеллектуальное ядро, база знаний и инструменты.'
              : 'AI core, personal knowledge base and tools.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
        ),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: FutureBuilder<bool>(
              future: _configured,
              builder: (context, snapshot) {
                final ready = snapshot.data == true;
                final waiting = snapshot.connectionState == ConnectionState.waiting;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          ready ? Icons.offline_bolt_outlined : Icons.psychology_alt_outlined,
                          color: ready ? Colors.green : scheme.primary,
                          size: 28,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            isRussian ? 'Генеративная модель' : 'Generative model',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: FontWeight.w700,
                                ),
                          ),
                        ),
                        if (waiting)
                          const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        else
                          Icon(
                            ready ? Icons.check_circle : Icons.info_outline,
                            color: ready ? Colors.green : scheme.onSurfaceVariant,
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      ready
                          ? (isRussian
                              ? 'Qwen3-0.6B включена в APK. Приложение подготовит её автоматически при первом запросе к нейросети; перед генерацией проверяется доступная память.'
                              : 'Qwen3-0.6B is included in the APK. The app prepares it automatically when AI is first requested and checks available RAM before generation.')
                          : (isRussian
                              ? 'Встроенная модель пока не подготовлена. Проверьте свободное место и повторите подготовку; справочник, история, локальный поиск и решатели работают независимо от нейросети.'
                              : 'The bundled model is not prepared yet. Check free storage and retry; the reference, history, local search and deterministic solvers work independently of the neural model.'),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.4),
                    ),
                    if (snapshot.hasError) ...[
                      const SizedBox(height: 8),
                      Text('${snapshot.error}', style: Theme.of(context).textTheme.bodySmall?.copyWith(color: scheme.error)),
                    ],
                    const SizedBox(height: 14),
                    FilledButton.icon(
                      onPressed: widget.onOpenSettings,
                      icon: const Icon(Icons.tune),
                      label: Text(isRussian ? 'Настройки встроенной модели' : 'Bundled model settings'),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.auto_stories_outlined, color: scheme.primary, size: 26),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        isRussian ? 'Локальная база знаний' : 'Local knowledge base',
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  isRussian
                      ? 'Импортируйте PDF, TXT, MD, CSV и JSON. Qwen3-0.6B использует найденные текстовые фрагменты как контекст. Текущая модель не поддерживает прямой анализ изображений.'
                      : 'Import PDF, TXT, MD, CSV and JSON. Qwen3-0.6B uses retrieved text excerpts as context. The current model does not support direct image analysis.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.4),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => StudyScreen(isRussian: isRussian),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: scheme.secondaryContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(Icons.science_outlined, color: scheme.onSecondaryContainer, size: 28),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isRussian ? 'Научный справочник и решатель' : 'Science reference & solver',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          isRussian
                              ? 'История мира, 100+ формул и вычисления без нейросети.'
                              : 'World history, 100+ formulas and deterministic calculations.',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => RunnerGameScreen(isRussian: isRussian),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: scheme.primaryContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(Icons.directions_run, color: scheme.onPrimaryContainer, size: 30),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isRussian ? 'Небольшой перерыв' : 'Take a short break',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                              ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          isRussian
                              ? 'Мини-игра: беги и перепрыгивай препятствия.'
                              : 'Mini-game: run and jump over obstacles.',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: scheme.onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}
