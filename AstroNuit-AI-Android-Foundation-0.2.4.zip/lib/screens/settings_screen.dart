import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';
import '../widgets/offline_model_card.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    super.key,
    required this.themeKind,
    required this.strings,
    required this.languageCode,
    required this.animationsEnabled,
    required this.onThemeChanged,
    required this.onLanguageChanged,
    required this.onAnimationsChanged,
  });

  final ThemeKind themeKind;
  final AppStrings strings;
  final String languageCode;
  final bool animationsEnabled;
  final ValueChanged<ThemeKind> onThemeChanged;
  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<bool> onAnimationsChanged;

  String _themeName(ThemeKind kind) {
    switch (kind) {
      case ThemeKind.system:
        return strings.systemTheme;
      case ThemeKind.light:
        return strings.lightTheme;
      case ThemeKind.dark:
        return strings.darkTheme;
      case ThemeKind.halloween:
        return strings.halloweenTheme;
      case ThemeKind.christmas:
        return strings.christmasTheme;
      case ThemeKind.cosmos:
        return strings.cosmosTheme;
      case ThemeKind.pink:
        return strings.pinkTheme;
      case ThemeKind.aurora:
        return strings.auroraTheme;
      case ThemeKind.autumn:
        return strings.autumnTheme;
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    // Solid panel so Halloween pumpkins / Christmas decor don't cover labels.
    final panelColor = scheme.surface.withValues(alpha: 0.92);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
      child: Material(
        color: panelColor,
        elevation: 1.5,
        shadowColor: Colors.black26,
        borderRadius: BorderRadius.circular(18),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                strings.theme,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: scheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 6),
              RadioGroup<ThemeKind>(
                groupValue: themeKind,
                onChanged: (value) {
                  if (value != null) onThemeChanged(value);
                },
                child: Column(
                  children: ThemeKind.values
                      .map(
                        (kind) => RadioListTile<ThemeKind>(
                          value: kind,
                          title: Text(
                            _themeName(kind),
                            style: TextStyle(
                              color: scheme.onSurface,
                              fontWeight: themeKind == kind
                                  ? FontWeight.w600
                                  : FontWeight.w400,
                            ),
                          ),
                          contentPadding: EdgeInsets.zero,
                          dense: true,
                          activeColor: scheme.primary,
                        ),
                      )
                      .toList(),
                ),
              ),
              Divider(height: 28, color: scheme.outline.withValues(alpha: 0.35)),
              Text(
                strings.language,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: scheme.onSurface,
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 10),
              SegmentedButton<String>(
                segments: const [
                  ButtonSegment<String>(value: 'ru', label: Text('Русский')),
                  ButtonSegment<String>(value: 'en', label: Text('English')),
                ],
                selected: {languageCode},
                onSelectionChanged: (values) => onLanguageChanged(values.first),
              ),
              Divider(height: 28, color: scheme.outline.withValues(alpha: 0.35)),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(
                  strings.animations,
                  style: TextStyle(color: scheme.onSurface),
                ),
                value: animationsEnabled,
                onChanged: onAnimationsChanged,
              ),
              Divider(height: 28, color: scheme.outline.withValues(alpha: 0.35)),
              OfflineModelCard(isRussian: languageCode == 'ru'),
              const SizedBox(height: 16),
              Text(
                languageCode == 'ru'
                    ? 'Тема, язык и анимации сохраняются на устройстве. «Системная» следует за светлой/тёмной темой устройства.\n\nИИ работает локально. Импортируйте модель .litertlm и документы — сеть приложению не нужна.'
                    : 'Theme, language and animation settings are saved on this device. “System” follows the device light/dark mode.\n\nAI runs locally. Qwen3 is already included in the APK and prepares automatically; only your own documents need importing. The app does not need network access.',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: scheme.onSurface.withValues(alpha: 0.72),
                      height: 1.35,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
