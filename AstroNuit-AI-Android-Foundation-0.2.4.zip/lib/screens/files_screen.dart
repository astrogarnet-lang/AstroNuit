import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../core/document_importer.dart';
import '../data/knowledge_db.dart';

class FilesScreen extends StatefulWidget {
  const FilesScreen({super.key, required this.strings});
  final AppStrings strings;

  @override
  State<FilesScreen> createState() => _FilesScreenState();
}

class _FilesScreenState extends State<FilesScreen> {
  List<Map<String, dynamic>> docs = [];

  Future<void> load() async {
    final d = await KnowledgeDb.instance.listDocuments();
    if (mounted) setState(() => docs = d);
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> importPaste() async {
    final title = TextEditingController();
    final body = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(widget.strings.isRussian
            ? 'Импорт текста / файла как текст'
            : 'Import text'),
        content: SingleChildScrollView(
          child: Column(children: [
            TextField(
                controller: title,
                decoration: InputDecoration(
                    labelText: widget.strings.isRussian
                        ? 'Имя файла'
                        : 'File name')),
            const SizedBox(height: 8),
            TextField(
              controller: body,
              maxLines: 12,
              decoration: InputDecoration(
                labelText: widget.strings.isRussian
                    ? 'Содержимое (TXT/MD/CSV/код; PDF — вставьте текст)'
                    : 'Content (TXT/MD/CSV/code; paste PDF text)',
              ),
            ),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(widget.strings.isRussian ? 'Отмена' : 'Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(widget.strings.isRussian ? 'Импорт' : 'Import')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await DocumentImporter.importText(
        title: title.text.trim().isEmpty ? 'import.txt' : title.text.trim(),
        content: body.text,
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: importPaste,
        icon: const Icon(Icons.file_upload_outlined),
        label: Text(s.isRussian ? 'Импорт' : 'Import'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
        children: [
          Text(s.filesTitle, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(
            s.isRussian
                ? 'Здесь можно вставить текст вручную. Для импорта PDF, TXT, MD, CSV или JSON выберите скрепку в чате. DOCX пока не поддерживается.'
                : 'Paste text here. To import PDF, TXT, MD, CSV or JSON, use the attachment button in Chat. DOCX is not supported yet.',
            style: TextStyle(
              color: Theme.of(context)
                  .colorScheme
                  .onSurface
                  .withValues(alpha: 0.65),
            ),
          ),
          const SizedBox(height: 16),
          if (docs.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('—'),
              ),
            )
          else
            ...docs.map((d) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.insert_drive_file_outlined),
                    title: Text('${d['title']}'),
                    subtitle: Text('${d['mime']} · ${d['char_count']}'),
                  ),
                )),
        ],
      ),
    );
  }
}
