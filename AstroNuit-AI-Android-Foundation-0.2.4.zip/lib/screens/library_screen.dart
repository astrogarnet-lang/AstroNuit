import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../core/document_importer.dart';
import '../core/local_core.dart';
import '../data/knowledge_db.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key, required this.strings});
  final AppStrings strings;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<Map<String, dynamic>> docs = [];
  int chunks = 0;
  bool loading = true;

  Future<void> load() async {
    final d = await KnowledgeDb.instance.listDocuments();
    final c = await KnowledgeDb.instance.chunkCount();
    if (!mounted) return;
    setState(() {
      docs = d;
      chunks = c;
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> pasteImport() async {
    final title = TextEditingController();
    final body = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(widget.strings.isRussian
            ? 'Добавить в библиотеку'
            : 'Add to library'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: title,
              decoration: InputDecoration(
                labelText: widget.strings.isRussian ? 'Название' : 'Title',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: body,
              maxLines: 10,
              decoration: InputDecoration(
                labelText: widget.strings.isRussian
                    ? 'Текст / конспект / формула'
                    : 'Text / notes / formula',
              ),
            ),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(widget.strings.isRussian ? 'Отмена' : 'Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(widget.strings.isRussian ? 'Сохранить' : 'Save')),
        ],
      ),
    );
    if (ok != true) return;
    final t = title.text.trim().isEmpty
        ? (widget.strings.isRussian ? 'Заметка' : 'Note')
        : title.text.trim();
    try {
      await DocumentImporter.importText(title: t, content: body.text);
      await load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(widget.strings.isRussian
              ? 'Документ добавлен в RAG-базу'
              : 'Document added to RAG store'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.strings;
    final theme = Theme.of(context);
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: pasteImport,
        icon: const Icon(Icons.note_add_outlined),
        label: Text(s.isRussian ? 'Добавить текст' : 'Add text'),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
        children: [
          Text(s.scienceLibrary, style: theme.textTheme.titleLarge),
          const SizedBox(height: 6),
          Text(
            s.isRussian
                ? 'Локальная база для RAG. Чанков: $chunks. ${LocalCore.instance.statusRu}'
                : 'Local RAG store. Chunks: $chunks. ${LocalCore.instance.statusEn}',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurface.withValues(alpha: 0.65),
            ),
          ),
          const SizedBox(height: 16),
          if (loading)
            const Center(child: CircularProgressIndicator())
          else if (docs.isEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  s.isRussian
                      ? 'Библиотека пуста. Добавьте конспекты, формулы или статьи текстом — чат начнёт опираться на них.'
                      : 'Library is empty. Add notes, formulas or articles as text — chat will retrieve them.',
                ),
              ),
            )
          else
            ...docs.map((d) => Card(
                  child: ListTile(
                    title: Text('${d['title']}'),
                    subtitle: Text(
                      s.isRussian
                          ? '${d['char_count']} символов'
                          : '${d['char_count']} chars',
                    ),
                    trailing: (d['source_path'] as String? ?? '').startsWith('builtin:')
                        ? const Tooltip(message: 'Встроенный источник', child: Icon(Icons.verified_outlined))
                        : IconButton(
                            icon: const Icon(Icons.delete_outline),
                            onPressed: () async {
                              await KnowledgeDb.instance.deleteDocument(d['id'] as int);
                              await load();
                            },
                          ),
                  ),
                )),
        ],
      ),
    );
  }
}
