import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/equation_solver.dart';
import '../core/science_task_solver.dart';

class StudyScreen extends StatefulWidget {
  const StudyScreen({super.key, required this.isRussian});
  final bool isRussian;

  @override
  State<StudyScreen> createState() => _StudyScreenState();
}

class _StudyScreenState extends State<StudyScreen> {
  final _searchController = TextEditingController();
  final _equationController = TextEditingController();
  final _solver = const ScienceTaskSolver();
  final _equations = EquationSolver();
  String _section = 'formulas';
  String _category = 'all';
  String _search = '';
  List<Map<String, dynamic>> _formulas = const [];
  List<Map<String, dynamic>> _history = const [];
  bool _loading = true;
  EquationSolution? _solution;

  bool get _ru => widget.isRussian;

  @override
  void initState() {
    super.initState();
    _loadAssets();
    _searchController.addListener(() => setState(() => _search = _searchController.text.trim().toLowerCase()));
  }

  Future<void> _loadAssets() async {
    try {
      final formulasJson = jsonDecode(await rootBundle.loadString('assets/knowledge/science_formulas.json')) as Map<String, dynamic>;
      final historyJson = jsonDecode(await rootBundle.loadString('assets/knowledge/world_history_timeline.json')) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _formulas = (formulasJson['formulas'] as List).cast<Map<String, dynamic>>();
        _history = (historyJson['events'] as List).cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось открыть встроенный справочник: $error')));
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    _equationController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get _filteredFormulas => _formulas.where((item) {
        final categoryOk = _category == 'all' || item['category'] == _category;
        final haystack = '${item['title']} ${item['formula']} ${item['description']} ${item['variables']}'.toLowerCase();
        return categoryOk && (_search.isEmpty || haystack.contains(_search));
      }).toList(growable: false);

  List<Map<String, dynamic>> get _filteredHistory => _history.where((item) {
        final haystack = '${item['era']} ${item['date']} ${item['title']} ${item['description']}'.toLowerCase();
        return _search.isEmpty || haystack.contains(_search);
      }).toList(growable: false);

  Future<void> _calculateFormula(Map<String, dynamic> formula) async {
    final id = formula['calculator'] as String?;
    if (id == null) return;
    final fields = ScienceTaskSolver.inputs[id];
    if (fields == null) return;
    final controllers = {for (final field in fields) field.key: TextEditingController()};
    final values = await showDialog<Map<String, double>>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_ru ? 'Решить: ${formula['title']}' : 'Calculate: ${formula['title']}'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: fields.map((field) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: TextField(
                controller: controllers[field.key],
                keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                decoration: InputDecoration(labelText: '${field.label} (${field.key})', border: const OutlineInputBorder()),
              ),
            )).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text(_ru ? 'Отмена' : 'Cancel')),
          FilledButton(
            onPressed: () {
              final parsed = <String, double>{};
              for (final field in fields) {
                final text = controllers[field.key]!.text.trim().replaceAll(',', '.');
                final number = double.tryParse(text);
                if (number == null || !number.isFinite) return;
                parsed[field.key] = number;
              }
              Navigator.pop(dialogContext, parsed);
            },
            child: Text(_ru ? 'Рассчитать' : 'Calculate'),
          ),
        ],
      ),
    );
    for (final controller in controllers.values) {
      controller.dispose();
    }
    if (values == null || !mounted) return;
    final result = _solver.calculate(id, values);
    if (result == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_ru ? 'Проверьте исходные значения. Деление на ноль недопустимо.' : 'Check input values. Division by zero is not allowed.')));
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(_ru ? 'Результат' : 'Result'),
        content: SelectableText('${formula['formula']}\n\n${result.expression}\n\n${result.result}'),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('OK'))],
      ),
    );
  }

  void _solveEquation() {
    final result = _equations.solve(_equationController.text);
    setState(() => _solution = result);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(_ru ? 'Справочник и решатель' : 'Reference & solver')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                  child: SegmentedButton<String>(
                    segments: [
                      ButtonSegment(value: 'formulas', label: Text(_ru ? 'Формулы' : 'Formulas'), icon: const Icon(Icons.functions)),
                      ButtonSegment(value: 'history', label: Text(_ru ? 'История' : 'History'), icon: const Icon(Icons.history_edu)),
                      ButtonSegment(value: 'solver', label: Text(_ru ? 'Решатель' : 'Solver'), icon: const Icon(Icons.calculate_outlined)),
                    ],
                    selected: {_section},
                    onSelectionChanged: (value) => setState(() => _section = value.first),
                  ),
                ),
                if (_section != 'solver')
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: TextField(
                      controller: _searchController,
                      decoration: InputDecoration(
                        prefixIcon: const Icon(Icons.search),
                        hintText: _ru ? 'Поиск по справочнику' : 'Search reference',
                        suffixIcon: _search.isEmpty ? null : IconButton(onPressed: _searchController.clear, icon: const Icon(Icons.clear)),
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                if (_section == 'formulas')
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: DropdownButtonFormField<String>(
                      initialValue: _category,
                      decoration: InputDecoration(labelText: _ru ? 'Раздел науки' : 'Subject', border: const OutlineInputBorder()),
                      items: [
                        DropdownMenuItem(value: 'all', child: Text(_ru ? 'Все разделы' : 'All subjects')),
                        DropdownMenuItem(value: 'math', child: Text(_ru ? 'Математика' : 'Mathematics')),
                        DropdownMenuItem(value: 'physics', child: Text(_ru ? 'Физика' : 'Physics')),
                        DropdownMenuItem(value: 'chemistry', child: Text(_ru ? 'Химия' : 'Chemistry')),
                      ],
                      onChanged: (value) => setState(() => _category = value ?? 'all'),
                    ),
                  ),
                Expanded(
                  child: _section == 'solver'
                      ? _buildSolver(colors, textTheme)
                      : _section == 'formulas'
                          ? _buildFormulas(colors, textTheme)
                          : _buildHistory(colors, textTheme),
                ),
              ],
            ),
    );
  }

  Widget _buildSolver(ColorScheme colors, TextTheme textTheme) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        Text(_ru ? 'Уравнения без нейросети' : 'Equation solver without AI', style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(_ru ? 'Полиномы до 4-й степени решаются численно с выделением действительных корней. Для функций sin, cos, tan, ln, log, sqrt и степеней выше 4 выполняется приближённый поиск на интервале −100…100.' : 'Polynomials through degree 4 are solved numerically. For functions such as sin, cos, tan, ln, log, sqrt and higher powers, approximate root search is performed on −100…100.'),
        const SizedBox(height: 12),
        TextField(
          controller: _equationController,
          minLines: 1,
          maxLines: 3,
          decoration: InputDecoration(labelText: _ru ? 'Уравнение' : 'Equation', hintText: '2x² - 5x + 2 = 0', border: const OutlineInputBorder()),
          onSubmitted: (_) => _solveEquation(),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(onPressed: _solveEquation, icon: const Icon(Icons.functions), label: Text(_ru ? 'Решить' : 'Solve')),
        if (_solution != null) ...[
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_solution!.formatted, style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                if (_solution!.steps.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  ..._solution!.steps.map((step) => Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('• $step'))),
                ],
              ]),
            ),
          ),
        ],
        const SizedBox(height: 16),
        Text(_ru ? 'Ограничения' : 'Limitations', style: textTheme.titleSmall),
        const SizedBox(height: 4),
        Text(_ru ? 'Решатель не является универсальным символьным CAS. Для уравнений с функциями корни ищутся численно на конечном интервале −100…100: могут быть пропущены кратные корни без смены знака, корни вне интервала и решения с особенностями. Системы уравнений, дифференциальные уравнения и комплексные корни пока не поддерживаются.' : 'This is not a universal symbolic CAS. Equations with functions are searched numerically on the finite interval −100…100; repeated roots without a sign change, roots outside the interval and singularities may be missed. Systems, differential equations and complex roots are not supported yet.'),
        const SizedBox(height: 16),
        Text(_ru ? 'Физические и химические расчёты' : 'Physics and chemistry calculations', style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(_ru ? 'Калькуляторы работают без нейросети: кинематика, динамика, работа и энергия, давление, гидростатика, тепло, электрические цепи, газовые законы, количество вещества, концентрации, pH и выход реакции. Вводите значения и единицы так, как указано в полях.' : 'Built-in calculators work without AI: kinematics, dynamics, work and energy, pressure, hydrostatics, heat, circuits, gas laws, amount of substance, concentration, pH and reaction yield. Follow the units shown in the input fields.'),
      ],
    );
  }

  Widget _buildFormulas(ColorScheme colors, TextTheme textTheme) {
    final items = _filteredFormulas;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        final category = item['category'] as String? ?? '';
        final hasCalculator = item['calculator'] is String;
        return Card(
          margin: const EdgeInsets.only(bottom: 9),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('${item['title']}', style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold))),
                Chip(label: Text(category == 'math' ? 'Математика' : category == 'physics' ? 'Физика' : 'Химия')),
              ]),
              const SizedBox(height: 7),
              SelectableText('${item['formula']}', style: textTheme.titleMedium?.copyWith(color: colors.primary, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text('${item['description']}'),
              if ((item['variables'] as String? ?? '').isNotEmpty) ...[
                const SizedBox(height: 5),
                Text('${item['variables']}', style: textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant)),
              ],
              if (hasCalculator) ...[
                const SizedBox(height: 9),
                Align(alignment: Alignment.centerRight, child: OutlinedButton.icon(onPressed: () => _calculateFormula(item), icon: const Icon(Icons.calculate_outlined), label: Text(_ru ? 'Рассчитать' : 'Calculate'))),
              ],
            ]),
          ),
        );
      },
    );
  }

  Widget _buildHistory(ColorScheme colors, TextTheme textTheme) {
    final items = _filteredHistory;
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 9),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${item['era']} • ${item['date']}', style: textTheme.labelMedium?.copyWith(color: colors.primary, fontWeight: FontWeight.w600)),
              const SizedBox(height: 5),
              Text('${item['title']}', style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text('${item['description']}'),
            ]),
          ),
        );
      },
    );
  }
}
