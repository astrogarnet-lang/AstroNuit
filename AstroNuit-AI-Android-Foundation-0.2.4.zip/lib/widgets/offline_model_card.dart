import 'package:flutter/material.dart';

import '../core/offline_model_manager.dart';

class OfflineModelCard extends StatefulWidget {
  const OfflineModelCard({super.key, required this.isRussian});
  final bool isRussian;

  @override
  State<OfflineModelCard> createState() => _OfflineModelCardState();
}

class _OfflineModelCardState extends State<OfflineModelCard> {
  bool _ready = false;
  bool _busy = false;
  String? _status;

  bool get _ru => widget.isRussian;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final ready = await OfflineModelManager.instance.refreshInstalledState();
    if (!mounted) return;
    setState(() {
      _ready = ready;
      _status = ready
          ? (_ru ? 'Модель уже подготовлена. Отдельный файл не нужен.' : 'The model is already prepared. No separate file is needed.')
          : (_ru ? 'Модель уже входит в APK и будет извлечена автоматически при первом AI-запросе.' : 'The model is already bundled in the APK and will be extracted automatically on the first AI request.');
    });
  }

  Future<void> _prepare() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _status = _ru
          ? 'Подготовка встроенной модели. Первый запуск может занять несколько минут…'
          : 'Preparing the bundled model. The first setup may take a few minutes…';
    });
    try {
      await OfflineModelManager.instance.ensureBundledModelInstalled();
      if (!mounted) return;
      setState(() {
        _ready = true;
        _busy = false;
        _status = _ru
            ? 'Qwen3-0.6B уже входит в APK и подготовлена в памяти приложения. Отдельный файл выбирать не нужно.'
            : 'Qwen3-0.6B is included in the APK and prepared in app storage. No separate file is needed.';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _ready = false;
        _status = error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(Icons.offline_bolt_outlined, color: scheme.primary, size: 26),
              const SizedBox(width: 10),
              Expanded(child: Text(
                _ru ? 'Встроенная офлайн-нейросеть' : 'Built-in offline AI model',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
              )),
              if (_busy)
                const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              else
                Icon(_ready ? Icons.check_circle : Icons.error_outline,
                    color: _ready ? Colors.green : scheme.error),
            ]),
            const SizedBox(height: 9),
            Text(
              _ru
                  ? 'Qwen3-0.6B INT4 включена в установочный APK. Приложение само извлечёт её во внутреннюю память при первом AI-запросе; интернет и ручной импорт не нужны.'
                  : 'Qwen3-0.6B INT4 is included in the installation APK. The app extracts it to private storage on the first AI request; no internet or manual import is needed.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(height: 1.4),
            ),
            const SizedBox(height: 8),
            Text(
              _ru
                  ? 'Для модели требуется около 350 МБ дополнительного места во внутренней памяти после установки. Это текстовая модель, анализ изображений не поддерживается. На телефонах с 2 ГБ ОЗУ генерация может не запуститься из-за ограничений Android; остальные локальные функции останутся доступны.'
                  : 'The model needs about 350 MB of additional internal storage after installation. It is text-only and does not analyse images. On 2 GB RAM phones, generation may fail due to Android memory limits; all other offline features remain available.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: scheme.onSurfaceVariant, height: 1.35),
            ),
            if (_status != null) ...[
              const SizedBox(height: 10),
              Text(_status!, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: _ready ? Colors.green : (_busy ? scheme.onSurfaceVariant : scheme.error))),
            ],
            const SizedBox(height: 13),
            FilledButton.icon(
              onPressed: _busy ? null : (_ready ? null : _prepare),
              icon: _busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : Icon(_ready ? Icons.check_circle_outline : Icons.refresh),
              label: Text(_busy
                  ? (_ru ? 'Подготовка…' : 'Preparing…')
                  : (_ready ? (_ru ? 'Модель готова' : 'Model ready') : (_ru ? 'Подготовить сейчас' : 'Prepare now'))),
            ),
          ],
        ),
      ),
    );
  }
}
