import 'package:flutter/material.dart';

import '../core/offline_model_manager.dart';

class NeuralNetworkSwitch extends StatefulWidget {
  const NeuralNetworkSwitch({super.key, required this.isRussian});

  final bool isRussian;

  @override
  State<NeuralNetworkSwitch> createState() => _NeuralNetworkSwitchState();
}

class _NeuralNetworkSwitchState extends State<NeuralNetworkSwitch> {
  bool _enabled = false;
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _restoreState();
  }

  Future<void> _restoreState() async {
    try {
      final enabled = await OfflineModelManager.instance.isNeuralNetworkEnabled();
      if (!mounted) return;
      setState(() {
        _enabled = enabled;
        _busy = false;
      });
    } catch (error) {
      final manager = OfflineModelManager.instance;
      manager.reportError(error);
      final persistedEnabled = await manager.isNeuralNetworkEnabled();
      if (!mounted) return;
      setState(() {
        _enabled = persistedEnabled;
        _busy = false;
      });
    }
  }

  Future<void> _onChanged(bool value) async {
    if (_busy) return;
    OfflineModelManager.instance.clearError();
    setState(() {
      _busy = true;
    });

    try {
      if (value) {
        await OfflineModelManager.instance.enableNeuralNetwork();
      } else {
        await OfflineModelManager.instance.disableNeuralNetwork();
      }
      if (!mounted) return;
      setState(() {
        _enabled = value;
        _busy = false;
      });
    } catch (error) {
      final manager = OfflineModelManager.instance;
      manager.reportError(error);
      final persistedEnabled = await manager.isNeuralNetworkEnabled();
      if (!mounted) return;
      setState(() {
        _enabled = persistedEnabled;
        _busy = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final manager = OfflineModelManager.instance;
    return ValueListenableBuilder<String?>(
      valueListenable: manager.lastError,
      builder: (context, error, _) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(
              widget.isRussian ? 'Включить нейросеть' : 'Enable neural network',
            ),
            value: _enabled,
            onChanged: _busy ? null : _onChanged,
            secondary: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : null,
          ),
          if (error != null) ...[
            const SizedBox(height: 4),
            SelectableText(
              error,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: scheme.error,
                    height: 1.35,
                  ),
            ),
          ],
        ],
      ),
    );
  }
}
