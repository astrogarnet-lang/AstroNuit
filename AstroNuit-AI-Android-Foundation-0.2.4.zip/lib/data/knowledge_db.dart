import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// On-device knowledge store. No network access is used by this class.
class KnowledgeDb {
  KnowledgeDb._();
  static final KnowledgeDb instance = KnowledgeDb._();
  Database? _db;
  Future<Database>? _opening;
  Future<void>? _seeding;
  static const _constitutionSource = 'builtin:constitution-rf-selected-v1';

  Future<Database> get database async {
    if (_db == null) {
      _opening ??= _openDatabase();
      _db = await _opening!;
      _opening = null;
    }
    await _ensureSeeded();
    return _db!;
  }

  Future<Database> _openDatabase() async {
    final root = await getDatabasesPath();
    return openDatabase(
      p.join(root, 'astronuit_knowledge.db'),
      version: 4,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            source_path TEXT NOT NULL DEFAULT '',
            mime TEXT NOT NULL DEFAULT 'text/plain',
            created_at INTEGER NOT NULL,
            char_count INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE chunks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content TEXT NOT NULL,
            FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('CREATE INDEX idx_chunks_doc ON chunks(document_id)');
        await db.execute('''
          CREATE TABLE chat_messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_chat_messages_created ON chat_messages(created_at)');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''
            CREATE TABLE chat_messages(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              role TEXT NOT NULL,
              content TEXT NOT NULL,
              created_at INTEGER NOT NULL
            )
          ''');
          await db.execute('CREATE INDEX idx_chat_messages_created ON chat_messages(created_at)');
        }
      },
    );
  }

  Future<void> _ensureSeeded() async {
    if (_seeding != null) return _seeding!;
    _seeding = _seedBuiltInKnowledge();
    try {
      await _seeding;
    } finally {
      _seeding = null;
    }
  }

  Future<void> _seedBuiltInKnowledge() async {
    final db = _db;
    if (db == null) return;
    final existing = await db.query('documents', where: 'source_path = ?', whereArgs: [_constitutionSource], limit: 1);
    if (existing.isEmpty) {
      final content = await rootBundle.loadString('assets/knowledge/constitution_rf_selected.md');
      final now = DateTime.now().millisecondsSinceEpoch;
      await db.transaction((txn) async {
        final id = await txn.insert('documents', {
          'title': 'Конституция РФ — стартовая подборка статей',
          'source_path': _constitutionSource,
          'mime': 'text/markdown',
          'created_at': now,
          'char_count': content.length,
        });
        var index = 0;
        for (final chunk in _chunk(content)) {
          await txn.insert('chunks', {
            'document_id': id,
            'chunk_index': index++,
            'content': chunk,
          });
        }
      });
    }

    await _seedJsonKnowledge(
      db,
      assetPath: 'assets/knowledge/science_formulas.json',
      sourcePath: 'builtin:science-formulas-v2',
      title: 'Справочник формул: математика, физика и химия',
      mime: 'application/json',
      toText: (decoded) {
        final formulas = (decoded['formulas'] as List).cast<Map<String, dynamic>>();
        return formulas.map((item) => [
          'Раздел: ${decoded['categories'][item['category']] ?? item['category']}',
          'Название: ${item['title']}',
          'Формула: ${item['formula']}',
          'Описание: ${item['description']}',
          'Обозначения: ${item['variables']}',
          if ((item['example'] as String? ?? '').isNotEmpty) 'Пример: ${item['example']}',
        ].join('\n')).join('\n\n');
      },
    );
    await _seedJsonKnowledge(
      db,
      assetPath: 'assets/knowledge/world_history_timeline.json',
      sourcePath: 'builtin:world-history-timeline-v2',
      title: 'Всемирная история — краткая хронология',
      mime: 'application/json',
      toText: (decoded) {
        final events = (decoded['events'] as List).cast<Map<String, dynamic>>();
        return events.map((item) => 'Эпоха: ${item['era']}\nДата: ${item['date']}\nСобытие: ${item['title']}\nОписание: ${item['description']}').join('\n\n');
      },
    );
  }

  Future<void> _seedJsonKnowledge(
    Database db, {
    required String assetPath,
    required String sourcePath,
    required String title,
    required String mime,
    required String Function(Map<String, dynamic>) toText,
  }) async {
    final existing = await db.query(
      'documents',
      columns: ['id'],
      where: 'source_path = ?',
      whereArgs: [sourcePath],
      limit: 1,
    );
    if (existing.isNotEmpty) return;
    final decoded = jsonDecode(await rootBundle.loadString(assetPath)) as Map<String, dynamic>;
    final content = toText(decoded).trim();
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.transaction((txn) async {
      final id = await txn.insert('documents', {
        'title': title,
        'source_path': sourcePath,
        'mime': mime,
        'created_at': now,
        'char_count': content.length,
      });
      var index = 0;
      for (final chunk in _chunk(content, size: 700, overlap: 100)) {
        await txn.insert('chunks', {
          'document_id': id,
          'chunk_index': index++,
          'content': chunk,
        });
      }
    });
  }

  Future<int> addDocument({
    required String title,
    required String content,
    String sourcePath = '',
    String mime = 'text/plain',
  }) async {
    final db = await database;
    final cleaned = content.trim();
    if (cleaned.isEmpty) throw ArgumentError('Документ пустой.');
    return db.transaction((txn) async {
      final id = await txn.insert('documents', {
        'title': title,
        'source_path': sourcePath,
        'mime': mime,
        'created_at': DateTime.now().millisecondsSinceEpoch,
        'char_count': cleaned.length,
      });
      var i = 0;
      for (final chunk in _chunk(cleaned)) {
        await txn.insert('chunks', {
          'document_id': id,
          'chunk_index': i++,
          'content': chunk,
        });
      }
      return id;
    });
  }

  List<String> _chunk(String text, {int size = 700, int overlap = 120}) {
    final clean = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.isEmpty) return [];
    final out = <String>[];
    var start = 0;
    while (start < clean.length) {
      var end = (start + size).clamp(0, clean.length);
      if (end < clean.length) {
        final boundary = clean.lastIndexOf(' ', end);
        if (boundary > start + size ~/ 2) end = boundary;
      }
      out.add(clean.substring(start, end));
      if (end >= clean.length) break;
      start = (end - overlap).clamp(0, clean.length);
    }
    return out;
  }

  Future<List<Map<String, dynamic>>> listDocuments() async {
    final db = await database;
    return db.query('documents', orderBy: 'created_at DESC');
  }

  Future<void> deleteDocument(int id) async {
    final db = await database;
    final rows = await db.query('documents', columns: ['source_path'], where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty || (rows.first['source_path'] as String? ?? '').startsWith('builtin:')) return;
    await db.delete('chunks', where: 'document_id = ?', whereArgs: [id]);
    await db.delete('documents', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> chunkCount() async {
    final db = await database;
    return Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM chunks')) ?? 0;
  }

  Future<void> saveChatMessage({required String role, required String content}) async {
    final db = await database;
    await db.insert('chat_messages', {
      'role': role,
      'content': content,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> loadChatMessages({int limit = 100}) async {
    final db = await database;
    final rows = await db.query('chat_messages', orderBy: 'created_at DESC, id DESC', limit: limit);
    return rows.reversed.toList(growable: false);
  }

  Future<void> clearChatMessages() async {
    final db = await database;
    await db.delete('chat_messages');
  }

  /// Local lexical retrieval with article-number matching for legal questions.
  Future<List<Map<String, dynamic>>> search(String query, {int limit = 6}) async {
    final db = await database;
    final stop = {
      'это', 'как', 'что', 'или', 'для', 'при', 'the', 'and', 'for', 'with',
      'есть', 'был', 'была', 'были', 'также', 'если', 'когда', 'which',
      'from', 'that', 'this', 'are', 'was', 'were',
    };
    final terms = query.toLowerCase()
        .split(RegExp(r'[^a-zA-Zа-яА-ЯёЁ0-9]+'))
        .where((t) => (t.length > 2 || RegExp(r'^\d{1,3}$').hasMatch(t)) && !stop.contains(t))
        .toSet().toList();
    final article = RegExp(r'стать(?:я|и|е|ю)?\s*(\d{1,3})', caseSensitive: false).firstMatch(query);
    final articleNumber = article?.group(1);
    if (terms.isEmpty && articleNumber == null) {
      return db.rawQuery('''
        SELECT c.content, d.title, c.document_id, d.source_path
        FROM chunks c JOIN documents d ON d.id = c.document_id
        ORDER BY c.id DESC LIMIT ?
      ''', [limit]);
    }
    final effectiveTerms = {...terms, if (articleNumber != null) articleNumber};
    final clauses = <String>[];
    final args = <Object?>[];
    for (final term in effectiveTerms) {
      clauses.add('LOWER(c.content) LIKE ?');
      args.add('%${term.toLowerCase()}%');
    }
    if (articleNumber != null) {
      clauses.add('LOWER(c.content) LIKE ?');
      args.add('%статья $articleNumber%');
    }
    final rows = await db.rawQuery('''
      SELECT c.content, d.title, c.document_id, d.source_path
      FROM chunks c JOIN documents d ON d.id = c.document_id
      WHERE ${clauses.join(' OR ')}
      LIMIT 200
    ''', args);
    final scored = <Map<String, dynamic>>[];
    for (final row in rows) {
      final text = (row['content'] as String).toLowerCase();
      var score = 0;
      for (final term in effectiveTerms) {
        score += RegExp(RegExp.escape(term.toLowerCase())).allMatches(text).length;
        if (term.length >= 6 && text.contains(term.toLowerCase())) score += 2;
      }
      if (articleNumber != null && text.contains('статья $articleNumber')) score += 100;
      if (score > 0) scored.add({...row, 'score': score});
    }
    scored.sort((a, b) => (b['score'] as int).compareTo(a['score'] as int));
    return scored.take(limit).toList();
  }
}
