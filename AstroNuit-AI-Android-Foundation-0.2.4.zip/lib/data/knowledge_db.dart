import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Local knowledge base: documents, chunks, simple term index.
class KnowledgeDb {
  KnowledgeDb._();
  static final KnowledgeDb instance = KnowledgeDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(
      p.join(root, 'astronuit_knowledge.db'),
      version: 1,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE documents(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            source_path TEXT NOT NULL DEFAULT '',
            mime TEXT NOT NULL DEFAULT 'text/plain',
            created_at INTEGER NOT NULL,
            char_count INTEGER NOT NULL DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE chunks(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            document_id INTEGER NOT NULL,
            chunk_index INTEGER NOT NULL,
            content TEXT NOT NULL,
            FOREIGN KEY(document_id) REFERENCES documents(id) ON DELETE CASCADE
          )
        ''');
        await db.execute(
            'CREATE INDEX idx_chunks_doc ON chunks(document_id)');
      },
    );
    return _db!;
  }

  Future<int> addDocument({
    required String title,
    required String content,
    String sourcePath = '',
    String mime = 'text/plain',
  }) async {
    final db = await database;
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = await db.insert('documents', {
      'title': title,
      'source_path': sourcePath,
      'mime': mime,
      'created_at': now,
      'char_count': content.length,
    });
    final chunks = _chunk(content);
    var i = 0;
    for (final c in chunks) {
      await db.insert('chunks', {
        'document_id': id,
        'chunk_index': i++,
        'content': c,
      });
    }
    return id;
  }

  List<String> _chunk(String text, {int size = 700, int overlap = 120}) {
    final clean = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (clean.isEmpty) return [];
    final out = <String>[];
    var i = 0;
    while (i < clean.length) {
      final end = (i + size).clamp(0, clean.length);
      out.add(clean.substring(i, end));
      if (end >= clean.length) break;
      i = end - overlap;
      if (i < 0) i = 0;
    }
    return out;
  }

  Future<List<Map<String, dynamic>>> listDocuments() async {
    final db = await database;
    return db.query('documents', orderBy: 'created_at DESC');
  }

  Future<void> deleteDocument(int id) async {
    final db = await database;
    await db.delete('chunks', where: 'document_id = ?', whereArgs: [id]);
    await db.delete('documents', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> chunkCount() async {
    final db = await database;
    return Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM chunks')) ??
        0;
  }

  /// Ranked keyword retrieval (lightweight RAG).
  Future<List<Map<String, dynamic>>> search(String query, {int limit = 6}) async {
    final db = await database;
    final stop = {
      'это', 'как', 'что', 'или', 'для', 'при', 'the', 'and', 'for', 'with',
      'есть', 'был', 'была', 'были', 'также', 'если', 'когда', 'which',
      'from', 'that', 'this', 'are', 'was', 'were',
    };
    final terms = query
        .toLowerCase()
        .split(RegExp(r'[^a-zA-Zа-яА-ЯёЁ0-9]+'))
        .where((t) => t.length > 2 && !stop.contains(t))
        .toSet()
        .toList();
    if (terms.isEmpty) {
      return db.rawQuery('''
        SELECT c.content, d.title, c.document_id
        FROM chunks c JOIN documents d ON d.id = c.document_id
        ORDER BY c.id DESC LIMIT ?
      ''', [limit]);
    }
    // Fetch candidates containing any term, score in Dart.
    final conditions =
        List<String>.filled(terms.length, 'LOWER(c.content) LIKE ?').join(' OR ');
    final arguments = terms.map((term) => '%${term.toLowerCase()}%').toList();
    final rows = await db.rawQuery('''
      SELECT c.content, d.title, c.document_id
      FROM chunks c JOIN documents d ON d.id = c.document_id
      WHERE $conditions
      LIMIT 120
    ''', arguments);
    final scored = <Map<String, dynamic>>[];
    for (final r in rows) {
      final text = (r['content'] as String).toLowerCase();
      var score = 0;
      for (final t in terms) {
        score += RegExp(RegExp.escape(t)).allMatches(text).length;
        // Bonus for longer / more specific terms.
        if (t.length >= 6 && text.contains(t)) score += 2;
      }
      if (score > 0) {
        scored.add({...r, 'score': score});
      }
    }
    scored.sort((a, b) => (b['score'] as int).compareTo(a['score'] as int));
    return scored.take(limit).toList();
  }
}
