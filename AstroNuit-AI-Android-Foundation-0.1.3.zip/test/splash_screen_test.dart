import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/screens/splash_screen.dart';

void main() {
  testWidgets('splash starts with tagline and finishes after seven seconds',
      (tester) async {
    var completed = false;
    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(onFinished: () => completed = true),
      ),
    );

    // Start the animation ticker at the test's initial timestamp.
    await tester.pump();

    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(completed, isFalse);

    await tester.pump(const Duration(seconds: 2));
    expect(find.text('Welcome to dark'), findsOneWidget);
    expect(completed, isFalse);

    await tester.pump(const Duration(seconds: 5));
    await tester.pump();
    expect(completed, isTrue);
  });
}
