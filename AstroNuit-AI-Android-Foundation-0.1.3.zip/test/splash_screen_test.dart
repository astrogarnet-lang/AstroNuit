import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/screens/splash_screen.dart';

void main() {
  testWidgets('splash follows the complete 14-second liquid transition',
      (tester) async {
    var completed = false;
    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(
          languageCode: 'en',
          onFinished: () => completed = true,
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(find.text('Welcome to the darkness'), findsNothing);
    expect(completed, isFalse);

    // First phrase remains alone for the first four seconds.
    await tester.pump(const Duration(seconds: 4));
    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(find.text('Welcome to the darkness'), findsNothing);
    expect(completed, isFalse);

    // During seconds 4–8 the liquid covers the first phrase. At 8 seconds
    // it is removed from the tree and the new phrase has not appeared yet.
    await tester.pump(const Duration(seconds: 4));
    expect(find.text('Your companion in the dark'), findsNothing);
    expect(find.text('Welcome to the darkness'), findsNothing);
    expect(completed, isFalse);

    // The welcome phrase emerges over two seconds, then remains for four.
    await tester.pump(const Duration(seconds: 2));
    expect(find.text('Welcome to the darkness'), findsOneWidget);
    expect(find.text('Your companion in the dark'), findsNothing);
    expect(completed, isFalse);

    await tester.pump(const Duration(seconds: 4));
    await tester.pump();
    expect(completed, isTrue);
  });

  testWidgets('splash uses Russian text when Russian is selected',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(
          languageCode: 'ru',
          onFinished: () {},
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Твой спутник во тьме'), findsOneWidget);
    expect(find.text('Добро пожаловать во тьму'), findsNothing);

    await tester.pump(const Duration(seconds: 10));
    expect(find.text('Твой спутник во тьме'), findsNothing);
    expect(find.text('Добро пожаловать во тьму'), findsOneWidget);
  });
}
