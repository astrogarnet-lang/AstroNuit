import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/screens/splash_screen.dart';

void main() {
  testWidgets('splash starts with tagline and finishes after seven seconds',
      (tester) async {
    var completed = false;
    final startedAt = tester.binding.clock.now();

    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(onFinished: () => completed = true),
      ),
    );

    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(completed, isFalse);

    await tester.pump(const Duration(seconds: 2));
    expect(find.text('Welcome to dark'), findsOneWidget);
    expect(completed, isFalse);

    // Let the finite animation advance frame-by-frame to its completed state.
    // This avoids relying on a single frame exactly at the 7-second boundary.
    await tester.pumpAndSettle();

    expect(completed, isTrue);
    expect(
      tester.binding.clock.now().difference(startedAt),
      greaterThanOrEqualTo(const Duration(seconds: 7)),
    );
  });
}
