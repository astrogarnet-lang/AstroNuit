import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/widgets/theme_atmosphere.dart';

void main() {
  testWidgets('seasonal atmosphere paints without blocking the page',
      (tester) async {
    for (final kind in [
      ThemeKind.halloween,
      ThemeKind.christmas,
      ThemeKind.cosmos,
    ]) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ThemeAtmosphere(
              themeKind: kind,
              animationsEnabled: false,
              child: const Center(child: Text('page content')),
            ),
          ),
        ),
      );
      expect(find.text('page content'), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('Christmas climate cycle runs without errors', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ThemeAtmosphere(
            themeKind: ThemeKind.christmas,
            animationsEnabled: true,
            child: const Center(child: Text('page content')),
          ),
        ),
      ),
    );

    await tester.pump();
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);

    // Advance through snow → melt → day → night return (17 min cycle).
    await tester.pump(const Duration(minutes: 5));
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(minutes: 5));
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(minutes: 2));
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(minutes: 5));
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
