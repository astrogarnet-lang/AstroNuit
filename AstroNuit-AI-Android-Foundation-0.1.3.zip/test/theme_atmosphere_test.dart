import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/widgets/theme_atmosphere.dart';

void main() {
  testWidgets('seasonal atmosphere paints without blocking the page',
      (tester) async {
    for (final kind in [
      ThemeKind.halloween,
      ThemeKind.christmas,
      ThemeKind.cosmos,
    ]) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: ThemeAtmosphere(
              themeKind: kind,
              animationsEnabled: false,
              child: const Center(child: Text('page content')),
            ),
          ),
        ),
      );
      expect(find.text('page content'), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('Christmas snow accumulates then stickman clears for two minutes',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: ThemeAtmosphere(
            themeKind: ThemeKind.christmas,
            animationsEnabled: true,
            child: const Center(child: Text('page content')),
          ),
        ),
      ),
    );

    await tester.pump();
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);

    await tester.pump(const Duration(minutes: 5));
    expect(tester.takeException(), isNull);

    // 140s clear cycle (10s out + 120s work + 10s in)
    await tester.pump(const Duration(seconds: 140));
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
