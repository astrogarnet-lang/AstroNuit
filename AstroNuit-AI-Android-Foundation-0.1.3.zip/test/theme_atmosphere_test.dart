import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/widgets/theme_atmosphere.dart';

void main() {
  testWidgets('seasonal atmosphere paints without blocking the page',
      (tester) async {
    for (final kind in [
      ThemeKind.halloween,
      ThemeKind.christmas,
      ThemeKind.cosmos,
    ]) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Stack(
              fit: StackFit.expand,
              children: [
                ThemeAtmosphere(
                  themeKind: kind,
                  animationsEnabled: false,
                ),
                const Center(child: Text('page content')),
              ],
            ),
          ),
        ),
      );
      expect(find.text('page content'), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });
  testWidgets('Christmas snowdrift accumulates over ten minutes',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Stack(
            fit: StackFit.expand,
            children: const [
              ThemeAtmosphere(
                themeKind: ThemeKind.christmas,
                animationsEnabled: true,
              ),
              Center(child: Text('page content')),
            ],
          ),
        ),
      ),
    );

    await tester.pump();
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);

    // Halfway through the ten-minute accumulation and at its completion,
    // the animated painter must remain valid and non-interactive.
    await tester.pump(const Duration(minutes: 5));
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(minutes: 5));
    expect(find.text('page content'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

}
