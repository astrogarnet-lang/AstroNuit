import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/widgets/theme_atmosphere.dart';

void main() {
  testWidgets('seasonal atmosphere paints without blocking the page',
      (tester) async {
    for (final kind in [
      ThemeKind.halloween,
      ThemeKind.christmas,
      ThemeKind.cosmos,
    ]) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Stack(
              fit: StackFit.expand,
              children: [
                ThemeAtmosphere(
                  themeKind: kind,
                  animationsEnabled: false,
                ),
                const Center(child: Text('page content')),
              ],
            ),
          ),
        ),
      );
      expect(find.text('page content'), findsOneWidget);
      expect(tester.takeException(), isNull);
    }
  });
}
