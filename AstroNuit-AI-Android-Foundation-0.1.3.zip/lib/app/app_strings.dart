class AppStrings {
  const AppStrings(this.languageCode);

  final String languageCode;
  bool get isRussian => languageCode == 'ru';

  String get appGreeting => isRussian ? 'Привет!' : 'Hello!';
  String get greetingSubtitle => isRussian
      ? 'Чем я могу помочь?'
      : 'How can I help?';
  String get messageHint => isRussian ? 'Задайте вопрос...' : 'Ask a question...';
  String get chat => isRussian ? 'Чат' : 'Chat';
  String get library => isRussian ? 'Библиотека' : 'Library';
  String get agent => isRussian ? 'Агент' : 'Agent';
  String get files => isRussian ? 'Файлы' : 'Files';
  String get settings => isRussian ? 'Настройки' : 'Settings';
  String get scienceLibrary => isRussian ? 'Научная библиотека' : 'Science library';
  String get codeAgent => isRussian ? 'Программный агент' : 'Coding agent';
  String get localCorePending => isRussian
      ? 'Локальное ядро ИИ будет подключено на следующем этапе.'
      : 'The local AI core will be connected in a later stage.';
  String get modulePending => isRussian
      ? 'Этот модуль будет реализован на следующем этапе разработки.'
      : 'This module will be implemented in a later development stage.';
  String get theme => isRussian ? 'Тема оформления' : 'Appearance';
  String get language => isRussian ? 'Язык интерфейса' : 'App language';
  String get systemLanguage => isRussian ? 'Русский' : 'English';
  String get animations => isRussian ? 'Анимации интерфейса' : 'Interface animations';
  String get lightTheme => isRussian ? 'Светлая' : 'Light';
  String get darkTheme => isRussian ? 'Тёмная' : 'Dark';
  String get halloweenTheme => isRussian ? 'Хэллоуинская' : 'Halloween';
  String get christmasTheme => isRussian ? 'Рождественская' : 'Christmas';
  String get cosmosTheme => isRussian ? 'Космическая' : 'Cosmos';
  String get chooseTheme => isRussian ? 'Выберите тему' : 'Choose a theme';
  String get loadingModules => isRussian ? 'Подготовка AstroNuit…' : 'Preparing AstroNuit…';
  String get attach => isRussian ? 'Прикрепить файл' : 'Attach a file';
  String get send => isRussian ? 'Отправить' : 'Send';
  String get foxWorking => isRussian ? 'Изучаю запрос…' : 'Working on your request…';
  String get knowledgeTitle => isRussian ? 'База знаний' : 'Knowledge base';
  String get filesTitle => isRussian ? 'Ваши файлы' : 'Your files';
}
