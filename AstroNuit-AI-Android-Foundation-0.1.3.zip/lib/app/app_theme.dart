import 'package:flutter/material.dart';

enum ThemeKind { light, dark, halloween, christmas, cosmos, pink }

class AstroNuitTheme {
  const AstroNuitTheme._();

  static ThemeData build(ThemeKind kind) {
    final spec = _ThemeSpec.forKind(kind);
    final baseScheme = ColorScheme.fromSeed(
      seedColor: spec.accent,
      brightness: spec.brightness,
      surface: spec.surface,
    );

    // Explicitly set every color used by Material components. This prevents
    // ColorScheme.fromSeed's generated tonal palette from leaking an unrelated
    // hue into buttons, navigation indicators, radio controls or input borders.
    final scheme = baseScheme.copyWith(
      primary: spec.accent,
      onPrimary: spec.onAccent,
      primaryContainer: spec.accentContainer,
      onPrimaryContainer: spec.onAccentContainer,
      secondary: spec.secondary,
      onSecondary: spec.onSecondary,
      secondaryContainer: spec.secondaryContainer,
      onSecondaryContainer: spec.onSecondaryContainer,
      tertiary: spec.tertiary,
      onTertiary: spec.onTertiary,
      surface: spec.surface,
      onSurface: spec.text,
      surfaceContainerHighest: spec.surfaceVariant,
      onSurfaceVariant: spec.secondaryText,
      outline: spec.outline,
      outlineVariant: spec.outline.withValues(alpha: 0.62),
      surfaceTint: Colors.transparent,
      inversePrimary: spec.accent,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: spec.brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: spec.background,
      canvasColor: spec.background,
      dividerColor: spec.outline.withValues(alpha: 0.55),
      splashColor: spec.accent.withValues(alpha: 0.08),
      highlightColor: spec.accent.withValues(alpha: 0.035),
      appBarTheme: AppBarTheme(
        backgroundColor: spec.background,
        foregroundColor: spec.text,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: spec.background,
        indicatorColor: spec.accent.withValues(alpha: 0.12),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          return IconThemeData(
            color: states.contains(WidgetState.selected)
                ? spec.accent
                : spec.secondaryText,
          );
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w600
                : FontWeight.w400,
            color: states.contains(WidgetState.selected)
                ? spec.accent
                : spec.secondaryText,
          );
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: spec.surface,
        hintStyle: TextStyle(color: spec.secondaryText),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 18,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(28),
          borderSide: BorderSide(color: spec.outline),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(28),
          borderSide: BorderSide(color: spec.outline),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(28),
          borderSide: BorderSide(color: spec.accent, width: 1.2),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: spec.secondaryText,
        textColor: spec.text,
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? spec.accent
                : spec.secondaryText),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? spec.onAccent
                : spec.secondaryText),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? spec.accent
                : spec.outline),
      ),
      textTheme: ThemeData(brightness: spec.brightness).textTheme.apply(
            bodyColor: spec.text,
            displayColor: spec.text,
          ),
    );
  }

  static Color accentFor(ThemeKind kind) => _ThemeSpec.forKind(kind).accent;
  static Color backgroundFor(ThemeKind kind) =>
      _ThemeSpec.forKind(kind).background;
}

class _ThemeSpec {
  const _ThemeSpec({
    required this.brightness,
    required this.background,
    required this.surface,
    required this.surfaceVariant,
    required this.text,
    required this.secondaryText,
    required this.accent,
    required this.onAccent,
    required this.accentContainer,
    required this.onAccentContainer,
    required this.secondary,
    required this.onSecondary,
    required this.secondaryContainer,
    required this.onSecondaryContainer,
    required this.tertiary,
    required this.onTertiary,
    required this.outline,
  });

  final Brightness brightness;
  final Color background;
  final Color surface;
  final Color surfaceVariant;
  final Color text;
  final Color secondaryText;
  final Color accent;
  final Color onAccent;
  final Color accentContainer;
  final Color onAccentContainer;
  final Color secondary;
  final Color onSecondary;
  final Color secondaryContainer;
  final Color onSecondaryContainer;
  final Color tertiary;
  final Color onTertiary;
  final Color outline;

  static _ThemeSpec forKind(ThemeKind kind) {
    switch (kind) {
      case ThemeKind.light:
        return const _ThemeSpec(
          brightness: Brightness.light,
          background: Color(0xFFFFFFFF),
          surface: Color(0xFFF7F7F8),
          surfaceVariant: Color(0xFFECEDEF),
          text: Color(0xFF17181B),
          secondaryText: Color(0xFF737780),
          accent: Color(0xFF41464F),
          onAccent: Colors.white,
          accentContainer: Color(0xFFE8E9EC),
          onAccentContainer: Color(0xFF282C33),
          secondary: Color(0xFF626873),
          onSecondary: Colors.white,
          secondaryContainer: Color(0xFFEDEEF0),
          onSecondaryContainer: Color(0xFF30343B),
          tertiary: Color(0xFF737780),
          onTertiary: Colors.white,
          outline: Color(0xFFE0E1E5),
        );
      case ThemeKind.dark:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF090A0C),
          surface: Color(0xFF17191D),
          surfaceVariant: Color(0xFF24262B),
          text: Color(0xFFF2F3F5),
          secondaryText: Color(0xFF9A9DA5),
          accent: Color(0xFFC2C5CC),
          onAccent: Color(0xFF17191D),
          accentContainer: Color(0xFF30333A),
          onAccentContainer: Color(0xFFE6E8EC),
          secondary: Color(0xFFAEB2BA),
          onSecondary: Color(0xFF17191D),
          secondaryContainer: Color(0xFF292C32),
          onSecondaryContainer: Color(0xFFE0E2E7),
          tertiary: Color(0xFF8D929B),
          onTertiary: Color(0xFF101114),
          outline: Color(0xFF30333A),
        );
      case ThemeKind.halloween:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF111012),
          surface: Color(0xFF1D1A1D),
          surfaceVariant: Color(0xFF292326),
          text: Color(0xFFECE8E7),
          secondaryText: Color(0xFFAAA1A0),
          accent: Color(0xFFAD7955),
          onAccent: Color(0xFF17110E),
          accentContainer: Color(0xFF382A22),
          onAccentContainer: Color(0xFFE6C5A8),
          secondary: Color(0xFF94715D),
          onSecondary: Color(0xFF17110E),
          secondaryContainer: Color(0xFF30251F),
          onSecondaryContainer: Color(0xFFE0C7B4),
          tertiary: Color(0xFF82716A),
          onTertiary: Color(0xFF17110E),
          outline: Color(0xFF403638),
        );
      case ThemeKind.christmas:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF101814),
          surface: Color(0xFF19221D),
          surfaceVariant: Color(0xFF26312B),
          text: Color(0xFFE9EEE9),
          secondaryText: Color(0xFFAAB6AC),
          accent: Color(0xFFA2B29F),
          onAccent: Color(0xFF111812),
          accentContainer: Color(0xFF2B3B30),
          onAccentContainer: Color(0xFFD8E3D7),
          secondary: Color(0xFF9B8374),
          onSecondary: Color(0xFF17120F),
          secondaryContainer: Color(0xFF332A25),
          onSecondaryContainer: Color(0xFFE4D5C9),
          tertiary: Color(0xFFC0AE84),
          onTertiary: Color(0xFF201B12),
          outline: Color(0xFF34443A),
        );
      case ThemeKind.cosmos:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF0C0E16),
          surface: Color(0xFF171A25),
          surfaceVariant: Color(0xFF242838),
          text: Color(0xFFEEEFF5),
          secondaryText: Color(0xFFA8AABD),
          accent: Color(0xFFA39CC5),
          onAccent: Color(0xFF151320),
          accentContainer: Color(0xFF302C45),
          onAccentContainer: Color(0xFFE0DCF4),
          secondary: Color(0xFF8D91AE),
          onSecondary: Color(0xFF11131D),
          secondaryContainer: Color(0xFF292D40),
          onSecondaryContainer: Color(0xFFD9DDF1),
          tertiary: Color(0xFF8588A5),
          onTertiary: Color(0xFF10121B),
          outline: Color(0xFF34384D),
        );
      case ThemeKind.pink:
        return const _ThemeSpec(
          brightness: Brightness.light,
          background: Color(0xFFFFF0F5),
          surface: Color(0xFFFFF5F8),
          surfaceVariant: Color(0xFFFCE4EC),
          text: Color(0xFF4A2C3A),
          secondaryText: Color(0xFF9A6B7C),
          accent: Color(0xFFE8A0B5),
          onAccent: Color(0xFF3A1A28),
          accentContainer: Color(0xFFF8D0DC),
          onAccentContainer: Color(0xFF5A2A3A),
          secondary: Color(0xFFD490A8),
          onSecondary: Color(0xFF3A1A28),
          secondaryContainer: Color(0xFFF5D8E4),
          onSecondaryContainer: Color(0xFF5A3040),
          tertiary: Color(0xFFC87898),
          onTertiary: Colors.white,
          outline: Color(0xFFF0C8D4),
        );
    }
  }
}
