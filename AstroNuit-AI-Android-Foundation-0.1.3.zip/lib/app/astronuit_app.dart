import 'package:flutter/material.dart';

import 'app_strings.dart';
import 'app_theme.dart';
import '../screens/app_shell.dart';
import '../screens/splash_screen.dart';

class AstroNuitApp extends StatefulWidget {
  const AstroNuitApp({super.key});

  @override
  State<AstroNuitApp> createState() => _AstroNuitAppState();
}

class _AstroNuitAppState extends State<AstroNuitApp> {
  ThemeKind _themeKind = ThemeKind.light;
  late String _languageCode;
  bool _showSplash = true;
  bool _animationsEnabled = true;

  @override
  void initState() {
    super.initState();
    final systemLanguage = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    _languageCode = systemLanguage == 'ru' ? 'ru' : 'en';
  }

  @override
  Widget build(BuildContext context) {
    final strings = AppStrings(_languageCode);
    return MaterialApp(
      title: 'AstroNuit',
      debugShowCheckedModeBanner: false,
      theme: AstroNuitTheme.build(_themeKind),
      themeAnimationDuration: const Duration(milliseconds: 620),
      themeAnimationCurve: Curves.easeInOutCubic,
      home: _showSplash
          ? SplashScreen(
              languageCode: _languageCode,
              onFinished: () => setState(() => _showSplash = false),
            )
          : AppShell(
              themeKind: _themeKind,
              strings: strings,
              languageCode: _languageCode,
              animationsEnabled: _animationsEnabled,
              onThemeChanged: (value) => setState(() => _themeKind = value),
              onLanguageChanged: (value) => setState(() => _languageCode = value),
              onAnimationsChanged: (value) =>
                  setState(() => _animationsEnabled = value),
            ),
    );
  }
}
