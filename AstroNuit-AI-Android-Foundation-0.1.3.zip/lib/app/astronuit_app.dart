import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_strings.dart';
import 'app_theme.dart';
import '../screens/app_shell.dart';
import '../screens/splash_screen.dart';

class AstroNuitApp extends StatefulWidget {
  const AstroNuitApp({super.key});

  @override
  State<AstroNuitApp> createState() => _AstroNuitAppState();
}

class _AstroNuitAppState extends State<AstroNuitApp> {
  static const _kTheme = 'theme_kind';
  static const _kLang = 'language_code';
  static const _kAnim = 'animations_enabled';

  ThemeKind _themeKind = ThemeKind.light;
  late String _languageCode;
  bool _showSplash = true;
  bool _animationsEnabled = true;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    final systemLanguage =
        WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    _languageCode = systemLanguage == 'ru' ? 'ru' : 'en';
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      final themeIdx = p.getInt(_kTheme);
      final lang = p.getString(_kLang);
      final anim = p.getBool(_kAnim);
      if (!mounted) return;
      setState(() {
        if (themeIdx != null &&
            themeIdx >= 0 &&
            themeIdx < ThemeKind.values.length) {
          _themeKind = ThemeKind.values[themeIdx];
        }
        if (lang == 'ru' || lang == 'en') _languageCode = lang!;
        if (anim != null) _animationsEnabled = anim;
        _ready = true;
      });
    } catch (_) {
      if (mounted) setState(() => _ready = true);
    }
  }

  Future<void> _savePrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt(_kTheme, _themeKind.index);
      await p.setString(_kLang, _languageCode);
      await p.setBool(_kAnim, _animationsEnabled);
    } catch (_) {
      // Persistence is best-effort; UI still works without it.
    }
  }

  void _setTheme(ThemeKind value) {
    setState(() => _themeKind = value);
    _savePrefs();
  }

  void _setLanguage(String value) {
    setState(() => _languageCode = value);
    _savePrefs();
  }

  void _setAnimations(bool value) {
    setState(() => _animationsEnabled = value);
    _savePrefs();
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) {
      return const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          body: Center(child: CircularProgressIndicator()),
        ),
      );
    }

    final strings = AppStrings(_languageCode);
    return MaterialApp(
      title: 'AstroNuit',
      debugShowCheckedModeBanner: false,
      theme: AstroNuitTheme.build(_themeKind),
      themeAnimationDuration: const Duration(milliseconds: 620),
      themeAnimationCurve: Curves.easeInOutCubic,
      home: _showSplash
          ? SplashScreen(
              languageCode: _languageCode,
              onFinished: () => setState(() => _showSplash = false),
            )
          : AppShell(
              themeKind: _themeKind,
              strings: strings,
              languageCode: _languageCode,
              animationsEnabled: _animationsEnabled,
              onThemeChanged: _setTheme,
              onLanguageChanged: _setLanguage,
              onAnimationsChanged: _setAnimations,
            ),
    );
  }
}
