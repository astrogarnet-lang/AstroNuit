import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A single flowing fox line-art animation shown while a search is running.
/// The fox travels across the available display width, then re-enters smoothly.
class FoxSketchAnimation extends StatefulWidget {
  const FoxSketchAnimation({super.key, required this.color});

  final Color color;

  @override
  State<FoxSketchAnimation> createState() => _FoxSketchAnimationState();
}

class _FoxSketchAnimationState extends State<FoxSketchAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 76,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _FoxSketchPainter(
              progress: _controller.value,
              color: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

class _FoxSketchPainter extends CustomPainter {
  const _FoxSketchPainter({
    required this.progress,
    required this.color,
  });

  final double progress;
  final Color color;

  static const double _foxWidth = 164;
  static const double _foxHeight = 66;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final travel = size.width + _foxWidth + 28;
    final x = -_foxWidth + travel * progress;
    final runPhase = progress * math.pi * 2 * 5.5;
    final bob = math.sin(runPhase * 2) * 1.15;
    final y = (size.height - _foxHeight) / 2 + bob;

    final edgeFade = math.min(
      (progress / 0.06).clamp(0.0, 1.0),
      ((1 - progress) / 0.06).clamp(0.0, 1.0),
    );
    final alpha = (0.88 * edgeFade).clamp(0.0, 1.0).toDouble();

    final ink = Paint()
      ..color = color.withValues(alpha: alpha)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.85
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final fineInk = Paint()
      ..color = color.withValues(alpha: alpha * 0.58)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.05
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final softFill = Paint()
      ..color = color.withValues(alpha: alpha * 0.055)
      ..style = PaintingStyle.fill;

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.translate(x, y);

    // A few restrained search glints follow the fox instead of decorative
    // cartoon effects.
    final glintPaint = Paint()
      ..color = color.withValues(alpha: alpha * 0.36)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 3; i++) {
      final pulse = 0.5 + 0.5 * math.sin(runPhase + i * 1.9);
      final gx = -8.0 - i * 11;
      final gy = 24.0 + (i.isEven ? -1 : 1) * pulse * 4;
      canvas.drawLine(Offset(gx - 2, gy), Offset(gx + 2, gy), glintPaint);
      canvas.drawLine(Offset(gx, gy - 2), Offset(gx, gy + 2), glintPaint);
    }

    _drawFox(
      canvas,
      ink,
      fineInk,
      softFill,
      runPhase: runPhase,
    );

    canvas.restore();
  }

  void _drawFox(
    Canvas canvas,
    Paint ink,
    Paint fineInk,
    Paint softFill, {
    required double runPhase,
  }) {
    final stride = math.sin(runPhase) * 5.2;
    final counterStride = math.sin(runPhase + math.pi) * 4.7;
    final tailLift = math.sin(runPhase * 0.5) * 2.1;

    // The legs sit behind the body and remain connected to its silhouette.
    final legs = Path()
      ..moveTo(51, 43)
      ..cubicTo(47, 48, 46 - stride, 55, 43 - stride, 60)
      ..lineTo(39 - stride, 62)
      ..moveTo(64, 45)
      ..cubicTo(67, 50, 67 + counterStride, 56, 68 + counterStride, 61)
      ..lineTo(73 + counterStride, 62)
      ..moveTo(91, 42)
      ..cubicTo(91, 49, 88 - counterStride, 55, 88 - counterStride, 61)
      ..lineTo(93 - counterStride, 62)
      ..moveTo(103, 39)
      ..cubicTo(108, 45, 110 + stride, 53, 113 + stride, 59)
      ..lineTo(118 + stride, 60);
    canvas.drawPath(legs, ink);

    // A full, sweeping tail gives the silhouette the familiar fox character.
    final tail = Path()
      ..moveTo(57, 39)
      ..cubicTo(43, 39 + tailLift, 34, 24 + tailLift, 20, 18 + tailLift)
      ..cubicTo(7, 12 + tailLift, 1, 21 + tailLift, 8, 35 + tailLift)
      ..cubicTo(15, 51 + tailLift, 35, 57, 51, 53)
      ..cubicTo(59, 51, 65, 46, 69, 41)
      ..close();
    canvas.drawPath(tail, softFill);
    canvas.drawPath(tail, ink);

    // The tail tip and inner sweep are one continuous secondary contour.
    final tailTip = Path()
      ..moveTo(8, 35 + tailLift)
      ..cubicTo(17, 37 + tailLift, 24, 44, 34, 49)
      ..cubicTo(40, 52, 46, 52, 52, 49);
    canvas.drawPath(tailTip, fineInk);
    canvas.drawPath(
      Path()
        ..moveTo(19, 24 + tailLift)
        ..cubicTo(28, 25 + tailLift, 37, 34 + tailLift, 47, 40)
        ..quadraticBezierTo(55, 44, 62, 42),
      fineInk,
    );

    // Long athletic torso, drawn as one restrained contour.
    final body = Path()
      ..moveTo(45, 39)
      ..cubicTo(52, 29, 69, 25, 86, 29)
      ..cubicTo(98, 30, 108, 35, 112, 42)
      ..cubicTo(108, 50, 93, 54, 76, 53)
      ..cubicTo(61, 52, 49, 48, 43, 44)
      ..quadraticBezierTo(40, 42, 45, 39)
      ..close();
    canvas.drawPath(body, softFill);
    canvas.drawPath(body, ink);

    // Neck and shoulder flow into a sharp, forward-facing fox profile.
    final chest = Path()
      ..moveTo(91, 29)
      ..cubicTo(91, 36, 98, 43, 108, 46)
      ..cubicTo(113, 47, 119, 44, 122, 39);
    canvas.drawPath(chest, fineInk);

    final head = Path()
      ..moveTo(96, 29)
      ..cubicTo(96, 19, 103, 12, 113, 12)
      ..cubicTo(122, 12, 127, 17, 130, 23)
      ..cubicTo(140, 23, 149, 27, 160, 32)
      ..cubicTo(153, 37, 145, 40, 134, 39)
      ..cubicTo(126, 39, 118, 36, 112, 33)
      ..cubicTo(106, 34, 100, 33, 96, 29)
      ..close();
    canvas.drawPath(head, softFill);
    canvas.drawPath(head, ink);

    // Two narrow ears are integrated into the head outline.
    final ears = Path()
      ..moveTo(103, 17)
      ..lineTo(105, 2)
      ..quadraticBezierTo(113, 7, 119, 17)
      ..moveTo(121, 19)
      ..lineTo(132, 5)
      ..quadraticBezierTo(136, 14, 135, 24);
    canvas.drawPath(ears, ink);
    canvas.drawPath(
      Path()
        ..moveTo(108, 13)
        ..lineTo(107, 7)
        ..moveTo(128, 18)
        ..lineTo(132, 11),
      fineInk,
    );

    // The tapered muzzle, nose and eye keep the animal recognizably a fox.
    canvas.drawPath(
      Path()
        ..moveTo(139, 29)
        ..quadraticBezierTo(151, 27, 160, 32)
        ..quadraticBezierTo(153, 36, 143, 36),
      fineInk,
    );
    canvas.drawCircle(const Offset(159, 32), 1.35, ink);
    canvas.drawCircle(const Offset(130, 25), 1.05, ink);
    canvas.drawPath(
      Path()
        ..moveTo(137, 34)
        ..quadraticBezierTo(141, 37, 146, 35),
      fineInk,
    );

    // Fur strokes are sparse and directional, not childlike zig-zags.
    final fur = Path()
      ..moveTo(73, 31)
      ..quadraticBezierTo(81, 29, 88, 32)
      ..moveTo(79, 49)
      ..quadraticBezierTo(88, 50, 96, 47)
      ..moveTo(113, 39)
      ..quadraticBezierTo(118, 42, 123, 41)
      ..moveTo(28, 33)
      ..quadraticBezierTo(35, 39, 42, 42);
    canvas.drawPath(fur, fineInk);

    // Small ground-contact strokes make the running cycle read at phone size.
    final motion = Paint()
      ..color = ink.color.withValues(alpha: ink.color.a * 0.42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(35, 65), const Offset(121, 65), motion);
  }

  @override
  bool shouldRepaint(covariant _FoxSketchPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.color != color;
}
