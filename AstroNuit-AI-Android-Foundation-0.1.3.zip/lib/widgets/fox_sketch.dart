import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A small, flat 2D fox drawn as a clean pencil/ink sketch.
/// The loop is intentionally lightweight: no raster assets, filters or shaders.
class FoxSketchAnimation extends StatefulWidget {
  const FoxSketchAnimation({super.key, required this.color});

  final Color color;

  @override
  State<FoxSketchAnimation> createState() => _FoxSketchAnimationState();
}

class _FoxSketchAnimationState extends State<FoxSketchAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 58,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _FoxSketchPainter(
              progress: _controller.value,
              color: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

class _FoxSketchPainter extends CustomPainter {
  const _FoxSketchPainter({required this.progress, required this.color});

  final double progress;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    const foxWidth = 100.0;
    double x;
    double y = 5;
    double run = 0;
    double sniff = 0;
    double jump = 0;
    double scale = 1;
    double opacity = 1;

    if (progress < 0.50) {
      final t = Curves.easeInOut.transform(progress / 0.50);
      x = _lerp(-foxWidth, size.width - foxWidth, t);
      run = math.sin(progress / 0.50 * math.pi * 8);
      y += math.sin(progress / 0.50 * math.pi * 8) * 1.8;
    } else if (progress < 0.66) {
      x = size.width - foxWidth;
      final t = (progress - 0.50) / 0.16;
      sniff = Curves.easeInOut.transform(t);
      y += math.sin(t * math.pi * 3) * 0.7;
    } else if (progress < 0.94) {
      final t = Curves.easeInOut.transform((progress - 0.66) / 0.28);
      x = _lerp(size.width - foxWidth, size.width - 66, t);
      jump = math.sin(t * math.pi);
      y += 7 + jump * 17;
      scale = _lerp(1, 0.48, t);
      opacity = 1 - t * 0.72;
    } else {
      x = size.width - 68;
      y = 31;
      scale = 0.42;
      opacity = (1 - (progress - 0.94) / 0.06).clamp(0.0, 1.0).toDouble();
    }

    final ink = Paint()
      ..color = color.withValues(alpha: opacity.clamp(0.0, 1.0).toDouble())
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.55
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final softInk = Paint()
      ..color = ink.color.withValues(alpha: ink.color.a * 0.48)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    canvas.save();
    canvas.translate(x, y);
    canvas.scale(scale);

    // A few tiny paw marks trail behind the fox as it runs.
    if (progress < 0.66) {
      final pawPaint = Paint()
        ..color = ink.color.withValues(alpha: ink.color.a * 0.25)
        ..style = PaintingStyle.fill;
      for (var i = 0; i < 3; i++) {
        final px = 9.0 - i * 9;
        final py = 33.0 + math.sin(progress * math.pi * 16 + i) * 2;
        canvas.drawCircle(Offset(px, py), 1.1, pawPaint);
        canvas.drawCircle(Offset(px + 2.5, py - 2), 0.65, pawPaint);
      }
    }

    _drawFox(canvas, ink, softInk, run: run, sniff: sniff, jump: jump);

    // Small scent strokes make the sniffing phase readable without clutter.
    if (sniff > 0.18 && sniff < 0.94) {
      final scentPaint = Paint()
        ..color = ink.color.withValues(alpha: ink.color.a * 0.60)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.9
        ..strokeCap = StrokeCap.round;
      final pulse = math.sin(sniff * math.pi * 3).abs();
      canvas.drawArc(
        Rect.fromLTWH(94, 12 + sniff * 4, 7 + pulse * 2, 6),
        -1.1,
        0.8,
        false,
        scentPaint,
      );
      canvas.drawArc(
        Rect.fromLTWH(98, 20 + sniff * 3, 5, 4),
        -1.0,
        0.7,
        false,
        scentPaint,
      );
    }
    canvas.restore();
  }

  void _drawFox(
    Canvas canvas,
    Paint ink,
    Paint softInk, {
    required double run,
    required double sniff,
    required double jump,
  }) {
    final headDrop = sniff * 3.8;
    final tailSwing = math.sin(run * 0.7) * 2.2;

    // Bushy tail, with a distinct pointed tip and a short inner sketch line.
    final tail = Path()
      ..moveTo(31, 25)
      ..cubicTo(18, 25 + tailSwing, 15, 9 + tailSwing, 3, 8 + tailSwing)
      ..cubicTo(4, 18, 8, 30, 21, 34)
      ..quadraticBezierTo(28, 35, 34, 29)
      ..close();
    canvas.drawPath(tail, ink);
    final tailMark = Path()
      ..moveTo(7, 12 + tailSwing)
      ..cubicTo(13, 15, 14, 25, 25, 29);
    canvas.drawPath(tailMark, softInk);

    // Compact body, clearly separated from tail and head.
    final body = Path()
      ..moveTo(27, 25)
      ..cubicTo(33, 17, 47, 16, 61, 20)
      ..cubicTo(69, 22, 72, 28, 65, 32)
      ..cubicTo(52, 37, 36, 34, 27, 30)
      ..quadraticBezierTo(23, 28, 27, 25)
      ..close();
    canvas.drawPath(body, ink);
    canvas.drawPath(
      Path()
        ..moveTo(36, 21)
        ..quadraticBezierTo(47, 18, 57, 22),
      softInk,
    );

    // Neck and head form one readable fox profile; the muzzle points forward.
    final head = Path()
      ..moveTo(56, 22)
      ..cubicTo(56, 14, 62, 8 + headDrop, 72, 9 + headDrop)
      ..cubicTo(81, 9 + headDrop, 84, 15 + headDrop, 82, 20 + headDrop)
      ..cubicTo(80, 24 + headDrop, 74, 26 + headDrop, 67, 25 + headDrop)
      ..lineTo(62, 29)
      ..close();
    canvas.drawPath(head, ink);

    // Two pointed ears, with a small inner-ear stroke.
    final ears = Path()
      ..moveTo(61, 14 + headDrop)
      ..lineTo(60, 2 + headDrop)
      ..lineTo(70, 11 + headDrop)
      ..moveTo(73, 10 + headDrop)
      ..lineTo(82, 3 + headDrop)
      ..lineTo(80, 15 + headDrop);
    canvas.drawPath(ears, ink);
    canvas.drawPath(
      Path()
        ..moveTo(63, 10 + headDrop)
        ..lineTo(64, 6 + headDrop)
        ..moveTo(77, 11 + headDrop)
        ..lineTo(79, 7 + headDrop),
      softInk,
    );

    // A short, tapered muzzle and nose distinguish the fox from a cat.
    final muzzle = Path()
      ..moveTo(79, 17 + headDrop)
      ..quadraticBezierTo(88, 15 + headDrop, 98, 20 + headDrop)
      ..lineTo(91, 25 + headDrop)
      ..quadraticBezierTo(84, 25 + headDrop, 79, 22 + headDrop);
    canvas.drawPath(muzzle, ink);
    canvas.drawCircle(Offset(98, 20 + headDrop), 1.25, ink);
    canvas.drawCircle(Offset(76, 15 + headDrop), 1.05, ink);
    canvas.drawPath(
      Path()
        ..moveTo(85, 22 + headDrop)
        ..quadraticBezierTo(89, 24 + headDrop, 93, 22 + headDrop),
      softInk,
    );

    // Four short articulated legs. Their stride changes with the running cycle.
    final stride = run * 4.0;
    final legs = Path()
      ..moveTo(34, 30)
      ..lineTo(29 - stride, 39)
      ..lineTo(24 - stride, 39)
      ..moveTo(43, 32)
      ..lineTo(47 + stride, 39)
      ..lineTo(52 + stride, 39)
      ..moveTo(58, 30)
      ..lineTo(57 - stride, 39)
      ..lineTo(62 - stride, 39)
      ..moveTo(64, 29)
      ..lineTo(70 + stride, 36)
      ..lineTo(74 + stride, 36);
    canvas.drawPath(legs, ink);

    // A tiny body movement during the leap makes the final jump distinct.
    if (jump > 0) {
      canvas.drawPath(
        Path()
          ..moveTo(20, 18)
          ..lineTo(15, 15)
          ..moveTo(22, 22)
          ..lineTo(16, 21),
        softInk,
      );
    }
  }

  double _lerp(double a, double b, double t) => a + (b - a) * t;

  @override
  bool shouldRepaint(covariant _FoxSketchPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.color != color;
}
