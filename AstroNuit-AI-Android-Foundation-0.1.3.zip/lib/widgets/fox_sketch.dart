import 'dart:math' as math;

import 'package:flutter/material.dart';

/// A recognizable, full-body fox sketch that runs across the search strip.
/// The silhouette is deliberately larger and more characterful than the
/// previous thin, abstract outline: pointed ears, tapered muzzle, four legs,
/// and a large pale-tipped brush tail.
class FoxSketchAnimation extends StatefulWidget {
  const FoxSketchAnimation({super.key, required this.color});

  final Color color;

  @override
  State<FoxSketchAnimation> createState() => _FoxSketchAnimationState();
}

class _FoxSketchAnimationState extends State<FoxSketchAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _FoxSketchPainter(
              progress: _controller.value,
              accent: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

class _FoxSketchPainter extends CustomPainter {
  const _FoxSketchPainter({required this.progress, required this.accent});

  final double progress;
  final Color accent;

  static const double _foxWidth = 232;
  static const double _foxHeight = 92;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final travel = size.width + _foxWidth + 32;
    final x = -_foxWidth + travel * progress;
    final phase = progress * math.pi * 2 * 2.65;
    final bob = math.sin(phase * 2) * 1.45;
    final y = (size.height - _foxHeight) / 2 + bob;
    final fade = math.min(
      (progress / 0.045).clamp(0.0, 1.0),
      ((1 - progress) / 0.055).clamp(0.0, 1.0),
    ).toDouble();

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.translate(x, y);
    _drawFox(canvas, phase, fade);
    _drawSearchGlints(canvas, phase, fade);
    canvas.restore();
  }

  void _drawFox(Canvas canvas, double phase, double fade) {
    const orange = Color(0xFFE66A2D);
    const orangeLight = Color(0xFFFFA34E);
    const orangeDark = Color(0xFF9D421F);
    const cream = Color(0xFFFFEBD2);
    const ink = Color(0xFF4A2A22);

    final outline = Paint()
      ..color = ink.withValues(alpha: fade * 0.92)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.45
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final detail = Paint()
      ..color = orangeDark.withValues(alpha: fade * 0.82)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final bodyFill = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          orangeLight.withValues(alpha: fade),
          orange.withValues(alpha: fade),
          orangeDark.withValues(alpha: fade),
        ],
      ).createShader(const Rect.fromLTWH(0, 0, _foxWidth, _foxHeight));
    final creamFill = Paint()..color = cream.withValues(alpha: fade);

    final strideA = math.sin(phase) * 7.2;
    final strideB = math.sin(phase + math.pi) * 6.8;
    final tailSwing = math.sin(phase * 0.5) * 2.6;

    // Far-side legs are placed first so they emerge naturally from the body.
    final farLegs = Paint()
      ..color = orangeDark.withValues(alpha: fade)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.1
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final farLegPaths = [
      Path()
        ..moveTo(78, 57)
        ..cubicTo(85, 63, 91 + strideB, 71, 98 + strideB, 79)
        ..quadraticBezierTo(101 + strideB, 82, 107 + strideB, 80),
      Path()
        ..moveTo(139, 58)
        ..cubicTo(146, 64, 146 + strideB, 71, 151 + strideB, 78)
        ..quadraticBezierTo(155 + strideB, 81, 160 + strideB, 78),
    ];
    for (final path in farLegPaths) {
      canvas.drawPath(path, farLegs);
    }

    // Large brush tail with a visibly pale tip; its curved silhouette is one
    // of the key fox cues and is intentionally much fuller than before.
    final tail = Path()
      ..moveTo(82, 53)
      ..cubicTo(64, 34 + tailSwing, 34, 24 + tailSwing, 15, 34 + tailSwing)
      ..cubicTo(-4, 44 + tailSwing, 7, 67 + tailSwing, 29, 74)
      ..cubicTo(50, 81, 73, 69, 91, 59)
      ..cubicTo(98, 55, 99, 50, 94, 47)
      ..close();
    canvas.drawPath(tail, bodyFill);
    canvas.drawPath(tail, outline);

    final tailTip = Path()
      ..moveTo(16, 35 + tailSwing)
      ..cubicTo(5, 39 + tailSwing, 10, 53 + tailSwing, 19, 61 + tailSwing)
      ..cubicTo(27, 68 + tailSwing, 37, 71, 47, 69)
      ..cubicTo(36, 61, 28, 49, 25, 38 + tailSwing)
      ..cubicTo(22, 36 + tailSwing, 19, 35 + tailSwing, 16, 35 + tailSwing)
      ..close();
    canvas.drawPath(tailTip, creamFill);
    canvas.drawPath(tailTip, outline);

    // Main torso: low, athletic back and fuller chest rather than a round blob.
    final torso = Path()
      ..moveTo(59, 49)
      ..cubicTo(70, 34, 94, 29, 118, 35)
      ..cubicTo(139, 39, 154, 50, 162, 61)
      ..cubicTo(151, 71, 131, 73, 111, 68)
      ..cubicTo(90, 63, 72, 64, 58, 58)
      ..cubicTo(53, 56, 54, 52, 59, 49)
      ..close();
    canvas.drawPath(torso, bodyFill);
    canvas.drawPath(torso, outline);

    // Pale belly and chest flow into the throat, not a separate circular patch.
    final bib = Path()
      ..moveTo(119, 37)
      ..cubicTo(123, 46, 134, 56, 151, 62)
      ..cubicTo(143, 67, 132, 67, 123, 60)
      ..cubicTo(114, 54, 110, 46, 109, 39)
      ..close();
    canvas.drawPath(bib, creamFill);
    canvas.drawPath(bib, detail);

    // Neck rises into the head in one continuous shoulder line.
    final neck = Path()
      ..moveTo(120, 42)
      ..cubicTo(125, 29, 134, 20, 148, 19)
      ..cubicTo(156, 19, 162, 24, 168, 32)
      ..cubicTo(158, 38, 147, 44, 137, 48);
    canvas.drawPath(neck, bodyFill);
    canvas.drawPath(neck, outline);

    // Distinctive pointed ears, narrow face and long tapered muzzle.
    final head = Path()
      ..moveTo(143, 27)
      ..cubicTo(139, 17, 146, 9, 158, 9)
      ..cubicTo(169, 8, 180, 14, 186, 22)
      ..cubicTo(196, 22, 205, 27, 213, 33)
      ..lineTo(229, 39)
      ..cubicTo(220, 46, 207, 45, 195, 41)
      ..cubicTo(184, 38, 175, 35, 164, 36)
      ..cubicTo(154, 37, 147, 34, 143, 27)
      ..close();
    canvas.drawPath(head, bodyFill);
    canvas.drawPath(head, outline);

    final ears = Path()
      ..moveTo(148, 18)
      ..lineTo(151, 0)
      ..quadraticBezierTo(162, 6, 168, 19)
      ..moveTo(169, 19)
      ..lineTo(180, 4)
      ..quadraticBezierTo(187, 12, 188, 25);
    canvas.drawPath(ears, bodyFill);
    canvas.drawPath(ears, outline);

    final innerEars = Path()
      ..moveTo(154, 13)
      ..lineTo(154, 6)
      ..quadraticBezierTo(160, 11, 163, 18)
      ..moveTo(176, 17)
      ..lineTo(180, 10)
      ..quadraticBezierTo(183, 17, 183, 21);
    canvas.drawPath(innerEars, detail);

    final muzzle = Path()
      ..moveTo(190, 31)
      ..cubicTo(205, 27, 218, 32, 229, 39)
      ..cubicTo(221, 45, 208, 45, 197, 41)
      ..cubicTo(191, 39, 187, 36, 184, 35)
      ..close();
    canvas.drawPath(muzzle, creamFill);
    canvas.drawPath(muzzle, detail);

    final nosePaint = Paint()..color = const Color(0xFF241C1B).withValues(alpha: fade);
    canvas.drawCircle(const Offset(228, 39), 2.15, nosePaint);
    canvas.drawCircle(const Offset(184, 25), 1.45, nosePaint);
    canvas.drawPath(
      Path()
        ..moveTo(190, 34)
        ..quadraticBezierTo(196, 37, 202, 36),
      detail,
    );
    canvas.drawPath(
      Path()
        ..moveTo(197, 42)
        ..quadraticBezierTo(204, 47, 211, 43),
      detail,
    );

    // Near-side legs complete the running silhouette with alternating stride.
    final nearLegs = Paint()
      ..color = orange.withValues(alpha: fade)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final nearLegPaths = [
      Path()
        ..moveTo(68, 57)
        ..cubicTo(69, 64, 63 + strideA, 73, 59 + strideA, 81)
        ..quadraticBezierTo(62 + strideA, 84, 69 + strideA, 82),
      Path()
        ..moveTo(132, 59)
        ..cubicTo(138, 64, 139 + strideA, 73, 145 + strideA, 82)
        ..quadraticBezierTo(149 + strideA, 84, 155 + strideA, 81),
    ];
    for (final path in nearLegPaths) {
      canvas.drawPath(path, nearLegs);
      canvas.drawPath(path, outline);
    }

    // Fine contours add fur direction and form without cluttering the sketch.
    final fur = Path()
      ..moveTo(38, 66)
      ..quadraticBezierTo(48, 67, 56, 62)
      ..moveTo(84, 38)
      ..quadraticBezierTo(96, 34, 109, 38)
      ..moveTo(91, 61)
      ..quadraticBezierTo(105, 63, 117, 60)
      ..moveTo(126, 31)
      ..quadraticBezierTo(134, 26, 143, 25)
      ..moveTo(202, 31)
      ..quadraticBezierTo(211, 32, 218, 36);
    canvas.drawPath(fur, detail);

    // A restrained accent glint ties the character back to the app palette.
    final accentStroke = Paint()
      ..color = accent.withValues(alpha: fade * 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      const Rect.fromLTWH(9, 26, 78, 58),
      math.pi * 0.95,
      math.pi * 0.72,
      false,
      accentStroke,
    );
  }

  void _drawSearchGlints(Canvas canvas, double phase, double fade) {
    final paint = Paint()
      ..color = accent.withValues(alpha: fade * 0.46)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 3; i++) {
      final pulse = 0.5 + 0.5 * math.sin(phase + i * 1.8);
      final point = Offset(-8.0 - i * 10, 26 + (i.isEven ? -1 : 1) * pulse * 4);
      canvas.drawLine(point + const Offset(-2, 0), point + const Offset(2, 0), paint);
      canvas.drawLine(point + const Offset(0, -2), point + const Offset(0, 2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _FoxSketchPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.accent != accent;
}
