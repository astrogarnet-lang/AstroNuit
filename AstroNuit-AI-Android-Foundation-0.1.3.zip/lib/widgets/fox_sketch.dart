import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Original line-art fox inspired by classic wildlife silhouettes.
/// Side profile looking slightly upward, large curved brush tail, walking gait.
/// Drawn as clean vector paths — not a reproduction of any specific artwork.
class FoxSketchAnimation extends StatefulWidget {
  const FoxSketchAnimation({super.key, required this.color});

  final Color color;

  @override
  State<FoxSketchAnimation> createState() => _FoxSketchAnimationState();
}

class _FoxSketchAnimationState extends State<FoxSketchAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4800),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 110,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _FoxSketchPainter(
              progress: _controller.value,
              accent: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

class _FoxSketchPainter extends CustomPainter {
  const _FoxSketchPainter({required this.progress, required this.accent});

  final double progress;
  final Color accent;

  static const double _foxWidth = 200.0;
  static const double _foxHeight = 96.0;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final travel = size.width + _foxWidth + 40;
    final x = -_foxWidth + travel * progress;
    final phase = progress * math.pi * 2 * 2.4;
    final bob = math.sin(phase * 2) * 1.6;
    final y = (size.height - _foxHeight) / 2 + bob + 4;
    final fade = math
        .min(
          (progress / 0.05).clamp(0.0, 1.0),
          ((1 - progress) / 0.06).clamp(0.0, 1.0),
        )
        .toDouble();

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.translate(x, y);
    _drawFox(canvas, phase, fade);
    canvas.restore();
  }

  void _drawFox(Canvas canvas, double phase, double fade) {
    final ink = Color.fromRGBO(28, 28, 32, fade);
    final fill = Color.fromRGBO(255, 255, 255, fade * 0.92);

    final outline = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.15
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;

    final solid = Paint()
      ..color = ink
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    final bodyFill = Paint()
      ..color = fill
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    final strideA = math.sin(phase) * 6.5;
    final strideB = math.sin(phase + math.pi) * 6.2;
    final tailSwing = math.sin(phase * 0.55) * 3.2;
    final headTilt = math.sin(phase * 0.35) * 1.1;

    // --- Far (rear) legs first so body covers their tops ---
    final farLegPaint = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Hind far leg
    final hindFar = Path()
      ..moveTo(72, 58)
      ..cubicTo(78, 66, 82 + strideB * 0.4, 74, 88 + strideB, 84)
      ..quadraticBezierTo(91 + strideB, 88, 96 + strideB, 86);
    canvas.drawPath(hindFar, farLegPaint);

    // Front far leg
    final frontFar = Path()
      ..moveTo(128, 56)
      ..cubicTo(134, 64, 136 + strideB * 0.35, 72, 140 + strideB, 84)
      ..quadraticBezierTo(143 + strideB, 88, 148 + strideB, 86);
    canvas.drawPath(frontFar, farLegPaint);

    // --- Large brush tail (signature silhouette element) ---
    final tail = Path()
      ..moveTo(78, 52)
      ..cubicTo(
        58,
        38 + tailSwing,
        28,
        28 + tailSwing * 1.1,
        8,
        36 + tailSwing,
      )
      ..cubicTo(
        -10,
        46 + tailSwing,
        -2,
        72 + tailSwing * 0.6,
        22,
        78,
      )
      ..cubicTo(42, 84, 66, 72, 82, 58)
      ..cubicTo(88, 52, 86, 48, 78, 52)
      ..close();
    canvas.drawPath(tail, bodyFill);
    canvas.drawPath(tail, outline);

    // Soft inner tail flow lines
    final tailFlow = Path()
      ..moveTo(68, 54)
      ..cubicTo(48, 42 + tailSwing * 0.7, 26, 40 + tailSwing, 14, 48 + tailSwing)
      ..moveTo(62, 62)
      ..cubicTo(44, 58 + tailSwing * 0.5, 30, 62 + tailSwing * 0.4, 22, 70);
    final flowPaint = Paint()
      ..color = ink.withValues(alpha: fade * 0.45)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(tailFlow, flowPaint);

    // --- Torso: elegant arched back, fuller chest ---
    final torso = Path()
      ..moveTo(70, 50)
      ..cubicTo(82, 34, 108, 28, 132, 34)
      ..cubicTo(150, 38, 162, 48, 168, 58)
      ..cubicTo(158, 68, 140, 70, 122, 66)
      ..cubicTo(102, 62, 84, 62, 72, 56)
      ..cubicTo(68, 54, 68, 52, 70, 50)
      ..close();
    canvas.drawPath(torso, bodyFill);
    canvas.drawPath(torso, outline);

    // Chest / underbelly curve
    final belly = Path()
      ..moveTo(118, 38)
      ..cubicTo(128, 48, 142, 56, 158, 60)
      ..cubicTo(150, 66, 136, 66, 124, 60)
      ..cubicTo(114, 54, 110, 46, 110, 40);
    canvas.drawPath(belly, flowPaint);

    // --- Neck into head, slightly lifted (looking up) ---
    final neckHead = Path()
      ..moveTo(130, 40)
      ..cubicTo(136, 28 + headTilt, 146, 18 + headTilt, 158, 16 + headTilt)
      ..cubicTo(168, 14 + headTilt, 178, 18 + headTilt, 186, 26 + headTilt)
      ..cubicTo(194, 28 + headTilt, 200, 34 + headTilt, 206, 40 + headTilt)
      ..lineTo(198, 46 + headTilt)
      ..cubicTo(188, 44 + headTilt, 178, 42 + headTilt, 168, 42 + headTilt)
      ..cubicTo(156, 42 + headTilt, 146, 46, 138, 50)
      ..close();
    canvas.drawPath(neckHead, bodyFill);
    canvas.drawPath(neckHead, outline);

    // Pointed ears
    final earL = Path()
      ..moveTo(152, 18 + headTilt)
      ..lineTo(148, 2 + headTilt)
      ..quadraticBezierTo(158, 6 + headTilt, 162, 18 + headTilt)
      ..close();
    final earR = Path()
      ..moveTo(168, 16 + headTilt)
      ..lineTo(172, 0 + headTilt)
      ..quadraticBezierTo(180, 6 + headTilt, 180, 18 + headTilt)
      ..close();
    canvas.drawPath(earL, bodyFill);
    canvas.drawPath(earL, outline);
    canvas.drawPath(earR, bodyFill);
    canvas.drawPath(earR, outline);

    // Inner ear detail
    final innerEar = Paint()
      ..color = ink.withValues(alpha: fade * 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(
      Path()
        ..moveTo(153, 14 + headTilt)
        ..lineTo(152, 6 + headTilt)
        ..quadraticBezierTo(157, 9 + headTilt, 159, 15 + headTilt),
      innerEar,
    );
    canvas.drawPath(
      Path()
        ..moveTo(171, 13 + headTilt)
        ..lineTo(173, 5 + headTilt)
        ..quadraticBezierTo(177, 9 + headTilt, 176, 15 + headTilt),
      innerEar,
    );

    // Eye (simple almond, looking up)
    final eyePaint = Paint()
      ..color = ink
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(174, 28 + headTilt),
        width: 4.2,
        height: 2.6,
      ),
      eyePaint,
    );

    // Nose tip
    canvas.drawCircle(Offset(206, 40 + headTilt), 2.0, solid);

    // Muzzle contour
    canvas.drawPath(
      Path()
        ..moveTo(186, 34 + headTilt)
        ..quadraticBezierTo(196, 36 + headTilt, 204, 40 + headTilt),
      flowPaint,
    );

    // --- Near legs (walking stride) ---
    final nearLegPaint = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    // Hind near leg
    final hindNear = Path()
      ..moveTo(78, 56)
      ..cubicTo(74, 64, 68 + strideA * 0.5, 74, 64 + strideA, 86)
      ..quadraticBezierTo(66 + strideA, 90, 72 + strideA, 88);
    canvas.drawPath(hindNear, nearLegPaint);

    // Front near leg (lifted / stepping)
    final frontNear = Path()
      ..moveTo(138, 54)
      ..cubicTo(142, 62, 146 + strideA * 0.4, 72, 152 + strideA, 84)
      ..quadraticBezierTo(156 + strideA, 88, 160 + strideA, 86);
    canvas.drawPath(frontNear, nearLegPaint);

    // Subtle fur direction lines on body
    final fur = Path()
      ..moveTo(90, 42)
      ..quadraticBezierTo(104, 36, 118, 38)
      ..moveTo(96, 56)
      ..quadraticBezierTo(112, 58, 126, 54)
      ..moveTo(148, 36 + headTilt * 0.5)
      ..quadraticBezierTo(156, 32 + headTilt, 164, 34 + headTilt);
    canvas.drawPath(fur, flowPaint);

    // Soft accent glint tied to app color
    final accentPaint = Paint()
      ..color = accent.withValues(alpha: fade * 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      const Rect.fromLTWH(100, 36, 28, 18),
      -0.6,
      1.4,
      false,
      accentPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _FoxSketchPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.accent != accent;
}
