import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Low-contrast seasonal details painted behind every app page.
/// All effects are vector-based and remain lightweight on older devices.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  AnimationController? _snowAccumulationController;

  bool get _isSeasonal => widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _shouldAnimate => _isSeasonal && widget.animationsEnabled;

  bool get _shouldAccumulateSnow =>
      _shouldAnimate &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  @override
  void initState() {
    super.initState();
    _syncController();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _syncController();
    }
  }

  void _syncController() {
    if (_shouldAnimate) {
      _controller ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 24),
      );
      if (!_controller!.isAnimating) _controller!.repeat();

      if (_shouldAccumulateSnow) {
        _snowAccumulationController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 10),
        );
        if (!_snowAccumulationController!.isAnimating &&
            _snowAccumulationController!.value < 1) {
          _snowAccumulationController!.forward();
        }
      } else {
        _snowAccumulationController?.stop();
      }
    } else {
      _controller?.stop();
      _snowAccumulationController?.stop();
      _controller?.value = 0;
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    _snowAccumulationController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: Listenable.merge([
        _controller ?? const AlwaysStoppedAnimation<double>(0),
        _snowAccumulationController ??
            const AlwaysStoppedAnimation<double>(0),
      ]),
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _ThemeAtmospherePainter(
              kind: widget.themeKind,
              progress: _controller?.value ?? 0,
              topInset: topInset,
              animate: _shouldAnimate,
              snowAccumulation: _snowAccumulationController?.value ?? 0,
            ),
            child: const SizedBox.expand(),
          ),
        ),
      ),
    );
  }
}

class _ThemeAtmospherePainter extends CustomPainter {
  const _ThemeAtmospherePainter({
    required this.kind,
    required this.progress,
    required this.topInset,
    required this.animate,
    required this.snowAccumulation,
  });

  final ThemeKind kind;
  final double progress;
  final double topInset;
  final bool animate;
  final double snowAccumulation;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.light:
      case ThemeKind.dark:
        return;
      case ThemeKind.halloween:
        _paintHalloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _paintChristmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _paintCosmos(canvas, size);
        break;
    }
  }

  void _paintHalloween(Canvas canvas, Size size) {
    final base = const Color(0xFFB27B54);
    final flicker = animate
        ? (0.72 + 0.28 * math.sin(progress * math.pi * 2))
        : 0.78;

    final batPaint = Paint()
      ..color = const Color(0xFF382D38).withValues(alpha: 0.72)
      ..style = PaintingStyle.fill;
    final batDetailPaint = Paint()
      ..color = const Color(0xFFC9A99D).withValues(alpha: 0.42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round;

    // Angular flying-bat silhouettes: pointed wing tips, scalloped lower
    // membranes, long finger bones, and unmistakable pointed ears.
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.12 + i * 0.19) +
          (animate ? math.sin(progress * math.pi * 2 + i * 1.4) * 13 : 0);
      final y = topInset + 84 + (i % 3) * 62.0;
      final wingPhase = animate
          ? progress * math.pi * 2 * 2.2 + i * 1.15
          : math.pi * 0.35;
      _drawBat(
        canvas,
        Offset(x, y),
        batPaint,
        batDetailPaint,
        0.72 + (i % 3) * 0.10,
        wingPhase,
      );
    }

    // Fine threads and three small spiders descending at different rates.
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.78
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < 3; i++) {
      final x = size.width * (0.22 + i * 0.28);
      final travel = 42.0 + i * 20.0;
      final descent = animate
          ? (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i * 1.7)) * travel
          : travel * 0.55;
      final y = topInset + 60 + i * 36.0 + descent;
      canvas.drawLine(Offset(x, topInset + 28), Offset(x, y - 5), webPaint);
      canvas.drawCircle(
        Offset(x, topInset + 28),
        1.5,
        Paint()..color = webPaint.color,
      );
      _drawSpider(
        canvas,
        Offset(x, y),
        0.72 + (i % 2) * 0.10,
        animate ? math.sin(progress * math.pi * 2 + i) : 0,
        webPaint,
      );
    }

    _drawPumpkin(
      canvas,
      Offset(25, size.height * 0.76),
      15,
      base.withValues(alpha: 0.58 * flicker),
      base.withValues(alpha: 0.10 * flicker),
    );
    _drawPumpkin(
      canvas,
      Offset(size.width - 28, size.height * 0.68),
      12,
      base.withValues(alpha: 0.42 * flicker),
      base.withValues(alpha: 0.07 * flicker),
    );
  }

  void _drawBat(
    Canvas canvas,
    Offset center,
    Paint fillPaint,
    Paint detailPaint,
    double scale,
    double wingPhase,
  ) {
    final flap = math.sin(wingPhase) * 5.8;
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);

    // A bat wing is long and angular, with a pointed leading tip and a
    // scalloped trailing edge. The mirrored membranes are articulated from
    // the shoulder rather than drawn as rounded butterfly wings.
    final leftWing = Path()
      ..moveTo(-3, -2)
      ..cubicTo(-12, -9 - flap, -25, -19 - flap, -39, -23 - flap)
      ..lineTo(-34, -10 - flap * 0.55)
      ..cubicTo(-43, -18 - flap * 0.65, -54, -19 - flap * 0.45, -61, -14)
      ..lineTo(-49, -3)
      ..cubicTo(-58, -8, -66, -5, -68, 2)
      ..cubicTo(-64, 12, -53, 16, -43, 12)
      ..cubicTo(-35, 9, -29, 14, -22, 11)
      ..cubicTo(-15, 8, -9, 7, -3, 9)
      ..close();
    canvas.drawPath(leftWing, fillPaint);
    canvas.save();
    canvas.scale(-1, 1);
    canvas.drawPath(leftWing, fillPaint);
    canvas.restore();

    // Narrow body with two pointed ears; these cues make the silhouette read
    // as a bat even when the wings are viewed at small phone-screen size.
    final body = Path()
      ..moveTo(-4, -5)
      ..lineTo(-8, -19)
      ..lineTo(-2, -14)
      ..lineTo(0, -11)
      ..lineTo(3, -14)
      ..lineTo(8, -19)
      ..lineTo(5, -5)
      ..cubicTo(8, 1, 6, 13, 0, 20)
      ..cubicTo(-6, 13, -8, 1, -4, -5)
      ..close();
    canvas.drawPath(body, fillPaint);

    // Wing finger bones radiate from each shoulder to the pointed membrane
    // tips, a key visual distinction from a butterfly silhouette.
    final bones = Path()
      ..moveTo(-3, 0)
      ..lineTo(-39, -22 - flap)
      ..moveTo(-3, 1)
      ..lineTo(-34, -10 - flap * 0.55)
      ..moveTo(-3, 2)
      ..lineTo(-61, -14)
      ..moveTo(-3, 4)
      ..lineTo(-49, -3)
      ..moveTo(-2, 5)
      ..lineTo(-43, 12)
      ..moveTo(3, 0)
      ..lineTo(39, -22 - flap)
      ..moveTo(3, 1)
      ..lineTo(34, -10 - flap * 0.55)
      ..moveTo(3, 2)
      ..lineTo(61, -14)
      ..moveTo(3, 4)
      ..lineTo(49, -3)
      ..moveTo(2, 5)
      ..lineTo(43, 12);
    canvas.drawPath(bones, detailPaint);

    final eyePaint = Paint()
      ..color = const Color(0xFFE6A06E).withValues(alpha: fillPaint.color.a * 0.85)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(const Offset(-2.3, -6), 0.9, eyePaint);
    canvas.drawCircle(const Offset(2.3, -6), 0.9, eyePaint);
    canvas.restore();
  }

  void _drawSpider(
    Canvas canvas,
    Offset center,
    double scale,
    double legMotion,
    Paint webPaint,
  ) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);

    final legs = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.05
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final swing = legMotion * 2.2;
    final legPath = Path()
      ..moveTo(-2, -2)
      ..quadraticBezierTo(-7 - swing, -8, -12 - swing, -7)
      ..lineTo(-15 - swing, -11)
      ..moveTo(-3, 0)
      ..quadraticBezierTo(-10 - swing, -1, -13 - swing, 3)
      ..lineTo(-17 - swing, 4)
      ..moveTo(-3, 2)
      ..quadraticBezierTo(-9 - swing, 6, -11 - swing, 11)
      ..lineTo(-15 - swing, 13)
      ..moveTo(-2, 3)
      ..quadraticBezierTo(-5 - swing, 10, -6 - swing, 14)
      ..lineTo(-9 - swing, 16)
      ..moveTo(2, -2)
      ..quadraticBezierTo(7 + swing, -8, 12 + swing, -7)
      ..lineTo(15 + swing, -11)
      ..moveTo(3, 0)
      ..quadraticBezierTo(10 + swing, -1, 13 + swing, 3)
      ..lineTo(17 + swing, 4)
      ..moveTo(3, 2)
      ..quadraticBezierTo(9 + swing, 6, 11 + swing, 11)
      ..lineTo(15 + swing, 13)
      ..moveTo(2, 3)
      ..quadraticBezierTo(5 + swing, 10, 6 + swing, 14)
      ..lineTo(9 + swing, 16);
    canvas.drawPath(legPath, legs);

    final abdomenPaint = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.35)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 5), width: 9, height: 12),
      abdomenPaint,
    );
    canvas.drawCircle(const Offset(0, -2), 3.2, abdomenPaint);
    canvas.drawLine(const Offset(-1.5, -6), const Offset(-2.5, -8), legs);
    canvas.drawLine(const Offset(1.5, -6), const Offset(2.5, -8), legs);
    canvas.restore();
  }

  void _drawPumpkin(
    Canvas canvas,
    Offset center,
    double radius,
    Color strokeColor,
    Color fillColor,
  ) {
    final outline = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final r = radius;
    final halo = Paint()
      ..color = strokeColor.withValues(alpha: strokeColor.a * 0.24)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 0.75);
    canvas.drawCircle(center, radius * 1.35, halo);
    final shape = Path()
      ..moveTo(center.dx, center.dy - r * 0.72)
      ..cubicTo(center.dx - r * 0.95, center.dy - r * 1.05,
          center.dx - r * 1.15, center.dy - r * 0.25, center.dx - r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx - r * 0.50, center.dy + r * 1.05,
          center.dx + r * 0.50, center.dy + r * 1.05, center.dx + r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx + r * 1.15, center.dy - r * 0.25,
          center.dx + r * 0.95, center.dy - r * 1.05, center.dx, center.dy - r * 0.72)
      ..close();
    canvas.drawPath(shape, fill);
    canvas.drawPath(shape, outline);
    canvas.drawLine(
      Offset(center.dx, center.dy - r * 0.72),
      Offset(center.dx + r * 0.10, center.dy - r * 1.12),
      outline,
    );
    final face = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round;
    final facePath = Path()
      ..moveTo(center.dx - r * 0.47, center.dy - r * 0.02)
      ..lineTo(center.dx - r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx - r * 0.02, center.dy - r * 0.02)
      ..moveTo(center.dx + r * 0.02, center.dy - r * 0.02)
      ..lineTo(center.dx + r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx + r * 0.47, center.dy - r * 0.02)
      ..moveTo(center.dx - r * 0.34, center.dy + r * 0.30)
      ..quadraticBezierTo(center.dx, center.dy + r * 0.57,
          center.dx + r * 0.34, center.dy + r * 0.30);
    canvas.drawPath(facePath, face);
  }

  void _paintChristmas(Canvas canvas, Size size) {
    final wire = Paint()
      ..color = const Color(0xFF829184).withValues(alpha: 0.52)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final garlandY = topInset + 25;
    final garland = Path()
      ..moveTo(0, garlandY)
      ..cubicTo(size.width * 0.22, garlandY + 32, size.width * 0.30,
          garlandY - 5, size.width * 0.50, garlandY + 15)
      ..cubicTo(size.width * 0.70, garlandY + 35, size.width * 0.80,
          garlandY - 3, size.width, garlandY + 16);
    canvas.drawPath(garland, wire);

    const bulbColors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
    ];
    for (var i = 0; i < 13; i++) {
      final x = size.width * i / 12;
      final y = garlandY + 13 + math.sin(i / 12 * math.pi * 2) * 7;
      final pulse = animate
          ? 0.58 + 0.25 * math.sin(progress * math.pi * 2 + i * 0.8)
          : 0.62;
      final bulb = Paint()
        ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), 2.4, bulb);
      if (i % 3 == 0) {
        final halo = Paint()
          ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse * 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
        canvas.drawCircle(Offset(x, y), 5, halo);
      }
    }

    _drawFirTree(canvas, Offset(20, size.height - 22), 27, const Color(0xFF829184).withValues(alpha: 0.20));
    _drawFirTree(canvas, Offset(size.width - 20, size.height - 22), 23, const Color(0xFF829184).withValues(alpha: 0.16));

    // A denser, more varied snowfall: fine drifting flakes plus larger
    // six-armed snow crystals distributed over the full display.
    final snow = Paint()
      ..color = const Color(0xFFDCE6E0).withValues(alpha: 0.48);
    final crystalPaint = Paint()
      ..color = const Color(0xFFE7F0EA).withValues(alpha: 0.52)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.85
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < 104; i++) {
      final x = ((i * 73.0 + 19) % size.width).toDouble();
      final baseY = ((i * 47.0 + 13) % size.height).toDouble();
      final screenPasses = 1 + (i % 3);
      final y = ((baseY +
                  (animate ? progress * size.height * screenPasses : 0)) %
              size.height)
          .toDouble();
      final sway = math.sin(i * 0.7 + progress * math.pi * 2) *
          (1.8 + (i % 4) * 0.55);
      final radius = 0.75 + (i % 5) * 0.28;
      snow.color = const Color(0xFFDCE6E0)
          .withValues(alpha: 0.30 + (i % 4) * 0.055);
      canvas.drawCircle(Offset(x + sway, y), radius, snow);

      if (i % 6 == 0) {
        final crystalRadius = 2.2 + (i % 3) * 0.55;
        final center = Offset(x + sway, y);
        for (var arm = 0; arm < 3; arm++) {
          final angle = arm * math.pi / 3;
          final dx = math.cos(angle) * crystalRadius;
          final dy = math.sin(angle) * crystalRadius;
          canvas.drawLine(
            Offset(center.dx - dx, center.dy - dy),
            Offset(center.dx + dx, center.dy + dy),
            crystalPaint,
          );
        }
      }
    }

    _drawSnowdrift(canvas, size, snowAccumulation);
  }

  void _drawSnowdrift(Canvas canvas, Size size, double growth) {
    if (growth <= 0 || size.isEmpty) return;

    final normalizedGrowth = growth.clamp(0.0, 1.0).toDouble();
    final maxHeight = math.min(size.height * 0.14, 92.0);
    final height = maxHeight * normalizedGrowth;
    if (height < 0.5) return;

    final bottom = size.height;
    final ridge = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(
        size.width * 0.12, bottom - height * 0.66,
        size.width * 0.20, bottom - height * 0.12,
        size.width * 0.36, bottom - height * 0.38,
      )
      ..cubicTo(
        size.width * 0.51, bottom - height * 0.70,
        size.width * 0.59, bottom - height * 0.14,
        size.width * 0.74, bottom - height * 0.42,
      )
      ..cubicTo(
        size.width * 0.86, bottom - height * 0.62,
        size.width * 0.94, bottom - height * 0.20,
        size.width, bottom - height * 0.39,
      )
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();

    final fill = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xDDF4FAF8),
          Color(0xD9E1EBE9),
          Color(0xE8C9D5D7),
        ],
        stops: [0, 0.48, 1],
      ).createShader(
        Rect.fromLTWH(0, bottom - height, size.width, height),
      );
    canvas.drawPath(ridge, fill);

    final ridgeLine = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(
        size.width * 0.12, bottom - height * 0.66,
        size.width * 0.20, bottom - height * 0.12,
        size.width * 0.36, bottom - height * 0.38,
      )
      ..cubicTo(
        size.width * 0.51, bottom - height * 0.70,
        size.width * 0.59, bottom - height * 0.14,
        size.width * 0.74, bottom - height * 0.42,
      )
      ..cubicTo(
        size.width * 0.86, bottom - height * 0.62,
        size.width * 0.94, bottom - height * 0.20,
        size.width, bottom - height * 0.39,
      );
    final ridgePaint = Paint()
      ..color = const Color(0xDDF8FFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(ridgeLine, ridgePaint);

    // Fine grains appear progressively along the ridge as the snow gathers.
    final grainPaint = Paint()..style = PaintingStyle.fill;
    final grainCount = (normalizedGrowth * 44).round();
    for (var i = 0; i < grainCount; i++) {
      final x = ((i * 47.0 + 17) % size.width).toDouble();
      final wave = 0.38 + 0.12 * math.sin(i * 1.13);
      final y = bottom - height * wave - (i % 4) * 1.4;
      grainPaint.color = const Color(0xFFF9FFFF)
          .withValues(alpha: 0.32 + (i % 3) * 0.12);
      canvas.drawCircle(
        Offset(x, y),
        0.55 + (i % 3) * 0.22,
        grainPaint,
      );
    }
  }

  void _drawFirTree(Canvas canvas, Offset bottom, double height, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.27, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx + height * 0.27, bottom.dy - height * 0.52)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawLine(bottom, Offset(bottom.dx, bottom.dy - height * 0.14), paint);
  }

  void _paintCosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = ((i * 67.0 + 11) % size.width).toDouble();
      final y = ((i * 91.0 + 37) % size.height).toDouble();
      final twinkle = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i))
          : 0.23;
      final star = Paint()
        ..color = const Color(0xFFB9B1D7).withValues(alpha: twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.45 : 0.8, star);
    }

    final center = Offset(size.width - 44, topInset + 116);
    final orbitPaint = Paint()
      ..color = const Color(0xFF9991BE).withValues(alpha: 0.20)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 66, height: 23),
      orbitPaint,
    );
    final planetPaint = Paint()
      ..color = const Color(0xFF9C94BD).withValues(alpha: 0.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;
    canvas.drawCircle(center, 9, planetPaint);

    // Multiple staggered meteors replace the single comet: each has a short
    // luminous head and a tapered diagonal trail, with no change to the theme.
    for (var i = 0; i < 8; i++) {
      final phase = (progress * 3.15 + i * 0.173) % 1.0;
      if (!animate || phase >= 0.28) continue;

      final t = phase / 0.28;
      final startX = ((i * 137.0 + 31) % (size.width + 90)) - 45;
      final startY = topInset + 38 + (i * 59.0) % 250;
      final end = Offset(startX + 112 * t, startY + 76 * t);
      final tail = Offset(end.dx - 27, end.dy - 18);
      final fade = (1 - t * 0.58).clamp(0.0, 1.0).toDouble();

      final glow = Paint()
        ..color = const Color(0xFFBFB7EA).withValues(alpha: 0.15 * fade)
        ..strokeWidth = 4.2
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = const Color(0xFFE0DAFF).withValues(alpha: 0.72 * fade)
        ..strokeWidth = 1.15
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, end, glow);
      canvas.drawLine(tail, end, core);
      canvas.drawCircle(
        end,
        1.65,
        Paint()
          ..color = const Color(0xFFF0ECFF).withValues(alpha: 0.72 * fade),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ThemeAtmospherePainter oldDelegate) =>
      oldDelegate.kind != kind ||
      oldDelegate.progress != progress ||
      oldDelegate.topInset != topInset ||
      oldDelegate.animate != animate ||
      oldDelegate.snowAccumulation != snowAccumulation;
}
