import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Low-contrast seasonal details painted behind every app page.
/// The painter uses a small fixed set of vector shapes instead of image assets,
/// keeping APK size and animation cost low on older devices.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;

  bool get _isSeasonal => widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _shouldAnimate => _isSeasonal && widget.animationsEnabled;

  @override
  void initState() {
    super.initState();
    _syncController();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled) {
      _syncController();
    }
  }

  void _syncController() {
    if (_shouldAnimate) {
      _controller ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 24),
      );
      if (!_controller!.isAnimating) _controller!.repeat();
    } else {
      _controller?.stop();
      _controller?.value = 0;
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: _controller ?? const AlwaysStoppedAnimation<double>(0),
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _ThemeAtmospherePainter(
              kind: widget.themeKind,
              progress: _controller?.value ?? 0,
              topInset: topInset,
              animate: _shouldAnimate,
            ),
            child: const SizedBox.expand(),
          ),
        ),
      ),
    );
  }
}

class _ThemeAtmospherePainter extends CustomPainter {
  const _ThemeAtmospherePainter({
    required this.kind,
    required this.progress,
    required this.topInset,
    required this.animate,
  });

  final ThemeKind kind;
  final double progress;
  final double topInset;
  final bool animate;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.light:
      case ThemeKind.dark:
        return;
      case ThemeKind.halloween:
        _paintHalloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _paintChristmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _paintCosmos(canvas, size);
        break;
    }
  }

  void _paintHalloween(Canvas canvas, Size size) {
    final base = const Color(0xFFB27B54);
    final flicker = animate ? (0.72 + 0.28 * math.sin(progress * math.pi * 2)) : 0.78;
    final batPaint = Paint()
      ..color = const Color(0xFF8B7774).withValues(alpha: 0.24)
      ..style = PaintingStyle.fill;

    for (var i = 0; i < 4; i++) {
      final x = ((size.width * (0.13 + i * 0.25) +
              (animate ? math.sin(progress * math.pi * 2 + i) * 18 : 0)) %
          size.width).toDouble();
      final y = topInset + 82 + (i.isEven ? 20.0 : 48.0);
      _drawBat(canvas, Offset(x, y), batPaint, 0.65 + i * 0.08);
    }

    _drawPumpkin(
      canvas,
      Offset(25, size.height * 0.76),
      15,
      base.withValues(alpha: 0.58 * flicker),
      base.withValues(alpha: 0.10 * flicker),
    );
    _drawPumpkin(
      canvas,
      Offset(size.width - 28, size.height * 0.68),
      12,
      base.withValues(alpha: 0.42 * flicker),
      base.withValues(alpha: 0.07 * flicker),
    );
  }

  void _drawBat(Canvas canvas, Offset center, Paint paint, double scale) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);
    final path = Path()
      ..moveTo(-16, 0)
      ..quadraticBezierTo(-23, -12, -28, -8)
      ..quadraticBezierTo(-29, -1, -21, 5)
      ..quadraticBezierTo(-14, 2, -7, 6)
      ..quadraticBezierTo(0, 11, 7, 6)
      ..quadraticBezierTo(14, 2, 21, 5)
      ..quadraticBezierTo(29, -1, 28, -8)
      ..quadraticBezierTo(23, -12, 16, 0)
      ..quadraticBezierTo(7, -5, 0, 1)
      ..quadraticBezierTo(-7, -5, -16, 0)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawCircle(const Offset(-3, 1), 1, paint);
    canvas.drawCircle(const Offset(3, 1), 1, paint);
    canvas.restore();
  }

  void _drawPumpkin(
    Canvas canvas,
    Offset center,
    double radius,
    Color strokeColor,
    Color fillColor,
  ) {
    final outline = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final r = radius;
    final halo = Paint()
      ..color = strokeColor.withValues(alpha: strokeColor.a * 0.24)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 0.75);
    canvas.drawCircle(center, radius * 1.35, halo);
    final shape = Path()
      ..moveTo(center.dx, center.dy - r * 0.72)
      ..cubicTo(center.dx - r * 0.95, center.dy - r * 1.05,
          center.dx - r * 1.15, center.dy - r * 0.25, center.dx - r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx - r * 0.50, center.dy + r * 1.05,
          center.dx + r * 0.50, center.dy + r * 1.05, center.dx + r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx + r * 1.15, center.dy - r * 0.25,
          center.dx + r * 0.95, center.dy - r * 1.05, center.dx, center.dy - r * 0.72)
      ..close();
    canvas.drawPath(shape, fill);
    canvas.drawPath(shape, outline);
    canvas.drawLine(
      Offset(center.dx, center.dy - r * 0.72),
      Offset(center.dx + r * 0.10, center.dy - r * 1.12),
      outline,
    );
    final face = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round;
    final facePath = Path()
      ..moveTo(center.dx - r * 0.47, center.dy - r * 0.02)
      ..lineTo(center.dx - r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx - r * 0.02, center.dy - r * 0.02)
      ..moveTo(center.dx + r * 0.02, center.dy - r * 0.02)
      ..lineTo(center.dx + r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx + r * 0.47, center.dy - r * 0.02)
      ..moveTo(center.dx - r * 0.34, center.dy + r * 0.30)
      ..quadraticBezierTo(center.dx, center.dy + r * 0.57,
          center.dx + r * 0.34, center.dy + r * 0.30);
    canvas.drawPath(facePath, face);
  }

  void _paintChristmas(Canvas canvas, Size size) {
    final wire = Paint()
      ..color = const Color(0xFF829184).withValues(alpha: 0.52)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final garlandY = topInset + 25;
    final garland = Path()
      ..moveTo(0, garlandY)
      ..cubicTo(size.width * 0.22, garlandY + 32, size.width * 0.30,
          garlandY - 5, size.width * 0.50, garlandY + 15)
      ..cubicTo(size.width * 0.70, garlandY + 35, size.width * 0.80,
          garlandY - 3, size.width, garlandY + 16);
    canvas.drawPath(garland, wire);

    const bulbColors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
    ];
    for (var i = 0; i < 13; i++) {
      final x = size.width * i / 12;
      final y = garlandY + 13 + math.sin(i / 12 * math.pi * 2) * 7;
      final pulse = animate
          ? 0.58 + 0.25 * math.sin(progress * math.pi * 2 + i * 0.8)
          : 0.62;
      final bulb = Paint()
        ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), 2.4, bulb);
      if (i % 3 == 0) {
        final halo = Paint()
          ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse * 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
        canvas.drawCircle(Offset(x, y), 5, halo);
      }
    }

    _drawFirTree(canvas, Offset(20, size.height - 22), 27, const Color(0xFF829184).withValues(alpha: 0.20));
    _drawFirTree(canvas, Offset(size.width - 20, size.height - 22), 23, const Color(0xFF829184).withValues(alpha: 0.16));

    final snow = Paint()..color = const Color(0xFFDCE6E0).withValues(alpha: 0.50);
    for (var i = 0; i < 34; i++) {
      final x = ((i * 73.0 + 19) % size.width).toDouble();
      final baseY = ((i * 47.0 + 13) % size.height).toDouble();
      // Each flake travels an integer number of screen heights per loop,
      // so its position does not jump when the 24-second animation repeats.
      final screenPasses = 1 + (i % 2);
      final y = ((baseY +
                  (animate ? progress * size.height * screenPasses : 0)) %
              size.height)
          .toDouble();
      final radius = 0.8 + (i % 3) * 0.38;
      canvas.drawCircle(Offset(x + math.sin(i + progress * 6) * 2, y), radius, snow);
      if (i % 7 == 0) {
        final flakePaint = Paint()
          ..color = const Color(0xFFDCE6E0).withValues(alpha: 0.38)
          ..strokeWidth = 0.8
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(Offset(x - 2, y), Offset(x + 2, y), flakePaint);
        canvas.drawLine(Offset(x, y - 2), Offset(x, y + 2), flakePaint);
      }
    }
  }

  void _drawFirTree(Canvas canvas, Offset bottom, double height, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.27, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx + height * 0.27, bottom.dy - height * 0.52)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawLine(bottom, Offset(bottom.dx, bottom.dy - height * 0.14), paint);
  }

  void _paintCosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = ((i * 67.0 + 11) % size.width).toDouble();
      final y = ((i * 91.0 + 37) % size.height).toDouble();
      final twinkle = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i))
          : 0.23;
      final star = Paint()
        ..color = const Color(0xFFB9B1D7).withValues(alpha: twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.45 : 0.8, star);
    }

    final center = Offset(size.width - 44, topInset + 116);
    final orbitPaint = Paint()
      ..color = const Color(0xFF9991BE).withValues(alpha: 0.20)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 66, height: 23),
      orbitPaint,
    );
    final planetPaint = Paint()
      ..color = const Color(0xFF9C94BD).withValues(alpha: 0.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;
    canvas.drawCircle(center, 9, planetPaint);
    if (animate) {
      final cometX = (progress * (size.width + 80)) - 40;
      final cometY = topInset + 170 + math.sin(progress * math.pi * 2) * 18;
      final cometPaint = Paint()
        ..color = const Color(0xFFC3BCE0).withValues(alpha: 0.42)
        ..strokeWidth = 1.1
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(
        Offset(cometX - 17, cometY - 5),
        Offset(cometX, cometY),
        cometPaint,
      );
      canvas.drawCircle(Offset(cometX, cometY), 1.5, cometPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _ThemeAtmospherePainter oldDelegate) =>
      oldDelegate.kind != kind ||
      oldDelegate.progress != progress ||
      oldDelegate.topInset != topInset ||
      oldDelegate.animate != animate;
}
