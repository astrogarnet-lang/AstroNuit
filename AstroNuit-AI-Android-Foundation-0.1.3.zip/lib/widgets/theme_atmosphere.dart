import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Seasonal atmosphere: decorations behind pages, interactive overlays on top.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
    this.child,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;
  final Widget? child;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  /// Continuous loop for flake motion / flicker (does not drive the day cycle).
  AnimationController? _loop;

  /// Full climate cycle: snow → melt/day → night return.
  /// 5 + 5 + 2 + 5 = 17 minutes.
  AnimationController? _climate;

  AnimationController? _spider;

  int _leftGlow = 0;
  int _rightGlow = 0;
  bool _screamer = false;
  bool _aaaButton = false;
  bool _houseGarlandOn = false;

  bool get _seasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _anim => _seasonal && widget.animationsEnabled;

  bool get _christmas =>
      _anim &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _halloween => _anim && widget.themeKind == ThemeKind.halloween;

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _sync();
      if (widget.themeKind != ThemeKind.halloween) {
        _leftGlow = 0;
        _rightGlow = 0;
        _screamer = false;
        _aaaButton = false;
      }
      if (widget.themeKind != ThemeKind.christmas) {
        _houseGarlandOn = false;
      }
    }
  }

  void _sync() {
    if (_anim) {
      _loop ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 20),
      )..repeat();
      if (!_loop!.isAnimating) _loop!.repeat();

      if (_christmas) {
        _climate ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 17),
        )..repeat();
        if (!_climate!.isAnimating) _climate!.repeat();
      } else {
        _climate?.stop();
      }

      if (_halloween) {
        _spider ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 41),
        )..repeat();
        if (!_spider!.isAnimating) _spider!.repeat();
      } else {
        _spider?.stop();
      }
    } else {
      _loop?.stop();
      _climate?.stop();
      _spider?.stop();
      _loop?.value = 0;
    }
  }

  void _tapLeftPumpkin() {
    if (_screamer) return;
    setState(() => _leftGlow = (_leftGlow + 1) % 6);
  }

  void _tapRightPumpkin() {
    if (_screamer) return;
    setState(() {
      if (_rightGlow < 4) {
        _rightGlow++;
      } else {
        _rightGlow = 4;
        _screamer = true;
        _aaaButton = false;
      }
    });
    if (_screamer) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && _screamer) setState(() => _aaaButton = true);
      });
    }
  }

  void _dismissScreamer() {
    setState(() {
      _screamer = false;
      _aaaButton = false;
      _leftGlow = 0;
      _rightGlow = 0;
    });
  }

  @override
  void dispose() {
    _loop?.dispose();
    _climate?.dispose();
    _spider?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: Listenable.merge([
        _loop ?? const AlwaysStoppedAnimation(0.0),
        _climate ?? const AlwaysStoppedAnimation(0.0),
        _spider ?? const AlwaysStoppedAnimation(0.0),
      ]),
      builder: (context, _) {
        final climate = _climate?.value ?? 0.0;
        final leftPumpkin = Offset(32, size.height * 0.76);
        final rightPumpkin = Offset(size.width - 36, size.height * 0.70);

        return Stack(
          fit: StackFit.expand,
          clipBehavior: Clip.none,
          children: [
            IgnorePointer(
              child: CustomPaint(
                painter: _AtmospherePainter(
                  kind: widget.themeKind,
                  loop: _loop?.value ?? 0,
                  topInset: topInset,
                  animate: _anim,
                  climate: climate,
                  spider: _spider?.value ?? 0,
                  houseGarlandOn: _houseGarlandOn,
                ),
                size: size,
              ),
            ),
            if (widget.child != null) widget.child!,

            // Halloween pumpkins — real widgets for reliable taps.
            if (widget.themeKind == ThemeKind.halloween) ...[
              Positioned(
                left: leftPumpkin.dx - 28,
                top: leftPumpkin.dy - 28,
                width: 56,
                height: 56,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapLeftPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _leftGlow,
                      flicker: _anim
                          ? 0.7 +
                              0.3 *
                                  math.sin((_loop?.value ?? 0) * math.pi * 2)
                          : 0.8,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: rightPumpkin.dx - 24,
                top: rightPumpkin.dy - 24,
                width: 48,
                height: 48,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapRightPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _rightGlow,
                      flicker: _anim
                          ? 0.7 +
                              0.3 *
                                  math.sin(
                                      (_loop?.value ?? 0) * math.pi * 2 + 1)
                          : 0.8,
                    ),
                  ),
                ),
              ),
            ],

            // Christmas: house garland toggle button.
            if (widget.themeKind == ThemeKind.christmas)
              Positioned(
                right: 14,
                bottom: 18,
                child: GestureDetector(
                  onTap: () =>
                      setState(() => _houseGarlandOn = !_houseGarlandOn),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2A332E).withValues(alpha: 0.92),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: _houseGarlandOn
                            ? const Color(0xFFFFD080).withValues(alpha: 0.85)
                            : const Color(0xFF6A7A70).withValues(alpha: 0.6),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          _houseGarlandOn
                              ? Icons.lightbulb
                              : Icons.lightbulb_outline,
                          size: 16,
                          color: _houseGarlandOn
                              ? const Color(0xFFFFD080)
                              : const Color(0xFF9AAA9A),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          _houseGarlandOn ? 'Гирлянда вкл' : 'Гирлянда',
                          style: TextStyle(
                            color: _houseGarlandOn
                                ? const Color(0xFFFFF0D0)
                                : const Color(0xFFC8D0C8),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

            if (_screamer)
              Positioned.fill(
                child: _ScreamerOverlay(
                  showButton: _aaaButton,
                  onDismiss: _dismissScreamer,
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Pumpkin
// ---------------------------------------------------------------------------

class _PumpkinPainter extends CustomPainter {
  _PumpkinPainter({required this.glow, required this.flicker});
  final int glow;
  final double flicker;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide * 0.42;
    final base = const Color(0xFFB27B54);
    final glowA = 0.08 + glow * 0.16;
    if (glow > 0) {
      canvas.drawCircle(
        c,
        r * (1.3 + glow * 0.2),
        Paint()
          ..color = const Color(0xFFFFB040).withValues(alpha: glowA * flicker)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 6.0 + glow * 2),
      );
    }
    final fill = Paint()
      ..color = const Color(0xFFFFB040).withValues(alpha: glowA * flicker)
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = base.withValues(alpha: 0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy, c.dx - r * 0.9,
          c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, stroke);
    canvas.drawLine(
        Offset(c.dx, c.dy - r * 0.7), Offset(c.dx, c.dy - r * 1.05), stroke);
  }

  @override
  bool shouldRepaint(covariant _PumpkinPainter old) =>
      old.glow != glow || old.flicker != flicker;
}

// ---------------------------------------------------------------------------
// Screamer — horror figure with knife
// ---------------------------------------------------------------------------

class _ScreamerOverlay extends StatelessWidget {
  const _ScreamerOverlay({required this.showButton, required this.onDismiss});
  final bool showButton;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.94),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(
              painter: _HorrorFigurePainter(), child: const SizedBox.expand()),
          if (showButton)
            Align(
              alignment: const Alignment(0, 0.62),
              child: _AaaButton(onPressed: onDismiss),
            ),
        ],
      ),
    );
  }
}

class _AaaButton extends StatefulWidget {
  const _AaaButton({required this.onPressed});
  final VoidCallback onPressed;
  @override
  State<_AaaButton> createState() => _AaaButtonState();
}

class _AaaButtonState extends State<_AaaButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          child!,
          SizedBox(
            height: 36,
            width: 160,
            child: CustomPaint(painter: _DripsPainter(_c.value)),
          ),
        ],
      ),
      child: FilledButton(
        onPressed: widget.onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF8B1515),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        ),
        child: const Text('ААААААААААА!',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      ),
    );
  }
}

class _DripsPainter extends CustomPainter {
  _DripsPainter(this.p);
  final double p;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFB01010);
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.15 + i * 0.18);
      final fall = (p + i * 0.17) % 1.0;
      final y = fall * size.height;
      canvas.drawCircle(Offset(x, y), 2.2, paint);
      canvas.drawOval(
        Rect.fromCenter(
            center: Offset(x, y - 4), width: 1.6, height: 6 + fall * 8),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DripsPainter old) => old.p != p;
}

/// Stylized horror silhouette: hooded figure + knife (original vector art).
class _HorrorFigurePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width * 0.5;
    final cy = size.height * 0.42;
    final fill = Paint()..color = const Color(0xFF1A1218);
    final edge = Paint()
      ..color = const Color(0xFF3A2A32)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    // Cloak / body
    final cloak = Path()
      ..moveTo(cx - 70, cy + 160)
      ..lineTo(cx - 55, cy + 20)
      ..quadraticBezierTo(cx - 40, cy - 40, cx - 20, cy - 70)
      ..lineTo(cx + 20, cy - 70)
      ..quadraticBezierTo(cx + 40, cy - 40, cx + 55, cy + 20)
      ..lineTo(cx + 70, cy + 160)
      ..close();
    canvas.drawPath(cloak, fill);
    canvas.drawPath(cloak, edge);

    // Hood
    final hood = Path()
      ..moveTo(cx - 32, cy - 55)
      ..quadraticBezierTo(cx - 38, cy - 110, cx, cy - 125)
      ..quadraticBezierTo(cx + 38, cy - 110, cx + 32, cy - 55)
      ..quadraticBezierTo(cx, cy - 40, cx - 32, cy - 55)
      ..close();
    canvas.drawPath(hood, fill);
    canvas.drawPath(hood, edge);

    // Face void
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy - 78), width: 36, height: 42),
      Paint()..color = const Color(0xFF0A0608),
    );
    // Glowing eyes
    final eye = Paint()..color = const Color(0xFFE8B060).withValues(alpha: 0.9);
    canvas.drawCircle(Offset(cx - 8, cy - 82), 3.2, eye);
    canvas.drawCircle(Offset(cx + 8, cy - 82), 3.2, eye);
    canvas.drawCircle(
      Offset(cx - 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawCircle(
      Offset(cx + 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // Arm raised with knife
    final arm = Path()
      ..moveTo(cx + 30, cy - 20)
      ..lineTo(cx + 75, cy - 90)
      ..lineTo(cx + 85, cy - 82)
      ..lineTo(cx + 42, cy - 5)
      ..close();
    canvas.drawPath(arm, fill);

    // Knife blade
    final blade = Path()
      ..moveTo(cx + 78, cy - 95)
      ..lineTo(cx + 118, cy - 175)
      ..lineTo(cx + 130, cy - 165)
      ..lineTo(cx + 92, cy - 88)
      ..close();
    canvas.drawPath(
      blade,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF0F0F4), Color(0xFF8A8A94)],
        ).createShader(Rect.fromLTWH(cx + 70, cy - 180, 70, 100)),
    );
    // Handle
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
            center: Offset(cx + 82, cy - 80), width: 12, height: 28),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF3A2010),
    );

    // Red slash accents
    final slash = Paint()
      ..color = const Color(0xFFB01010).withValues(alpha: 0.45)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(cx - 90, cy - 40), Offset(cx + 40, cy + 80), slash);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Main painter
// ---------------------------------------------------------------------------

class _AtmospherePainter extends CustomPainter {
  _AtmospherePainter({
    required this.kind,
    required this.loop,
    required this.topInset,
    required this.animate,
    required this.climate,
    required this.spider,
    required this.houseGarlandOn,
  });

  final ThemeKind kind;
  final double loop;
  final double topInset;
  final bool animate;
  final double climate; // 0..1 over 17 min cycle
  final double spider;
  final bool houseGarlandOn;

  // Phase boundaries (must match state constants).
  static const snowEnd = 5.0 / 17.0;
  static const meltEnd = 10.0 / 17.0;
  static const dayEnd = 12.0 / 17.0;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.halloween:
        _halloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _christmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _cosmos(canvas, size);
        break;
      default:
        break;
    }
  }

  // ---- Halloween ----

  void _halloween(Canvas canvas, Size size) {
    final flicker =
        animate ? 0.72 + 0.28 * math.sin(loop * math.pi * 2) : 0.78;
    final moon = Offset(size.width * 0.16, topInset + 88);
    canvas.drawCircle(
      moon,
      58,
      Paint()
        ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.16)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 36),
    );
    canvas.drawCircle(moon, 34,
        Paint()..color = const Color(0xFFEDE6CF).withValues(alpha: 0.92));
    for (final s in [
      (const Offset(-10, 6), 9.0, 0.28),
      (const Offset(12, -8), 7.5, 0.22),
      (const Offset(2, 2), 11.0, 0.12),
    ]) {
      canvas.drawCircle(
        moon + s.$1,
        s.$2,
        Paint()..color = const Color(0xFFC9BFA0).withValues(alpha: s.$3),
      );
    }

    final fieldTop = size.height * 0.62;
    canvas.drawRect(
      Rect.fromLTRB(0, fieldTop, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF3A322C).withValues(alpha: 0.5),
            const Color(0xFF1C1816).withValues(alpha: 0.85),
          ],
        ).createShader(Rect.fromLTRB(0, fieldTop, size.width, size.height)),
    );
    _gothicCastle(
        canvas, Offset(size.width * 0.74, fieldTop), size.width * 0.32, flicker);
    _spiderLife(canvas, size);
  }

  void _spiderLife(Canvas canvas, Size size) {
    if (!animate) return;
    final totalMin = spider * 41.0;
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    final anchor = Offset(size.width - 18, size.height - 28);
    const webRadius = 52.0;

    void orb(double c) {
      for (var i = 0; i < 8; i++) {
        final a = -math.pi * 0.15 - i * (math.pi * 0.85 / 7);
        canvas.drawLine(
          anchor,
          anchor +
              Offset(math.cos(a) * webRadius * c, -math.sin(a).abs() * webRadius * c - 4),
          webPaint,
        );
      }
    }

    void spiderAt(Offset c, double scale, double motion) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.scale(scale);
      final legs = Paint()
        ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..strokeCap = StrokeCap.round;
      final sw = motion * 2.4;
      canvas.drawPath(
        Path()
          ..moveTo(-2, -2)
          ..quadraticBezierTo(-7 - sw, -8, -12 - sw, -7)
          ..moveTo(2, -2)
          ..quadraticBezierTo(7 + sw, -8, 12 + sw, -7),
        legs,
      );
      canvas.drawCircle(const Offset(0, 0), 3.5,
          Paint()..color = const Color(0xFFC7B2A8).withValues(alpha: 0.6));
      canvas.restore();
    }

    if (totalMin < 40 / 60) {
      final t = (totalMin / (40 / 60)).clamp(0.0, 1.0);
      orb(t);
      final a = -math.pi * 0.15 - t * math.pi * 0.85;
      spiderAt(
          anchor +
              Offset(math.cos(a) * webRadius * t,
                  -math.sin(a).abs() * webRadius * t - 4),
          0.8,
          loop * math.pi * 6);
    } else if (totalMin < 11) {
      orb(1);
      spiderAt(anchor + const Offset(-28, -40), 0.85, math.sin(loop * math.pi * 4));
    } else if (totalMin < 12) {
      final t = totalMin - 11;
      orb(1);
      spiderAt(
          Offset.lerp(anchor + const Offset(-28, -40),
              Offset(size.width + 30, size.height - 40), t)!,
          0.8,
          loop * math.pi * 4);
    } else {
      orb(1);
    }
  }

  void _gothicCastle(
      Canvas canvas, Offset base, double width, double flicker) {
    final h = width * 1.05;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF2A2228).withValues(alpha: 0.75);
    final roof = Paint()..color = const Color(0xFF1A151A).withValues(alpha: 0.88);
    final light = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.55 * flicker);
    canvas.drawRect(
        Rect.fromLTRB(
            left + width * 0.28, top + h * 0.36, left + width * 0.72, bottom),
        body);
    canvas.drawPath(
      Path()
        ..moveTo(left + width * 0.26, top + h * 0.36)
        ..lineTo(left + width * 0.5, top + h * 0.06)
        ..lineTo(left + width * 0.74, top + h * 0.36)
        ..close(),
      roof,
    );
    void tower(double cx, double tw, double th) {
      final tLeft = cx - tw / 2;
      final tTop = bottom - th;
      canvas.drawRect(
          Rect.fromLTWH(tLeft, tTop + th * 0.16, tw, th * 0.84), body);
      canvas.drawPath(
        Path()
          ..moveTo(tLeft - 1, tTop + th * 0.2)
          ..lineTo(cx, tTop - th * 0.12)
          ..lineTo(tLeft + tw + 1, tTop + th * 0.2)
          ..close(),
        roof,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: Offset(cx, tTop + th * 0.5),
              width: tw * 0.14,
              height: th * 0.07),
          const Radius.circular(1),
        ),
        light,
      );
    }

    tower(left + width * 0.12, width * 0.15, h * 0.52);
    tower(left + width * 0.28, width * 0.13, h * 0.6);
    tower(left + width * 0.72, width * 0.13, h * 0.6);
    tower(left + width * 0.88, width * 0.15, h * 0.52);
  }

  // ---- Christmas climate cycle ----
  // 0..snowEnd  : night, snow falls, moon center, drift grows
  // snowEnd..meltEnd : no new snow, moon→left, sun↑, melt
  // meltEnd..dayEnd  : day hold, sun center
  // dayEnd..1        : sun→left, moon from right→center, then snow again

  void _christmas(Canvas canvas, Size size) {
    final groundY = size.height * 0.72;
    final c = climate;

    // Sky tint by phase.
    final isNight = c < snowEnd || c >= dayEnd;
    if (isNight) {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0xFF0E1218).withValues(alpha: 0.25),
      );
    } else {
      canvas.drawRect(
        Offset.zero & size,
        Paint()..color = const Color(0xFFC8D8E8).withValues(alpha: 0.12),
      );
    }

    // Ground field (full lower area — snow covers the field).
    canvas.drawRect(
      Rect.fromLTRB(0, groundY * 0.55, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF3A4A40).withValues(alpha: 0.25),
            const Color(0xFF2A332E).withValues(alpha: 0.45),
          ],
        ).createShader(
          Rect.fromLTRB(0, groundY * 0.55, size.width, size.height),
        ),
    );

    // Celestial bodies (smooth positions, no teleport).
    _celestial(canvas, size);

    // Drift amount: builds in snow phase, melts in melt phase, 0 in day.
    final drift = _driftAmount(c);
    _snowdrift(canvas, size, groundY, drift);

    // Two-story house with lit windows + optional garland.
    final houseBase = Offset(size.width * 0.5, groundY);
    _twoStoryHouse(canvas, houseBase, size.width * 0.34);

    // Trees on the field.
    _fir(canvas, Offset(30, groundY), 40,
        const Color(0xFF5E7A62).withValues(alpha: 0.38));
    _fir(canvas, Offset(size.width - 30, groundY), 34,
        const Color(0xFF5E7A62).withValues(alpha: 0.32));
    _fir(canvas, Offset(size.width * 0.22, groundY), 58,
        const Color(0xFF4E6A52).withValues(alpha: 0.42));

    // Continuous snowfall only in snow phase; existing flakes finish falling
    // at the start of melt (handled by not spawning new ones).
    _snowfall(canvas, size, groundY, c, houseBase);
  }

  double _driftAmount(double c) {
    if (c < snowEnd) {
      // Start growing only after flakes would have landed (~8% into phase).
      final t = ((c / snowEnd) - 0.08) / 0.92;
      return t.clamp(0.0, 1.0);
    }
    if (c < meltEnd) {
      final t = (c - snowEnd) / (meltEnd - snowEnd);
      return (1.0 - Curves.easeInOut.transform(t)).clamp(0.0, 1.0);
    }
    return 0.0;
  }

  void _celestial(Canvas canvas, Size size) {
    final c = climate;
    final center = Offset(size.width * 0.5, topInset + 90);
    final leftPark = Offset(-40, topInset + 100);
    final rightPark = Offset(size.width + 40, topInset + 100);
    final sunStart = Offset(size.width * 0.85, size.height * 0.85);

    Offset moonPos;
    Offset? sunPos;
    double moonA = 1;
    double sunA = 0;

    if (c < snowEnd) {
      // Night: moon at center.
      moonPos = center;
      sunPos = null;
    } else if (c < meltEnd) {
      // Melt: moon drifts left, sun rises from bottom-right to center.
      final t = Curves.easeInOut.transform(
          ((c - snowEnd) / (meltEnd - snowEnd)).clamp(0.0, 1.0));
      moonPos = Offset.lerp(center, leftPark, t)!;
      sunPos = Offset.lerp(sunStart, center, t)!;
      moonA = 1 - t * 0.7;
      sunA = 0.3 + t * 0.7;
    } else if (c < dayEnd) {
      // Day hold: sun at center.
      moonPos = leftPark;
      sunPos = center;
      moonA = 0.2;
      sunA = 1;
    } else {
      // Night return: sun goes left, moon from right → center.
      final t = Curves.easeInOut
          .transform(((c - dayEnd) / (1 - dayEnd)).clamp(0.0, 1.0));
      sunPos = Offset.lerp(center, leftPark, t)!;
      moonPos = Offset.lerp(rightPark, center, t)!;
      sunA = 1 - t * 0.85;
      moonA = 0.3 + t * 0.7;
    }

    // Moon
    if (moonA > 0.05) {
      canvas.drawCircle(
        moonPos,
        50,
        Paint()
          ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.12 * moonA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
      );
      canvas.drawCircle(
        moonPos,
        28,
        Paint()
          ..color = const Color(0xFFEDE6CF).withValues(alpha: 0.9 * moonA),
      );
      canvas.drawCircle(
        moonPos + const Offset(-6, 4),
        7,
        Paint()
          ..color = const Color(0xFFC9BFA0).withValues(alpha: 0.22 * moonA),
      );
    }

    // Sun
    if (sunPos != null && sunA > 0.05) {
      canvas.drawCircle(
        sunPos,
        55,
        Paint()
          ..color = const Color(0xFFFFE0A0).withValues(alpha: 0.18 * sunA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30),
      );
      canvas.drawCircle(
        sunPos,
        26,
        Paint()
          ..color = const Color(0xFFFFD060).withValues(alpha: 0.9 * sunA),
      );
    }
  }

  void _snowfall(
      Canvas canvas, Size size, double groundY, double c, Offset houseBase) {
    // Snow intensity: ramps 0→1 during snow phase, then stops spawning.
    final inSnow = c < snowEnd;
    final snowT = inSnow ? (c / snowEnd).clamp(0.0, 1.0) : 1.0;
    final spawnFade = c < snowEnd
        ? 1.0
        : c < snowEnd + 0.02
            ? 1.0
            : 0.0;

    final count = (80 + snowT * 920).round().clamp(80, 1000);
    final speedMul = 1.3 + snowT * 1.4;

    if (!inSnow && spawnFade == 0) return;

    final paint = Paint()..style = PaintingStyle.fill;
    final houseTop = houseBase.dy - size.width * 0.34 * 0.9;
    final houseLeft = houseBase.dx - size.width * 0.34 / 2;
    final houseRight = houseBase.dx + size.width * 0.34 / 2;

    for (var i = 0; i < count; i++) {
      final birth = i / 1000.0;
      if (snowT < birth) continue;

      // Irregular hash so flakes are scattered, not in vertical columns.
      final h1 = _hash(i, 0.123);
      final h2 = _hash(i, 0.791);
      final h3 = _hash(i, 0.457);
      final h4 = _hash(i, 0.913);

      final speed = (1.8 + h1 * 2.4) * speedMul;
      // Unique phase per flake — spreads them across the full height.
      final phase = (loop * speed + h2) % 1.0;
      var y = phase * (size.height + 16) - 8;
      // Fully random X across the width + gentle individual sway.
      var x = h3 * size.width +
          math.sin(loop * math.pi * 2 * (0.4 + h4) + h2 * math.pi * 2) *
              (4.0 + h1 * 8.0);

      // Keep X wrapped inside the screen.
      x = x % size.width;
      if (x < 0) x += size.width;

      // Soft interaction with the roof.
      if (y > houseTop &&
          y < houseTop + 28 &&
          x > houseLeft &&
          x < houseRight) {
        final side = x >= houseBase.dx ? 1.0 : -1.0;
        x += side * (1.2 + h4 * 1.5);
        y += 0.6 + h1;
      }

      final r = 0.55 + h2 * 0.7;
      paint.color = const Color(0xFFDCE6E0)
          .withValues(alpha: (0.22 + h4 * 0.2) * spawnFade);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  /// Deterministic 0..1 hash from index + salt (stable across frames).
  double _hash(int i, double salt) {
    final v = math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
    return v - v.floorToDouble();
  }

  void _snowdrift(Canvas canvas, Size size, double groundY, double level) {
    if (level <= 0.001) return;
    // Cover the field, not only a thin strip at the very bottom.
    final maxH = (size.height - groundY * 0.55) * 0.55;
    final h = maxH * level;
    final bottom = size.height;
    final path = Path()
      ..moveTo(0, bottom - h * 0.35)
      ..cubicTo(size.width * 0.18, bottom - h * 0.75, size.width * 0.32,
          bottom - h * 0.25, size.width * 0.48, bottom - h * 0.6)
      ..cubicTo(size.width * 0.62, bottom - h * 0.9, size.width * 0.78,
          bottom - h * 0.3, size.width, bottom - h * 0.45)
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xEEF4FAF8), Color(0xE8C9D5D7)],
        ).createShader(Rect.fromLTWH(0, bottom - h, size.width, h)),
    );
  }

  void _twoStoryHouse(Canvas canvas, Offset base, double w) {
    final h = w * 0.95;
    final left = base.dx - w / 2;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF4A3A2A).withValues(alpha: 0.92);
    final roofP = Paint()..color = const Color(0xFF3A2A22).withValues(alpha: 0.95);
    final trim = Paint()..color = const Color(0xFF2A1E18);

    // Ground floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(left, top + h * 0.48, left + w, bottom),
        const Radius.circular(2),
      ),
      body,
    );
    // Second floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(
            left + w * 0.06, top + h * 0.22, left + w * 0.94, top + h * 0.5),
        const Radius.circular(2),
      ),
      body,
    );
    // Roof
    canvas.drawPath(
      Path()
        ..moveTo(left - 8, top + h * 0.26)
        ..lineTo(base.dx, top)
        ..lineTo(left + w + 8, top + h * 0.26)
        ..close(),
      roofP,
    );
    // Chimney + smoke
    final ch = Rect.fromLTWH(left + w * 0.72, top + h * 0.02, w * 0.1, h * 0.22);
    canvas.drawRect(ch, trim);
    if (animate) {
      for (var i = 0; i < 5; i++) {
        final sy = ch.top - 6 - i * 9 - (loop * 28 + i * 4) % 18;
        final sx = ch.center.dx + math.sin(loop * math.pi * 2 + i) * 3.5;
        canvas.drawCircle(
          Offset(sx, sy),
          3 + i * 0.7,
          Paint()
            ..color = const Color(0xFFB0B0B0).withValues(alpha: 0.18 - i * 0.025),
        );
      }
    }

    // Windows — all lit, illuminate the field.
    final winLight = Paint()
      ..color = const Color(0xFFFFD080).withValues(alpha: 0.88);
    final glow = Paint()
      ..color = const Color(0xFFFFD080).withValues(alpha: 0.14)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    void window(Offset c, double ww, double hh) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: c, width: ww, height: hh),
          const Radius.circular(1.5),
        ),
        winLight,
      );
      canvas.drawCircle(c + Offset(0, hh), ww * 1.6, glow);
    }

    // 2nd floor windows
    window(Offset(base.dx - w * 0.22, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.05, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.28, top + h * 0.34), w * 0.1, h * 0.1);
    // 1st floor windows
    window(Offset(base.dx - w * 0.28, top + h * 0.68), w * 0.13, h * 0.12);
    window(Offset(base.dx + w * 0.22, top + h * 0.68), w * 0.13, h * 0.12);

    // Field illumination pool
    canvas.drawCircle(
      Offset(base.dx, bottom + 12),
      w * 0.7,
      Paint()
        ..color = const Color(0xFFFFD080).withValues(alpha: 0.1)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
    );

    // Door (static)
    final door = Rect.fromLTWH(
        base.dx - w * 0.06, bottom - h * 0.28, w * 0.12, h * 0.28);
    canvas.drawRect(door, Paint()..color = const Color(0xFF2A1A12));
    canvas.drawCircle(Offset(door.right - 4, door.center.dy), 1.4,
        Paint()..color = const Color(0xFFC9A86A));

    // House garland (eaves) — bright but soft.
    if (houseGarlandOn) {
      final bulbs = <Offset>[
        Offset(left + w * 0.1, top + h * 0.24),
        Offset(left + w * 0.25, top + h * 0.2),
        Offset(left + w * 0.4, top + h * 0.18),
        Offset(left + w * 0.55, top + h * 0.18),
        Offset(left + w * 0.7, top + h * 0.2),
        Offset(left + w * 0.85, top + h * 0.24),
        Offset(left + w * 0.15, top + h * 0.48),
        Offset(left + w * 0.5, top + h * 0.48),
        Offset(left + w * 0.85, top + h * 0.48),
      ];
      final wire = Paint()
        ..color = const Color(0xFF8A9088).withValues(alpha: 0.5)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke;
      for (var i = 0; i < 5; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }
      const cols = [
        Color(0xFFFFE0A0),
        Color(0xFFFFB0B0),
        Color(0xFFB0E0FF),
        Color(0xFFC0FFC0),
        Color(0xFFE0C0FF),
      ];
      for (var i = 0; i < bulbs.length; i++) {
        final pulse = animate
            ? 0.7 +
                0.3 *
                    (0.5 +
                        0.5 *
                            math.sin(loop * math.pi * 2 * (1.2 + i * 0.15) + i))
            : 0.85;
        final col = cols[i % cols.length];
        // Soft halo — bright but not harsh.
        canvas.drawCircle(
          bulbs[i],
          7,
          Paint()
            ..color = col.withValues(alpha: 0.22 * pulse)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5),
        );
        canvas.drawCircle(
          bulbs[i],
          2.8,
          Paint()..color = col.withValues(alpha: 0.85 * pulse),
        );
      }
    }
  }

  void _fir(Canvas canvas, Offset bottom, double height, Color color) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(
      Path()
        ..moveTo(bottom.dx, bottom.dy - height)
        ..lineTo(bottom.dx - height * 0.28, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.12)
        ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.12)
        ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx + height * 0.28, bottom.dy - height * 0.5)
        ..close(),
      p,
    );
    canvas.drawLine(bottom, Offset(bottom.dx, bottom.dy - height * 0.12), p);
  }

  void _cosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = (i * 67.0 + 11) % size.width;
      final y = (i * 91.0 + 37) % size.height;
      final tw = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 + i))
          : 0.23;
      canvas.drawCircle(
        Offset(x, y),
        i % 9 == 0 ? 1.4 : 0.8,
        Paint()..color = const Color(0xFFB9B1D7).withValues(alpha: tw),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _AtmospherePainter old) =>
      old.loop != loop ||
      old.climate != climate ||
      old.spider != spider ||
      old.houseGarlandOn != houseGarlandOn ||
      old.kind != kind;
}
