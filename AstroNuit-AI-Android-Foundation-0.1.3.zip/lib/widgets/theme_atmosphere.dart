import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Low-contrast seasonal details painted behind every app page.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  AnimationController? _snowAccumulationController;
  AnimationController? _snowClearController;
  AnimationController? _flockController;

  bool get _isSeasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _shouldAnimate => _isSeasonal && widget.animationsEnabled;

  bool get _shouldAccumulateSnow =>
      _shouldAnimate &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _shouldFlock =>
      _shouldAnimate && widget.themeKind == ThemeKind.halloween;

  @override
  void initState() {
    super.initState();
    _syncController();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _syncController();
    }
  }

  void _syncController() {
    if (_shouldAnimate) {
      _controller ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 24),
      );
      if (!_controller!.isAnimating) _controller!.repeat();

      if (_shouldAccumulateSnow) {
        _snowAccumulationController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 5),
        );
        _snowClearController ??= AnimationController(
          vsync: this,
          duration: const Duration(seconds: 30),
        );
        _snowAccumulationController!.removeStatusListener(_onSnowFull);
        _snowAccumulationController!.addStatusListener(_onSnowFull);
        if (!_snowAccumulationController!.isAnimating &&
            _snowAccumulationController!.value < 1 &&
            (_snowClearController?.value ?? 0) == 0) {
          _snowAccumulationController!.forward();
        }
      } else {
        _snowAccumulationController?.stop();
        _snowClearController?.stop();
      }

      if (_shouldFlock) {
        // One flock wave every 5 minutes after launch.
        _flockController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 5),
        );
        if (!_flockController!.isAnimating) _flockController!.repeat();
      } else {
        _flockController?.stop();
      }
    } else {
      _controller?.stop();
      _snowAccumulationController?.stop();
      _snowClearController?.stop();
      _flockController?.stop();
      _controller?.value = 0;
    }
  }

  void _onSnowFull(AnimationStatus status) {
    if (status == AnimationStatus.completed && mounted) {
      _snowClearController?.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _snowAccumulationController?.removeStatusListener(_onSnowFull);
    _controller?.dispose();
    _snowAccumulationController?.dispose();
    _snowClearController?.dispose();
    _flockController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: Listenable.merge([
          _controller ?? const AlwaysStoppedAnimation<double>(0),
          _snowAccumulationController ??
              const AlwaysStoppedAnimation<double>(0),
          _snowClearController ?? const AlwaysStoppedAnimation<double>(0),
          _flockController ?? const AlwaysStoppedAnimation<double>(0),
        ]),
        builder: (context, child) {
          // Effective snow height: accumulates 0→1 over 5 min, then clears 1→0 over 30 s.
          final accum = _snowAccumulationController?.value ?? 0;
          final clear = _snowClearController?.value ?? 0;
          final snowLevel = clear > 0 ? (1.0 - clear).clamp(0.0, 1.0) : accum;

          return RepaintBoundary(
            child: CustomPaint(
              painter: _ThemeAtmospherePainter(
                kind: widget.themeKind,
                progress: _controller?.value ?? 0,
                topInset: topInset,
                animate: _shouldAnimate,
                snowAccumulation: snowLevel,
                snowClearProgress: clear,
                flockProgress: _flockController?.value ?? 0,
              ),
              child: const SizedBox.expand(),
            ),
          );
        },
      ),
    );
  }
}

class _ThemeAtmospherePainter extends CustomPainter {
  const _ThemeAtmospherePainter({
    required this.kind,
    required this.progress,
    required this.topInset,
    required this.animate,
    required this.snowAccumulation,
    required this.snowClearProgress,
    required this.flockProgress,
  });

  final ThemeKind kind;
  final double progress;
  final double topInset;
  final bool animate;
  final double snowAccumulation;
  final double snowClearProgress;
  final double flockProgress;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.light:
      case ThemeKind.dark:
        return;
      case ThemeKind.halloween:
        _paintHalloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _paintChristmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _paintCosmos(canvas, size);
        break;
    }
  }

  // ---------------------------------------------------------------------------
  // Halloween
  // ---------------------------------------------------------------------------

  void _paintHalloween(Canvas canvas, Size size) {
    final base = const Color(0xFFB27B54);
    final flicker = animate
        ? (0.72 + 0.28 * math.sin(progress * math.pi * 2))
        : 0.78;

    // Moon (upper left) with soft glow that lights the field.
    final moonCenter = Offset(size.width * 0.18, topInset + 72);
    final moonGlow = Paint()
      ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.14)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28);
    canvas.drawCircle(moonCenter, 42, moonGlow);
    final moon = Paint()
      ..color = const Color(0xFFEDE4C8).withValues(alpha: 0.88)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(moonCenter, 22, moon);
    // Subtle crater marks
    final crater = Paint()
      ..color = const Color(0xFFD4C9A8).withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(moonCenter + const Offset(-6, 4), 4.5, crater);
    canvas.drawCircle(moonCenter + const Offset(7, -5), 3.2, crater);

    // Detailed field / ground under moonlight.
    final fieldTop = size.height * 0.58;
    final fieldPath = Path()
      ..moveTo(0, fieldTop + 18)
      ..quadraticBezierTo(
          size.width * 0.2, fieldTop - 8, size.width * 0.4, fieldTop + 6)
      ..quadraticBezierTo(
          size.width * 0.6, fieldTop + 22, size.width * 0.78, fieldTop)
      ..quadraticBezierTo(
          size.width * 0.9, fieldTop - 10, size.width, fieldTop + 8)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    final fieldPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFF3A322C).withValues(alpha: 0.55),
          const Color(0xFF2A2420).withValues(alpha: 0.72),
          const Color(0xFF1C1816).withValues(alpha: 0.85),
        ],
      ).createShader(
        Rect.fromLTWH(0, fieldTop - 20, size.width, size.height - fieldTop + 20),
      );
    canvas.drawPath(fieldPath, fieldPaint);

    // Grass / stubble lines on the field.
    final grass = Paint()
      ..color = const Color(0xFF4A4038).withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 40; i++) {
      final x = (i * 37.0 + 11) % size.width;
      final y = fieldTop + 10 + (i % 5) * 8.0 + math.sin(i * 0.7) * 4;
      canvas.drawLine(Offset(x, y), Offset(x + 1.5, y - 5 - (i % 3)), grass);
    }

    // Gothic multi-tower castle on the horizon (right side).
    final castleBase = Offset(size.width * 0.72, fieldTop + 4);
    _drawGothicCastle(canvas, castleBase, size.width * 0.34, flicker);

    // Bat flock: white comma-like marks, once every 5 minutes.
    // flockProgress 0→1 over 5 min; wave visible only in first ~18 s of cycle.
    final cycleSeconds = flockProgress * 5 * 60;
    final waveActive = animate && cycleSeconds < 18;
    if (waveActive) {
      final t = cycleSeconds / 18.0; // 0→1 during the wave
      final batPaint = Paint()
        ..color = Colors.white.withValues(alpha: 0.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.15
        ..strokeCap = StrokeCap.round;

      const count = 100;
      for (var i = 0; i < count; i++) {
        final seed = i * 1.6180339887;
        final lane = (i % 12) / 11.0;
        final baseY = topInset + 40 + lane * (fieldTop - topInset - 60);
        // Fly from right toward castle then past it (behind silhouette).
        final x = size.width * (1.15 - t * 1.35) + math.sin(seed) * 18;
        final y = baseY +
            math.sin(t * math.pi * 3 + seed) * 16 +
            math.sin(seed * 2.1) * 10;
        // Draw as a tiny apostrophe / comma stroke «‘,»
        final path = Path()
          ..moveTo(x, y)
          ..quadraticBezierTo(x + 1.8, y + 1.2, x + 0.6, y + 3.4);
        canvas.drawPath(path, batPaint);
      }
    }

    // Spiders
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.78
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < 3; i++) {
      final x = size.width * (0.18 + i * 0.22);
      final travel = 42.0 + i * 20.0;
      final descent = animate
          ? (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i * 1.7)) * travel
          : travel * 0.55;
      final y = topInset + 60 + i * 36.0 + descent;
      canvas.drawLine(Offset(x, topInset + 28), Offset(x, y - 5), webPaint);
      canvas.drawCircle(
        Offset(x, topInset + 28),
        1.5,
        Paint()..color = webPaint.color,
      );
      _drawSpider(
        canvas,
        Offset(x, y),
        0.72 + (i % 2) * 0.10,
        animate ? math.sin(progress * math.pi * 2 + i) : 0,
        webPaint,
      );
    }

    _drawPumpkin(
      canvas,
      Offset(25, size.height * 0.76),
      15,
      base.withValues(alpha: 0.58 * flicker),
      base.withValues(alpha: 0.10 * flicker),
    );
    _drawPumpkin(
      canvas,
      Offset(size.width - 28, size.height * 0.68),
      12,
      base.withValues(alpha: 0.42 * flicker),
      base.withValues(alpha: 0.07 * flicker),
    );
  }

  /// Multi-tower gothic castle with lit windows and arrow slits.
  void _drawGothicCastle(
    Canvas canvas,
    Offset base,
    double width,
    double flicker,
  ) {
    final h = width * 1.15;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;

    final body = Paint()
      ..color = const Color(0xFF2A2228).withValues(alpha: 0.72)
      ..style = PaintingStyle.fill;
    final roof = Paint()
      ..color = const Color(0xFF1A151A).withValues(alpha: 0.85)
      ..style = PaintingStyle.fill;
    final light = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.55 * flicker)
      ..style = PaintingStyle.fill;
    final lightGlow = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.18 * flicker)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    // Main keep
    final keep = Path()
      ..moveTo(left + width * 0.28, bottom)
      ..lineTo(left + width * 0.28, top + h * 0.38)
      ..lineTo(left + width * 0.72, top + h * 0.38)
      ..lineTo(left + width * 0.72, bottom)
      ..close();
    canvas.drawPath(keep, body);

    // Central tall roof
    final centralRoof = Path()
      ..moveTo(left + width * 0.26, top + h * 0.38)
      ..lineTo(left + width * 0.50, top + h * 0.08)
      ..lineTo(left + width * 0.74, top + h * 0.38)
      ..close();
    canvas.drawPath(centralRoof, roof);

    // Gate arch
    final gate = Path()
      ..moveTo(left + width * 0.40, bottom)
      ..lineTo(left + width * 0.40, bottom - h * 0.18)
      ..quadraticBezierTo(
        left + width * 0.50,
        bottom - h * 0.28,
        left + width * 0.60,
        bottom - h * 0.18,
      )
      ..lineTo(left + width * 0.60, bottom)
      ..close();
    canvas.drawPath(
      gate,
      Paint()..color = const Color(0xFF121014).withValues(alpha: 0.9),
    );

    // Helper: round tower with conical roof + lit arrow slits
    void tower(double cx, double baseY, double tw, double th, {bool tall = false}) {
      final tLeft = cx - tw / 2;
      final tTop = baseY - th;
      // Shaft
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(tLeft, tTop + th * 0.18, tw, th * 0.82),
          const Radius.circular(2),
        ),
        body,
      );
      // Conical roof
      final spire = Path()
        ..moveTo(tLeft - 1, tTop + th * 0.22)
        ..lineTo(cx, tTop - (tall ? th * 0.22 : th * 0.12))
        ..lineTo(tLeft + tw + 1, tTop + th * 0.22)
        ..close();
      canvas.drawPath(spire, roof);
      // Arrow slits with warm light
      for (final slotY in [0.35, 0.55, 0.72]) {
        final slot = Rect.fromCenter(
          center: Offset(cx, tTop + th * slotY),
          width: tw * 0.14,
          height: th * 0.08,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(slot, const Radius.circular(1)),
          lightGlow,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(slot, const Radius.circular(1)),
          light,
        );
      }
    }

    // Left outer tower
    tower(left + width * 0.12, bottom, width * 0.16, h * 0.55);
    // Left inner
    tower(left + width * 0.28, bottom - h * 0.05, width * 0.14, h * 0.62);
    // Right inner
    tower(left + width * 0.72, bottom - h * 0.05, width * 0.14, h * 0.62);
    // Right outer
    tower(left + width * 0.88, bottom, width * 0.16, h * 0.55);
    // Tall central spire tower
    tower(left + width * 0.58, top + h * 0.35, width * 0.12, h * 0.55, tall: true);

    // Windows on the keep body with yellowish light
    for (final wx in [0.36, 0.50, 0.64]) {
      for (final wy in [0.48, 0.62]) {
        final wRect = Rect.fromCenter(
          center: Offset(left + width * wx, top + h * wy),
          width: width * 0.045,
          height: h * 0.055,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(wRect, const Radius.circular(1.5)),
          lightGlow,
        );
        canvas.drawRRect(
          RRect.fromRectAndRadius(wRect, const Radius.circular(1.5)),
          light,
        );
      }
    }
  }

  void _drawSpider(
    Canvas canvas,
    Offset center,
    double scale,
    double legMotion,
    Paint webPaint,
  ) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);

    final legs = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.05
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final swing = legMotion * 2.2;
    final legPath = Path()
      ..moveTo(-2, -2)
      ..quadraticBezierTo(-7 - swing, -8, -12 - swing, -7)
      ..lineTo(-15 - swing, -11)
      ..moveTo(-3, 0)
      ..quadraticBezierTo(-10 - swing, -1, -13 - swing, 3)
      ..lineTo(-17 - swing, 4)
      ..moveTo(-3, 2)
      ..quadraticBezierTo(-9 - swing, 6, -11 - swing, 11)
      ..lineTo(-15 - swing, 13)
      ..moveTo(-2, 3)
      ..quadraticBezierTo(-5 - swing, 10, -6 - swing, 14)
      ..lineTo(-9 - swing, 16)
      ..moveTo(2, -2)
      ..quadraticBezierTo(7 + swing, -8, 12 + swing, -7)
      ..lineTo(15 + swing, -11)
      ..moveTo(3, 0)
      ..quadraticBezierTo(10 + swing, -1, 13 + swing, 3)
      ..lineTo(17 + swing, 4)
      ..moveTo(3, 2)
      ..quadraticBezierTo(9 + swing, 6, 11 + swing, 11)
      ..lineTo(15 + swing, 13)
      ..moveTo(2, 3)
      ..quadraticBezierTo(5 + swing, 10, 6 + swing, 14)
      ..lineTo(9 + swing, 16);
    canvas.drawPath(legPath, legs);

    final abdomenPaint = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.35)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 5), width: 9, height: 12),
      abdomenPaint,
    );
    canvas.drawCircle(const Offset(0, -2), 3.2, abdomenPaint);
    canvas.drawLine(const Offset(-1.5, -6), const Offset(-2.5, -8), legs);
    canvas.drawLine(const Offset(1.5, -6), const Offset(2.5, -8), legs);
    canvas.restore();
  }

  void _drawPumpkin(
    Canvas canvas,
    Offset center,
    double radius,
    Color strokeColor,
    Color fillColor,
  ) {
    final outline = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final r = radius;
    final halo = Paint()
      ..color = strokeColor.withValues(alpha: strokeColor.a * 0.24)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 0.75);
    canvas.drawCircle(center, radius * 1.35, halo);
    final shape = Path()
      ..moveTo(center.dx, center.dy - r * 0.72)
      ..cubicTo(
          center.dx - r * 0.95,
          center.dy - r * 1.05,
          center.dx - r * 1.15,
          center.dy - r * 0.25,
          center.dx - r * 0.92,
          center.dy + r * 0.48)
      ..cubicTo(
          center.dx - r * 0.50,
          center.dy + r * 1.05,
          center.dx + r * 0.50,
          center.dy + r * 1.05,
          center.dx + r * 0.92,
          center.dy + r * 0.48)
      ..cubicTo(
          center.dx + r * 1.15,
          center.dy - r * 0.25,
          center.dx + r * 0.95,
          center.dy - r * 1.05,
          center.dx,
          center.dy - r * 0.72)
      ..close();
    canvas.drawPath(shape, fill);
    canvas.drawPath(shape, outline);
    canvas.drawLine(
      Offset(center.dx, center.dy - r * 0.72),
      Offset(center.dx, center.dy - r * 1.05),
      outline,
    );
  }

  // ---------------------------------------------------------------------------
  // Christmas
  // ---------------------------------------------------------------------------

  void _paintChristmas(Canvas canvas, Size size) {
    final wire = Paint()
      ..color = const Color(0xFF8A9088).withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;

    final garlandY = topInset + 25;
    final garland = Path()
      ..moveTo(0, garlandY)
      ..cubicTo(size.width * 0.22, garlandY + 32, size.width * 0.30,
          garlandY - 5, size.width * 0.50, garlandY + 15)
      ..cubicTo(size.width * 0.70, garlandY + 35, size.width * 0.80,
          garlandY - 3, size.width, garlandY + 16);
    canvas.drawPath(garland, wire);

    const bulbColors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
    ];
    for (var i = 0; i < 13; i++) {
      final x = size.width * i / 12;
      final y = garlandY + 13 + math.sin(i / 12 * math.pi * 2) * 7;
      final pulse = animate
          ? 0.58 + 0.25 * math.sin(progress * math.pi * 2 + i * 0.8)
          : 0.62;
      final bulb = Paint()
        ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), 2.4, bulb);
    }

    _drawFirTree(canvas, Offset(20, size.height - 22), 27,
        const Color(0xFF829184).withValues(alpha: 0.20));
    _drawFirTree(canvas, Offset(size.width - 20, size.height - 22), 23,
        const Color(0xFF829184).withValues(alpha: 0.16));

    // Falling snowflakes that land on the drift.
    final snow = Paint()
      ..color = const Color(0xFFDCE6E0).withValues(alpha: 0.48);
    for (var i = 0; i < 90; i++) {
      final x = ((i * 73.0 + 19) % size.width).toDouble();
      final baseY = ((i * 47.0 + 13) % size.height).toDouble();
      final y = ((baseY +
                  (animate ? progress * size.height * (1 + i % 3) : 0)) %
              size.height)
          .toDouble();
      final sway = math.sin(i * 0.7 + progress * math.pi * 2) * 2.2;
      snow.color =
          const Color(0xFFDCE6E0).withValues(alpha: 0.30 + (i % 4) * 0.05);
      canvas.drawCircle(Offset(x + sway, y), 0.8 + (i % 4) * 0.25, snow);
    }

    _drawSnowdrift(canvas, size, snowAccumulation);

    // Stickmen with shovels during the 30-second clear phase.
    if (snowClearProgress > 0 && snowClearProgress < 1) {
      _drawStickmenClearing(canvas, size, snowClearProgress, snowAccumulation);
    }
  }

  void _drawSnowdrift(Canvas canvas, Size size, double growth) {
    if (growth <= 0 || size.isEmpty) return;

    final normalizedGrowth = growth.clamp(0.0, 1.0).toDouble();
    final maxHeight = math.min(size.height * 0.14, 92.0);
    final height = maxHeight * normalizedGrowth;
    if (height < 0.5) return;

    final bottom = size.height;
    final ridge = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(
        size.width * 0.12,
        bottom - height * 0.66,
        size.width * 0.20,
        bottom - height * 0.12,
        size.width * 0.36,
        bottom - height * 0.38,
      )
      ..cubicTo(
        size.width * 0.51,
        bottom - height * 0.70,
        size.width * 0.59,
        bottom - height * 0.14,
        size.width * 0.74,
        bottom - height * 0.42,
      )
      ..cubicTo(
        size.width * 0.86,
        bottom - height * 0.62,
        size.width * 0.94,
        bottom - height * 0.20,
        size.width,
        bottom - height * 0.39,
      )
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();

    final fill = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xDDF4FAF8),
          Color(0xD9E1EBE9),
          Color(0xE8C9D5D7),
        ],
        stops: [0, 0.48, 1],
      ).createShader(
        Rect.fromLTWH(0, bottom - height, size.width, height),
      );
    canvas.drawPath(ridge, fill);

    // Accumulated flake grains on the surface (not a sudden shape change).
    final grainPaint = Paint()..style = PaintingStyle.fill;
    final grainCount = (normalizedGrowth * 52).round();
    for (var i = 0; i < grainCount; i++) {
      final x = ((i * 47.0 + 17) % size.width).toDouble();
      final wave = 0.38 + 0.12 * math.sin(i * 1.13);
      final y = bottom - height * wave - (i % 4) * 1.4;
      grainPaint.color =
          const Color(0xFFF9FFFF).withValues(alpha: 0.32 + (i % 3) * 0.12);
      canvas.drawCircle(
        Offset(x, y),
        0.55 + (i % 3) * 0.22,
        grainPaint,
      );
    }
  }

  /// 10 stick figures with shovels clear the drift over 30 seconds.
  void _drawStickmenClearing(
    Canvas canvas,
    Size size,
    double clearProgress,
    double snowLevel,
  ) {
    final ink = Paint()
      ..color = const Color(0xFF3A4540).withValues(alpha: 0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final bottom = size.height;
    final driftH = math.min(size.height * 0.14, 92.0) * snowLevel;

    for (var i = 0; i < 10; i++) {
      final x = size.width * (0.08 + i * 0.09);
      // Walk in from sides during first 20% of clear, then dig in place.
      final enter = (clearProgress / 0.2).clamp(0.0, 1.0);
      final fromLeft = i % 2 == 0;
      final startX = fromLeft ? -20.0 : size.width + 20;
      final targetX = x;
      final px = startX + (targetX - startX) * enter;
      final py = bottom - driftH * 0.55 - 4;

      final dig = math.sin(clearProgress * math.pi * 8 + i) * 3;

      // Head
      canvas.drawCircle(Offset(px, py - 16), 3.2, ink);
      // Body
      canvas.drawLine(Offset(px, py - 13), Offset(px, py - 2), ink);
      // Legs
      canvas.drawLine(Offset(px, py - 2), Offset(px - 4, py + 8), ink);
      canvas.drawLine(Offset(px, py - 2), Offset(px + 4, py + 8), ink);
      // Arms + shovel
      canvas.drawLine(Offset(px, py - 10), Offset(px + 8 + dig, py - 4), ink);
      canvas.drawLine(
          Offset(px + 8 + dig, py - 4), Offset(px + 10 + dig, py + 6), ink);
      // Shovel blade
      canvas.drawLine(
          Offset(px + 7 + dig, py + 6), Offset(px + 13 + dig, py + 6), ink);
    }
  }

  void _drawFirTree(Canvas canvas, Offset bottom, double height, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.27, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx + height * 0.27, bottom.dy - height * 0.52)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawLine(
        bottom, Offset(bottom.dx, bottom.dy - height * 0.14), paint);
  }

  // ---------------------------------------------------------------------------
  // Cosmos
  // ---------------------------------------------------------------------------

  void _paintCosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = ((i * 67.0 + 11) % size.width).toDouble();
      final y = ((i * 91.0 + 37) % size.height).toDouble();
      final twinkle = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i))
          : 0.23;
      final star = Paint()
        ..color = const Color(0xFFB9B1D7).withValues(alpha: twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.45 : 0.8, star);
    }

    final center = Offset(size.width - 44, topInset + 116);
    final orbitPaint = Paint()
      ..color = const Color(0xFF9991BE).withValues(alpha: 0.20)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 66, height: 23),
      orbitPaint,
    );
    final planetPaint = Paint()
      ..color = const Color(0xFF9C94BD).withValues(alpha: 0.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;
    canvas.drawCircle(center, 9, planetPaint);

    for (var i = 0; i < 8; i++) {
      final phase = (progress * 3.15 + i * 0.173) % 1.0;
      if (!animate || phase >= 0.28) continue;

      final t = phase / 0.28;
      final startX = ((i * 137.0 + 31) % (size.width + 90)) - 45;
      final startY = topInset + 38 + (i * 59.0) % 250;
      final end = Offset(startX + 112 * t, startY + 76 * t);
      final tail = Offset(end.dx - 27, end.dy - 18);
      final fade = (1 - t * 0.58).clamp(0.0, 1.0).toDouble();

      final glow = Paint()
        ..color = const Color(0xFFBFB7EA).withValues(alpha: 0.15 * fade)
        ..strokeWidth = 4.2
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = const Color(0xFFE0DAFF).withValues(alpha: 0.72 * fade)
        ..strokeWidth = 1.15
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, end, glow);
      canvas.drawLine(tail, end, core);
      canvas.drawCircle(
        end,
        1.65,
        Paint()
          ..color = const Color(0xFFF0ECFF).withValues(alpha: 0.72 * fade),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ThemeAtmospherePainter oldDelegate) =>
      oldDelegate.kind != kind ||
      oldDelegate.progress != progress ||
      oldDelegate.topInset != topInset ||
      oldDelegate.animate != animate ||
      oldDelegate.snowAccumulation != snowAccumulation ||
      oldDelegate.snowClearProgress != snowClearProgress ||
      oldDelegate.flockProgress != flockProgress;
}
