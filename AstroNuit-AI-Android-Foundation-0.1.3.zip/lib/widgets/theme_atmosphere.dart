import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Seasonal atmosphere: decorations behind pages, interactive overlays on top.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
    this.child,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;
  final Widget? child;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  /// Continuous loop for flake motion / flicker.
  AnimationController? _loop;

  AnimationController? _spider;

  /// Wall-clock climate (continues while the app is backgrounded).
  Timer? _clock;
  double _climate = 0;
  double _loopPhase = 0;
  static const _cycleMs = 17 * 60 * 1000;

  int _leftGlow = 0;
  int _rightGlow = 0;
  int _leftTap = 0; // 1..7 cycle for left interactive pumpkin
  int _fieldGlow = 0; // glow level for the 50 field pumpkins
  bool _screamer = false;
  bool _aaaButton = false;
  bool _houseGarlandOn = false;
  bool _houseLightsOn = true;

  bool get _seasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _anim => _seasonal && widget.animationsEnabled;

  bool get _christmas =>
      _anim &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _halloween => _anim && widget.themeKind == ThemeKind.halloween;

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _sync();
      if (widget.themeKind != ThemeKind.halloween) {
        _leftGlow = 0;
        _rightGlow = 0;
        _leftTap = 0;
        _fieldGlow = 0;
        _screamer = false;
        _aaaButton = false;
      }
      if (widget.themeKind != ThemeKind.christmas) {
        _houseGarlandOn = false;
        _houseLightsOn = true;
      }
    }
  }

  void _sync() {
    _clock?.cancel();
    _clock = null;

    if (_anim) {
      // Short duration → more ticks per second (smoother motion up to display Hz).
      _loop ??= AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 200), // ~5 cycles/sec base
      )..repeat();
      if (!_loop!.isAnimating) _loop!.repeat();

      if (_halloween) {
        _spider ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 41),
        )..repeat();
        if (!_spider!.isAnimating) _spider!.repeat();
      } else {
        _spider?.stop();
      }

      void tick() {
        final ms = DateTime.now().millisecondsSinceEpoch;
        // Climate cycle only meaningful for Christmas; still sample loop always.
        if (_christmas) {
          _climate = (ms % _cycleMs) / _cycleMs;
        }
        _loopPhase = (ms % 5000) / 5000.0;
      }

      tick();
      // Keep cycle advancing even if the vsync ticker pauses (background/resume).
      if (_christmas || _halloween) {
        _clock = Timer.periodic(const Duration(milliseconds: 5), (_) {
          if (!mounted) return;
          final prev = _climate;
          final prevLoop = _loopPhase;
          tick();
          if ((_climate - prev).abs() > 0.00005 ||
              (_loopPhase - prevLoop).abs() > 0.00005) {
            setState(() {});
          }
        });
      }
    } else {
      _loop?.stop();
      _spider?.stop();
      _loop?.value = 0;
      _climate = 0;
      _loopPhase = 0;
    }
  }

  void _tapLeftPumpkin() {
    if (_screamer) return;
    setState(() {
      _leftTap += 1;
      if (_leftTap <= 5) {
        _leftGlow = _leftTap;
      } else if (_leftTap == 6) {
        // All field pumpkins + left to level 3.
        _leftGlow = 3;
        _fieldGlow = 3;
      } else {
        // 7th press: everything off.
        _leftGlow = 0;
        _rightGlow = 0;
        _fieldGlow = 0;
        _leftTap = 0;
      }
    });
  }

  void _tapRightPumpkin() {
    if (_screamer) return;
    setState(() {
      if (_rightGlow < 4) {
        _rightGlow++;
      } else {
        _rightGlow = 4;
        _screamer = true;
        _aaaButton = false;
      }
    });
    if (_screamer) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && _screamer) setState(() => _aaaButton = true);
      });
    }
  }

  void _dismissScreamer() {
    setState(() {
      _screamer = false;
      _aaaButton = false;
      _leftGlow = 0;
      _rightGlow = 0;
      _leftTap = 0;
      _fieldGlow = 0;
    });
  }

  Widget _chipButton({
    required bool on,
    required VoidCallback onTap,
    required IconData iconOn,
    required IconData iconOff,
    required String labelOn,
    required String labelOff,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF2A332E).withValues(alpha: 0.92),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: on
                ? const Color(0xFFFFD080).withValues(alpha: 0.85)
                : const Color(0xFF6A7A70).withValues(alpha: 0.6),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              on ? iconOn : iconOff,
              size: 16,
              color: on ? const Color(0xFFFFD080) : const Color(0xFF9AAA9A),
            ),
            const SizedBox(width: 6),
            Text(
              on ? labelOn : labelOff,
              style: TextStyle(
                color: on ? const Color(0xFFFFF0D0) : const Color(0xFFC8D0C8),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _clock?.cancel();
    _loop?.dispose();
    _spider?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: Listenable.merge([
        _loop ?? const AlwaysStoppedAnimation(0.0),
        _spider ?? const AlwaysStoppedAnimation(0.0),
      ]),
      builder: (context, _) {
        // Prefer high-freq wall-clock values when animations are on.
        final climate = _anim ? _climate : 0.0;
        final loopVal = _anim ? _loopPhase : (_loop?.value ?? 0.0);
        // Interactive pumpkins sit beside the LAST row (not inside the grid).
        final fieldTop = size.height * 0.58;
        final gridTop = fieldTop + (size.height - fieldTop) * 0.28;
        final rowH = (size.height - gridTop - 36) / 4;
        final lastRowY = gridTop + rowH * 3;
        final leftPumpkin = Offset(28, lastRowY);
        final rightPumpkin = Offset(size.width - 28, lastRowY);

        return Stack(
          fit: StackFit.expand,
          clipBehavior: Clip.none,
          children: [
            IgnorePointer(
              child: CustomPaint(
                painter: _AtmospherePainter(
                  kind: widget.themeKind,
                  loop: loopVal,
                  topInset: topInset,
                  animate: _anim,
                  climate: climate,
                  spider: _spider?.value ?? 0,
                  houseGarlandOn: _houseGarlandOn,
                  houseLightsOn: _houseLightsOn,
                  fieldGlow: _fieldGlow,
                ),
                size: size,
              ),
            ),
            if (widget.child != null) widget.child!,

            // Halloween pumpkins — real widgets for reliable taps.
            if (widget.themeKind == ThemeKind.halloween) ...[
              Positioned(
                left: leftPumpkin.dx - 28,
                top: leftPumpkin.dy - 28,
                width: 56,
                height: 56,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapLeftPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _leftGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin(loopVal * math.pi * 2)
                          : 0.8,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: rightPumpkin.dx - 24,
                top: rightPumpkin.dy - 24,
                width: 48,
                height: 48,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapRightPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinPainter(
                      glow: _rightGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin(loopVal * math.pi * 2 + 1)
                          : 0.8,
                    ),
                  ),
                ),
              ),
            ],

            // Christmas: garland + house lights toggles.
            if (widget.themeKind == ThemeKind.christmas)
              Positioned(
                right: 14,
                bottom: 96, // above chat send / input bar
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _chipButton(
                      on: _houseLightsOn,
                      onTap: () =>
                          setState(() => _houseLightsOn = !_houseLightsOn),
                      iconOn: Icons.home,
                      iconOff: Icons.home_outlined,
                      labelOn: 'Свет вкл',
                      labelOff: 'Свет',
                    ),
                    const SizedBox(height: 8),
                    _chipButton(
                      on: _houseGarlandOn,
                      onTap: () =>
                          setState(() => _houseGarlandOn = !_houseGarlandOn),
                      iconOn: Icons.lightbulb,
                      iconOff: Icons.lightbulb_outline,
                      labelOn: 'Гирлянда вкл',
                      labelOff: 'Гирлянда',
                    ),
                  ],
                ),
              ),

            if (_screamer)
              Positioned.fill(
                child: _ScreamerOverlay(
                  showButton: _aaaButton,
                  onDismiss: _dismissScreamer,
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Pumpkin
// ---------------------------------------------------------------------------

class _PumpkinPainter extends CustomPainter {
  _PumpkinPainter({required this.glow, required this.flicker});
  final int glow;
  final double flicker;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide * 0.42;
    final base = const Color(0xFFB27B54);
    final glowA = 0.08 + glow * 0.16;
    // Soft local light on the ground when lit.
    if (glow > 0) {
      canvas.drawCircle(
        c + Offset(0, r * 0.5),
        r * (2.0 + glow * 0.3),
        Paint()
          ..color = const Color(0xFFFFB040)
              .withValues(alpha: (0.1 + glow * 0.05) * flicker)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
    }
    final fill = Paint()
      ..color = const Color(0xFFFFB040)
          .withValues(alpha: (glowA * 1.35).clamp(0.0, 1.0) * flicker)
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = base.withValues(alpha: 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy, c.dx - r * 0.9,
          c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, stroke);
    canvas.drawLine(
        Offset(c.dx, c.dy - r * 0.7), Offset(c.dx, c.dy - r * 1.05), stroke);
  }

  @override
  bool shouldRepaint(covariant _PumpkinPainter old) =>
      old.glow != glow || old.flicker != flicker;
}

// ---------------------------------------------------------------------------
// Screamer — horror figure with knife
// ---------------------------------------------------------------------------

class _ScreamerOverlay extends StatelessWidget {
  const _ScreamerOverlay({required this.showButton, required this.onDismiss});
  final bool showButton;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.94),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(
              painter: _HorrorFigurePainter(), child: const SizedBox.expand()),
          if (showButton)
            Align(
              alignment: const Alignment(0, 0.62),
              child: _AaaButton(onPressed: onDismiss),
            ),
        ],
      ),
    );
  }
}

class _AaaButton extends StatefulWidget {
  const _AaaButton({required this.onPressed});
  final VoidCallback onPressed;
  @override
  State<_AaaButton> createState() => _AaaButtonState();
}

class _AaaButtonState extends State<_AaaButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 900))
    ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          child!,
          SizedBox(
            height: 36,
            width: 160,
            child: CustomPaint(painter: _DripsPainter(_c.value)),
          ),
        ],
      ),
      child: FilledButton(
        onPressed: widget.onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF8B1515),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        ),
        child: const Text('ААААААААААА!',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      ),
    );
  }
}

class _DripsPainter extends CustomPainter {
  _DripsPainter(this.p);
  final double p;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFB01010);
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.15 + i * 0.18);
      final fall = (p + i * 0.17) % 1.0;
      final y = fall * size.height;
      canvas.drawCircle(Offset(x, y), 2.2, paint);
      canvas.drawOval(
        Rect.fromCenter(
            center: Offset(x, y - 4), width: 1.6, height: 6 + fall * 8),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DripsPainter old) => old.p != p;
}

/// Stylized horror silhouette: hooded figure + knife (original vector art).
class _HorrorFigurePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width * 0.5;
    final cy = size.height * 0.42;
    final fill = Paint()..color = const Color(0xFF1A1218);
    final edge = Paint()
      ..color = const Color(0xFF3A2A32)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    // Cloak / body
    final cloak = Path()
      ..moveTo(cx - 70, cy + 160)
      ..lineTo(cx - 55, cy + 20)
      ..quadraticBezierTo(cx - 40, cy - 40, cx - 20, cy - 70)
      ..lineTo(cx + 20, cy - 70)
      ..quadraticBezierTo(cx + 40, cy - 40, cx + 55, cy + 20)
      ..lineTo(cx + 70, cy + 160)
      ..close();
    canvas.drawPath(cloak, fill);
    canvas.drawPath(cloak, edge);

    // Hood
    final hood = Path()
      ..moveTo(cx - 32, cy - 55)
      ..quadraticBezierTo(cx - 38, cy - 110, cx, cy - 125)
      ..quadraticBezierTo(cx + 38, cy - 110, cx + 32, cy - 55)
      ..quadraticBezierTo(cx, cy - 40, cx - 32, cy - 55)
      ..close();
    canvas.drawPath(hood, fill);
    canvas.drawPath(hood, edge);

    // Face void
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, cy - 78), width: 36, height: 42),
      Paint()..color = const Color(0xFF0A0608),
    );
    // Glowing eyes
    final eye = Paint()..color = const Color(0xFFE8B060).withValues(alpha: 0.9);
    canvas.drawCircle(Offset(cx - 8, cy - 82), 3.2, eye);
    canvas.drawCircle(Offset(cx + 8, cy - 82), 3.2, eye);
    canvas.drawCircle(
      Offset(cx - 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawCircle(
      Offset(cx + 8, cy - 82),
      7,
      Paint()
        ..color = const Color(0xFFE8B060).withValues(alpha: 0.2)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // Arm raised with knife
    final arm = Path()
      ..moveTo(cx + 30, cy - 20)
      ..lineTo(cx + 75, cy - 90)
      ..lineTo(cx + 85, cy - 82)
      ..lineTo(cx + 42, cy - 5)
      ..close();
    canvas.drawPath(arm, fill);

    // Knife blade
    final blade = Path()
      ..moveTo(cx + 78, cy - 95)
      ..lineTo(cx + 118, cy - 175)
      ..lineTo(cx + 130, cy - 165)
      ..lineTo(cx + 92, cy - 88)
      ..close();
    canvas.drawPath(
      blade,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF0F0F4), Color(0xFF8A8A94)],
        ).createShader(Rect.fromLTWH(cx + 70, cy - 180, 70, 100)),
    );
    // Handle
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
            center: Offset(cx + 82, cy - 80), width: 12, height: 28),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF3A2010),
    );

    // Red slash accents
    final slash = Paint()
      ..color = const Color(0xFFB01010).withValues(alpha: 0.45)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(Offset(cx - 90, cy - 40), Offset(cx + 40, cy + 80), slash);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Main painter
// ---------------------------------------------------------------------------

class _AtmospherePainter extends CustomPainter {
  _AtmospherePainter({
    required this.kind,
    required this.loop,
    required this.topInset,
    required this.animate,
    required this.climate,
    required this.spider,
    required this.houseGarlandOn,
    required this.houseLightsOn,
    required this.fieldGlow,
  });

  final ThemeKind kind;
  final double loop;
  final double topInset;
  final bool animate;
  final double climate; // 0..1 over 17 min cycle
  final double spider;
  final bool houseGarlandOn;
  final bool houseLightsOn;
  final int fieldGlow;

  // Phase boundaries (must match state constants).
  static const snowEnd = 5.0 / 17.0;
  static const meltEnd = 10.0 / 17.0;
  static const dayEnd = 12.0 / 17.0;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.halloween:
        _halloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _christmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _cosmos(canvas, size);
        break;
      default:
        break;
    }
  }

  // ---- Halloween ----

  void _halloween(Canvas canvas, Size size) {
    final flicker =
        animate ? 0.72 + 0.28 * math.sin(loop * math.pi * 2) : 0.78;

    // Dark sky + stars
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFF080A10).withValues(alpha: 0.55),
    );
    final star = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 60; i++) {
      final x = _hash(i, 0.21) * size.width;
      final y = _hash(i, 0.63) * size.height * 0.55;
      final tw = 0.25 +
          0.55 *
              (0.5 +
                  0.5 *
                      math.sin(loop * math.pi * 2 * (0.7 + _hash(i, 0.4)) + i));
      star.color = const Color(0xFFE8E4D8).withValues(alpha: tw * 0.7);
      canvas.drawCircle(Offset(x, y), 0.6 + _hash(i, 0.9) * 0.9, star);
    }

    final moon = Offset(size.width * 0.16, topInset + 88);
    canvas.drawCircle(
      moon,
      58,
      Paint()
        ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.16)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 36),
    );
    canvas.drawCircle(moon, 34,
        Paint()..color = const Color(0xFFEDE6CF).withValues(alpha: 0.92));
    canvas.drawCircle(moon + const Offset(-6, 4), 7,
        Paint()..color = const Color(0xFFC9BFA0).withValues(alpha: 0.22));

    final fieldTop = size.height * 0.58;
    canvas.drawRect(
      Rect.fromLTRB(0, fieldTop, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF2A2420).withValues(alpha: 0.55),
            const Color(0xFF1C1816).withValues(alpha: 0.9),
          ],
        ).createShader(Rect.fromLTRB(0, fieldTop, size.width, size.height)),
    );

    final castleBase = Offset(size.width * 0.74, fieldTop);
    final castleW = size.width * 0.32;
    _gothicCastle(canvas, castleBase, castleW, flicker);
    _spiderLife(canvas, size);

    // 50 decorative field pumpkins (not on the castle, not on edge controls).
    _fieldPumpkins(canvas, size, fieldTop, castleBase, castleW);
  }

  void _fieldPumpkins(Canvas canvas, Size size, double fieldTop,
      Offset castleBase, double castleW) {
    // 4×5 grid = 20 slots. Interactive widgets occupy the outer ends of the
    // LAST row (drawn as widgets, not here).
    final gridTop = fieldTop + (size.height - fieldTop) * 0.28;
    final rowH = (size.height - gridTop - 36) / 4;
    final colW = (size.width - 64) / 4;
    for (var row = 0; row < 4; row++) {
      for (var col = 0; col < 5; col++) {
        // Last row ends are the tappable pumpkins (widgets).
        if (row == 3 && (col == 0 || col == 4)) continue;
        final x = 32 + colW * col;
        final y = gridTop + rowH * row;
        final castleLeft = castleBase.dx - castleW * 0.45;
        final castleRight = castleBase.dx + castleW * 0.45;
        if (y < fieldTop + 48 && x > castleLeft && x < castleRight) continue;
        final maxR = math.min(colW, rowH) * 0.26;
        final r = (5.5 + ((row * 3 + col) % 4) * 1.6).clamp(5.0, maxR);
        _drawFieldPumpkin(canvas, Offset(x, y), r, fieldGlow, flicker: 0.85);
      }
    }
  }

  void _drawFieldPumpkin(Canvas canvas, Offset c, double r, int glow,
      {double flicker = 0.8}) {
    final base = const Color(0xFFB27B54);
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy, c.dx - r * 0.9,
          c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();

    // Soft ground light around the pumpkin when lit (not past a huge radius).
    if (glow > 0) {
      final a = (0.12 + glow * 0.06) * flicker;
      canvas.drawCircle(
        c + Offset(0, r * 0.4),
        r * (1.8 + glow * 0.25),
        Paint()
          ..color = const Color(0xFFFFB040).withValues(alpha: a)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
    }

    final fillA = glow > 0 ? (0.22 + glow * 0.18) * flicker : 0.06;
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFFFFB040).withValues(alpha: fillA)
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = base.withValues(alpha: 0.85)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.15,
    );
    canvas.drawLine(
      Offset(c.dx, c.dy - r * 0.7),
      Offset(c.dx, c.dy - r * 1.0),
      Paint()
        ..color = base.withValues(alpha: 0.85)
        ..strokeWidth = 1.15,
    );
  }

  void _spiderLife(Canvas canvas, Size size) {
    if (!animate) return;
    final totalMin = spider * 41.0;
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9;
    final anchor = Offset(size.width - 18, size.height - 28);
    const webRadius = 52.0;

    void orb(double c) {
      for (var i = 0; i < 8; i++) {
        final a = -math.pi * 0.15 - i * (math.pi * 0.85 / 7);
        canvas.drawLine(
          anchor,
          anchor +
              Offset(math.cos(a) * webRadius * c, -math.sin(a).abs() * webRadius * c - 4),
          webPaint,
        );
      }
    }

    void spiderAt(Offset c, double scale, double motion) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.scale(scale);
      final legs = Paint()
        ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..strokeCap = StrokeCap.round;
      final sw = motion * 2.4;
      canvas.drawPath(
        Path()
          ..moveTo(-2, -2)
          ..quadraticBezierTo(-7 - sw, -8, -12 - sw, -7)
          ..moveTo(2, -2)
          ..quadraticBezierTo(7 + sw, -8, 12 + sw, -7),
        legs,
      );
      canvas.drawCircle(const Offset(0, 0), 3.5,
          Paint()..color = const Color(0xFFC7B2A8).withValues(alpha: 0.6));
      canvas.restore();
    }

    if (totalMin < 40 / 60) {
      final t = (totalMin / (40 / 60)).clamp(0.0, 1.0);
      orb(t);
      final a = -math.pi * 0.15 - t * math.pi * 0.85;
      spiderAt(
          anchor +
              Offset(math.cos(a) * webRadius * t,
                  -math.sin(a).abs() * webRadius * t - 4),
          0.8,
          loop * math.pi * 6);
    } else if (totalMin < 11) {
      orb(1);
      spiderAt(anchor + const Offset(-28, -40), 0.85, math.sin(loop * math.pi * 4));
    } else if (totalMin < 12) {
      final t = totalMin - 11;
      orb(1);
      spiderAt(
          Offset.lerp(anchor + const Offset(-28, -40),
              Offset(size.width + 30, size.height - 40), t)!,
          0.8,
          loop * math.pi * 4);
    } else {
      orb(1);
    }
  }

  void _gothicCastle(
      Canvas canvas, Offset base, double width, double flicker) {
    final h = width * 1.05;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF2A2228).withValues(alpha: 0.75);
    final roof = Paint()..color = const Color(0xFF1A151A).withValues(alpha: 0.88);
    final light = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.55 * flicker);
    canvas.drawRect(
        Rect.fromLTRB(
            left + width * 0.28, top + h * 0.36, left + width * 0.72, bottom),
        body);
    canvas.drawPath(
      Path()
        ..moveTo(left + width * 0.26, top + h * 0.36)
        ..lineTo(left + width * 0.5, top + h * 0.06)
        ..lineTo(left + width * 0.74, top + h * 0.36)
        ..close(),
      roof,
    );
    void tower(double cx, double tw, double th) {
      final tLeft = cx - tw / 2;
      final tTop = bottom - th;
      canvas.drawRect(
          Rect.fromLTWH(tLeft, tTop + th * 0.16, tw, th * 0.84), body);
      canvas.drawPath(
        Path()
          ..moveTo(tLeft - 1, tTop + th * 0.2)
          ..lineTo(cx, tTop - th * 0.12)
          ..lineTo(tLeft + tw + 1, tTop + th * 0.2)
          ..close(),
        roof,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(
              center: Offset(cx, tTop + th * 0.5),
              width: tw * 0.14,
              height: th * 0.07),
          const Radius.circular(1),
        ),
        light,
      );
    }

    tower(left + width * 0.12, width * 0.15, h * 0.52);
    tower(left + width * 0.28, width * 0.13, h * 0.6);
    tower(left + width * 0.72, width * 0.13, h * 0.6);
    tower(left + width * 0.88, width * 0.15, h * 0.52);
  }

  // ---- Christmas climate cycle ----
  // 0..snowEnd  : night, snow falls, moon center, drift grows
  // snowEnd..meltEnd : no new snow, moon→left, sun↑, melt
  // meltEnd..dayEnd  : day hold, sun center
  // dayEnd..1        : sun→left, moon from right→center, then snow again

  void _christmas(Canvas canvas, Size size) {
    final groundY = size.height * 0.70;
    final c = climate;
    // Day factor 0=night, 1=full day — smooth transitions, never a hard cut.
    double dayFactor;
    if (c < snowEnd) {
      dayFactor = 0;
    } else if (c < meltEnd) {
      dayFactor = Curves.easeInOut.transform(
          ((c - snowEnd) / (meltEnd - snowEnd)).clamp(0.0, 1.0));
    } else if (c < dayEnd) {
      dayFactor = 1;
    } else {
      dayFactor = 1 -
          Curves.easeInOut
              .transform(((c - dayEnd) / (1 - dayEnd)).clamp(0.0, 1.0));
    }

    final nightTop = const Color(0xFF070A12);
    final nightBot = const Color(0xFF101820);
    final dayTop = const Color(0xFF7EC8E8);
    final dayBot = const Color(0xFFB8DCF0);
    Color lerpC(Color a, Color b, double t) => Color.lerp(a, b, t)!;

    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            lerpC(nightTop, dayTop, dayFactor),
            lerpC(nightBot, dayBot, dayFactor),
          ],
        ).createShader(Offset.zero & size),
    );

    // Stars fade out as day arrives.
    if (dayFactor < 0.95) {
      final star = Paint()..style = PaintingStyle.fill;
      for (var i = 0; i < 70; i++) {
        final x = _hash(i, 0.31) * size.width;
        final y = _hash(i, 0.77) * size.height * 0.58;
        final tw = 0.2 +
            0.6 *
                (0.5 +
                    0.5 *
                        math.sin(
                            loop * math.pi * 2 * (0.6 + _hash(i, 0.2)) + i));
        star.color = const Color(0xFFEDE8D8)
            .withValues(alpha: tw * 0.75 * (1 - dayFactor));
        canvas.drawCircle(Offset(x, y), 0.55 + _hash(i, 0.5) * 1.0, star);
      }
    }

    // Clouds only visible by day; opacity follows dayFactor.
    if (dayFactor > 0.05) {
      _clouds(canvas, size, dayFactor);
    }

    // Forest behind the house (silhouette band).
    _forest(canvas, size, groundY);

    // Snow field: dimmer at night, brighter by day — smooth via dayFactor.
    canvas.drawRect(
      Rect.fromLTRB(0, groundY * 0.92, size.width, size.height),
      Paint()
        ..color = Color.lerp(
          const Color(0xFF8A9290).withValues(alpha: 0.55),
          const Color(0xFFE8EEF0).withValues(alpha: 0.88),
          dayFactor,
        )!,
    );

    // Celestial bodies from screen edges.
    _celestial(canvas, size);

    // Soft moon light pool only near the house at night.
    final houseBase = Offset(size.width * 0.5, groundY);
    if (dayFactor < 0.85) {
      canvas.drawCircle(
        Offset(houseBase.dx, groundY + 8),
        size.width * 0.28,
        Paint()
          ..color = const Color(0xFFD8D0B8)
              .withValues(alpha: 0.10 * (1 - dayFactor))
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 28),
      );
    }

    // Drift on top of the field.
    final drift = _driftAmount(c);
    _snowdrift(canvas, size, groundY, drift);

    // Local garland reflection on snow under the house only.
    if (houseGarlandOn && animate) {
      final shimmer = 0.03 +
          0.04 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 * 2.3));
      canvas.drawCircle(
        Offset(houseBase.dx, groundY + 6),
        size.width * 0.2,
        Paint()
          ..color = const Color(0xFFFFE0A0).withValues(alpha: shimmer)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16),
      );
    }

    _twoStoryHouse(canvas, houseBase, size.width * 0.34);

    _fir(canvas, Offset(30, groundY), 40, const Color(0xFF2E4A34));
    _fir(canvas, Offset(size.width - 30, groundY), 34, const Color(0xFF2A4430));

    _snowfall(canvas, size, groundY, c, houseBase);
  }

  void _clouds(Canvas canvas, Size size, double opacity) {
    final cloud = Paint()
      ..color = const Color(0xFFFFFFFF).withValues(alpha: 0.5 * opacity);
    void puff(double x, double y, double s) {
      canvas.drawCircle(Offset(x, y), 14 * s, cloud);
      canvas.drawCircle(Offset(x + 12 * s, y + 2 * s), 12 * s, cloud);
      canvas.drawCircle(Offset(x - 12 * s, y + 3 * s), 11 * s, cloud);
      canvas.drawCircle(Offset(x + 4 * s, y - 6 * s), 10 * s, cloud);
    }

    // Continuous wall-clock drift (no loop-phase reset → no visible tear).
    final span = size.width + 140.0;
    final sec = animate
        ? DateTime.now().millisecondsSinceEpoch / 1000.0
        : 0.0;
    double wrap(double base, double pxPerSec) {
      final x = base + sec * pxPerSec;
      return (x % span + span) % span - 70;
    }

    puff(wrap(size.width * 0.10, 8.0), topInset + 70, 1.1);
    puff(wrap(size.width * 0.45, 5.5), topInset + 100, 0.9);
    puff(wrap(size.width * 0.75, 7.0), topInset + 60, 1.0);
    puff(wrap(size.width * 0.30, 4.0), topInset + 85, 0.85);
  }

  void _forest(Canvas canvas, Size size, double groundY) {
    // Fully opaque night forest band (no transparency).
    final fill = Paint()
      ..color = const Color(0xFF152218)
      ..style = PaintingStyle.fill;
    final fill2 = Paint()
      ..color = const Color(0xFF0E1812)
      ..style = PaintingStyle.fill;
    // Solid undergrowth so sky never shows through.
    canvas.drawRect(
      Rect.fromLTRB(0, groundY - 28, size.width, groundY + 2),
      fill2,
    );
    for (var i = 0; i < 32; i++) {
      final x = size.width * (i / 31.0);
      final h = 42.0 + _hash(i, 0.44) * 56.0;
      final top = groundY - h;
      final half = 11.0 + _hash(i, 0.2) * 9.0;
      final path = Path()
        ..moveTo(x, groundY)
        ..lineTo(x - half, groundY)
        ..lineTo(x, top)
        ..lineTo(x + half, groundY)
        ..close();
      canvas.drawPath(path, fill);
      canvas.drawPath(
        Path()
          ..moveTo(x, top + h * 0.28)
          ..lineTo(x - half * 0.7, top + h * 0.5)
          ..lineTo(x + half * 0.7, top + h * 0.5)
          ..close(),
        fill2,
      );
    }
  }

  double _driftAmount(double c) {
    if (c < snowEnd) {
      // Start growing only after flakes would have landed (~8% into phase).
      final t = ((c / snowEnd) - 0.08) / 0.92;
      return t.clamp(0.0, 1.0);
    }
    if (c < meltEnd) {
      final t = (c - snowEnd) / (meltEnd - snowEnd);
      return (1.0 - Curves.easeInOut.transform(t)).clamp(0.0, 1.0);
    }
    return 0.0;
  }

  void _celestial(Canvas canvas, Size size) {
    final c = climate;
    final center = Offset(size.width * 0.5, topInset + 90);
    final leftOff = Offset(-60, topInset + 105);
    final rightOff = Offset(size.width + 60, topInset + 105);
    final sunBottomRight = Offset(size.width + 50, size.height * 0.9);

    Offset? moonPos;
    Offset? sunPos;
    double moonA = 0;
    double sunA = 0;

    if (c < snowEnd) {
      // Night only — moon centered, no sun.
      moonPos = center;
      moonA = 1;
    } else if (c < meltEnd) {
      // Split melt: first half moon exits, second half sun enters.
      // Never both visible.
      final t = ((c - snowEnd) / (meltEnd - snowEnd)).clamp(0.0, 1.0);
      if (t < 0.5) {
        final u = Curves.easeInOut.transform(t * 2);
        moonPos = Offset.lerp(center, leftOff, u)!;
        moonA = 1 - u * 0.15; // still solid until past edge
        sunPos = null;
      } else {
        final u = Curves.easeInOut.transform((t - 0.5) * 2);
        moonPos = null;
        sunPos = Offset.lerp(sunBottomRight, center, u)!;
        sunA = u;
      }
    } else if (c < dayEnd) {
      // Day hold — sun only.
      sunPos = center;
      sunA = 1;
    } else {
      // Split return: first half sun exits left, second half moon enters right.
      final t = ((c - dayEnd) / (1 - dayEnd)).clamp(0.0, 1.0);
      if (t < 0.5) {
        final u = Curves.easeInOut.transform(t * 2);
        sunPos = Offset.lerp(center, leftOff, u)!;
        sunA = 1 - u * 0.15;
        moonPos = null;
      } else {
        final u = Curves.easeInOut.transform((t - 0.5) * 2);
        sunPos = null;
        moonPos = Offset.lerp(rightOff, center, u)!;
        moonA = u;
      }
    }

    if (moonPos != null && moonA > 0.04) {
      canvas.drawCircle(
        moonPos,
        42,
        Paint()
          ..color = const Color(0xFFD8D0B0).withValues(alpha: 0.07 * moonA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 22),
      );
      canvas.drawCircle(
        moonPos,
        24,
        Paint()
          ..color = const Color(0xFFDCD6C0).withValues(alpha: 0.75 * moonA),
      );
      canvas.drawCircle(
        moonPos + const Offset(-5, 3),
        6,
        Paint()
          ..color = const Color(0xFFB8B09A).withValues(alpha: 0.18 * moonA),
      );
    }

    if (sunPos != null && sunA > 0.04) {
      canvas.drawCircle(
        sunPos,
        55,
        Paint()
          ..color = const Color(0xFFFFE0A0).withValues(alpha: 0.18 * sunA)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 30),
      );
      canvas.drawCircle(
        sunPos,
        26,
        Paint()
          ..color = const Color(0xFFFFD060).withValues(alpha: 0.9 * sunA),
      );
    }
  }

  void _snowfall(
      Canvas canvas, Size size, double groundY, double c, Offset houseBase) {
    // Snow intensity: ramps 0→1 during snow phase, then stops spawning.
    final inSnow = c < snowEnd;
    final snowT = inSnow ? (c / snowEnd).clamp(0.0, 1.0) : 1.0;
    final spawnFade = c < snowEnd
        ? 1.0
        : c < snowEnd + 0.02
            ? 1.0
            : 0.0;

    final count = (80 + snowT * 920).round().clamp(80, 1000);
    final speedMul = 1.3 + snowT * 1.4;

    if (!inSnow && spawnFade == 0) return;

    final paint = Paint()..style = PaintingStyle.fill;
    final houseTop = houseBase.dy - size.width * 0.34 * 0.9;
    final houseLeft = houseBase.dx - size.width * 0.34 / 2;
    final houseRight = houseBase.dx + size.width * 0.34 / 2;

    for (var i = 0; i < count; i++) {
      final birth = i / 1000.0;
      if (snowT < birth) continue;

      // Irregular hash so flakes are scattered, not in vertical columns.
      final h1 = _hash(i, 0.123);
      final h2 = _hash(i, 0.791);
      final h3 = _hash(i, 0.457);
      final h4 = _hash(i, 0.913);

      final speed = (1.8 + h1 * 2.4) * speedMul;
      // Unique phase per flake — spreads them across the full height.
      final phase = (loop * speed + h2) % 1.0;
      var y = phase * (size.height + 16) - 8;
      // Fully random X across the width + gentle individual sway.
      var x = h3 * size.width +
          math.sin(loop * math.pi * 2 * (0.4 + h4) + h2 * math.pi * 2) *
              (4.0 + h1 * 8.0);

      // Keep X wrapped inside the screen.
      x = x % size.width;
      if (x < 0) x += size.width;

      // Soft interaction with the roof.
      if (y > houseTop &&
          y < houseTop + 28 &&
          x > houseLeft &&
          x < houseRight) {
        final side = x >= houseBase.dx ? 1.0 : -1.0;
        x += side * (1.2 + h4 * 1.5);
        y += 0.6 + h1;
      }

      final r = 0.55 + h2 * 0.7;
      paint.color = const Color(0xFFE8EEF0)
          .withValues(alpha: (0.35 + h4 * 0.25) * spawnFade);
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  /// Deterministic 0..1 hash from index + salt (stable across frames).
  double _hash(int i, double salt) {
    final v = math.sin(i * 127.1 + salt * 311.7) * 43758.5453;
    return v - v.floorToDouble();
  }

  void _snowdrift(Canvas canvas, Size size, double groundY, double level) {
    if (level <= 0.001) return;
    // Cover the field, not only a thin strip at the very bottom.
    final maxH = (size.height - groundY * 0.55) * 0.55;
    final h = maxH * level;
    final bottom = size.height;
    final path = Path()
      ..moveTo(0, bottom - h * 0.35)
      ..cubicTo(size.width * 0.18, bottom - h * 0.75, size.width * 0.32,
          bottom - h * 0.25, size.width * 0.48, bottom - h * 0.6)
      ..cubicTo(size.width * 0.62, bottom - h * 0.9, size.width * 0.78,
          bottom - h * 0.3, size.width, bottom - h * 0.45)
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x99B0B8B6), Color(0xAA8A9290)],
        ).createShader(Rect.fromLTWH(0, bottom - h, size.width, h)),
    );
  }

  void _twoStoryHouse(Canvas canvas, Offset base, double w) {
    final h = w * 0.95;
    final left = base.dx - w / 2;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF4A3A2A).withValues(alpha: 0.92);
    final roofP = Paint()..color = const Color(0xFF3A2A22).withValues(alpha: 0.95);
    final trim = Paint()..color = const Color(0xFF2A1E18);

    // Ground floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(left, top + h * 0.48, left + w, bottom),
        const Radius.circular(2),
      ),
      body,
    );
    // Second floor
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(
            left + w * 0.06, top + h * 0.22, left + w * 0.94, top + h * 0.5),
        const Radius.circular(2),
      ),
      body,
    );
    // Roof
    canvas.drawPath(
      Path()
        ..moveTo(left - 8, top + h * 0.26)
        ..lineTo(base.dx, top)
        ..lineTo(left + w + 8, top + h * 0.26)
        ..close(),
      roofP,
    );
    // Chimney + smoke
    final ch = Rect.fromLTWH(left + w * 0.72, top + h * 0.02, w * 0.1, h * 0.22);
    canvas.drawRect(ch, trim);
    if (animate) {
      for (var i = 0; i < 5; i++) {
        final sy = ch.top - 6 - i * 9 - (loop * 28 + i * 4) % 18;
        final sx = ch.center.dx + math.sin(loop * math.pi * 2 + i) * 3.5;
        canvas.drawCircle(
          Offset(sx, sy),
          3 + i * 0.7,
          Paint()
            ..color = const Color(0xFFB0B0B0).withValues(alpha: 0.18 - i * 0.025),
        );
      }
    }

    // Windows — lit only when house lights are on.
    final winLight = Paint()
      ..color = houseLightsOn
          ? const Color(0xFFFFD080).withValues(alpha: 0.88)
          : const Color(0xFF2A2218).withValues(alpha: 0.9);
    final glow = Paint()
      ..color = const Color(0xFFFFD080).withValues(alpha: 0.14)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);

    void window(Offset c, double ww, double hh) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: c, width: ww, height: hh),
          const Radius.circular(1.5),
        ),
        winLight,
      );
      if (houseLightsOn) {
        canvas.drawCircle(c + Offset(0, hh), ww * 1.6, glow);
      }
    }

    // 2nd floor windows
    window(Offset(base.dx - w * 0.22, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.05, top + h * 0.34), w * 0.12, h * 0.1);
    window(Offset(base.dx + w * 0.28, top + h * 0.34), w * 0.1, h * 0.1);
    // 1st floor windows
    window(Offset(base.dx - w * 0.28, top + h * 0.68), w * 0.13, h * 0.12);
    window(Offset(base.dx + w * 0.22, top + h * 0.68), w * 0.13, h * 0.12);

    // Field illumination pool — only with lights on.
    if (houseLightsOn) {
      canvas.drawCircle(
        Offset(base.dx, bottom + 12),
        w * 0.7,
        Paint()
          ..color = const Color(0xFFFFD080).withValues(alpha: 0.1)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
      );
    }

    // Door (static)
    final door = Rect.fromLTWH(
        base.dx - w * 0.06, bottom - h * 0.28, w * 0.12, h * 0.28);
    canvas.drawRect(door, Paint()..color = const Color(0xFF2A1A12));
    canvas.drawCircle(Offset(door.right - 4, door.center.dy), 1.4,
        Paint()..color = const Color(0xFFC9A86A));

    // House garland always hangs on the house; bulbs light only when enabled.
    {
      final bulbs = <Offset>[];
      for (var i = 0; i < 12; i++) {
        final t = i / 11.0;
        bulbs.add(Offset(
          left + w * (0.06 + t * 0.88),
          top + h * (0.22 + math.sin(t * math.pi) * -0.04),
        ));
      }
      for (var i = 0; i < 8; i++) {
        final t = i / 7.0;
        bulbs.add(Offset(left + w * (0.1 + t * 0.8), top + h * 0.48));
      }
      for (var i = 0; i < 6; i++) {
        final t = i / 5.0;
        bulbs.add(Offset(left + w * (0.12 + t * 0.76), top + h * 0.72));
      }

      final wire = Paint()
        ..color = const Color(0xFF6A7068).withValues(alpha: 0.55)
        ..strokeWidth = 0.9
        ..style = PaintingStyle.stroke;
      for (var i = 0; i < 11; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }
      for (var i = 12; i < 19; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }
      for (var i = 20; i < 25; i++) {
        canvas.drawLine(bulbs[i], bulbs[i + 1], wire);
      }

      const cols = [
        Color(0xFFFFE0A0),
        Color(0xFFFFB0B0),
        Color(0xFFB0E0FF),
        Color(0xFFC0FFC0),
        Color(0xFFE0C0FF),
        Color(0xFFFFD0A0),
      ];
      for (var i = 0; i < bulbs.length; i++) {
        if (houseGarlandOn) {
          final rate = 0.9 + _hash(i, 0.33) * 2.8;
          final phase = _hash(i, 0.71) * math.pi * 2;
          final wave = math.sin(loop * math.pi * 2 * rate + phase);
          final on = !animate || wave > -0.35;
          final pulse = on ? (0.75 + 0.25 * ((wave + 1) * 0.5)) : 0.12;
          final col = cols[i % cols.length];
          if (on) {
            canvas.drawCircle(
              bulbs[i],
              6,
              Paint()
                ..color = col.withValues(alpha: 0.2 * pulse)
                ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
            );
          }
          canvas.drawCircle(
            bulbs[i],
            2.4,
            Paint()..color = col.withValues(alpha: (on ? 0.9 : 0.15) * pulse),
          );
        } else {
          // Unlit bulbs still visible on the wire.
          canvas.drawCircle(
            bulbs[i],
            2.2,
            Paint()..color = const Color(0xFF3A4038).withValues(alpha: 0.85),
          );
        }
      }
    }
  }

  void _fir(Canvas canvas, Offset bottom, double height, Color color) {
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.28, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.12)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.12)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.5)
      ..lineTo(bottom.dx + height * 0.28, bottom.dy - height * 0.5)
      ..close();
    // Opaque body so trees don't look transparent at night.
    canvas.drawPath(
      path,
      Paint()
        ..color = color.withValues(alpha: 1.0)
        ..style = PaintingStyle.fill,
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = const Color(0xFF0E1A12)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );
    canvas.drawLine(
      bottom,
      Offset(bottom.dx, bottom.dy - height * 0.12),
      Paint()
        ..color = const Color(0xFF3A2A18)
        ..strokeWidth = 2.2,
    );
  }

  void _cosmos(Canvas canvas, Size size) {
    // Deep space background.
    canvas.drawRect(
      Offset.zero & size,
      Paint()..color = const Color(0xFF070714).withValues(alpha: 0.35),
    );

    // Nebulae (soft color clouds).
    final nebulaCenters = [
      (Offset(size.width * 0.25, size.height * 0.3), const Color(0xFF6A4A8A)),
      (Offset(size.width * 0.75, size.height * 0.45), const Color(0xFF4A6A9A)),
      (Offset(size.width * 0.5, size.height * 0.7), const Color(0xFF8A5A6A)),
    ];
    for (final n in nebulaCenters) {
      canvas.drawCircle(
        n.$1,
        size.width * 0.22,
        Paint()
          ..color = n.$2.withValues(alpha: 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
      );
      canvas.drawCircle(
        n.$1 + const Offset(20, -10),
        size.width * 0.12,
        Paint()
          ..color = n.$2.withValues(alpha: 0.08)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 24),
      );
    }

    // Field stars.
    for (var i = 0; i < 70; i++) {
      final x = _hash(i, 0.11) * size.width;
      final y = _hash(i, 0.37) * size.height;
      final tw = animate
          ? 0.2 + 0.4 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 * (0.5 + _hash(i, 0.2)) + i))
          : 0.3;
      canvas.drawCircle(
        Offset(x, y),
        0.6 + _hash(i, 0.5) * 1.1,
        Paint()..color = const Color(0xFFD8D0F0).withValues(alpha: tw),
      );
    }

    // Constellations rotate every 10 minutes (wall clock, works in background).
    final tenMin = DateTime.now().millisecondsSinceEpoch ~/ (10 * 60 * 1000);
    final setIdx = tenMin % 4;
    final constellations = <List<Offset>>[
      // Orion-like
      [
        const Offset(0.35, 0.25),
        const Offset(0.42, 0.28),
        const Offset(0.38, 0.36),
        const Offset(0.40, 0.42),
        const Offset(0.36, 0.48),
        const Offset(0.44, 0.48),
        const Offset(0.40, 0.55),
      ],
      // Big dipper-like
      [
        const Offset(0.55, 0.20),
        const Offset(0.62, 0.18),
        const Offset(0.68, 0.22),
        const Offset(0.72, 0.28),
        const Offset(0.70, 0.35),
        const Offset(0.62, 0.36),
        const Offset(0.58, 0.30),
      ],
      // Cassiopeia-like
      [
        const Offset(0.20, 0.35),
        const Offset(0.28, 0.30),
        const Offset(0.34, 0.36),
        const Offset(0.40, 0.28),
        const Offset(0.48, 0.34),
      ],
      // Southern cross-like
      [
        const Offset(0.65, 0.55),
        const Offset(0.65, 0.62),
        const Offset(0.65, 0.70),
        const Offset(0.60, 0.62),
        const Offset(0.70, 0.62),
      ],
    ];
    final stars = constellations[setIdx];
    final line = Paint()
      ..color = const Color(0xFFB0A8D8).withValues(alpha: 0.35)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    final pts = [for (final s in stars) Offset(s.dx * size.width, s.dy * size.height)];
    for (var i = 0; i < pts.length - 1; i++) {
      canvas.drawLine(pts[i], pts[i + 1], line);
    }
    for (final p in pts) {
      canvas.drawCircle(
        p,
        2.2,
        Paint()..color = const Color(0xFFE8E0FF).withValues(alpha: 0.9),
      );
      canvas.drawCircle(
        p,
        5,
        Paint()
          ..color = const Color(0xFFC0B8F0).withValues(alpha: 0.15)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
      );
    }

    // Falling comets.
    if (animate) {
      final sec = DateTime.now().millisecondsSinceEpoch / 1000.0;
      for (var i = 0; i < 3; i++) {
        final period = 9.0 + i * 3.5;
        final t = (sec / period + _hash(i, 0.6)) % 1.0;
        final x0 = size.width * (0.2 + _hash(i, 0.3) * 0.6);
        final y0 = size.height * (0.05 + _hash(i, 0.5) * 0.2);
        final x = x0 + t * size.width * 0.35;
        final y = y0 + t * size.height * 0.45;
        final tail = Paint()
          ..shader = LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              const Color(0xFFEEE8FF).withValues(alpha: 0.0),
              const Color(0xFFD0C8F8).withValues(alpha: 0.55),
            ],
          ).createShader(Rect.fromPoints(
              Offset(x - 28, y - 18), Offset(x, y)));
        canvas.drawLine(
          Offset(x - 28, y - 18),
          Offset(x, y),
          Paint()
            ..shader = tail.shader
            ..strokeWidth = 2.0
            ..strokeCap = StrokeCap.round,
        );
        canvas.drawCircle(
          Offset(x, y),
          2.5,
          Paint()..color = const Color(0xFFF0ECFF).withValues(alpha: 0.9),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _AtmospherePainter old) =>
      old.loop != loop ||
      old.climate != climate ||
      old.spider != spider ||
      old.houseGarlandOn != houseGarlandOn ||
      old.houseLightsOn != houseLightsOn ||
      old.fieldGlow != fieldGlow ||
      old.kind != kind;
}
