import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Low-contrast seasonal details painted behind every app page.
/// All effects are vector-based and remain lightweight on older devices.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  AnimationController? _snowAccumulationController;

  bool get _isSeasonal => widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _shouldAnimate => _isSeasonal && widget.animationsEnabled;

  bool get _shouldAccumulateSnow =>
      _shouldAnimate &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  @override
  void initState() {
    super.initState();
    _syncController();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _syncController();
    }
  }

  void _syncController() {
    if (_shouldAnimate) {
      _controller ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 24),
      );
      if (!_controller!.isAnimating) _controller!.repeat();

      if (_shouldAccumulateSnow) {
        _snowAccumulationController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 10),
        );
        if (!_snowAccumulationController!.isAnimating &&
            _snowAccumulationController!.value < 1) {
          _snowAccumulationController!.forward();
        }
      } else {
        _snowAccumulationController?.stop();
      }
    } else {
      _controller?.stop();
      _snowAccumulationController?.stop();
      _controller?.value = 0;
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    _snowAccumulationController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: Listenable.merge([
        _controller ?? const AlwaysStoppedAnimation<double>(0),
        _snowAccumulationController ??
            const AlwaysStoppedAnimation<double>(0),
      ]),
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _ThemeAtmospherePainter(
              kind: widget.themeKind,
              progress: _controller?.value ?? 0,
              topInset: topInset,
              animate: _shouldAnimate,
              snowAccumulation: _snowAccumulationController?.value ?? 0,
            ),
            child: const SizedBox.expand(),
          ),
        ),
      ),
    );
  }
}

class _ThemeAtmospherePainter extends CustomPainter {
  const _ThemeAtmospherePainter({
    required this.kind,
    required this.progress,
    required this.topInset,
    required this.animate,
    required this.snowAccumulation,
  });

  final ThemeKind kind;
  final double progress;
  final double topInset;
  final bool animate;
  final double snowAccumulation;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.light:
      case ThemeKind.dark:
        return;
      case ThemeKind.halloween:
        _paintHalloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _paintChristmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _paintCosmos(canvas, size);
        break;
    }
  }

  void _paintHalloween(Canvas canvas, Size size) {
    final base = const Color(0xFFB27B54);
    final flicker = animate
        ? (0.72 + 0.28 * math.sin(progress * math.pi * 2))
        : 0.78;

    // Soft ground / field strip at the bottom so the castle sits on a landscape.
    final fieldPaint = Paint()
      ..color = const Color(0xFF2C2428).withValues(alpha: 0.35)
      ..style = PaintingStyle.fill;
    final fieldTop = size.height * 0.62;
    final field = Path()
      ..moveTo(0, fieldTop)
      ..quadraticBezierTo(size.width * 0.25, fieldTop - 12, size.width * 0.5, fieldTop - 4)
      ..quadraticBezierTo(size.width * 0.75, fieldTop + 8, size.width, fieldTop - 6)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(field, fieldPaint);

    // Distant castle on the horizon (small, far away, slightly right).
    final castleCenter = Offset(size.width * 0.78, fieldTop - 2);
    _drawCastle(canvas, castleCenter, size.width * 0.16);

    // 100 barely-visible dots streaming toward / behind the castle
    // (subtle flock of bats — almost imperceptible individual shapes).
    final dotPaint = Paint()
      ..color = const Color(0xFF1A1518).withValues(alpha: 0.22)
      ..style = PaintingStyle.fill;

    const flockCount = 100;
    for (var i = 0; i < flockCount; i++) {
      final seed = i * 1.6180339887;
      final lane = (i % 11) / 10.0;
      final baseY = topInset + 36 + lane * (fieldTop - topInset - 50);
      final speed = 0.4 + (i % 7) * 0.08;
      final t = animate
          ? ((progress * speed) + seed * 0.031) % 1.0
          : (0.1 + (i % 13) * 0.06);
      // Fly from right toward the castle area, then continue past it.
      final x = size.width * (1.12 - t * 1.25);
      final y = baseY +
          math.sin(t * math.pi * 2.6 + seed) * 14 +
          math.sin(seed * 1.7) * 8;
      final r = 0.7 + (i % 5) * 0.25;
      canvas.drawCircle(Offset(x, y), r, dotPaint);
    }

    // Fine threads and three small spiders.
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.30)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.78
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < 3; i++) {
      final x = size.width * (0.18 + i * 0.22);
      final travel = 42.0 + i * 20.0;
      final descent = animate
          ? (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i * 1.7)) * travel
          : travel * 0.55;
      final y = topInset + 60 + i * 36.0 + descent;
      canvas.drawLine(Offset(x, topInset + 28), Offset(x, y - 5), webPaint);
      canvas.drawCircle(
        Offset(x, topInset + 28),
        1.5,
        Paint()..color = webPaint.color,
      );
      _drawSpider(
        canvas,
        Offset(x, y),
        0.72 + (i % 2) * 0.10,
        animate ? math.sin(progress * math.pi * 2 + i) : 0,
        webPaint,
      );
    }

    _drawPumpkin(
      canvas,
      Offset(25, size.height * 0.76),
      15,
      base.withValues(alpha: 0.58 * flicker),
      base.withValues(alpha: 0.10 * flicker),
    );
    _drawPumpkin(
      canvas,
      Offset(size.width - 28, size.height * 0.68),
      12,
      base.withValues(alpha: 0.42 * flicker),
      base.withValues(alpha: 0.07 * flicker),
    );
  }

  /// Small distant castle silhouette sitting on the field horizon.
  void _drawCastle(Canvas canvas, Offset anchor, double width) {
    final paint = Paint()
      ..color = const Color(0xFF2A2228).withValues(alpha: 0.50)
      ..style = PaintingStyle.fill;
    final h = width * 1.05;
    final left = anchor.dx - width * 0.5;
    final bottom = anchor.dy;
    final top = bottom - h;

    final path = Path();
    path.moveTo(left + width * 0.15, bottom);
    path.lineTo(left + width * 0.15, top + h * 0.32);
    // Left tower
    path.lineTo(left + width * 0.02, top + h * 0.32);
    path.lineTo(left + width * 0.02, top + h * 0.10);
    path.lineTo(left + width * 0.10, top);
    path.lineTo(left + width * 0.20, top + h * 0.10);
    path.lineTo(left + width * 0.20, top + h * 0.26);
    // Battlements
    path.lineTo(left + width * 0.30, top + h * 0.26);
    path.lineTo(left + width * 0.30, top + h * 0.14);
    path.lineTo(left + width * 0.38, top + h * 0.14);
    path.lineTo(left + width * 0.38, top + h * 0.26);
    path.lineTo(left + width * 0.48, top + h * 0.26);
    path.lineTo(left + width * 0.48, top + h * 0.14);
    path.lineTo(left + width * 0.56, top + h * 0.14);
    path.lineTo(left + width * 0.56, top + h * 0.26);
    // Right tower
    path.lineTo(left + width * 0.70, top + h * 0.26);
    path.lineTo(left + width * 0.70, top + h * 0.10);
    path.lineTo(left + width * 0.80, top);
    path.lineTo(left + width * 0.92, top + h * 0.10);
    path.lineTo(left + width * 0.92, top + h * 0.32);
    path.lineTo(left + width * 0.82, top + h * 0.32);
    path.lineTo(left + width * 0.82, bottom);
    path.close();
    canvas.drawPath(path, paint);
  }

  void _drawSpider(
    Canvas canvas,
    Offset center,
    double scale,
    double legMotion,
    Paint webPaint,
  ) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);

    final legs = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.05
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final swing = legMotion * 2.2;
    final legPath = Path()
      ..moveTo(-2, -2)
      ..quadraticBezierTo(-7 - swing, -8, -12 - swing, -7)
      ..lineTo(-15 - swing, -11)
      ..moveTo(-3, 0)
      ..quadraticBezierTo(-10 - swing, -1, -13 - swing, 3)
      ..lineTo(-17 - swing, 4)
      ..moveTo(-3, 2)
      ..quadraticBezierTo(-9 - swing, 6, -11 - swing, 11)
      ..lineTo(-15 - swing, 13)
      ..moveTo(-2, 3)
      ..quadraticBezierTo(-5 - swing, 10, -6 - swing, 14)
      ..lineTo(-9 - swing, 16)
      ..moveTo(2, -2)
      ..quadraticBezierTo(7 + swing, -8, 12 + swing, -7)
      ..lineTo(15 + swing, -11)
      ..moveTo(3, 0)
      ..quadraticBezierTo(10 + swing, -1, 13 + swing, 3)
      ..lineTo(17 + swing, 4)
      ..moveTo(3, 2)
      ..quadraticBezierTo(9 + swing, 6, 11 + swing, 11)
      ..lineTo(15 + swing, 13)
      ..moveTo(2, 3)
      ..quadraticBezierTo(5 + swing, 10, 6 + swing, 14)
      ..lineTo(9 + swing, 16);
    canvas.drawPath(legPath, legs);

    final abdomenPaint = Paint()
      ..color = webPaint.color.withValues(alpha: webPaint.color.a * 1.35)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 5), width: 9, height: 12),
      abdomenPaint,
    );
    canvas.drawCircle(const Offset(0, -2), 3.2, abdomenPaint);
    canvas.drawLine(const Offset(-1.5, -6), const Offset(-2.5, -8), legs);
    canvas.drawLine(const Offset(1.5, -6), const Offset(2.5, -8), legs);
    canvas.restore();
  }

  void _drawPumpkin(
    Canvas canvas,
    Offset center,
    double radius,
    Color strokeColor,
    Color fillColor,
  ) {
    final outline = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final r = radius;
    final halo = Paint()
      ..color = strokeColor.withValues(alpha: strokeColor.a * 0.24)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * 0.75);
    canvas.drawCircle(center, radius * 1.35, halo);
    final shape = Path()
      ..moveTo(center.dx, center.dy - r * 0.72)
      ..cubicTo(center.dx - r * 0.95, center.dy - r * 1.05,
          center.dx - r * 1.15, center.dy - r * 0.25, center.dx - r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx - r * 0.50, center.dy + r * 1.05,
          center.dx + r * 0.50, center.dy + r * 1.05, center.dx + r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx + r * 1.15, center.dy - r * 0.25,
          center.dx + r * 0.95, center.dy - r * 1.05, center.dx, center.dy - r * 0.72)
      ..close();
    canvas.drawPath(shape, fill);
    canvas.drawPath(shape, outline);
    canvas.drawLine(
      Offset(center.dx, center.dy - r * 0.72),
      Offset(center.dx + r * 0.10, center.dy - r * 1.12),
      outline,
    );
    final face = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round;
    final facePath = Path()
      ..moveTo(center.dx - r * 0.47, center.dy - r * 0.02)
      ..lineTo(center.dx - r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx - r * 0.02, center.dy - r * 0.02)
      ..moveTo(center.dx + r * 0.02, center.dy - r * 0.02)
      ..lineTo(center.dx + r * 0.22, center.dy - r * 0.30)
      ..lineTo(center.dx + r * 0.47, center.dy - r * 0.02)
      ..moveTo(center.dx - r * 0.34, center.dy + r * 0.30)
      ..quadraticBezierTo(center.dx, center.dy + r * 0.57,
          center.dx + r * 0.34, center.dy + r * 0.30);
    canvas.drawPath(facePath, face);
  }

  void _paintChristmas(Canvas canvas, Size size) {
    final wire = Paint()
      ..color = const Color(0xFF829184).withValues(alpha: 0.52)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final garlandY = topInset + 25;
    final garland = Path()
      ..moveTo(0, garlandY)
      ..cubicTo(size.width * 0.22, garlandY + 32, size.width * 0.30,
          garlandY - 5, size.width * 0.50, garlandY + 15)
      ..cubicTo(size.width * 0.70, garlandY + 35, size.width * 0.80,
          garlandY - 3, size.width, garlandY + 16);
    canvas.drawPath(garland, wire);

    const bulbColors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
    ];
    for (var i = 0; i < 13; i++) {
      final x = size.width * i / 12;
      final y = garlandY + 13 + math.sin(i / 12 * math.pi * 2) * 7;
      final pulse = animate
          ? 0.58 + 0.25 * math.sin(progress * math.pi * 2 + i * 0.8)
          : 0.62;
      final bulb = Paint()
        ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), 2.4, bulb);
      if (i % 3 == 0) {
        final halo = Paint()
          ..color = bulbColors[i % bulbColors.length].withValues(alpha: pulse * 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
        canvas.drawCircle(Offset(x, y), 5, halo);
      }
    }

    _drawFirTree(canvas, Offset(20, size.height - 22), 27, const Color(0xFF829184).withValues(alpha: 0.20));
    _drawFirTree(canvas, Offset(size.width - 20, size.height - 22), 23, const Color(0xFF829184).withValues(alpha: 0.16));

    // A denser, more varied snowfall: fine drifting flakes plus larger
    // six-armed snow crystals distributed over the full display.
    final snow = Paint()
      ..color = const Color(0xFFDCE6E0).withValues(alpha: 0.48);
    final crystalPaint = Paint()
      ..color = const Color(0xFFE7F0EA).withValues(alpha: 0.52)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.85
      ..strokeCap = StrokeCap.round;

    for (var i = 0; i < 104; i++) {
      final x = ((i * 73.0 + 19) % size.width).toDouble();
      final baseY = ((i * 47.0 + 13) % size.height).toDouble();
      final screenPasses = 1 + (i % 3);
      final y = ((baseY +
                  (animate ? progress * size.height * screenPasses : 0)) %
              size.height)
          .toDouble();
      final sway = math.sin(i * 0.7 + progress * math.pi * 2) *
          (1.8 + (i % 4) * 0.55);
      final radius = 0.75 + (i % 5) * 0.28;
      snow.color = const Color(0xFFDCE6E0)
          .withValues(alpha: 0.30 + (i % 4) * 0.055);
      canvas.drawCircle(Offset(x + sway, y), radius, snow);

      if (i % 6 == 0) {
        final crystalRadius = 2.2 + (i % 3) * 0.55;
        final center = Offset(x + sway, y);
        for (var arm = 0; arm < 3; arm++) {
          final angle = arm * math.pi / 3;
          final dx = math.cos(angle) * crystalRadius;
          final dy = math.sin(angle) * crystalRadius;
          canvas.drawLine(
            Offset(center.dx - dx, center.dy - dy),
            Offset(center.dx + dx, center.dy + dy),
            crystalPaint,
          );
        }
      }
    }

    _drawSnowdrift(canvas, size, snowAccumulation);
  }

  void _drawSnowdrift(Canvas canvas, Size size, double growth) {
    if (growth <= 0 || size.isEmpty) return;

    final normalizedGrowth = growth.clamp(0.0, 1.0).toDouble();
    final maxHeight = math.min(size.height * 0.14, 92.0);
    final height = maxHeight * normalizedGrowth;
    if (height < 0.5) return;

    final bottom = size.height;
    final ridge = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(
        size.width * 0.12, bottom - height * 0.66,
        size.width * 0.20, bottom - height * 0.12,
        size.width * 0.36, bottom - height * 0.38,
      )
      ..cubicTo(
        size.width * 0.51, bottom - height * 0.70,
        size.width * 0.59, bottom - height * 0.14,
        size.width * 0.74, bottom - height * 0.42,
      )
      ..cubicTo(
        size.width * 0.86, bottom - height * 0.62,
        size.width * 0.94, bottom - height * 0.20,
        size.width, bottom - height * 0.39,
      )
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();

    final fill = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xDDF4FAF8),
          Color(0xD9E1EBE9),
          Color(0xE8C9D5D7),
        ],
        stops: [0, 0.48, 1],
      ).createShader(
        Rect.fromLTWH(0, bottom - height, size.width, height),
      );
    canvas.drawPath(ridge, fill);

    final ridgeLine = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(
        size.width * 0.12, bottom - height * 0.66,
        size.width * 0.20, bottom - height * 0.12,
        size.width * 0.36, bottom - height * 0.38,
      )
      ..cubicTo(
        size.width * 0.51, bottom - height * 0.70,
        size.width * 0.59, bottom - height * 0.14,
        size.width * 0.74, bottom - height * 0.42,
      )
      ..cubicTo(
        size.width * 0.86, bottom - height * 0.62,
        size.width * 0.94, bottom - height * 0.20,
        size.width, bottom - height * 0.39,
      );
    final ridgePaint = Paint()
      ..color = const Color(0xDDF8FFFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(ridgeLine, ridgePaint);

    // Fine grains appear progressively along the ridge as the snow gathers.
    final grainPaint = Paint()..style = PaintingStyle.fill;
    final grainCount = (normalizedGrowth * 44).round();
    for (var i = 0; i < grainCount; i++) {
      final x = ((i * 47.0 + 17) % size.width).toDouble();
      final wave = 0.38 + 0.12 * math.sin(i * 1.13);
      final y = bottom - height * wave - (i % 4) * 1.4;
      grainPaint.color = const Color(0xFFF9FFFF)
          .withValues(alpha: 0.32 + (i % 3) * 0.12);
      canvas.drawCircle(
        Offset(x, y),
        0.55 + (i % 3) * 0.22,
        grainPaint,
      );
    }
  }

  void _drawFirTree(Canvas canvas, Offset bottom, double height, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.27, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx + height * 0.27, bottom.dy - height * 0.52)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawLine(bottom, Offset(bottom.dx, bottom.dy - height * 0.14), paint);
  }

  void _paintCosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = ((i * 67.0 + 11) % size.width).toDouble();
      final y = ((i * 91.0 + 37) % size.height).toDouble();
      final twinkle = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i))
          : 0.23;
      final star = Paint()
        ..color = const Color(0xFFB9B1D7).withValues(alpha: twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.45 : 0.8, star);
    }

    final center = Offset(size.width - 44, topInset + 116);
    final orbitPaint = Paint()
      ..color = const Color(0xFF9991BE).withValues(alpha: 0.20)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 66, height: 23),
      orbitPaint,
    );
    final planetPaint = Paint()
      ..color = const Color(0xFF9C94BD).withValues(alpha: 0.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;
    canvas.drawCircle(center, 9, planetPaint);

    // Multiple staggered meteors replace the single comet: each has a short
    // luminous head and a tapered diagonal trail, with no change to the theme.
    for (var i = 0; i < 8; i++) {
      final phase = (progress * 3.15 + i * 0.173) % 1.0;
      if (!animate || phase >= 0.28) continue;

      final t = phase / 0.28;
      final startX = ((i * 137.0 + 31) % (size.width + 90)) - 45;
      final startY = topInset + 38 + (i * 59.0) % 250;
      final end = Offset(startX + 112 * t, startY + 76 * t);
      final tail = Offset(end.dx - 27, end.dy - 18);
      final fade = (1 - t * 0.58).clamp(0.0, 1.0).toDouble();

      final glow = Paint()
        ..color = const Color(0xFFBFB7EA).withValues(alpha: 0.15 * fade)
        ..strokeWidth = 4.2
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = const Color(0xFFE0DAFF).withValues(alpha: 0.72 * fade)
        ..strokeWidth = 1.15
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, end, glow);
      canvas.drawLine(tail, end, core);
      canvas.drawCircle(
        end,
        1.65,
        Paint()
          ..color = const Color(0xFFF0ECFF).withValues(alpha: 0.72 * fade),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ThemeAtmospherePainter oldDelegate) =>
      oldDelegate.kind != kind ||
      oldDelegate.progress != progress ||
      oldDelegate.topInset != topInset ||
      oldDelegate.animate != animate ||
      oldDelegate.snowAccumulation != snowAccumulation;
}
