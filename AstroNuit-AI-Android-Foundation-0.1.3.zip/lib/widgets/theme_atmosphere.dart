import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Seasonal atmosphere: decorations behind pages, interactive overlays on top.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
    this.child,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;
  final Widget? child;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  AnimationController? _loop; // continuous 20s loop for falling snow / flicker
  AnimationController? _snowAccum; // 5 min fill
  AnimationController? _snowClear; // 10s out + 2min clear + 10s in
  AnimationController? _spider;
  AnimationController? _garlandAnim;

  int _leftGlow = 0;
  int _rightGlow = 0;
  bool _screamer = false;
  bool _aaaButton = false;
  bool _garlandCollapsed = false;

  bool get _seasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _anim => _seasonal && widget.animationsEnabled;

  bool get _christmas =>
      _anim &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _halloween => _anim && widget.themeKind == ThemeKind.halloween;

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _sync();
      if (widget.themeKind != ThemeKind.halloween) {
        _leftGlow = 0;
        _rightGlow = 0;
        _screamer = false;
        _aaaButton = false;
      }
      if (widget.themeKind != ThemeKind.christmas) {
        _garlandCollapsed = false;
      }
    }
  }

  void _sync() {
    if (_anim) {
      _loop ??= AnimationController(
          vsync: this, duration: const Duration(seconds: 20))
        ..repeat();
      if (!_loop!.isAnimating) _loop!.repeat();

      if (_christmas) {
        _snowAccum ??= AnimationController(
            vsync: this, duration: const Duration(minutes: 5));
        // 10s exit + 120s clear + 10s return = 140s
        _snowClear ??= AnimationController(
            vsync: this, duration: const Duration(seconds: 140));
        _snowAccum!.removeStatusListener(_onFull);
        _snowClear!.removeStatusListener(_onCleared);
        _snowAccum!.addStatusListener(_onFull);
        _snowClear!.addStatusListener(_onCleared);
        if (!_snowAccum!.isAnimating &&
            _snowAccum!.value < 1 &&
            (_snowClear?.value ?? 0) == 0) {
          _snowAccum!.forward();
        }
        _garlandAnim ??= AnimationController(
            vsync: this, duration: const Duration(milliseconds: 900));
      } else {
        _snowAccum?.stop();
        _snowClear?.stop();
      }

      if (_halloween) {
        _spider ??= AnimationController(
            vsync: this, duration: const Duration(minutes: 41))
          ..repeat();
        if (!_spider!.isAnimating) _spider!.repeat();
      } else {
        _spider?.stop();
      }
    } else {
      _loop?.stop();
      _snowAccum?.stop();
      _snowClear?.stop();
      _spider?.stop();
      _loop?.value = 0;
    }
  }

  void _onFull(AnimationStatus s) {
    if (s == AnimationStatus.completed && mounted) {
      _snowClear?.forward(from: 0);
    }
  }

  void _onCleared(AnimationStatus s) {
    if (s == AnimationStatus.completed && mounted) {
      _snowClear?.value = 0;
      _snowAccum?.forward(from: 0);
    }
  }

  void _tapLeftPumpkin() {
    if (_screamer) return;
    setState(() => _leftGlow = (_leftGlow + 1) % 6);
  }

  void _tapRightPumpkin() {
    if (_screamer) return;
    setState(() {
      if (_rightGlow < 4) {
        _rightGlow++;
      } else {
        _rightGlow = 4;
        _screamer = true;
        _aaaButton = false;
      }
    });
    if (_screamer) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && _screamer) setState(() => _aaaButton = true);
      });
    }
  }

  void _dismissScreamer() {
    setState(() {
      _screamer = false;
      _aaaButton = false;
      _leftGlow = 0;
      _rightGlow = 0;
    });
  }

  void _toggleGarland() {
    if (_garlandCollapsed) {
      _garlandAnim!.reverse().then((_) {
        if (mounted) setState(() => _garlandCollapsed = false);
      });
      setState(() {});
    } else {
      setState(() => _garlandCollapsed = true);
      _garlandAnim!.forward(from: 0);
    }
  }

  @override
  void dispose() {
    _snowAccum?.removeStatusListener(_onFull);
    _snowClear?.removeStatusListener(_onCleared);
    _loop?.dispose();
    _snowAccum?.dispose();
    _snowClear?.dispose();
    _spider?.dispose();
    _garlandAnim?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: Listenable.merge([
        _loop ?? const AlwaysStoppedAnimation(0.0),
        _snowAccum ?? const AlwaysStoppedAnimation(0.0),
        _snowClear ?? const AlwaysStoppedAnimation(0.0),
        _spider ?? const AlwaysStoppedAnimation(0.0),
        _garlandAnim ?? const AlwaysStoppedAnimation(0.0),
      ]),
      builder: (context, _) {
        final accum = _snowAccum?.value ?? 0.0;
        final clear = _snowClear?.value ?? 0.0;
        // Drift only after snow has had time to reach the ground (~12% of fill).
        final landed = ((accum - 0.12) / 0.88).clamp(0.0, 1.0);
        // During clear, snow is thrown off-screen over 2 minutes (middle phase).
        final clearWork = clear <= 0
            ? 0.0
            : clear < 10 / 140
                ? 0.0
                : clear > 130 / 140
                    ? 1.0
                    : ((clear - 10 / 140) / (120 / 140)).clamp(0.0, 1.0);
        final driftLevel =
            clear > 0 ? (landed * (1.0 - clearWork)).clamp(0.0, 1.0) : landed;

        final leftPumpkin = Offset(32, size.height * 0.76);
        final rightPumpkin = Offset(size.width - 36, size.height * 0.70);

        return Stack(
          fit: StackFit.expand,
          clipBehavior: Clip.none,
          children: [
            // Paint layer (non-interactive).
            IgnorePointer(
              child: CustomPaint(
                painter: _AtmospherePainter(
                  kind: widget.themeKind,
                  loop: _loop?.value ?? 0,
                  topInset: topInset,
                  animate: _anim,
                  accum: accum,
                  clear: clear,
                  driftLevel: driftLevel,
                  spider: _spider?.value ?? 0,
                  leftGlow: _leftGlow,
                  rightGlow: _rightGlow,
                  garlandT: _garlandCollapsed
                      ? (_garlandAnim?.value ?? 1.0)
                      : 0.0,
                  drawPumpkins: false, // drawn as widgets for hit-testing
                ),
                size: size,
              ),
            ),

            // App content.
            if (widget.child != null) widget.child!,

            // --- Halloween: real tappable pumpkin widgets ---
            if (widget.themeKind == ThemeKind.halloween) ...[
              Positioned(
                left: leftPumpkin.dx - 28,
                top: leftPumpkin.dy - 28,
                width: 56,
                height: 56,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapLeftPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinWidgetPainter(
                      glow: _leftGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin((_loop?.value ?? 0) * math.pi * 2)
                          : 0.8,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: rightPumpkin.dx - 24,
                top: rightPumpkin.dy - 24,
                width: 48,
                height: 48,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _tapRightPumpkin,
                  child: CustomPaint(
                    painter: _PumpkinWidgetPainter(
                      glow: _rightGlow,
                      flicker: _anim
                          ? 0.7 + 0.3 * math.sin((_loop?.value ?? 0) * math.pi * 2 + 1)
                          : 0.8,
                    ),
                  ),
                ),
              ),
            ],

            // --- Christmas: tappable garland / restore button ---
            if (widget.themeKind == ThemeKind.christmas) ...[
              if (!_garlandCollapsed || (_garlandAnim?.isAnimating ?? false))
                Positioned.fill(
                  child: GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTapUp: (d) {
                      // Only collapse if tap is near the top garland band.
                      if (!_garlandCollapsed && d.localPosition.dy < topInset + 70) {
                        _toggleGarland();
                      }
                    },
                    child: const SizedBox.expand(),
                  ),
                ),
              if (_garlandCollapsed && !(_garlandAnim?.isAnimating ?? false))
                Positioned(
                  right: 16,
                  bottom: 24,
                  child: GestureDetector(
                    onTap: _toggleGarland,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2A332E).withValues(alpha: 0.92),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: const Color(0xFFB79A76).withValues(alpha: 0.7),
                        ),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.lightbulb_outline,
                              color: Color(0xFFB79A76), size: 18),
                          SizedBox(width: 6),
                          Text('Гирлянда',
                              style: TextStyle(
                                  color: Color(0xFFE8EDE8), fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],

            if (_screamer)
              Positioned.fill(
                child: _ScreamerOverlay(
                  showButton: _aaaButton,
                  onDismiss: _dismissScreamer,
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Pumpkin widget painter (interactive)
// ---------------------------------------------------------------------------

class _PumpkinWidgetPainter extends CustomPainter {
  _PumpkinWidgetPainter({required this.glow, required this.flicker});
  final int glow;
  final double flicker;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.shortestSide * 0.42;
    final base = const Color(0xFFB27B54);
    final glowA = 0.08 + glow * 0.16;
    if (glow > 0) {
      canvas.drawCircle(
        c,
        r * (1.3 + glow * 0.2),
        Paint()
          ..color = const Color(0xFFFFB040).withValues(alpha: glowA * flicker)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 6.0 + glow * 2),
      );
    }
    final fill = Paint()
      ..color = const Color(0xFFFFB040).withValues(alpha: glowA * flicker)
      ..style = PaintingStyle.fill;
    final stroke = Paint()
      ..color = base.withValues(alpha: 0.75)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4;
    final path = Path()
      ..moveTo(c.dx, c.dy - r * 0.7)
      ..cubicTo(c.dx - r, c.dy - r, c.dx - r * 1.1, c.dy,
          c.dx - r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx - r * 0.4, c.dy + r, c.dx + r * 0.4, c.dy + r,
          c.dx + r * 0.9, c.dy + r * 0.5)
      ..cubicTo(c.dx + r * 1.1, c.dy, c.dx + r, c.dy - r, c.dx, c.dy - r * 0.7)
      ..close();
    canvas.drawPath(path, fill);
    canvas.drawPath(path, stroke);
    canvas.drawLine(
        Offset(c.dx, c.dy - r * 0.7), Offset(c.dx, c.dy - r * 1.05), stroke);
  }

  @override
  bool shouldRepaint(covariant _PumpkinWidgetPainter old) =>
      old.glow != glow || old.flicker != flicker;
}

// ---------------------------------------------------------------------------
// Screamer
// ---------------------------------------------------------------------------

class _ScreamerOverlay extends StatelessWidget {
  const _ScreamerOverlay({required this.showButton, required this.onDismiss});
  final bool showButton;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.92),
      child: Stack(
        fit: StackFit.expand,
        children: [
          CustomPaint(painter: _KnifePainter(), child: const SizedBox.expand()),
          if (showButton)
            Align(
              alignment: const Alignment(0, 0.55),
              child: _AaaButton(onPressed: onDismiss),
            ),
        ],
      ),
    );
  }
}

class _AaaButton extends StatefulWidget {
  const _AaaButton({required this.onPressed});
  final VoidCallback onPressed;
  @override
  State<_AaaButton> createState() => _AaaButtonState();
}

class _AaaButtonState extends State<_AaaButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 900))
        ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, child) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          child!,
          SizedBox(
            height: 36,
            width: 160,
            child: CustomPaint(painter: _DripsPainter(_c.value)),
          ),
        ],
      ),
      child: FilledButton(
        onPressed: widget.onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF8B1515),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
        ),
        child: const Text('ААААААААААА!',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
      ),
    );
  }
}

class _DripsPainter extends CustomPainter {
  _DripsPainter(this.p);
  final double p;
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFB01010);
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.15 + i * 0.18);
      final fall = (p + i * 0.17) % 1.0;
      final y = fall * size.height;
      canvas.drawCircle(Offset(x, y), 2.2, paint);
      canvas.drawOval(
          Rect.fromCenter(center: Offset(x, y - 4), width: 1.6, height: 6 + fall * 8),
          paint);
    }
  }

  @override
  bool shouldRepaint(covariant _DripsPainter old) => old.p != p;
}

class _KnifePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width * 0.5;
    final cy = size.height * 0.38;
    final blade = Path()
      ..moveTo(cx - 18, cy - 40)
      ..lineTo(cx + 22, cy - 160)
      ..lineTo(cx + 38, cy - 150)
      ..lineTo(cx + 8, cy - 20)
      ..close();
    canvas.drawPath(
      blade,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFE8E8EC), Color(0xFF9A9AA2)],
        ).createShader(Rect.fromLTWH(cx - 40, cy - 170, 80, 160)),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(cx - 6, cy + 30), width: 28, height: 70),
          const Radius.circular(4)),
      Paint()..color = const Color(0xFF3A2018),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ---------------------------------------------------------------------------
// Main painter
// ---------------------------------------------------------------------------

class _AtmospherePainter extends CustomPainter {
  _AtmospherePainter({
    required this.kind,
    required this.loop,
    required this.topInset,
    required this.animate,
    required this.accum,
    required this.clear,
    required this.driftLevel,
    required this.spider,
    required this.leftGlow,
    required this.rightGlow,
    required this.garlandT,
    required this.drawPumpkins,
  });

  final ThemeKind kind;
  final double loop;
  final double topInset;
  final bool animate;
  final double accum;
  final double clear;
  final double driftLevel;
  final double spider;
  final int leftGlow;
  final int rightGlow;
  final double garlandT; // 0 = up, 1 = collapsed to corner
  final bool drawPumpkins;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.halloween:
        _halloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _christmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _cosmos(canvas, size);
        break;
      default:
        break;
    }
  }

  // ---- Halloween (no pumpkins here — widgets handle them) ----

  void _halloween(Canvas canvas, Size size) {
    final flicker =
        animate ? 0.72 + 0.28 * math.sin(loop * math.pi * 2) : 0.78;

    // Moon
    final moon = Offset(size.width * 0.16, topInset + 88);
    canvas.drawCircle(
        moon,
        58,
        Paint()
          ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.16)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 36));
    canvas.drawCircle(
        moon, 34, Paint()..color = const Color(0xFFEDE6CF).withValues(alpha: 0.92));
    for (final s in [
      (const Offset(-10, 6), 9.0, 0.28),
      (const Offset(12, -8), 7.5, 0.22),
      (const Offset(-4, -14), 5.5, 0.18),
      (const Offset(8, 12), 6.0, 0.20),
      (const Offset(2, 2), 11.0, 0.12),
    ]) {
      canvas.drawCircle(
          moon + s.$1,
          s.$2,
          Paint()
            ..color = const Color(0xFFC9BFA0).withValues(alpha: s.$3));
    }

    final fieldTop = size.height * 0.62;
    canvas.drawRect(
      Rect.fromLTRB(0, fieldTop, size.width, size.height),
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            const Color(0xFF3A322C).withValues(alpha: 0.5),
            const Color(0xFF1C1816).withValues(alpha: 0.85),
          ],
        ).createShader(Rect.fromLTRB(0, fieldTop, size.width, size.height)),
    );

    _gothicCastle(canvas, Offset(size.width * 0.74, fieldTop), size.width * 0.32, flicker);
    _spiderLife(canvas, size);

    // Static pumpkins only if drawPumpkins (we use widgets instead).
  }

  void _spiderLife(Canvas canvas, Size size) {
    if (!animate) return;
    final totalMin = spider * 41.0;
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.42)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round;
    final anchor = Offset(size.width - 18, size.height - 28);
    const webRadius = 52.0;

    void orb(double c) {
      for (var i = 0; i < 8; i++) {
        final a = -math.pi * 0.15 - i * (math.pi * 0.85 / 7);
        final len = webRadius * c;
        canvas.drawLine(
            anchor, anchor + Offset(math.cos(a) * len, -math.sin(a).abs() * len - 4), webPaint);
      }
      final rings = (5 * c).ceil().clamp(0, 5);
      for (var r = 1; r <= rings; r++) {
        final rr = webRadius * r / 5;
        final path = Path();
        for (var i = 0; i <= 10; i++) {
          final a = -math.pi * 0.15 - i * (math.pi * 0.85 / 10);
          final p = anchor + Offset(math.cos(a) * rr, -math.sin(a).abs() * rr - 4);
          if (i == 0) {
            path.moveTo(p.dx, p.dy);
          } else {
            path.lineTo(p.dx, p.dy);
          }
        }
        canvas.drawPath(path, webPaint);
      }
    }

    void spiderAt(Offset c, double scale, double motion) {
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.scale(scale);
      final legs = Paint()
        ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.55)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.1
        ..strokeCap = StrokeCap.round;
      final sw = motion * 2.4;
      final path = Path()
        ..moveTo(-2, -2)
        ..quadraticBezierTo(-7 - sw, -8, -12 - sw, -7)
        ..moveTo(2, -2)
        ..quadraticBezierTo(7 + sw, -8, 12 + sw, -7)
        ..moveTo(-3, 2)
        ..quadraticBezierTo(-9 - sw, 6, -15 - sw, 13)
        ..moveTo(3, 2)
        ..quadraticBezierTo(9 + sw, 6, 15 + sw, 13);
      canvas.drawPath(path, legs);
      canvas.drawOval(Rect.fromCenter(center: const Offset(0, 5), width: 9, height: 12),
          Paint()..color = const Color(0xFFC7B2A8).withValues(alpha: 0.6));
      canvas.drawCircle(const Offset(0, -2), 3.2,
          Paint()..color = const Color(0xFFC7B2A8).withValues(alpha: 0.6));
      canvas.restore();
    }

    if (totalMin < 40 / 60) {
      final t = (totalMin / (40 / 60)).clamp(0.0, 1.0);
      orb(t);
      final a = -math.pi * 0.15 - t * math.pi * 0.85;
      final r = webRadius * t;
      spiderAt(anchor + Offset(math.cos(a) * r, -math.sin(a).abs() * r - 4), 0.8, loop * math.pi * 6);
    } else if (totalMin < 11) {
      orb(1);
      spiderAt(anchor + const Offset(-28, -40), 0.85, math.sin(loop * math.pi * 4));
    } else if (totalMin < 12) {
      final t = totalMin - 11;
      orb(1);
      spiderAt(Offset.lerp(anchor + const Offset(-28, -40), Offset(size.width + 30, size.height - 40), t)!,
          0.8, loop * math.pi * 4);
    } else {
      orb(1);
    }
  }

  void _gothicCastle(Canvas canvas, Offset base, double width, double flicker) {
    final h = width * 1.05;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;
    final body = Paint()..color = const Color(0xFF2A2228).withValues(alpha: 0.75);
    final roof = Paint()..color = const Color(0xFF1A151A).withValues(alpha: 0.88);
    final light = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.55 * flicker);
    canvas.drawRect(
        Rect.fromLTRB(left + width * 0.28, top + h * 0.36, left + width * 0.72, bottom),
        body);
    final cr = Path()
      ..moveTo(left + width * 0.26, top + h * 0.36)
      ..lineTo(left + width * 0.5, top + h * 0.06)
      ..lineTo(left + width * 0.74, top + h * 0.36)
      ..close();
    canvas.drawPath(cr, roof);
    void tower(double cx, double tw, double th) {
      final tLeft = cx - tw / 2;
      final tTop = bottom - th;
      canvas.drawRect(Rect.fromLTWH(tLeft, tTop + th * 0.16, tw, th * 0.84), body);
      canvas.drawPath(
          Path()
            ..moveTo(tLeft - 1, tTop + th * 0.2)
            ..lineTo(cx, tTop - th * 0.12)
            ..lineTo(tLeft + tw + 1, tTop + th * 0.2)
            ..close(),
          roof);
      for (final sy in [0.4, 0.6]) {
        canvas.drawRRect(
            RRect.fromRectAndRadius(
                Rect.fromCenter(
                    center: Offset(cx, tTop + th * sy),
                    width: tw * 0.14,
                    height: th * 0.07),
                const Radius.circular(1)),
            light);
      }
    }

    tower(left + width * 0.12, width * 0.15, h * 0.52);
    tower(left + width * 0.28, width * 0.13, h * 0.6);
    tower(left + width * 0.72, width * 0.13, h * 0.6);
    tower(left + width * 0.88, width * 0.15, h * 0.52);
  }

  // ---- Christmas ----

  void _christmas(Canvas canvas, Size size) {
    final groundY = size.height * 0.78;

    // Ground strip so trees/house don't float.
    canvas.drawRect(
      Rect.fromLTRB(0, groundY, size.width, size.height),
      Paint()..color = const Color(0xFF2A332E).withValues(alpha: 0.35),
    );

    // Garland (animates to bottom-right when collapsed).
    _garland(canvas, size);

    // House in the middle — drawn ABOVE drift so not buried.
    final houseBase = Offset(size.width * 0.5, groundY);
    _house(canvas, houseBase, size.width * 0.28, clear);

    // Side trees sitting on ground.
    _fir(canvas, Offset(28, groundY), 36, const Color(0xFF6E8A72).withValues(alpha: 0.35));
    _fir(canvas, Offset(size.width - 28, groundY), 30,
        const Color(0xFF6E8A72).withValues(alpha: 0.28));
    // Larger center-back tree (behind house slightly left).
    _fir(canvas, Offset(size.width * 0.32, groundY), 64,
        const Color(0xFF5E7A62).withValues(alpha: 0.4));

    // Continuous snowfall (never stops during clear), accelerates with minutes.
    _snowfall(canvas, size, groundY);

    // Drift grows only from landed snow; shrinks as stickman throws off-screen.
    _drift(canvas, size, groundY, driftLevel);

    // Stickman cycle on top of drift.
    if (clear > 0) {
      _stickmanCycle(canvas, size, groundY, driftLevel, houseBase);
    }
  }

  void _garland(Canvas canvas, Size size) {
    final t = garlandT.clamp(0.0, 1.0);
    final startY = topInset + 28.0;
    final end = Offset(size.width - 40, size.height - 50);
    // Interpolate whole garland toward the corner.
    Offset mapPoint(Offset p) => Offset.lerp(p, end, Curves.easeIn.transform(t))!;

    final pts = <Offset>[];
    Offset bez(Offset a, Offset b, Offset c, Offset d, double u) {
      final v = 1 - u;
      return a * (v * v * v) + b * (3 * v * v * u) + c * (3 * v * u * u) + d * (u * u * u);
    }

    for (var i = 0; i <= 24; i++) {
      final u = i / 24;
      final raw = u <= 0.5
          ? bez(Offset(12, startY), Offset(size.width * 0.22, startY + 30),
              Offset(size.width * 0.3, startY - 4), Offset(size.width * 0.5, startY + 14), u * 2)
          : bez(Offset(size.width * 0.5, startY + 14), Offset(size.width * 0.7, startY + 32),
              Offset(size.width * 0.82, startY - 2), Offset(size.width - 12, startY + 14),
              (u - 0.5) * 2);
      pts.add(mapPoint(raw));
    }

    final wire = Paint()
      ..color = const Color(0xFF8A9088).withValues(alpha: 0.45 * (1 - t * 0.3))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 1; i < pts.length; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    canvas.drawPath(path, wire);

    if (t > 0.95) return; // hidden when fully collapsed (button shows)

    const colors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
      Color(0xFF9AABB8),
    ];
    for (var i = 0; i < 13; i++) {
      final idx = (i * (pts.length - 1) / 12).round();
      final pos = pts[idx];
      final rate = 1.1 + (i % 5) * 0.55;
      final pulse = animate
          ? 0.35 + 0.55 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 * rate + i))
          : 0.65;
      final col = colors[i % colors.length];
      canvas.drawLine(pos, pos + const Offset(0, 3.5), wire);
      canvas.drawCircle(
          pos + const Offset(0, 5.5),
          2.6,
          Paint()..color = col.withValues(alpha: pulse * (1 - t)));
    }
  }

  void _house(Canvas canvas, Offset base, double w, double clearT) {
    final h = w * 0.85;
    final left = base.dx - w / 2;
    final bottom = base.dy;
    final top = bottom - h;

    // Body
    canvas.drawRRect(
      RRect.fromRectAndRadius(
          Rect.fromLTRB(left, top + h * 0.28, left + w, bottom), const Radius.circular(3)),
      Paint()..color = const Color(0xFF4A3A2A).withValues(alpha: 0.9),
    );
    // Roof
    canvas.drawPath(
      Path()
        ..moveTo(left - 6, top + h * 0.32)
        ..lineTo(base.dx, top)
        ..lineTo(left + w + 6, top + h * 0.32)
        ..close(),
      Paint()..color = const Color(0xFF3A2A22).withValues(alpha: 0.95),
    );
    // Chimney
    final ch = Rect.fromLTWH(left + w * 0.7, top + h * 0.05, w * 0.12, h * 0.28);
    canvas.drawRect(ch, Paint()..color = const Color(0xFF3A3030));
    // Smoke
    if (animate) {
      for (var i = 0; i < 5; i++) {
        final sy = ch.top - 8 - i * 10 - (loop * 30 + i * 5) % 20;
        final sx = ch.center.dx + math.sin(loop * math.pi * 2 + i) * 4;
        canvas.drawCircle(
            Offset(sx, sy),
            3.5 + i * 0.8,
            Paint()
              ..color = const Color(0xFFB0B0B0).withValues(alpha: 0.2 - i * 0.03));
      }
    }
    // Glowing window → light on field
    final win = Rect.fromCenter(
        center: Offset(base.dx - w * 0.12, top + h * 0.55), width: w * 0.18, height: h * 0.16);
    canvas.drawRRect(
        RRect.fromRectAndRadius(win, const Radius.circular(2)),
        Paint()..color = const Color(0xFFFFD080).withValues(alpha: 0.85));
    canvas.drawCircle(
        Offset(base.dx - w * 0.12, bottom + 8),
        w * 0.35,
        Paint()
          ..color = const Color(0xFFFFD080).withValues(alpha: 0.12)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 12));

    // Door (opens when stickman exits/enters).
    // clear phases: 0–10/140 exit open, 130/140–1 return open
    final doorOpen = clearT > 0 && (clearT < 12 / 140 || clearT > 128 / 140);
    final doorW = w * 0.16;
    final doorH = h * 0.32;
    final doorRect = Rect.fromLTWH(base.dx + w * 0.08, bottom - doorH, doorW, doorH);
    if (doorOpen) {
      // Open door swung to the side
      canvas.drawRect(
          Rect.fromLTWH(doorRect.right, doorRect.top, doorW * 0.2, doorH),
          Paint()..color = const Color(0xFF2A1A12));
      canvas.drawRect(
          Rect.fromLTWH(doorRect.left, doorRect.top, doorW * 0.35, doorH),
          Paint()..color = const Color(0xFF1A1008)); // dark opening
    } else {
      canvas.drawRect(doorRect, Paint()..color = const Color(0xFF2A1A12));
      canvas.drawCircle(Offset(doorRect.right - 4, doorRect.center.dy), 1.5,
          Paint()..color = const Color(0xFFC9A86A));
    }
  }

  void _snowfall(Canvas canvas, Size size, double groundY) {
    // Always falls; speed ramps with accumulation minutes (and stays fast when full/clearing).
    final minute = (accum * 5).clamp(0.0, 5.0);
    final speedMul = 1.2 + minute * 0.7; // accelerates each minute
    final count = (100 + accum * 900).round().clamp(100, 1000);

    final paint = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < count; i++) {
      final birth = i / 1000.0;
      final life = accum >= 1 ? 1.0 : (accum - birth).clamp(0.0, 1.0);
      if (accum < 1 && accum < birth) continue;

      final seed = i * 12.9898;
      final speed = (2.8 + (i % 7) * 0.4) * speedMul;
      // Continuous motion via loop so snow never freezes during clear.
      final fall = life * size.height * speed * 0.35 + loop * size.height * (0.9 + (i % 3) * 0.15);
      var y = fall % (size.height + 10);
      var x = (seed * 73) % size.width + math.sin(loop * math.pi * 2 + seed) * 2.5;

      // Slide off center tree area into drift.
      final treeX = size.width * 0.32;
      final treeTop = groundY - 64;
      if (y > treeTop && y < groundY && (x - treeX).abs() < 30) {
        x += (x >= treeX ? 1.5 : -1.5);
        y += 1.5;
      }

      paint.color = const Color(0xFFDCE6E0).withValues(alpha: 0.3);
      canvas.drawCircle(Offset(x, y), 0.7 + (i % 3) * 0.2, paint);
    }
  }

  void _drift(Canvas canvas, Size size, double groundY, double level) {
    if (level <= 0.001) return;
    final maxH = math.min(size.height * 0.12, 80.0);
    final h = maxH * level;
    final bottom = size.height;
    final path = Path()
      ..moveTo(0, bottom - h * 0.3)
      ..cubicTo(size.width * 0.2, bottom - h * 0.7, size.width * 0.35, bottom - h * 0.2,
          size.width * 0.5, bottom - h * 0.55)
      ..cubicTo(size.width * 0.65, bottom - h * 0.85, size.width * 0.8, bottom - h * 0.25,
          size.width, bottom - h * 0.4)
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();
    canvas.drawPath(
      path,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xEEF4FAF8), Color(0xE8C9D5D7)],
        ).createShader(Rect.fromLTWH(0, bottom - h, size.width, h)),
    );
  }

  void _stickmanCycle(
      Canvas canvas, Size size, double groundY, double driftLevel, Offset houseBase) {
    // clear 0..1 over 140s:
    // 0.00–0.07 (0–10s): door open, walk out from door along snow
    // 0.07–0.93 (10s–130s): shovel snow off-screen
    // 0.93–1.00 (130–140s): walk back in, door closes
    final t = clear;
    final maxH = math.min(size.height * 0.12, 80.0);
    final h = maxH * driftLevel;
    final surface = size.height - h * 0.45;

    final door = Offset(houseBase.dx + size.width * 0.28 * 0.08, surface);
    final workX = size.width * 0.72;

    double px;
    bool shoveling = false;
    if (t < 10 / 140) {
      final u = (t / (10 / 140)).clamp(0.0, 1.0);
      px = door.dx + (workX - door.dx) * Curves.easeInOut.transform(u);
    } else if (t < 130 / 140) {
      px = workX + math.sin((t - 10 / 140) * math.pi * 8) * 18;
      shoveling = true;
    } else {
      final u = ((t - 130 / 140) / (10 / 140)).clamp(0.0, 1.0);
      px = workX + (door.dx - workX) * Curves.easeInOut.transform(u);
    }
    final py = surface;

    final ink = Paint()
      ..color = const Color(0xFF2A332E).withValues(alpha: 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeCap = StrokeCap.round;

    final walk = t * math.pi * 12;
    final leg = math.sin(walk) * 3.5;

    // Head / body / legs on the snow surface
    canvas.drawCircle(Offset(px, py - 16), 2.6, ink);
    canvas.drawLine(Offset(px, py - 13), Offset(px, py - 2), ink);
    canvas.drawLine(Offset(px, py - 2), Offset(px - 3.5 + leg, py + 2), ink);
    canvas.drawLine(Offset(px, py - 2), Offset(px + 3.5 - leg, py + 2), ink);

    // Shovel + throw snow clumps OFF-SCREEN (to the right)
    final dig = shoveling ? (0.5 + 0.5 * math.sin(t * math.pi * 20)) : 0.0;
    final ang = shoveling ? (-0.3 + dig * 2.0) : 0.4;
    final sx = px + math.cos(ang) * 10;
    final sy = py - 8 + math.sin(ang) * 8;
    canvas.drawLine(Offset(px, py - 10), Offset(sx, sy), ink);
    canvas.drawLine(Offset(sx - 3, sy + 2), Offset(sx + 4, sy + 2), ink);

    if (shoveling && dig > 0.55) {
      final flight = (dig - 0.55) / 0.45;
      final snow = Paint()..color = const Color(0xFFE8F0EE).withValues(alpha: 0.8);
      // Throw toward right edge / off screen
      final fx = px + 12 + flight * (size.width - px);
      final fy = py - 4 - math.sin(flight * math.pi) * 20;
      canvas.drawCircle(Offset(fx, fy), 2.4, snow);
      canvas.drawCircle(Offset(fx - 3, fy + 2), 1.6, snow);
      canvas.drawCircle(Offset(fx + 2, fy + 3), 1.3, snow);
    }
  }

  void _fir(Canvas canvas, Offset bottom, double height, Color color) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.3
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(
      Path()
        ..moveTo(bottom.dx, bottom.dy - height)
        ..lineTo(bottom.dx - height * 0.28, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.12)
        ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.12)
        ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.5)
        ..lineTo(bottom.dx + height * 0.28, bottom.dy - height * 0.5)
        ..close(),
      p,
    );
    canvas.drawLine(bottom, Offset(bottom.dx, bottom.dy - height * 0.12), p);
  }

  void _cosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = (i * 67.0 + 11) % size.width;
      final y = (i * 91.0 + 37) % size.height;
      final tw = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(loop * math.pi * 2 + i))
          : 0.23;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.4 : 0.8,
          Paint()..color = const Color(0xFFB9B1D7).withValues(alpha: tw));
    }
  }

  @override
  bool shouldRepaint(covariant _AtmospherePainter old) =>
      old.loop != loop ||
      old.accum != accum ||
      old.clear != clear ||
      old.driftLevel != driftLevel ||
      old.spider != spider ||
      old.leftGlow != leftGlow ||
      old.rightGlow != rightGlow ||
      old.garlandT != garlandT ||
      old.kind != kind;
}
