import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../app/app_theme.dart';

/// Low-contrast seasonal details painted behind every app page.
class ThemeAtmosphere extends StatefulWidget {
  const ThemeAtmosphere({
    super.key,
    required this.themeKind,
    required this.animationsEnabled,
    this.snowdriftEnabled = true,
  });

  final ThemeKind themeKind;
  final bool animationsEnabled;
  final bool snowdriftEnabled;

  @override
  State<ThemeAtmosphere> createState() => _ThemeAtmosphereState();
}

class _ThemeAtmosphereState extends State<ThemeAtmosphere>
    with TickerProviderStateMixin {
  AnimationController? _controller;
  AnimationController? _snowAccumulationController;
  AnimationController? _snowClearController;
  AnimationController? _flockController;
  AnimationController? _spiderController;

  // Interactive pumpkins (Halloween).
  int _leftGlow = 0; // 0..5, 6th tap resets to 0
  int _rightGlow = 0; // 0..4, 5th tap triggers screamer
  bool _screamer = false;
  bool _aaaButton = false;

  bool get _isSeasonal =>
      widget.themeKind != ThemeKind.light &&
      widget.themeKind != ThemeKind.dark;

  bool get _shouldAnimate => _isSeasonal && widget.animationsEnabled;

  bool get _shouldAccumulateSnow =>
      _shouldAnimate &&
      widget.themeKind == ThemeKind.christmas &&
      widget.snowdriftEnabled;

  bool get _shouldHalloweenExtras =>
      _shouldAnimate && widget.themeKind == ThemeKind.halloween;

  @override
  void initState() {
    super.initState();
    _syncController();
  }

  @override
  void didUpdateWidget(covariant ThemeAtmosphere oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.themeKind != widget.themeKind ||
        oldWidget.animationsEnabled != widget.animationsEnabled ||
        oldWidget.snowdriftEnabled != widget.snowdriftEnabled) {
      _syncController();
      if (widget.themeKind != ThemeKind.halloween) {
        _leftGlow = 0;
        _rightGlow = 0;
        _screamer = false;
        _aaaButton = false;
      }
    }
  }

  void _syncController() {
    if (_shouldAnimate) {
      _controller ??= AnimationController(
        vsync: this,
        duration: const Duration(seconds: 24),
      );
      if (!_controller!.isAnimating) _controller!.repeat();

      if (_shouldAccumulateSnow) {
        _snowAccumulationController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 5),
        );
        _snowClearController ??= AnimationController(
          vsync: this,
          duration: const Duration(seconds: 30),
        );
        _snowAccumulationController!.removeStatusListener(_onSnowFull);
        _snowClearController!.removeStatusListener(_onSnowCleared);
        _snowAccumulationController!.addStatusListener(_onSnowFull);
        _snowClearController!.addStatusListener(_onSnowCleared);
        if (!_snowAccumulationController!.isAnimating &&
            _snowAccumulationController!.value < 1 &&
            (_snowClearController?.value ?? 0) == 0) {
          _snowAccumulationController!.forward();
        }
      } else {
        _snowAccumulationController?.stop();
        _snowClearController?.stop();
      }

      if (_shouldHalloweenExtras) {
        _flockController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 5),
        );
        if (!_flockController!.isAnimating) _flockController!.repeat();

        _spiderController ??= AnimationController(
          vsync: this,
          duration: const Duration(minutes: 41),
        );
        if (!_spiderController!.isAnimating) _spiderController!.repeat();
      } else {
        _flockController?.stop();
        _spiderController?.stop();
      }
    } else {
      _controller?.stop();
      _snowAccumulationController?.stop();
      _snowClearController?.stop();
      _flockController?.stop();
      _spiderController?.stop();
      _controller?.value = 0;
    }
  }

  void _onSnowFull(AnimationStatus status) {
    if (status == AnimationStatus.completed && mounted) {
      _snowClearController?.forward(from: 0);
    }
  }

  void _onSnowCleared(AnimationStatus status) {
    if (status == AnimationStatus.completed && mounted) {
      _snowClearController?.value = 0;
      _snowAccumulationController?.forward(from: 0);
    }
  }

  void _onLeftPumpkinTap() {
    if (_screamer) return;
    setState(() {
      _leftGlow = (_leftGlow + 1) % 6; // 0..5, 6th resets
    });
  }

  void _onRightPumpkinTap() {
    if (_screamer) return;
    setState(() {
      if (_rightGlow < 4) {
        _rightGlow += 1;
      } else {
        // 5th tap → screamer
        _rightGlow = 4;
        _screamer = true;
        _aaaButton = false;
      }
    });
    if (_screamer) {
      Future<void>.delayed(const Duration(seconds: 2), () {
        if (mounted && _screamer) {
          setState(() => _aaaButton = true);
        }
      });
    }
  }

  void _dismissScreamer() {
    setState(() {
      _screamer = false;
      _aaaButton = false;
      _leftGlow = 0;
      _rightGlow = 0;
    });
  }

  @override
  void dispose() {
    _snowAccumulationController?.removeStatusListener(_onSnowFull);
    _snowClearController?.removeStatusListener(_onSnowCleared);
    _controller?.dispose();
    _snowAccumulationController?.dispose();
    _snowClearController?.dispose();
    _flockController?.dispose();
    _spiderController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.paddingOf(context).top;
    final size = MediaQuery.sizeOf(context);

    return AnimatedBuilder(
      animation: Listenable.merge([
        _controller ?? const AlwaysStoppedAnimation<double>(0),
        _snowAccumulationController ?? const AlwaysStoppedAnimation<double>(0),
        _snowClearController ?? const AlwaysStoppedAnimation<double>(0),
        _flockController ?? const AlwaysStoppedAnimation<double>(0),
        _spiderController ?? const AlwaysStoppedAnimation<double>(0),
      ]),
      builder: (context, child) {
        final accum = _snowAccumulationController?.value ?? 0;
        final clear = _snowClearController?.value ?? 0;
        final snowLevel = clear > 0 ? (1.0 - clear).clamp(0.0, 1.0) : accum;

        // Pumpkin hit targets (match painter positions).
        final leftPumpkin = Offset(25, size.height * 0.78);
        final rightPumpkin = Offset(size.width - 28, size.height * 0.72);
        const leftR = 28.0;
        const rightR = 24.0;

        return Stack(
          fit: StackFit.expand,
          children: [
            // Decorative layer — does not block touches outside pumpkins.
            IgnorePointer(
              child: RepaintBoundary(
                child: CustomPaint(
                  painter: _ThemeAtmospherePainter(
                    kind: widget.themeKind,
                    progress: _controller?.value ?? 0,
                    topInset: topInset,
                    animate: _shouldAnimate,
                    snowAccumulation: snowLevel,
                    snowAccumProgress: accum,
                    snowClearProgress: clear,
                    flockProgress: _flockController?.value ?? 0,
                    spiderProgress: _spiderController?.value ?? 0,
                    leftGlow: _leftGlow,
                    rightGlow: _rightGlow,
                  ),
                  child: const SizedBox.expand(),
                ),
              ),
            ),

            // Interactive pumpkin hotspots (Halloween only).
            if (widget.themeKind == ThemeKind.halloween) ...[
              Positioned(
                left: leftPumpkin.dx - leftR,
                top: leftPumpkin.dy - leftR,
                width: leftR * 2,
                height: leftR * 2,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _onLeftPumpkinTap,
                  child: const SizedBox.expand(),
                ),
              ),
              Positioned(
                left: rightPumpkin.dx - rightR,
                top: rightPumpkin.dy - rightR,
                width: rightR * 2,
                height: rightR * 2,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: _onRightPumpkinTap,
                  child: const SizedBox.expand(),
                ),
              ),
            ],

            // Full-screen knife screamer.
            if (_screamer)
              Positioned.fill(
                child: _ScreamerOverlay(
                  showButton: _aaaButton,
                  onDismiss: _dismissScreamer,
                ),
              ),
          ],
        );
      },
    );
  }
}

/// Full-screen jump-scare with optional dripping "ААААААААААА!" button.
class _ScreamerOverlay extends StatelessWidget {
  const _ScreamerOverlay({
    required this.showButton,
    required this.onDismiss,
  });

  final bool showButton;
  final VoidCallback onDismiss;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.92),
      child: Stack(
        fit: StackFit.expand,
        children: [
          // Stylized knife silhouette (vector, not a photo).
          CustomPaint(
            painter: _KnifeScreamerPainter(),
            child: const SizedBox.expand(),
          ),
          if (showButton)
            Align(
              alignment: const Alignment(0, 0.55),
              child: _DrippingAaaButton(onPressed: onDismiss),
            ),
        ],
      ),
    );
  }
}

class _DrippingAaaButton extends StatefulWidget {
  const _DrippingAaaButton({required this.onPressed});
  final VoidCallback onPressed;

  @override
  State<_DrippingAaaButton> createState() => _DrippingAaaButtonState();
}

class _DrippingAaaButtonState extends State<_DrippingAaaButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, child) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            child!,
            SizedBox(
              height: 36,
              width: 160,
              child: CustomPaint(
                painter: _BloodDripsPainter(progress: _c.value),
              ),
            ),
          ],
        );
      },
      child: FilledButton(
        onPressed: widget.onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF8B1515),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Text(
          'ААААААААААА!',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }
}

class _BloodDripsPainter extends CustomPainter {
  const _BloodDripsPainter({required this.progress});
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFB01010)
      ..style = PaintingStyle.fill;
    for (var i = 0; i < 5; i++) {
      final x = size.width * (0.15 + i * 0.18);
      final fall = ((progress + i * 0.17) % 1.0);
      final y = fall * size.height;
      final r = 2.2 + (i % 3) * 0.6;
      canvas.drawCircle(Offset(x, y), r, paint);
      // Stretch droplet
      canvas.drawOval(
        Rect.fromCenter(
          center: Offset(x, y - 4),
          width: r * 0.7,
          height: 6 + fall * 8,
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BloodDripsPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class _KnifeScreamerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final cx = size.width * 0.5;
    final cy = size.height * 0.38;

    // Blade
    final blade = Path()
      ..moveTo(cx - 18, cy - 40)
      ..lineTo(cx + 22, cy - 160)
      ..lineTo(cx + 38, cy - 150)
      ..lineTo(cx + 8, cy - 20)
      ..close();
    canvas.drawPath(
      blade,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFE8E8EC), Color(0xFF9A9AA2)],
        ).createShader(Rect.fromLTWH(cx - 40, cy - 170, 80, 160)),
    );

    // Handle
    final handle = RRect.fromRectAndRadius(
      Rect.fromCenter(center: Offset(cx - 6, cy + 30), width: 28, height: 70),
      const Radius.circular(4),
    );
    canvas.drawRRect(
      handle,
      Paint()..color = const Color(0xFF3A2018),
    );
    // Guard
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx - 2, cy - 8), width: 52, height: 12),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF6A6A72),
    );

    // Red slash accents
    final slash = Paint()
      ..color = const Color(0xFFB01010).withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(
      Offset(cx - 80, cy - 100),
      Offset(cx + 90, cy + 40),
      slash,
    );
    canvas.drawLine(
      Offset(cx + 60, cy - 130),
      Offset(cx - 50, cy + 20),
      slash,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _ThemeAtmospherePainter extends CustomPainter {
  const _ThemeAtmospherePainter({
    required this.kind,
    required this.progress,
    required this.topInset,
    required this.animate,
    required this.snowAccumulation,
    required this.snowAccumProgress,
    required this.snowClearProgress,
    required this.flockProgress,
    required this.spiderProgress,
    this.leftGlow = 0,
    this.rightGlow = 0,
  });

  final ThemeKind kind;
  final double progress;
  final double topInset;
  final bool animate;
  final double snowAccumulation;
  final double snowAccumProgress;
  final double snowClearProgress;
  final double flockProgress;
  final double spiderProgress;
  final int leftGlow;
  final int rightGlow;

  @override
  void paint(Canvas canvas, Size size) {
    switch (kind) {
      case ThemeKind.light:
      case ThemeKind.dark:
        return;
      case ThemeKind.halloween:
        _paintHalloween(canvas, size);
        break;
      case ThemeKind.christmas:
        _paintChristmas(canvas, size);
        break;
      case ThemeKind.cosmos:
        _paintCosmos(canvas, size);
        break;
    }
  }

  // ---------------------------------------------------------------------------
  // Halloween
  // ---------------------------------------------------------------------------

  void _paintHalloween(Canvas canvas, Size size) {
    final base = const Color(0xFFB27B54);
    final flicker = animate
        ? (0.72 + 0.28 * math.sin(progress * math.pi * 2))
        : 0.78;

    // Larger moon (upper-left) with realistic crater spots.
    final moonCenter = Offset(size.width * 0.16, topInset + 88);
    final moonGlow = Paint()
      ..color = const Color(0xFFE8DCC0).withValues(alpha: 0.16)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 36);
    canvas.drawCircle(moonCenter, 58, moonGlow);

    final moon = Paint()
      ..color = const Color(0xFFEDE6CF).withValues(alpha: 0.92)
      ..style = PaintingStyle.fill;
    canvas.drawCircle(moonCenter, 34, moon);

    // Crater / mare spots (soft darker patches like the real Moon).
    final spots = <(Offset, double, double)>[
      (const Offset(-10, 6), 9.0, 0.28),
      (const Offset(12, -8), 7.5, 0.22),
      (const Offset(-4, -14), 5.5, 0.18),
      (const Offset(8, 12), 6.0, 0.20),
      (const Offset(-16, -4), 4.0, 0.16),
      (const Offset(2, 2), 11.0, 0.12),
      (const Offset(16, 4), 3.5, 0.20),
      (const Offset(-8, 16), 4.5, 0.15),
    ];
    for (final (offset, r, a) in spots) {
      canvas.drawCircle(
        moonCenter + offset,
        r,
        Paint()
          ..color = const Color(0xFFC9BFA0).withValues(alpha: a)
          ..style = PaintingStyle.fill,
      );
    }

    // Field under moonlight — even baseline so castle sits level.
    final fieldTop = size.height * 0.62;
    final fieldPath = Path()
      ..moveTo(0, fieldTop)
      ..lineTo(size.width, fieldTop)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    // Gentle rolling hills on top of the flat base.
    final hills = Path()
      ..moveTo(0, fieldTop)
      ..quadraticBezierTo(
          size.width * 0.25, fieldTop - 10, size.width * 0.5, fieldTop - 2)
      ..quadraticBezierTo(
          size.width * 0.75, fieldTop + 8, size.width, fieldTop - 4)
      ..lineTo(size.width, fieldTop + 1)
      ..lineTo(0, fieldTop + 1)
      ..close();

    final fieldPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          const Color(0xFF3A322C).withValues(alpha: 0.50),
          const Color(0xFF2A2420).withValues(alpha: 0.70),
          const Color(0xFF1C1816).withValues(alpha: 0.85),
        ],
      ).createShader(
        Rect.fromLTWH(0, fieldTop - 12, size.width, size.height - fieldTop + 12),
      );
    canvas.drawPath(fieldPath, fieldPaint);
    canvas.drawPath(
      hills,
      Paint()..color = const Color(0xFF342C28).withValues(alpha: 0.40),
    );

    // Grass stubble.
    final grass = Paint()
      ..color = const Color(0xFF4A4038).withValues(alpha: 0.32)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.9
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 48; i++) {
      final x = (i * 31.0 + 9) % size.width;
      final y = fieldTop + 6 + (i % 6) * 7.0;
      canvas.drawLine(Offset(x, y), Offset(x + 1.2, y - 4 - (i % 3)), grass);
    }

    // Level gothic castle sitting on the field horizon (right side).
    final castleBase = Offset(size.width * 0.74, fieldTop);
    _drawGothicCastle(canvas, castleBase, size.width * 0.32, flicker);

    // 30 bats: fly toward the castle and vanish behind it.
    final cycleSeconds = flockProgress * 5 * 60;
    final waveActive = animate && cycleSeconds < 20;
    if (waveActive) {
      final t = cycleSeconds / 20.0; // 0→1 during the wave
      final castleX = size.width * 0.74;

      for (var i = 0; i < 30; i++) {
        final seed = i * 1.6180339887;
        final lane = (i % 8) / 7.0;
        final baseY = topInset + 55 + lane * (fieldTop - topInset - 80);
        // Start off-screen right, end at/behind castle.
        final x = size.width * (1.12 - t * 0.95) + math.sin(seed) * 12;
        final y = baseY +
            math.sin(t * math.pi * 2.5 + seed) * 14 +
            math.sin(seed * 2.1) * 8;

        // Fade out as they reach the castle silhouette.
        final dist = (x - castleX).abs();
        final fade = (dist / (size.width * 0.22)).clamp(0.0, 1.0);
        if (fade < 0.05) continue;

        final batPaint = Paint()
          ..color = Colors.white.withValues(alpha: 0.50 * fade)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..strokeCap = StrokeCap.round;
        final path = Path()
          ..moveTo(x, y)
          ..quadraticBezierTo(x + 1.8, y + 1.2, x + 0.6, y + 3.4);
        canvas.drawPath(path, batPaint);
      }
    }

    // Single spider lifecycle (no static spiders over the moon).
    if (animate) {
      _drawSpiderLifecycle(canvas, size, fieldTop);
    }

    // Left pumpkin: glow levels 0..5 from taps.
    final leftGlowFactor = 0.10 + leftGlow * 0.18; // up to ~1.0
    _drawPumpkin(
      canvas,
      Offset(25, size.height * 0.78),
      15,
      base.withValues(alpha: (0.50 + leftGlow * 0.1) * flicker),
      const Color(0xFFFFB040).withValues(alpha: leftGlowFactor * flicker),
      lanternGlow: leftGlow,
    );
    // Right pumpkin: glow levels 0..4 from taps.
    final rightGlowFactor = 0.08 + rightGlow * 0.20;
    _drawPumpkin(
      canvas,
      Offset(size.width - 28, size.height * 0.72),
      12,
      base.withValues(alpha: (0.40 + rightGlow * 0.1) * flicker),
      const Color(0xFFFFB040).withValues(alpha: rightGlowFactor * flicker),
      lanternGlow: rightGlow,
    );
  }

  /// Spider: crawl from right → weave 1 min → sit 10 min twitching → leave 30 min.
  void _drawSpiderLifecycle(Canvas canvas, Size size, double fieldTop) {
    // spiderProgress 0..1 over 41 minutes.
    final totalMin = spiderProgress * 41.0;
    final webPaint = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.38)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.85
      ..strokeCap = StrokeCap.round;

    // Web anchor: upper area, right side — not over the moon (moon is left).
    final anchor = Offset(size.width * 0.82, topInset + 36);
    final webEnd = Offset(size.width * 0.68, topInset + 120);

    if (totalMin < 1.0) {
      // Phase 1: crawl in from right edge and weave the web (0–1 min).
      final t = totalMin; // 0→1
      final start = Offset(size.width + 20, topInset + 80);
      final weavePoint = Offset(
        anchor.dx + (webEnd.dx - anchor.dx) * t,
        anchor.dy + (webEnd.dy - anchor.dy) * t,
      );
      // Partial web line.
      canvas.drawLine(anchor, weavePoint, webPaint);
      // Radial strands growing.
      for (var i = 0; i < 5; i++) {
        final a = -0.6 + i * 0.35;
        final len = 28.0 * t;
        canvas.drawLine(
          weavePoint,
          weavePoint + Offset(math.cos(a) * len, math.sin(a) * len),
          webPaint,
        );
      }
      // Spider position: moves from right edge toward weave point.
      final spiderPos = Offset.lerp(start, weavePoint, t.clamp(0.0, 1.0))!;
      _drawAnimatedSpider(canvas, spiderPos, 0.85, progress * math.pi * 4);
    } else if (totalMin < 11.0) {
      // Phase 2: full web, spider sits and twitches legs (1–11 min).
      canvas.drawLine(anchor, webEnd, webPaint);
      for (var i = 0; i < 6; i++) {
        final a = -0.7 + i * 0.28;
        canvas.drawLine(
          webEnd,
          webEnd + Offset(math.cos(a) * 32, math.sin(a) * 32),
          webPaint,
        );
      }
      // Cross threads.
      for (var i = 1; i <= 3; i++) {
        final t = i / 4.0;
        final c = Offset.lerp(anchor, webEnd, t)!;
        canvas.drawLine(
          c + const Offset(-14, 4),
          c + const Offset(14, -4),
          webPaint,
        );
      }
      final twitch = math.sin(progress * math.pi * 2 * 1.8) * 0.9;
      _drawAnimatedSpider(canvas, webEnd, 0.9, twitch);
    } else if (totalMin < 12.0) {
      // Brief climb-down (11–12 min).
      final t = totalMin - 11.0;
      canvas.drawLine(anchor, webEnd, webPaint);
      final exit = Offset(size.width + 24, topInset + 100);
      final spiderPos = Offset.lerp(webEnd, exit, t)!;
      _drawAnimatedSpider(canvas, spiderPos, 0.85, progress * math.pi * 3);
    }
    // else: 12–41 min — spider is away, web may remain faintly.
    else if (totalMin < 41.0) {
      canvas.drawLine(
        anchor,
        webEnd,
        webPaint..color = webPaint.color.withValues(alpha: 0.12),
      );
    }
  }

  void _drawAnimatedSpider(
    Canvas canvas,
    Offset center,
    double scale,
    double legMotion,
  ) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale);

    final legs = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1
      ..strokeCap = StrokeCap.round;

    final swing = legMotion * 2.4;
    final legPath = Path()
      ..moveTo(-2, -2)
      ..quadraticBezierTo(-7 - swing, -8, -12 - swing, -7)
      ..lineTo(-15 - swing, -11)
      ..moveTo(-3, 0)
      ..quadraticBezierTo(-10 - swing, -1, -13 - swing, 3)
      ..lineTo(-17 - swing, 4)
      ..moveTo(-3, 2)
      ..quadraticBezierTo(-9 - swing, 6, -11 - swing, 11)
      ..lineTo(-15 - swing, 13)
      ..moveTo(-2, 3)
      ..quadraticBezierTo(-5 - swing, 10, -6 - swing, 14)
      ..lineTo(-9 - swing, 16)
      ..moveTo(2, -2)
      ..quadraticBezierTo(7 + swing, -8, 12 + swing, -7)
      ..lineTo(15 + swing, -11)
      ..moveTo(3, 0)
      ..quadraticBezierTo(10 + swing, -1, 13 + swing, 3)
      ..lineTo(17 + swing, 4)
      ..moveTo(3, 2)
      ..quadraticBezierTo(9 + swing, 6, 11 + swing, 11)
      ..lineTo(15 + swing, 13)
      ..moveTo(2, 3)
      ..quadraticBezierTo(5 + swing, 10, 6 + swing, 14)
      ..lineTo(9 + swing, 16);
    canvas.drawPath(legPath, legs);

    final body = Paint()
      ..color = const Color(0xFFC7B2A8).withValues(alpha: 0.6)
      ..style = PaintingStyle.fill;
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(0, 5), width: 9, height: 12),
      body,
    );
    canvas.drawCircle(const Offset(0, -2), 3.2, body);
    canvas.drawLine(const Offset(-1.5, -6), const Offset(-2.5, -8), legs);
    canvas.drawLine(const Offset(1.5, -6), const Offset(2.5, -8), legs);
    canvas.restore();
  }

  void _drawGothicCastle(
    Canvas canvas,
    Offset base,
    double width,
    double flicker,
  ) {
    final h = width * 1.05;
    final left = base.dx - width * 0.5;
    final bottom = base.dy;
    final top = bottom - h;

    final bodyPaint = Paint()
      ..color = const Color(0xFF2A2228).withValues(alpha: 0.75)
      ..style = PaintingStyle.fill;
    final roofPaint = Paint()
      ..color = const Color(0xFF1A151A).withValues(alpha: 0.88)
      ..style = PaintingStyle.fill;
    final light = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.55 * flicker)
      ..style = PaintingStyle.fill;
    final lightGlow = Paint()
      ..color = const Color(0xFFE8B86A).withValues(alpha: 0.18 * flicker)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

    // Main keep — flat base on field line.
    canvas.drawRect(
      Rect.fromLTRB(left + width * 0.28, top + h * 0.36, left + width * 0.72, bottom),
      bodyPaint,
    );

    // Central roof
    final centralRoof = Path()
      ..moveTo(left + width * 0.26, top + h * 0.36)
      ..lineTo(left + width * 0.50, top + h * 0.06)
      ..lineTo(left + width * 0.74, top + h * 0.36)
      ..close();
    canvas.drawPath(centralRoof, roofPaint);

    // Gate
    final gate = Path()
      ..moveTo(left + width * 0.42, bottom)
      ..lineTo(left + width * 0.42, bottom - h * 0.16)
      ..quadraticBezierTo(
        left + width * 0.50,
        bottom - h * 0.26,
        left + width * 0.58,
        bottom - h * 0.16,
      )
      ..lineTo(left + width * 0.58, bottom)
      ..close();
    canvas.drawPath(
      gate,
      Paint()..color = const Color(0xFF121014).withValues(alpha: 0.92),
    );

    void tower(double cx, double tw, double th, {bool tall = false}) {
      final tLeft = cx - tw / 2;
      final tTop = bottom - th;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(tLeft, tTop + th * 0.16, tw, th * 0.84),
          const Radius.circular(2),
        ),
        bodyPaint,
      );
      final spire = Path()
        ..moveTo(tLeft - 1, tTop + th * 0.20)
        ..lineTo(cx, tTop - (tall ? th * 0.20 : th * 0.10))
        ..lineTo(tLeft + tw + 1, tTop + th * 0.20)
        ..close();
      canvas.drawPath(spire, roofPaint);
      for (final slotY in [0.38, 0.58, 0.75]) {
        final slot = Rect.fromCenter(
          center: Offset(cx, tTop + th * slotY),
          width: tw * 0.14,
          height: th * 0.07,
        );
        canvas.drawRRect(
            RRect.fromRectAndRadius(slot, const Radius.circular(1)), lightGlow);
        canvas.drawRRect(
            RRect.fromRectAndRadius(slot, const Radius.circular(1)), light);
      }
    }

    tower(left + width * 0.12, width * 0.15, h * 0.52);
    tower(left + width * 0.28, width * 0.13, h * 0.60);
    tower(left + width * 0.72, width * 0.13, h * 0.60);
    tower(left + width * 0.88, width * 0.15, h * 0.52);
    tower(left + width * 0.58, width * 0.11, h * 0.78, tall: true);

    for (final wx in [0.38, 0.50, 0.62]) {
      for (final wy in [0.48, 0.62]) {
        final wRect = Rect.fromCenter(
          center: Offset(left + width * wx, top + h * wy),
          width: width * 0.04,
          height: h * 0.05,
        );
        canvas.drawRRect(
            RRect.fromRectAndRadius(wRect, const Radius.circular(1.5)),
            lightGlow);
        canvas.drawRRect(
            RRect.fromRectAndRadius(wRect, const Radius.circular(1.5)), light);
      }
    }
  }

  void _drawPumpkin(
    Canvas canvas,
    Offset center,
    double radius,
    Color strokeColor,
    Color fillColor, {
    int lanternGlow = 0,
  }) {
    final outline = Paint()
      ..color = strokeColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.35;
    final fill = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    final r = radius;
    // Lantern glow grows with tap level.
    final glowStrength = 0.20 + lanternGlow * 0.16;
    final halo = Paint()
      ..color = const Color(0xFFFFB040).withValues(alpha: glowStrength * (lanternGlow > 0 ? 1.0 : 0.3))
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, radius * (1.2 + lanternGlow * 0.35));
    canvas.drawCircle(center, radius * (1.4 + lanternGlow * 0.25), halo);
    final shape = Path()
      ..moveTo(center.dx, center.dy - r * 0.72)
      ..cubicTo(center.dx - r * 0.95, center.dy - r * 1.05,
          center.dx - r * 1.15, center.dy - r * 0.25,
          center.dx - r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx - r * 0.50, center.dy + r * 1.05,
          center.dx + r * 0.50, center.dy + r * 1.05,
          center.dx + r * 0.92, center.dy + r * 0.48)
      ..cubicTo(center.dx + r * 1.15, center.dy - r * 0.25,
          center.dx + r * 0.95, center.dy - r * 1.05,
          center.dx, center.dy - r * 0.72)
      ..close();
    canvas.drawPath(shape, fill);
    canvas.drawPath(shape, outline);
    canvas.drawLine(
      Offset(center.dx, center.dy - r * 0.72),
      Offset(center.dx, center.dy - r * 1.05),
      outline,
    );
  }

  // ---------------------------------------------------------------------------
  // Christmas
  // ---------------------------------------------------------------------------

  void _paintChristmas(Canvas canvas, Size size) {
    final wire = Paint()
      ..color = const Color(0xFF8A9088).withValues(alpha: 0.40)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15;

    final garlandY = topInset + 25;
    final garland = Path()
      ..moveTo(0, garlandY)
      ..cubicTo(size.width * 0.22, garlandY + 32, size.width * 0.30, garlandY - 5,
          size.width * 0.50, garlandY + 15)
      ..cubicTo(size.width * 0.70, garlandY + 35, size.width * 0.80, garlandY - 3,
          size.width, garlandY + 16);
    canvas.drawPath(garland, wire);

    // Animated glowing bulbs (pulse + soft halo).
    const bulbColors = [
      Color(0xFFB79A76),
      Color(0xFF839985),
      Color(0xFFA46F69),
      Color(0xFFB7B8A3),
    ];
    for (var i = 0; i < 13; i++) {
      final x = size.width * i / 12;
      final y = garlandY + 13 + math.sin(i / 12 * math.pi * 2) * 7;
      final pulse = animate
          ? 0.55 + 0.40 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i * 0.85))
          : 0.65;
      final color = bulbColors[i % bulbColors.length];
      if (animate) {
        final halo = Paint()
          ..color = color.withValues(alpha: pulse * 0.22)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
        canvas.drawCircle(Offset(x, y), 6.5, halo);
      }
      canvas.drawCircle(
        Offset(x, y),
        2.6,
        Paint()
          ..color = color.withValues(alpha: pulse)
          ..style = PaintingStyle.fill,
      );
    }

    _drawFirTree(canvas, Offset(20, size.height - 22), 27,
        const Color(0xFF829184).withValues(alpha: 0.20));
    _drawFirTree(canvas, Offset(size.width - 20, size.height - 22), 23,
        const Color(0xFF829184).withValues(alpha: 0.16));

    // Snowfall intensity ramps up each minute of accumulation, then resets.
    // Minute 0 → base count, minute 4 → ~3× flakes; after clear, cycle restarts.
    final minute = (snowAccumProgress * 5).floor().clamp(0, 4);
    final flakeCount = 60 + minute * 35; // 60 → 200 over 5 minutes
    final snow = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < flakeCount; i++) {
      final x = ((i * 73.0 + 19) % size.width).toDouble();
      final baseY = ((i * 47.0 + 13) % size.height).toDouble();
      final speed = 1 + (i % 3) + minute * 0.15;
      final y = ((baseY +
                  (animate ? progress * size.height * speed : 0)) %
              size.height)
          .toDouble();
      final sway = math.sin(i * 0.7 + progress * math.pi * 2) * (2.0 + minute * 0.3);
      snow.color =
          const Color(0xFFDCE6E0).withValues(alpha: 0.28 + (i % 4) * 0.06);
      canvas.drawCircle(
          Offset(x + sway, y), 0.7 + (i % 4) * 0.28, snow);
    }

    _drawSnowdrift(canvas, size, snowAccumulation);

    if (snowClearProgress > 0 && snowClearProgress < 1) {
      _drawStickmenClearing(canvas, size, snowClearProgress, snowAccumulation);
    }
  }

  void _drawSnowdrift(Canvas canvas, Size size, double growth) {
    if (growth <= 0 || size.isEmpty) return;

    final normalizedGrowth = growth.clamp(0.0, 1.0).toDouble();
    final maxHeight = math.min(size.height * 0.14, 92.0);
    final height = maxHeight * normalizedGrowth;
    if (height < 0.5) return;

    final bottom = size.height;
    final ridge = Path()
      ..moveTo(0, bottom - height * 0.34)
      ..cubicTo(size.width * 0.12, bottom - height * 0.66, size.width * 0.20,
          bottom - height * 0.12, size.width * 0.36, bottom - height * 0.38)
      ..cubicTo(size.width * 0.51, bottom - height * 0.70, size.width * 0.59,
          bottom - height * 0.14, size.width * 0.74, bottom - height * 0.42)
      ..cubicTo(size.width * 0.86, bottom - height * 0.62, size.width * 0.94,
          bottom - height * 0.20, size.width, bottom - height * 0.39)
      ..lineTo(size.width, bottom)
      ..lineTo(0, bottom)
      ..close();

    final fill = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xDDF4FAF8),
          Color(0xD9E1EBE9),
          Color(0xE8C9D5D7),
        ],
        stops: [0, 0.48, 1],
      ).createShader(Rect.fromLTWH(0, bottom - height, size.width, height));
    canvas.drawPath(ridge, fill);

    final grainPaint = Paint()..style = PaintingStyle.fill;
    final grainCount = (normalizedGrowth * 52).round();
    for (var i = 0; i < grainCount; i++) {
      final x = ((i * 47.0 + 17) % size.width).toDouble();
      final wave = 0.38 + 0.12 * math.sin(i * 1.13);
      final y = bottom - height * wave - (i % 4) * 1.4;
      grainPaint.color =
          const Color(0xFFF9FFFF).withValues(alpha: 0.32 + (i % 3) * 0.12);
      canvas.drawCircle(Offset(x, y), 0.55 + (i % 3) * 0.22, grainPaint);
    }
  }

  /// Stickmen enter from the LEFT, dig, then walk off to the RIGHT.
  void _drawStickmenClearing(
    Canvas canvas,
    Size size,
    double clearProgress,
    double snowLevel,
  ) {
    final ink = Paint()
      ..color = const Color(0xFF3A4540).withValues(alpha: 0.80)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final bottom = size.height;
    final driftH = math.min(size.height * 0.14, 92.0) * snowLevel;

    // Phases of clearProgress 0→1 over 30s:
    // 0.00–0.20 enter from left
    // 0.20–0.70 dig in place (walk cycle + shovel)
    // 0.70–1.00 walk off to the right
    for (var i = 0; i < 10; i++) {
      final slotX = size.width * (0.10 + i * 0.08);
      final stagger = i * 0.018;

      double px;
      final localT = (clearProgress - stagger).clamp(0.0, 1.0);

      if (localT < 0.20) {
        // Enter from left edge.
        final t = localT / 0.20;
        px = -16 + (slotX + 16) * Curves.easeOut.transform(t);
      } else if (localT < 0.70) {
        px = slotX;
      } else {
        // Exit to the right.
        final t = (localT - 0.70) / 0.30;
        px = slotX + (size.width + 24 - slotX) * Curves.easeIn.transform(t);
      }

      final py = bottom - driftH * 0.50 - 2;
      final walkPhase = clearProgress * math.pi * 10 + i * 0.7;
      final legSwing = math.sin(walkPhase) * 3.2;
      final dig = (localT >= 0.20 && localT < 0.70)
          ? math.sin(clearProgress * math.pi * 12 + i) * 2.8
          : 0.0;

      // Smaller stickman proportions.
      const scale = 0.72;
      final headR = 2.4 * scale;
      final headY = py - 14 * scale;
      final hipY = py - 1 * scale;
      final shoulderY = py - 9 * scale;

      // Head
      canvas.drawCircle(Offset(px, headY), headR, ink);
      // Body
      canvas.drawLine(Offset(px, headY + headR), Offset(px, hipY), ink);
      // Legs (walk cycle)
      canvas.drawLine(
          Offset(px, hipY), Offset(px - 3.5 + legSwing, py + 7 * scale), ink);
      canvas.drawLine(
          Offset(px, hipY), Offset(px + 3.5 - legSwing, py + 7 * scale), ink);
      // Arms + shovel
      final shovelX = px + 6 * scale + dig;
      canvas.drawLine(Offset(px, shoulderY), Offset(shovelX, py - 3 * scale), ink);
      // Shovel handle
      canvas.drawLine(
          Offset(shovelX, py - 3 * scale), Offset(shovelX + 1, py + 5 * scale), ink);
      // Shovel blade
      canvas.drawLine(
        Offset(shovelX - 2.5, py + 5 * scale),
        Offset(shovelX + 4.5, py + 5 * scale),
        ink,
      );
    }
  }

  void _drawFirTree(Canvas canvas, Offset bottom, double height, Color color) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.25
      ..strokeJoin = StrokeJoin.round;
    final path = Path()
      ..moveTo(bottom.dx, bottom.dy - height)
      ..lineTo(bottom.dx - height * 0.27, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx - height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.42, bottom.dy - height * 0.15)
      ..lineTo(bottom.dx + height * 0.12, bottom.dy - height * 0.52)
      ..lineTo(bottom.dx + height * 0.27, bottom.dy - height * 0.52)
      ..close();
    canvas.drawPath(path, paint);
    canvas.drawLine(
        bottom, Offset(bottom.dx, bottom.dy - height * 0.14), paint);
  }

  // ---------------------------------------------------------------------------
  // Cosmos
  // ---------------------------------------------------------------------------

  void _paintCosmos(Canvas canvas, Size size) {
    for (var i = 0; i < 46; i++) {
      final x = ((i * 67.0 + 11) % size.width).toDouble();
      final y = ((i * 91.0 + 37) % size.height).toDouble();
      final twinkle = animate
          ? 0.18 + 0.32 * (0.5 + 0.5 * math.sin(progress * math.pi * 2 + i))
          : 0.23;
      final star = Paint()
        ..color = const Color(0xFFB9B1D7).withValues(alpha: twinkle)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x, y), i % 9 == 0 ? 1.45 : 0.8, star);
    }

    final center = Offset(size.width - 44, topInset + 116);
    final orbitPaint = Paint()
      ..color = const Color(0xFF9991BE).withValues(alpha: 0.20)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawOval(
      Rect.fromCenter(center: center, width: 66, height: 23),
      orbitPaint,
    );
    final planetPaint = Paint()
      ..color = const Color(0xFF9C94BD).withValues(alpha: 0.34)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.1;
    canvas.drawCircle(center, 9, planetPaint);

    for (var i = 0; i < 8; i++) {
      final phase = (progress * 3.15 + i * 0.173) % 1.0;
      if (!animate || phase >= 0.28) continue;

      final t = phase / 0.28;
      final startX = ((i * 137.0 + 31) % (size.width + 90)) - 45;
      final startY = topInset + 38 + (i * 59.0) % 250;
      final end = Offset(startX + 112 * t, startY + 76 * t);
      final tail = Offset(end.dx - 27, end.dy - 18);
      final fade = (1 - t * 0.58).clamp(0.0, 1.0).toDouble();

      final glow = Paint()
        ..color = const Color(0xFFBFB7EA).withValues(alpha: 0.15 * fade)
        ..strokeWidth = 4.2
        ..strokeCap = StrokeCap.round;
      final core = Paint()
        ..color = const Color(0xFFE0DAFF).withValues(alpha: 0.72 * fade)
        ..strokeWidth = 1.15
        ..strokeCap = StrokeCap.round;
      canvas.drawLine(tail, end, glow);
      canvas.drawLine(tail, end, core);
      canvas.drawCircle(
        end,
        1.65,
        Paint()
          ..color = const Color(0xFFF0ECFF).withValues(alpha: 0.72 * fade),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ThemeAtmospherePainter oldDelegate) =>
      oldDelegate.kind != kind ||
      oldDelegate.progress != progress ||
      oldDelegate.topInset != topInset ||
      oldDelegate.animate != animate ||
      oldDelegate.snowAccumulation != snowAccumulation ||
      oldDelegate.snowAccumProgress != snowAccumProgress ||
      oldDelegate.snowClearProgress != snowClearProgress ||
      oldDelegate.flockProgress != flockProgress ||
      oldDelegate.spiderProgress != spiderProgress ||
      oldDelegate.leftGlow != leftGlow ||
      oldDelegate.rightGlow != rightGlow;
}
