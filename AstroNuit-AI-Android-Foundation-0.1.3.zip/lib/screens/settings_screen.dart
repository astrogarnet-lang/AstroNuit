import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    super.key,
    required this.strings,
    required this.themeKind,
    required this.languageCode,
    required this.animationsEnabled,
    required this.onThemeChanged,
    required this.onLanguageChanged,
    required this.onAnimationsChanged,
  });

  final AppStrings strings;
  final ThemeKind themeKind;
  final String languageCode;
  final bool animationsEnabled;
  final ValueChanged<ThemeKind> onThemeChanged;
  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<bool> onAnimationsChanged;

  String _themeName(ThemeKind kind) {
    switch (kind) {
      case ThemeKind.light:
        return strings.lightTheme;
      case ThemeKind.dark:
        return strings.darkTheme;
      case ThemeKind.halloween:
        return strings.halloweenTheme;
      case ThemeKind.christmas:
        return strings.christmasTheme;
      case ThemeKind.cosmos:
        return strings.cosmosTheme;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
      children: [
        Text(strings.settings, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 22),
        Text(strings.theme, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        RadioGroup<ThemeKind>(
          groupValue: themeKind,
          onChanged: (value) {
            if (value != null) onThemeChanged(value);
          },
          child: Column(
            children: ThemeKind.values.map(
              (kind) => RadioListTile<ThemeKind>(
                value: kind,
                title: Text(_themeName(kind)),
                secondary: CircleAvatar(
                  radius: 11,
                  backgroundColor: AstroNuitTheme.accentFor(kind),
                ),
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
            ).toList(),
          ),
        ),
        const Divider(height: 30),
        Text(strings.language, style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: [
            ButtonSegment<String>(value: 'ru', label: const Text('Русский')),
            ButtonSegment<String>(value: 'en', label: const Text('English')),
          ],
          selected: {languageCode},
          onSelectionChanged: (values) => onLanguageChanged(values.first),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: Text(strings.animations),
          value: animationsEnabled,
          onChanged: onAnimationsChanged,
        ),
        const SizedBox(height: 16),
        Text(
          strings.isRussian
              ? 'Настройки темы и языка действуют в текущем сеансе. Сохранение параметров будет добавлено позже.'
              : 'Theme and language settings apply for this session. Persistent settings will be added later.',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.58),
              ),
        ),
      ],
    );
  }
}
