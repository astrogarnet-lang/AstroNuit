import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key, required this.onFinished});

  final VoidCallback onFinished;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  static const Duration _totalDuration = Duration(seconds: 7);

  late final AnimationController _controller;
  late final Animation<Color?> _background;
  late final Animation<double> _firstOpacity;
  late final Animation<double> _welcomeOpacity;
  bool _completed = false;
  late final bool _russian;

  @override
  void initState() {
    super.initState();
    final code = WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    _russian = code == 'ru';

    _controller = AnimationController(
      vsync: this,
      duration: _totalDuration,
    );

    // The background finishes its white-to-black fade at t=3s.
    _background = ColorTween(
      begin: Colors.white,
      end: Colors.black,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0, 3 / 7, curve: Curves.easeInOutCubic),
      ),
    );

    // The first line is shown from t=0 and fades away between t=2s and t=3s.
    _firstOpacity = TweenSequence<double>([
      TweenSequenceItem(
        tween: ConstantTween<double>(1),
        weight: 2,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1, end: 0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 1,
      ),
      TweenSequenceItem(
        tween: ConstantTween<double>(0),
        weight: 4,
      ),
    ]).animate(_controller);

    // The second line starts exactly two seconds after the first one.
    // It stays on the black screen for five seconds, then fades with the screen.
    _welcomeOpacity = TweenSequence<double>([
      TweenSequenceItem(
        tween: ConstantTween<double>(0),
        weight: 2,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0, end: 1)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 0.35,
      ),
      TweenSequenceItem(
        tween: ConstantTween<double>(1),
        weight: 4.15,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1, end: 0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 0.5,
      ),
    ]).animate(_controller);

    _runSequence();
  }

  Future<void> _runSequence() async {
    await _controller.forward();
    if (!mounted || _completed) return;
    _completed = true;
    widget.onFinished();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final background = _background.value ?? Colors.white;
        final isDark = _controller.value >= 2 / 7;
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: isDark
              ? SystemUiOverlayStyle.light.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.black,
                  systemNavigationBarIconBrightness: Brightness.light,
                )
              : SystemUiOverlayStyle.dark.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.white,
                  systemNavigationBarIconBrightness: Brightness.dark,
                ),
          child: Scaffold(
            backgroundColor: background,
            body: SizedBox.expand(
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Opacity(
                    opacity: _firstOpacity.value,
                    child: Transform.translate(
                      offset: Offset(0, -10 * (1 - _firstOpacity.value)),
                      child: Text(
                        _russian
                            ? 'Твой спутник во тьме'
                            : 'Your companion in the dark',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color.lerp(
                            const Color(0xFF17181B),
                            const Color(0xFFEDEDED),
                            (_controller.value.clamp(0.0, 3 / 7) * (7 / 3)).toDouble(),
                          ),
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          letterSpacing: -0.3,
                        ),
                      ),
                    ),
                  ),
                  Opacity(
                    opacity: _welcomeOpacity.value,
                    child: Transform.translate(
                      offset: Offset(0, 10 * (1 - _welcomeOpacity.value)),
                      child: Text(
                        _russian
                            ? 'Добро пожаловать во тьму'
                            : 'Welcome to dark',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w500,
                          letterSpacing: -0.3,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
