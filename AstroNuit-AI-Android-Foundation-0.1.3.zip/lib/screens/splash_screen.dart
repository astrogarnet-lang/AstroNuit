import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({
    super.key,
    required this.onFinished,
    this.languageCode,
  });

  final VoidCallback onFinished;
  final String? languageCode;

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  /// Intro animation lasts 10 seconds, then the Start button is revealed.
  static const Duration _totalDuration = Duration(seconds: 10);

  late final AnimationController _controller;
  late final Animation<double> _welcomeOpacity;
  late final Animation<double> _buttonOpacity;
  bool _animationDone = false;

  double get _elapsedSeconds => _controller.value * 10.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: _totalDuration,
    );
    // Welcome phrase fades in during seconds 6–8.
    _welcomeOpacity = CurvedAnimation(
      parent: _controller,
      curve: const Interval(
        6 / 10,
        8 / 10,
        curve: Curves.easeOutCubic,
      ),
    );
    // Start button appears in the final second.
    _buttonOpacity = CurvedAnimation(
      parent: _controller,
      curve: const Interval(
        9 / 10,
        1.0,
        curve: Curves.easeOutCubic,
      ),
    );
    _controller.addStatusListener(_handleAnimationStatus);
    _controller.addListener(_handleAnimationValue);
    _controller.forward();
  }

  void _handleAnimationStatus(AnimationStatus status) {
    if (status != AnimationStatus.completed) return;
    _markDone();
  }

  void _handleAnimationValue() {
    if (_controller.value < 1.0) return;
    _markDone();
  }

  void _markDone() {
    if (!mounted || _animationDone) return;
    setState(() => _animationDone = true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final languageCode = widget.languageCode ??
        WidgetsBinding.instance.platformDispatcher.locale.languageCode;
    final isRussian = languageCode.toLowerCase().startsWith('ru');
    final tagline = isRussian
        ? 'Твой спутник во тьме'
        : 'Your companion in the dark';
    final welcome = isRussian
        ? 'Добро пожаловать во тьму'
        : 'Welcome to the darkness';
    final startLabel = isRussian ? 'Начать' : 'Start';

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final elapsed = _elapsedSeconds;
        // Liquid grows from corners during seconds 3–6.
        final liquidProgress =
            ((elapsed - 3.0) / 3.0).clamp(0.0, 1.0).toDouble();
        final isDark = elapsed >= 3.0;

        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: isDark
              ? SystemUiOverlayStyle.light.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.black,
                  systemNavigationBarIconBrightness: Brightness.light,
                )
              : SystemUiOverlayStyle.dark.copyWith(
                  statusBarColor: Colors.transparent,
                  systemNavigationBarColor: Colors.white,
                  systemNavigationBarIconBrightness: Brightness.dark,
                ),
          child: Scaffold(
            backgroundColor: Colors.white,
            body: SizedBox.expand(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // 0–6 s: first phrase on white, then covered by liquid.
                  if (elapsed < 6.0)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 28),
                        child: Text(
                          tagline,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Color(0xFF17181B),
                            fontSize: 22,
                            fontWeight: FontWeight.w500,
                            letterSpacing: -0.3,
                          ),
                        ),
                      ),
                    ),

                  // 3–6 s: black liquid expands only from the four corners.
                  Positioned.fill(
                    child: IgnorePointer(
                      child: CustomPaint(
                        painter: _LiquidDarknessPainter(
                          progress: liquidProgress,
                        ),
                      ),
                    ),
                  ),

                  // 6–10 s: welcome phrase after the screen is fully black.
                  if (elapsed > 6.0)
                    Center(
                      child: FadeTransition(
                        opacity: _welcomeOpacity,
                        child: AnimatedBuilder(
                          animation: _welcomeOpacity,
                          builder: (context, child) => Transform.translate(
                            offset: Offset(
                              0,
                              9 * (1 - _welcomeOpacity.value),
                            ),
                            child: child,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 28),
                            child: Text(
                              welcome,
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.w500,
                                letterSpacing: -0.3,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                  // After ~9 s: Start button; pressing it opens the app.
                  if (elapsed >= 9.0 || _animationDone)
                    Align(
                      alignment: const Alignment(0, 0.42),
                      child: FadeTransition(
                        opacity: _buttonOpacity,
                        child: FilledButton(
                          onPressed: widget.onFinished,
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: const Color(0xFF17181B),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 36,
                              vertical: 14,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(28),
                            ),
                          ),
                          child: Text(
                            startLabel,
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.2,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Black liquid expands exclusively from the four screen corners.
/// At progress 1 the whole display is covered.
class _LiquidDarknessPainter extends CustomPainter {
  const _LiquidDarknessPainter({required this.progress});

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty || progress <= 0) return;

    final p = Curves.easeInOutCubic.transform(
      progress.clamp(0.0, 1.0).toDouble(),
    );
    final diagonal =
        math.sqrt(size.width * size.width + size.height * size.height);
    final paint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    // Only corner origins — no edge pools or mid-screen drops.
    final corners = <Offset>[
      Offset.zero,
      Offset(size.width, 0),
      Offset(size.width, size.height),
      Offset(0, size.height),
    ];
    for (var i = 0; i < corners.length; i++) {
      // Slight per-corner variation keeps the front organic while still
      // originating strictly from the corners.
      final ripple = 1.08 + 0.04 * math.sin(i * 2.1 + p * math.pi * 1.4);
      canvas.drawCircle(corners[i], diagonal * p * ripple, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _LiquidDarknessPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
