import 'package:flutter/material.dart';

import 'app/astronuit_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AstroNuitApp());
}
