import 'package:flutter/material.dart';

enum ThemeKind {
  system,
  light,
  dark,
  halloween,
  christmas,
  cosmos,
  pink,
  aurora,
  autumn,
}

class AstroNuitTheme {
  const AstroNuitTheme._();

  /// Resolve [system] into light/dark from platform brightness.
  static ThemeKind resolve(ThemeKind kind, Brightness platformBrightness) {
    if (kind == ThemeKind.system) {
      return platformBrightness == Brightness.dark
          ? ThemeKind.dark
          : ThemeKind.light;
    }
    return kind;
  }

  static ThemeData build(ThemeKind kind) {
    final spec = _ThemeSpec.forKind(kind);
    final baseScheme = ColorScheme.fromSeed(
      seedColor: spec.accent,
      brightness: spec.brightness,
      surface: spec.surface,
    );

    // Explicitly set every color used by Material components. This prevents
    // ColorScheme.fromSeed's generated tonal palette from leaking an unrelated
    // hue into buttons, navigation indicators, radio controls or input borders.
    final scheme = baseScheme.copyWith(
      primary: spec.accent,
      onPrimary: spec.onAccent,
      primaryContainer: spec.accentContainer,
      onPrimaryContainer: spec.onAccentContainer,
      secondary: spec.secondary,
      onSecondary: spec.onSecondary,
      secondaryContainer: spec.secondaryContainer,
      onSecondaryContainer: spec.onSecondaryContainer,
      tertiary: spec.tertiary,
      onTertiary: spec.onTertiary,
      surface: spec.surface,
      onSurface: spec.text,
      surfaceContainerHighest: spec.surfaceVariant,
      onSurfaceVariant: spec.secondaryText,
      outline: spec.outline,
      outlineVariant: spec.outline.withValues(alpha: 0.62),
      surfaceTint: Colors.transparent,
      inversePrimary: spec.accent,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: spec.brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: spec.background,
      canvasColor: spec.background,
      dividerColor: spec.outline.withValues(alpha: 0.55),
      splashColor: spec.accent.withValues(alpha: 0.08),
      highlightColor: spec.accent.withValues(alpha: 0.035),
      appBarTheme: AppBarTheme(
        backgroundColor: spec.background,
        foregroundColor: spec.text,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: spec.background,
        indicatorColor: spec.accent.withValues(alpha: 0.12),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          return IconThemeData(
            color: states.contains(WidgetState.selected)
                ? spec.accent
                : spec.secondaryText,
          );
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          return TextStyle(
            fontSize: 11,
            fontWeight: states.contains(WidgetState.selected)
                ? FontWeight.w600
                : FontWeight.w400,
            color: states.contains(WidgetState.selected)
                ? spec.accent
                : spec.secondaryText,
          );
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: spec.surfaceVariant.withValues(alpha: 0.55),
        hintStyle: TextStyle(color: spec.secondaryText.withValues(alpha: 0.85)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: spec.outline.withValues(alpha: 0.35)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: spec.outline.withValues(alpha: 0.35)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: spec.accent.withValues(alpha: 0.85)),
        ),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return spec.accent;
          return spec.secondaryText;
        }),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return spec.accent;
          return spec.secondaryText;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return spec.accent.withValues(alpha: 0.35);
          }
          return spec.outline.withValues(alpha: 0.3);
        }),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: spec.accent,
          foregroundColor: spec.onAccent,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
      textTheme: TextTheme(
        bodyLarge: TextStyle(color: spec.text),
        bodyMedium: TextStyle(color: spec.text),
        bodySmall: TextStyle(color: spec.secondaryText),
        titleMedium: TextStyle(color: spec.text, fontWeight: FontWeight.w600),
        titleLarge: TextStyle(color: spec.text, fontWeight: FontWeight.w600),
      ),
    );
  }

  static Color accentFor(ThemeKind kind) => _ThemeSpec.forKind(kind).accent;

  static Color backgroundFor(ThemeKind kind) =>
      _ThemeSpec.forKind(kind).background;
}

class _ThemeSpec {
  const _ThemeSpec({
    required this.brightness,
    required this.background,
    required this.surface,
    required this.surfaceVariant,
    required this.text,
    required this.secondaryText,
    required this.accent,
    required this.onAccent,
    required this.accentContainer,
    required this.onAccentContainer,
    required this.secondary,
    required this.onSecondary,
    required this.secondaryContainer,
    required this.onSecondaryContainer,
    required this.tertiary,
    required this.onTertiary,
    required this.outline,
  });

  final Brightness brightness;
  final Color background;
  final Color surface;
  final Color surfaceVariant;
  final Color text;
  final Color secondaryText;
  final Color accent;
  final Color onAccent;
  final Color accentContainer;
  final Color onAccentContainer;
  final Color secondary;
  final Color onSecondary;
  final Color secondaryContainer;
  final Color onSecondaryContainer;
  final Color tertiary;
  final Color onTertiary;
  final Color outline;

  static _ThemeSpec forKind(ThemeKind kind) {
    switch (kind) {
      case ThemeKind.system:
        // Fallback; callers should resolve system first.
        return forKind(ThemeKind.light);
      case ThemeKind.light:
        return const _ThemeSpec(
          brightness: Brightness.light,
          background: Color(0xFFF6F7F9),
          surface: Color(0xFFFFFFFF),
          surfaceVariant: Color(0xFFE8EAED),
          text: Color(0xFF1A1C1E),
          secondaryText: Color(0xFF5C6370),
          accent: Color(0xFF41464F),
          onAccent: Color(0xFFF8F9FA),
          accentContainer: Color(0xFFDDE1E6),
          onAccentContainer: Color(0xFF1A1C1E),
          secondary: Color(0xFF5C6370),
          onSecondary: Color(0xFFF8F9FA),
          secondaryContainer: Color(0xFFE8EAED),
          onSecondaryContainer: Color(0xFF1A1C1E),
          tertiary: Color(0xFF6B7280),
          onTertiary: Color(0xFFF8F9FA),
          outline: Color(0xFFC5CAD3),
        );
      case ThemeKind.dark:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF101114),
          surface: Color(0xFF181A1F),
          surfaceVariant: Color(0xFF262A31),
          text: Color(0xFFE6E8EC),
          secondaryText: Color(0xFFA8ADB8),
          accent: Color(0xFFC2C5CC),
          onAccent: Color(0xFF15171B),
          accentContainer: Color(0xFF2E333C),
          onAccentContainer: Color(0xFFE6E8EC),
          secondary: Color(0xFF9AA0AA),
          onSecondary: Color(0xFF15171B),
          secondaryContainer: Color(0xFF2A2F38),
          onSecondaryContainer: Color(0xFFE6E8EC),
          tertiary: Color(0xFF8B919C),
          onTertiary: Color(0xFF15171B),
          outline: Color(0xFF3A404A),
        );
      case ThemeKind.halloween:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF120E12),
          surface: Color(0xFF1C161A),
          surfaceVariant: Color(0xFF2A2228),
          text: Color(0xFFE8DFD4),
          secondaryText: Color(0xFFB0A298),
          accent: Color(0xFFAD7955),
          onAccent: Color(0xFF1A1008),
          accentContainer: Color(0xFF3A2818),
          onAccentContainer: Color(0xFFF0D0B0),
          secondary: Color(0xFFC7B4A0),
          onSecondary: Color(0xFF1A1410),
          secondaryContainer: Color(0xFF322820),
          onSecondaryContainer: Color(0xFFE8D8C0),
          tertiary: Color(0xFF82716A),
          onTertiary: Color(0xFF17110E),
          outline: Color(0xFF403638),
        );
      case ThemeKind.christmas:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF101814),
          surface: Color(0xFF19221D),
          surfaceVariant: Color(0xFF26312B),
          text: Color(0xFFE9EEE9),
          secondaryText: Color(0xFFAAB6AC),
          accent: Color(0xFFA2B29F),
          onAccent: Color(0xFF111812),
          accentContainer: Color(0xFF2B3B30),
          onAccentContainer: Color(0xFFD8E3D7),
          secondary: Color(0xFF9B8374),
          onSecondary: Color(0xFF17120F),
          secondaryContainer: Color(0xFF332A25),
          onSecondaryContainer: Color(0xFFE4D5C9),
          tertiary: Color(0xFFC0AE84),
          onTertiary: Color(0xFF201B12),
          outline: Color(0xFF34443A),
        );
      case ThemeKind.cosmos:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF0C0E16),
          surface: Color(0xFF171A25),
          surfaceVariant: Color(0xFF242838),
          text: Color(0xFFEEEFF5),
          secondaryText: Color(0xFFA8AABD),
          accent: Color(0xFFA39CC5),
          onAccent: Color(0xFF151320),
          accentContainer: Color(0xFF302C45),
          onAccentContainer: Color(0xFFE0DCF4),
          secondary: Color(0xFF8D91AE),
          onSecondary: Color(0xFF11131D),
          secondaryContainer: Color(0xFF292D40),
          onSecondaryContainer: Color(0xFFD9DDF1),
          tertiary: Color(0xFF8588A5),
          onTertiary: Color(0xFF10121B),
          outline: Color(0xFF34384D),
        );
      case ThemeKind.pink:
        return const _ThemeSpec(
          brightness: Brightness.light,
          background: Color(0xFFFFF0F5),
          surface: Color(0xFFFFF5F8),
          surfaceVariant: Color(0xFFFCE4EC),
          text: Color(0xFF4A2C3A),
          secondaryText: Color(0xFF9A6B7C),
          accent: Color(0xFFE8A0B5),
          onAccent: Color(0xFF3A1A28),
          accentContainer: Color(0xFFF8D0DC),
          onAccentContainer: Color(0xFF5A2A3A),
          secondary: Color(0xFFD490A8),
          onSecondary: Color(0xFF3A1A28),
          secondaryContainer: Color(0xFFF5D8E4),
          onSecondaryContainer: Color(0xFF5A3040),
          tertiary: Color(0xFFC87898),
          onTertiary: Colors.white,
          outline: Color(0xFFF0C8D4),
        );
      case ThemeKind.aurora:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF0A1218),
          surface: Color(0xFF121C24),
          surfaceVariant: Color(0xFF1C2A34),
          text: Color(0xFFE4F0F4),
          secondaryText: Color(0xFF8AA8B4),
          accent: Color(0xFF5EC8A8),
          onAccent: Color(0xFF061410),
          accentContainer: Color(0xFF1A3A34),
          onAccentContainer: Color(0xFFB8F0E0),
          secondary: Color(0xFF6A9EC8),
          onSecondary: Color(0xFF0A1218),
          secondaryContainer: Color(0xFF1A2C40),
          onSecondaryContainer: Color(0xFFC0DCF0),
          tertiary: Color(0xFFA878D0),
          onTertiary: Color(0xFF120818),
          outline: Color(0xFF2A4050),
        );
      case ThemeKind.autumn:
        return const _ThemeSpec(
          brightness: Brightness.dark,
          background: Color(0xFF1A120E),
          surface: Color(0xFF241A14),
          surfaceVariant: Color(0xFF32241C),
          text: Color(0xFFF0E4D4),
          secondaryText: Color(0xFFB8A08A),
          accent: Color(0xFFD4844A),
          onAccent: Color(0xFF1A1008),
          accentContainer: Color(0xFF3A2818),
          onAccentContainer: Color(0xFFF0D0B0),
          secondary: Color(0xFFC8A060),
          onSecondary: Color(0xFF1A1408),
          secondaryContainer: Color(0xFF3A3018),
          onSecondaryContainer: Color(0xFFF0E0B0),
          tertiary: Color(0xFFA05040),
          onTertiary: Color(0xFFFFF0E8),
          outline: Color(0xFF4A3828),
        );
    }
  }
}
