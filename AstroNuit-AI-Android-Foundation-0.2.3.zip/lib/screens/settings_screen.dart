import 'package:flutter/material.dart';

import '../app/app_strings.dart';
import '../app/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({
    super.key,
    required this.themeKind,
    required this.strings,
    required this.languageCode,
    required this.animationsEnabled,
    required this.onThemeChanged,
    required this.onLanguageChanged,
    required this.onAnimationsChanged,
  });

  final ThemeKind themeKind;
  final AppStrings strings;
  final String languageCode;
  final bool animationsEnabled;
  final ValueChanged<ThemeKind> onThemeChanged;
  final ValueChanged<String> onLanguageChanged;
  final ValueChanged<bool> onAnimationsChanged;

  String _themeName(ThemeKind kind) {
    switch (kind) {
      case ThemeKind.system:
        return strings.systemTheme;
      case ThemeKind.light:
        return strings.lightTheme;
      case ThemeKind.dark:
        return strings.darkTheme;
      case ThemeKind.halloween:
        return strings.halloweenTheme;
      case ThemeKind.christmas:
        return strings.christmasTheme;
      case ThemeKind.cosmos:
        return strings.cosmosTheme;
      case ThemeKind.pink:
        return strings.pinkTheme;
      case ThemeKind.aurora:
        return strings.auroraTheme;
      case ThemeKind.autumn:
        return strings.autumnTheme;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(strings.theme, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          RadioGroup<ThemeKind>(
            groupValue: themeKind,
            onChanged: (value) {
              if (value != null) onThemeChanged(value);
            },
            child: Column(
              children: ThemeKind.values
                  .map(
                    (kind) => RadioListTile<ThemeKind>(
                      value: kind,
                      title: Text(_themeName(kind)),
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                    ),
                  )
                  .toList(),
            ),
          ),
          const Divider(height: 30),
          Text(strings.language, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 10),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment<String>(value: 'ru', label: Text('Русский')),
              ButtonSegment<String>(value: 'en', label: Text('English')),
            ],
            selected: {languageCode},
            onSelectionChanged: (values) => onLanguageChanged(values.first),
          ),
          const Divider(height: 30),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(strings.animations),
            value: animationsEnabled,
            onChanged: onAnimationsChanged,
          ),
          const SizedBox(height: 12),
          Text(
            languageCode == 'ru'
                ? 'Тема, язык и анимации сохраняются на устройстве. «Системная» следует за светлой/тёмной темой устройства.'
                : 'Theme, language and animation settings are saved on this device. “System” follows the device light/dark mode.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withValues(alpha: 0.58),
                ),
          ),
        ],
      ),
    );
  }
}
