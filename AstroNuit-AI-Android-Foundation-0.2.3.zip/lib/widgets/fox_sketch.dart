import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Clean black line-art fox in classic wildlife-logo style:
/// side profile looking slightly upward, full brush tail, walking gait.
/// Original vector paths — not a copy of any third-party artwork.
class FoxSketchAnimation extends StatefulWidget {
  const FoxSketchAnimation({super.key, required this.color});

  final Color color;

  @override
  State<FoxSketchAnimation> createState() => _FoxSketchAnimationState();
}

class _FoxSketchAnimationState extends State<FoxSketchAnimation>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 5200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 108,
      width: double.infinity,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) => RepaintBoundary(
          child: CustomPaint(
            painter: _FoxLinePainter(
              progress: _controller.value,
              accent: widget.color,
            ),
          ),
        ),
      ),
    );
  }
}

class _FoxLinePainter extends CustomPainter {
  const _FoxLinePainter({required this.progress, required this.accent});

  final double progress;
  final Color accent;

  static const double _w = 210;
  static const double _h = 100;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;

    final travel = size.width + _w + 48;
    final x = -_w + travel * progress;
    final phase = progress * math.pi * 2 * 2.2;
    final bob = math.sin(phase * 2) * 1.4;
    final y = (size.height - _h) / 2 + bob + 2;
    final fade = math
        .min(
          (progress / 0.04).clamp(0.0, 1.0),
          ((1 - progress) / 0.05).clamp(0.0, 1.0),
        )
        .toDouble();

    canvas.save();
    canvas.clipRect(Offset.zero & size);
    canvas.translate(x, y);
    _draw(canvas, phase, fade);
    canvas.restore();
  }

  void _draw(Canvas canvas, double phase, double fade) {
    final ink = Color.fromRGBO(22, 22, 26, fade);
    final white = Color.fromRGBO(252, 252, 254, fade * 0.97);

    final stroke = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.35
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..isAntiAlias = true;

    final fill = Paint()
      ..color = white
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    final solid = Paint()
      ..color = ink
      ..style = PaintingStyle.fill
      ..isAntiAlias = true;

    final stride = math.sin(phase) * 5.8;
    final strideOpp = math.sin(phase + math.pi) * 5.5;
    final tailSwing = math.sin(phase * 0.5) * 2.8;
    final headLift = math.sin(phase * 0.3) * 0.9;

    // Far legs
    final legFar = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.6
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(
      Path()
        ..moveTo(78, 58)
        ..cubicTo(84, 66, 88 + strideOpp * 0.35, 74, 92 + strideOpp, 86)
        ..quadraticBezierTo(95 + strideOpp, 90, 99 + strideOpp, 88),
      legFar,
    );
    canvas.drawPath(
      Path()
        ..moveTo(132, 56)
        ..cubicTo(136, 64, 140 + strideOpp * 0.3, 74, 144 + strideOpp, 86)
        ..quadraticBezierTo(147 + strideOpp, 90, 151 + strideOpp, 88),
      legFar,
    );

    // Brush tail
    final tail = Path()
      ..moveTo(76, 50)
      ..cubicTo(55, 36 + tailSwing, 24, 26 + tailSwing, 6, 34 + tailSwing)
      ..cubicTo(-12, 44 + tailSwing, -6, 70 + tailSwing * 0.5, 18, 76)
      ..cubicTo(40, 82, 64, 70, 80, 56)
      ..cubicTo(86, 50, 84, 46, 76, 50)
      ..close();
    canvas.drawPath(tail, fill);
    canvas.drawPath(tail, stroke);

    final tailInner = Paint()
      ..color = ink.withValues(alpha: fade * 0.4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(
      Path()
        ..moveTo(66, 52)
        ..cubicTo(48, 42 + tailSwing * 0.6, 28, 40 + tailSwing, 14, 48 + tailSwing)
        ..moveTo(58, 62)
        ..cubicTo(42, 58 + tailSwing * 0.4, 28, 64, 20, 72),
      tailInner,
    );

    // Torso
    final body = Path()
      ..moveTo(72, 48)
      ..cubicTo(86, 32, 112, 26, 136, 32)
      ..cubicTo(154, 36, 166, 46, 170, 56)
      ..cubicTo(160, 66, 142, 68, 124, 64)
      ..cubicTo(104, 60, 86, 60, 74, 54)
      ..cubicTo(70, 52, 70, 50, 72, 48)
      ..close();
    canvas.drawPath(body, fill);
    canvas.drawPath(body, stroke);

    canvas.drawPath(
      Path()
        ..moveTo(120, 36)
        ..cubicTo(132, 46, 146, 54, 160, 58),
      tailInner,
    );

    // Neck + head looking up
    final head = Path()
      ..moveTo(134, 38)
      ..cubicTo(140, 26 + headLift, 150, 16 + headLift, 162, 14 + headLift)
      ..cubicTo(172, 12 + headLift, 182, 16 + headLift, 190, 24 + headLift)
      ..cubicTo(198, 26 + headLift, 204, 32 + headLift, 210, 38 + headLift)
      ..lineTo(202, 44 + headLift)
      ..cubicTo(192, 42 + headLift, 182, 40 + headLift, 172, 40 + headLift)
      ..cubicTo(160, 40 + headLift, 148, 44, 140, 48)
      ..close();
    canvas.drawPath(head, fill);
    canvas.drawPath(head, stroke);

    // Ears
    final earL = Path()
      ..moveTo(154, 16 + headLift)
      ..lineTo(150, 1 + headLift)
      ..quadraticBezierTo(160, 5 + headLift, 164, 16 + headLift)
      ..close();
    final earR = Path()
      ..moveTo(170, 14 + headLift)
      ..lineTo(174, -1 + headLift)
      ..quadraticBezierTo(182, 5 + headLift, 182, 16 + headLift)
      ..close();
    canvas.drawPath(earL, fill);
    canvas.drawPath(earL, stroke);
    canvas.drawPath(earR, fill);
    canvas.drawPath(earR, stroke);

    canvas.drawPath(
      Path()
        ..moveTo(155, 12 + headLift)
        ..lineTo(154, 5 + headLift)
        ..quadraticBezierTo(159, 8 + headLift, 161, 13 + headLift),
      tailInner,
    );
    canvas.drawPath(
      Path()
        ..moveTo(173, 11 + headLift)
        ..lineTo(175, 4 + headLift)
        ..quadraticBezierTo(179, 8 + headLift, 178, 13 + headLift),
      tailInner,
    );

    // Eye
    canvas.drawOval(
      Rect.fromCenter(
        center: Offset(176, 26 + headLift),
        width: 4.0,
        height: 2.5,
      ),
      solid,
    );

    // Nose
    canvas.drawCircle(Offset(210, 38 + headLift), 2.1, solid);

    canvas.drawPath(
      Path()
        ..moveTo(188, 32 + headLift)
        ..quadraticBezierTo(198, 34 + headLift, 208, 38 + headLift),
      tailInner,
    );

    // Near legs
    final legNear = Paint()
      ..color = ink
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4.4
      ..strokeCap = StrokeCap.round;

    canvas.drawPath(
      Path()
        ..moveTo(80, 56)
        ..cubicTo(76, 64, 70 + stride * 0.45, 74, 66 + stride, 86)
        ..quadraticBezierTo(68 + stride, 90, 74 + stride, 88),
      legNear,
    );
    canvas.drawPath(
      Path()
        ..moveTo(140, 54)
        ..cubicTo(144, 62, 148 + stride * 0.35, 74, 154 + stride, 86)
        ..quadraticBezierTo(158 + stride, 90, 162 + stride, 88),
      legNear,
    );

    canvas.drawPath(
      Path()
        ..moveTo(92, 40)
        ..quadraticBezierTo(108, 34, 124, 36)
        ..moveTo(98, 56)
        ..quadraticBezierTo(116, 58, 130, 54),
      tailInner,
    );

    final accentPaint = Paint()
      ..color = accent.withValues(alpha: fade * 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.15
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(
      const Rect.fromLTWH(102, 34, 30, 20),
      -0.55,
      1.35,
      false,
      accentPaint,
    );
  }

  @override
  bool shouldRepaint(covariant _FoxLinePainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.accent != accent;
}
