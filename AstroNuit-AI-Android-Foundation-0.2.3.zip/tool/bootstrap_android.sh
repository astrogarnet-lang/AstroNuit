#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ ! -d android ]]; then
  TEMP_DIR="$(mktemp -d)"
  trap 'rm -rf "$TEMP_DIR"' EXIT

  flutter create \
    --platforms=android \
    --org com.astronuit \
    --project-name astronuit \
    --android-language kotlin \
    "$TEMP_DIR/astronuit"

  cp -R "$TEMP_DIR/astronuit/android" "$ROOT_DIR/android"

  MANIFEST="$ROOT_DIR/android/app/src/main/AndroidManifest.xml"
  if [[ -f "$MANIFEST" ]]; then
    sed -i 's/android:label="astronuit"/android:label="AstroNuit"/' "$MANIFEST"
    if ! grep -q 'android.permission.INTERNET' "$MANIFEST"; then
      sed -i '/<application/i\    <uses-permission android:name="android.permission.INTERNET" />' "$MANIFEST"
    fi
  fi
  echo "Android platform scaffold created."
else
  echo "Android platform folder already exists."
fi

# Install B&W milky-way launcher icons when provided in the package.
ICON_SRC="$ROOT_DIR/android_icons"
if [[ -d "$ICON_SRC" ]]; then
  for density in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
    dest="$ROOT_DIR/android/app/src/main/res/mipmap-$density"
    mkdir -p "$dest"
    if [[ -f "$ICON_SRC/mipmap-$density/ic_launcher.png" ]]; then
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher.png"
      cp "$ICON_SRC/mipmap-$density/ic_launcher.png" "$dest/ic_launcher_round.png"
    fi
  done
  echo "Launcher icons installed."
fi
