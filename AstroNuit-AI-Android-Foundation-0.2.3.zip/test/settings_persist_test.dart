import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:astronuit/app/app_theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('settings keys round-trip via SharedPreferences', () async {
    SharedPreferences.setMockInitialValues({});
    final p = await SharedPreferences.getInstance();
    await p.setInt('theme_kind', ThemeKind.christmas.index);
    await p.setString('language_code', 'ru');
    await p.setBool('animations_enabled', false);

    final p2 = await SharedPreferences.getInstance();
    expect(p2.getInt('theme_kind'), ThemeKind.christmas.index);
    expect(p2.getString('language_code'), 'ru');
    expect(p2.getBool('animations_enabled'), false);
  });
}
