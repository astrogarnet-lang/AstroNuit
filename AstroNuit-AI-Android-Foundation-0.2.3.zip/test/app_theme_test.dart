import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_theme.dart';

void main() {
  group('AstroNuit themes', () {
    test('light theme uses a light brightness', () {
      expect(AstroNuitTheme.build(ThemeKind.light).brightness, Brightness.light);
      expect(AstroNuitTheme.build(ThemeKind.pink).brightness, Brightness.light);
    });

    test('dark and seasonal themes use dark brightness', () {
      for (final kind in [
        ThemeKind.dark,
        ThemeKind.halloween,
        ThemeKind.christmas,
        ThemeKind.cosmos,
      ]) {
        expect(AstroNuitTheme.build(kind).brightness, Brightness.dark);
      }
    });

    test('standard light and dark accents remain neutral', () {
      final light = AstroNuitTheme.accentFor(ThemeKind.light);
      final dark = AstroNuitTheme.accentFor(ThemeKind.dark);
      expect(light, const Color(0xFF41464F));
      expect(dark, const Color(0xFFC2C5CC));
      expect(light, isNot(AstroNuitTheme.accentFor(ThemeKind.halloween)));
    });

    test('seasonal accents are distinct and explicitly mapped', () {
      expect(
        AstroNuitTheme.accentFor(ThemeKind.halloween),
        const Color(0xFFAD7955),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.christmas),
        const Color(0xFFA2B29F),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.cosmos),
        const Color(0xFFA39CC5),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.pink),
        const Color(0xFFE8A0B5),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.pink),
        isNot(AstroNuitTheme.accentFor(ThemeKind.cosmos)),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.aurora),
        const Color(0xFF5EC8A8),
      );
      expect(
        AstroNuitTheme.accentFor(ThemeKind.autumn),
        const Color(0xFFD4844A),
      );
    });

    test('each concrete theme has its own background color', () {
      final kinds = ThemeKind.values
          .where((k) => k != ThemeKind.system)
          .toList();
      final backgrounds = kinds.map(AstroNuitTheme.backgroundFor).toSet();
      expect(backgrounds, hasLength(kinds.length));
    });
  });
}
