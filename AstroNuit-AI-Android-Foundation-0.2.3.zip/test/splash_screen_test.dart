import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/screens/splash_screen.dart';

void main() {
  testWidgets('splash runs a 10-second liquid transition then shows Start',
      (tester) async {
    var completed = false;
    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(
          languageCode: 'en',
          onFinished: () => completed = true,
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(find.text('Welcome to the darkness'), findsNothing);
    expect(find.text('Start'), findsNothing);
    expect(completed, isFalse);

    // First phrase alone for the first three seconds.
    await tester.pump(const Duration(seconds: 3));
    expect(find.text('Your companion in the dark'), findsOneWidget);
    expect(find.text('Welcome to the darkness'), findsNothing);
    expect(completed, isFalse);

    // Liquid covers during 3–6 s; at 6 s the first phrase is gone and
    // the welcome has not fully appeared yet.
    await tester.pump(const Duration(seconds: 3));
    expect(find.text('Your companion in the dark'), findsNothing);
    expect(completed, isFalse);

    // Welcome phrase emerges over the next two seconds.
    await tester.pump(const Duration(seconds: 2));
    expect(find.text('Welcome to the darkness'), findsOneWidget);
    expect(find.text('Your companion in the dark'), findsNothing);
    expect(completed, isFalse);

    // Final stretch: Start button appears near the end of the 10 s animation.
    await tester.pump(const Duration(seconds: 2));
    await tester.pump(const Duration(milliseconds: 50));
    expect(find.text('Start'), findsOneWidget);
    expect(completed, isFalse);

    // Tapping Start opens the app.
    await tester.tap(find.text('Start'));
    await tester.pump();
    expect(completed, isTrue);
  });

  testWidgets('splash uses Russian text when Russian is selected',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: SplashScreen(
          languageCode: 'ru',
          onFinished: () {},
        ),
      ),
    );
    await tester.pump();

    expect(find.text('Твой спутник во тьме'), findsOneWidget);
    expect(find.text('Добро пожаловать во тьму'), findsNothing);

    await tester.pump(const Duration(seconds: 8));
    expect(find.text('Твой спутник во тьме'), findsNothing);
    expect(find.text('Добро пожаловать во тьму'), findsOneWidget);

    await tester.pump(const Duration(seconds: 2));
    await tester.pump(const Duration(milliseconds: 50));
    expect(find.text('Начать'), findsOneWidget);
  });
}
