import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astronuit/app/app_strings.dart';
import 'package:astronuit/app/app_theme.dart';
import 'package:astronuit/screens/settings_screen.dart';

void main() {
  testWidgets('theme selection is handled by RadioGroup', (tester) async {
    var selectedTheme = ThemeKind.light;

    await tester.pumpWidget(
      MaterialApp(
        theme: AstroNuitTheme.build(selectedTheme),
        home: Scaffold(
          body: StatefulBuilder(
            builder: (context, setState) {
              return SettingsScreen(
                strings: const AppStrings('ru'),
                themeKind: selectedTheme,
                languageCode: 'ru',
                animationsEnabled: true,
                onThemeChanged: (value) {
                  setState(() => selectedTheme = value);
                },
                onLanguageChanged: (_) {},
                onAnimationsChanged: (_) {},
              );
            },
          ),
        ),
      ),
    );

    await tester.tap(find.text('Тёмная'));
    await tester.pumpAndSettle();

    expect(selectedTheme, ThemeKind.dark);
  });
}
