package com.duckhunt.retro;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Duck Hunt Retro — a small, self-contained landscape arcade game.
 * All graphics are drawn with Canvas and all sound effects are bundled WAV files.
 */
public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.onHostPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.onHostResume();
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) gameView.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.handleBack();
        } else {
            super.onBackPressed();
        }
    }

    private static final class GameView extends View {
        private static final float WORLD_W = 960f;
        private static final float WORLD_H = 540f;
        private static final int SKY_DAY = Color.rgb(104, 190, 216);
        private static final int GRASS = Color.rgb(76, 139, 61);
        private static final int DARK = Color.rgb(24, 39, 30);
        private static final int PANEL = Color.rgb(24, 37, 31);
        private static final int GOLD = Color.rgb(255, 205, 75);
        private static final int CREAM = Color.rgb(248, 241, 211);
        private static final Typeface PIXEL = Typeface.create("monospace", Typeface.BOLD);

        private enum State { LOADING, MENU, SHOP, PLAYING, PAUSED, LEVEL_CLEAR, GAME_OVER, VICTORY }

        private static final class Duck {
            float x;
            float y;
            float baseY;
            float vx;
            float phase;
            float age;
            int hp;
            final int maxHp;
            final boolean attacker;
            boolean attacked;
            float retreatTimer;
            float retreatVx;
            float retreatVy;
            float attackCooldown;

            Duck(float x, float y, float vx, int hp, boolean attacker, Random random) {
                this.x = x;
                this.y = y;
                this.baseY = y;
                this.vx = vx;
                this.hp = hp;
                this.maxHp = hp;
                this.attacker = attacker;
                this.phase = random.nextFloat() * 6.28f;
                this.attackCooldown = random.nextFloat() * 1.2f;
            }
        }

        private static final class FallenDuck {
            float x;
            float y;
            float vy;
            float rotation;
            float landedTime;
            boolean queued;
            final float phase;
            final int saleValue;
            FallenDuck(float x, float y, Random random, int saleValue) {
                this.x = x;
                this.y = y;
                this.vy = -45f;
                this.phase = random.nextFloat() * 6.28f;
                this.saleValue = saleValue;
            }
        }

        private static final class FetchJob {
            final float x;
            final FallenDuck duck;
            FetchJob(FallenDuck duck) {
                this.duck = duck;
                this.x = Math.max(65, Math.min(825, duck.x));
            }
        }

        private static final class ConfettiPiece {
            float x, y, vx, vy, life;
            final int color;
            ConfettiPiece(float x, float y, float vx, float vy, int color) {
                this.x = x; this.y = y; this.vx = vx; this.vy = vy;
                this.life = 2.8f; this.color = color;
            }
        }


        private static class Monster {
            float x, y, vx;
            int hp;
            float attackClock;
            boolean fromLeft;
            Monster(float x, float y, float vx, boolean fromLeft) {
                this.x = x; this.y = y; this.vx = vx; this.fromLeft = fromLeft;
                this.hp = 40; this.attackClock = 1.2f + (float) Math.random();
            }
        }
        private static class FallenMonster {
            float x, y, life;
            FallenMonster(float x, float y) { this.x = x; this.y = y; this.life = 18f; }
        }

        private final Paint paint = new Paint();
        private final Random random = new Random();
        private final List<Duck> ducks = new ArrayList<>();
        private final List<FallenDuck> fallenDucks = new ArrayList<>();
        private final ArrayDeque<FetchJob> fetchQueue = new ArrayDeque<>();
        private float[] treeX = {78f, 252f, 510f, 757f, 905f};
        private final SoundEngine sound;
        private final List<Integer> basketDuckValues = new ArrayList<>();
        private final List<ConfettiPiece> confetti = new ArrayList<>();

        private State state = State.LOADING;
        private float loadingElapsed = 0f;
        private static final int WEAPON_PISTOL = 0;
        private static final int WEAPON_SHOTGUN = 1; // pump shotgun, area hit, 100 dmg
        private static final int WEAPON_BOW = 2;     // crossbow (replaces bow)
        private int selectedWeapon = WEAPON_PISTOL;
        private boolean shotgunUnlocked = false;
        private boolean bowUnlocked = false;
        private int pistolMagazine = 10;
        private int shotgunMagazine = 2;
        private boolean bowLoaded = true;
        private int shotgunAmmo = 18;
        private int bowAmmo = 12;
        private int purchasedShotgunAmmo = 0;
        private int purchasedBowAmmo = 0;
        private int ammoPurchaseQuantity = 10;
        private boolean reloading = false;
        private int reloadWeapon = WEAPON_PISTOL;
        private int reloadFillAmount = 0;
        private float reloadTimer = 0f;
        private float reloadDuration = 0f;
        private float reloadAnimation = 0f;
        private boolean deliveryDroneActive = false;
        private float deliveryDroneX = -80f;
        private float deliveryDroneTimer = 0f;
        private int deliveryWeapon = -1;
        private int deliveryAmmoWeapon = -1;
        private int deliveryAmmoAmount = 0;
        private boolean saleDroneActive = false;
        private float saleDroneX = 1040f;
        private float saleDroneTimer = 0f;
        private int dogActionCooldown = 0;
        private float dogCooldownTimer = 0f;
        private float monsterSpawnClock = 8f;
        private boolean monsterActive = false; // legacy single-flag; multi list below
        private float monsterX = -60f;
        private float monsterAttackClock = 0f;
        private float monsterFearTimer = 0f;
        private final List<Monster> monsters = new ArrayList<>();
        private final List<FallenMonster> fallenMonsters = new ArrayList<>();
        private final List<Integer> monsterBasketValues = new ArrayList<>();
        private int monsterBasketCount = 0;
        private float bigDroneTimer = 120f;
        private boolean bigDroneActive = false;
        private float bigDroneX = -120f;
        private float bigDronePhase = 0f; // 0 approach, 1 descend, 2 leave
        private float bigDroneAnim = 0f;
        // Delivery drone phases: 0 fly-in, 1 hover+lower, 2 drop into basket, 3 leave
        private int deliveryPhase = 0;
        private float deliveryAnim = 0f;
        private float deliveryY = 80f;
        // Sale drone phases: 0 approach, 1 descend, 2 grab, 3 leave with duck
        private int salePhase = 0;
        private float saleAnim = 0f;
        private float saleY = 80f;
        private int salePayloadGold = 0;
        private int cookedDucks = 0;
        private boolean cooking = false;
        private float cookingTimer = 0f;
        private boolean autoSellPending = false;
        private boolean birthdaySequenceStarted = false;
        private float birthdayWaitTimer = 0f;
        private float birthdayMessageTimer = 0f;
        private boolean dogHasCake = false;
        private float fireworkClock = 0f;
        private int level = 1;
        private int playerHp = 100;
        private int maxHp = 100;
        private int ammo = 0;
        private int basketCount = 0;
        private int duckInventory = 0;
        private int gold = 0;
        private int purchasedAmmo = 0;
        private int dogCarryCount = 0;
        private int kills = 0;
        private int requiredKills = 0;
        private float levelElapsed = 0f;
        private float levelTimeLimit = 0f;
        private float bossDuckHp = 120f;
        private float enderHp = 300f;
        private float bossX = 680f;
        private float bossY = 430f;
        private float bossDirection = -1f;
        private float spawnClock = 0f;
        private float attackClock = 0f;
        private float nextWaveAt = 0f;
        private int waveIndex = 0;
        private boolean finalBossPhase = false;
        private float finalPhaseElapsed = 0f;
        private float finalAttackClock = 0f;
        private float enderTeleportClock = 7f;
        private float enderTeleportFlash = 0f;
        private float enderWalkPhase = 0f;
        private float extraBossHp = 0f;
        private float extraBossMaxHp = 0f;
        private float extraBossAttackClock = 0f;
        private float extraBossSpawnClock = 0f;
        private int extraBossType = 0;
        private int extraLevel = 1;
        private int shopNextLevel = 1;
        private boolean extraMode = false;
        private boolean shopMidLevel = false;
        private int mapTheme = 0;
        private float weaponRecoil = 0f;
        private float bossDamageFlash = 0f;
        private float playerDamageFlash = 0f;
        private float muzzleFlash = 0f;
        private float crosshairX = -100f;
        private float crosshairY = -100f;
        private float crosshairTimer = 0f;
        private float duckSoundClock = 5f;
        private float dogX = 135f;
        private float dogTargetX = 135f;
        private int dogState = 0; // 0 idle, 1 fetch, 2 return, 3 leave, 4 wait, 5 return with cake
        private boolean dogCarrying = false;
        private final List<Integer> dogCarryValues = new ArrayList<>();
        private boolean soundOn = true;
        private boolean hostPaused = false;
        private boolean treesBroken = false;
        private String failureReason = "Попробуй ещё раз!";
        private long lastFrame = 0L;
        private float menuAnim = 0f;
        private float emergeOffset = 210f;
        private float gameScale = 1f;

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            invalidate();
        }
        private float gameOffsetX = 0f;
        private float gameOffsetY = 0f;

        GameView(Context context) {
            super(context);
            setFocusable(true);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            sound = new SoundEngine(context);
            state = State.LOADING;
            loadingElapsed = 0f;
            lastFrame = SystemClock.uptimeMillis();
            paint.setTypeface(PIXEL);
            paint.setAntiAlias(false);
            loadProgress();
        }

        private SharedPreferences prefs() {
            return getContext().getSharedPreferences("duckhunt_retro_save", Context.MODE_PRIVATE);
        }

        private void saveProgress() {
            prefs().edit()
                    .putInt("gold", gold)
                    .putInt("ammo", ammo)
                    .putInt("shotgunAmmo", shotgunAmmo)
                    .putInt("bowAmmo", bowAmmo)
                    .putInt("pistolMagazine", pistolMagazine)
                    .putInt("shotgunMagazine", shotgunMagazine)
                    .putBoolean("bowLoaded", bowLoaded)
                    .putBoolean("shotgunUnlocked", shotgunUnlocked)
                    .putBoolean("bowUnlocked", bowUnlocked)
                    .putInt("selectedWeapon", selectedWeapon)
                    .apply();
        }

        private void loadProgress() {
            SharedPreferences sp = prefs();
            gold = sp.getInt("gold", 0);
            ammo = sp.getInt("ammo", 50);
            shotgunAmmo = sp.getInt("shotgunAmmo", 0);
            bowAmmo = sp.getInt("bowAmmo", 0);
            pistolMagazine = sp.getInt("pistolMagazine", 10);
            shotgunMagazine = sp.getInt("shotgunMagazine", 0);
            bowLoaded = sp.getBoolean("bowLoaded", true);
            shotgunUnlocked = sp.getBoolean("shotgunUnlocked", false);
            bowUnlocked = sp.getBoolean("bowUnlocked", false);
            selectedWeapon = sp.getInt("selectedWeapon", WEAPON_PISTOL);
        }

        void onHostPause() {
            hostPaused = true;
            if (state == State.PLAYING) state = State.PAUSED;
            sound.pauseAmbience();
            saveProgress();
        }

        void onHostResume() {
            hostPaused = false;
            lastFrame = SystemClock.uptimeMillis();
            if (soundOn) sound.resumeAmbience();
            invalidate();
        }

        void release() {
            sound.release();
        }

        void handleBack() {
            if (state == State.PLAYING) {
                state = State.PAUSED;
            } else if (state == State.SHOP) {
                if (shopMidLevel && hasAnyWeaponAmmo()) state = State.PLAYING;
                else state = State.MENU;
            } else if (state == State.PAUSED) {
                state = State.PLAYING;
            } else if (state == State.MENU) {
                // Keep the game on its title screen; Android handles the app-level back gesture.
            } else {
                state = State.MENU;
            }
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.05f, Math.max(0f, (now - lastFrame) / 1000f));
            lastFrame = now;

            if (state == State.LOADING) {
                loadingElapsed += dt;
                if (loadingElapsed >= 2.4f) state = State.MENU;
            } else if (state == State.PLAYING && !hostPaused) {
                updateGame(dt);
            } else {
                if (state == State.LEVEL_CLEAR || state == State.VICTORY || state == State.SHOP) {
                    updateFallenDucks(dt);
                    updateDog(dt);
                }
                updateBackgroundSystems(dt);
            }
            menuAnim += dt;

            float sx = getWidth() / WORLD_W;
            float sy = getHeight() / WORLD_H;
            // Auto-fit to any screen: whole game world visible, letterboxed if needed.
            if (getWidth() <= 0 || getHeight() <= 0) {
                gameScale = 1f;
                gameOffsetX = 0f;
                gameOffsetY = 0f;
            } else {
                gameScale = Math.min(sx, sy);
                gameOffsetX = (getWidth() - WORLD_W * gameScale) * 0.5f;
                gameOffsetY = (getHeight() - WORLD_H * gameScale) * 0.5f;
            }

            canvas.drawColor(Color.BLACK);
            canvas.save();
            canvas.translate(gameOffsetX, gameOffsetY);
            canvas.scale(gameScale, gameScale);

            drawWorld(canvas);
            drawHud(canvas);
            drawCrosshair(canvas);
            drawStateOverlay(canvas);
            if (playerDamageFlash > 0f && state == State.PLAYING) {
                float flashAlpha = Math.min(0.42f, playerDamageFlash * 1.2f);
                fillRect(canvas, 0, 0, WORLD_W, WORLD_H,
                        Color.argb((int) (flashAlpha * 255), 230, 20, 30));
            }

            canvas.restore();
            postInvalidateDelayed(state == State.PLAYING ? 16 : 60);
        }

        private void startNewGame() {
            basketCount = 0;
            duckInventory = 0;
            basketDuckValues.clear();
            cookedDucks = 0;
            cooking = false;
            autoSellPending = false;
            shotgunUnlocked = false;
            bowUnlocked = false;
            selectedWeapon = WEAPON_PISTOL;
            dogActionCooldown = 0;
            dogCooldownTimer = 0f;
            monsterActive = false;
            monsterFearTimer = 0f;
            birthdaySequenceStarted = false;
            birthdayMessageTimer = 0f;
            dogHasCake = false;
            confetti.clear();
            fetchQueue.clear();
            fallenDucks.clear();
            treeX = new float[]{78f, 252f, 510f, 757f, 905f};
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            dogCarryValues.clear();
            duckInventory = 0;
            gold = 0;
            ammo = 50;
            shotgunAmmo = 0;
            bowAmmo = 0;
            pistolMagazine = 10;
            purchasedAmmo = 0;
            saveProgress();
            extraMode = false;
            extraLevel = 1;
            startLevel(1);
        }

        private void startExtraGame() {
            basketCount = 0;
            duckInventory = 0;
            basketDuckValues.clear();
            cookedDucks = 0;
            cooking = false;
            autoSellPending = false;
            shotgunUnlocked = false;
            bowUnlocked = false;
            selectedWeapon = WEAPON_PISTOL;
            dogActionCooldown = 0;
            monsterActive = false;
            monsterFearTimer = 0f;
            birthdaySequenceStarted = false;
            birthdayMessageTimer = 0f;
            dogHasCake = false;
            confetti.clear();
            gold = 0;
            purchasedAmmo = 0;
            fetchQueue.clear();
            fallenDucks.clear();
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            extraMode = true;
            extraLevel = 1;
            startLevel(1);
        }

        private void openShop(int targetLevel) {
            // Shop screen removed — economy UI is always available in-game.
            shopNextLevel = targetLevel;
            shopMidLevel = false;
            if (extraMode) startExtraLevel(targetLevel);
            else startLevel(targetLevel);
        }

        private void openAmmoShop() {
            if (state != State.PLAYING) return;
            // Shop removed; mid-level pause no longer opens a separate shop screen.
            shopMidLevel = false;
            lastFrame = SystemClock.uptimeMillis();
        }

        private void startLevel(int newLevel) {
            if (extraMode) {
                startExtraLevel(newLevel);
                return;
            }
            level = newLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            nextWaveAt = 0f;
            waveIndex = 0;
            finalBossPhase = false;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderTeleportClock = 7f;
            enderTeleportFlash = 0f;
            enderWalkPhase = 0f;
            treesBroken = false;
            bossDamageFlash = 0f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            emergeOffset = 210f;
            bossDuckHp = 120f;
            enderHp = 300f;
            bossX = 680f;
            bossY = 430f;
            bossDirection = -1f;
            duckSoundClock = 4f + random.nextFloat() * 3f;

            if (level <= 3 || level == 6) {
                maxHp = 100;
            } else {
                maxHp = 500;
            }
            playerHp = maxHp;

            switch (level) {
                case 1:
                    requiredKills = 10;
                    // First level grant: 50 rounds (base 30 + 20). Later levels keep current stock.
                    if (ammo <= 0 && shotgunAmmo <= 0 && bowAmmo <= 0) ammo = 50;
                    levelTimeLimit = 180f;
                    spawnFriendlyDucks(10, 1, 0.28f, 0.68f);
                    break;
                case 2:
                    requiredKills = 20;
                    levelTimeLimit = 240f;
                    spawnFriendlyDucks(20, 3, 0.45f, 0.9f);
                    break;
                case 3:
                    requiredKills = 20;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(20, 55, 0.72f, 1.12f);
                    bossDuckHp = 120f;
                    break;
                case 4:
                    requiredKills = 35;
                    levelTimeLimit = 0f;
                    // Five attacks/waves: the first starts immediately, the next four every 30 seconds.
                    spawnLevelFourWave();
                    break;
                case 5:
                    requiredKills = 10;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(10, 1, 0.52f, 0.86f);
                    break;
                case 6:
                    requiredKills = 1;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(1, 1, 0.18f, 0.18f);
                    break;
                default:
                    level = 1;
                    startLevel(1);
                    return;
            }
            ammo += purchasedAmmo;
            shotgunAmmo = Math.max(18, ammo / 3) + purchasedShotgunAmmo;
            bowAmmo = 12 + purchasedBowAmmo;
            purchasedAmmo = 0;
            purchasedShotgunAmmo = 0;
            purchasedBowAmmo = 0;
            pistolMagazine = 10;
            shotgunMagazine = 2;
            bowLoaded = true;
            if ((selectedWeapon == WEAPON_SHOTGUN && !shotgunUnlocked)
                    || (selectedWeapon == WEAPON_BOW && !bowUnlocked)) {
                selectedWeapon = WEAPON_PISTOL;
            }
            reloading = false;
            dogCarryValues.clear();
            monsterActive = false;
            monsters.clear();
            fallenMonsters.clear();
            monsterBasketValues.clear();
            monsterBasketCount = 0;
            bigDroneTimer = 120f;
            bigDroneActive = false;
            monsterSpawnClock = 28f + random.nextFloat() * 22f;
            monsterFearTimer = 0f;
            cooking = false;
            cookingTimer = 0f;
            dogCooldownTimer = 0f;
            birthdaySequenceStarted = false;
            birthdayMessageTimer = 0f;
            dogHasCake = false;
            confetti.clear();
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void startExtraLevel(int newLevel) {
            extraLevel = Math.max(1, Math.min(100, newLevel));
            level = extraLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            extraBossAttackClock = 0f;
            extraBossSpawnClock = 0f;
            extraBossHp = 120f + extraLevel * 18f;
            extraBossMaxHp = extraBossHp;
            extraBossType = random.nextInt(4);
            mapTheme = random.nextInt(5);
            treesBroken = false;
            finalBossPhase = false;
            bossX = 260f + random.nextFloat() * 440f;
            bossY = 140f + random.nextFloat() * 100f;
            bossDirection = random.nextBoolean() ? 1f : -1f;
            playerHp = maxHp = 500;
            // Extra levels also keep current ammo — no free refill.
            purchasedAmmo = 0;
            purchasedShotgunAmmo = 0;
            purchasedBowAmmo = 0;
            if (ammo <= 0 && shotgunAmmo <= 0 && bowAmmo <= 0) ammo = 50;
            pistolMagazine = 10;
            shotgunMagazine = 2;
            bowLoaded = true;
            if ((selectedWeapon == WEAPON_SHOTGUN && !shotgunUnlocked)
                    || (selectedWeapon == WEAPON_BOW && !bowUnlocked)) {
                selectedWeapon = WEAPON_PISTOL;
            }
            reloading = false;
            dogCarryValues.clear();
            monsterActive = false;
            monsters.clear();
            fallenMonsters.clear();
            monsterSpawnClock = 25f + random.nextFloat() * 25f;
            monsterFearTimer = 0f;
            cooking = false;
            cookingTimer = 0f;
            dogCooldownTimer = 0f;
            levelTimeLimit = 0f;
            requiredKills = 8 + random.nextInt(7) + extraLevel / 4;
            treeX = new float[5 + random.nextInt(4)];
            for (int i = 0; i < treeX.length; i++) treeX[i] = 45f + i * (870f / Math.max(1, treeX.length - 1)) + random.nextFloat() * 26f - 13f;
            for (int i = 0; i < requiredKills; i++) {
                float x = 65f + random.nextFloat() * 830f;
                float y = 105f + random.nextFloat() * 220f;
                int hp = 2 + Math.min(16, extraLevel / 5) + random.nextInt(4);
                boolean attacker = random.nextFloat() < 0.22f;
                float speed = 0.55f + random.nextFloat() * 0.95f + extraLevel * 0.003f;
                ducks.add(new Duck(x, y, speed * 95f * (random.nextBoolean() ? 1f : -1f), hp, attacker, random));
            }
            duckSoundClock = 2f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void spawnFriendlyDucks(int count, int hp, float minSpeed, float maxSpeed) {
            for (int i = 0; i < count; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 110 + random.nextFloat() * 190;
                float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
                float direction = random.nextBoolean() ? 1f : -1f;
                ducks.add(new Duck(x, y, speed * 95f * direction, hp, false, random));
            }
        }

        private void spawnLevelFourWave() {
            if (waveIndex >= 5) return;
            waveIndex++;
            for (int i = 0; i < 7; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 95 + random.nextFloat() * 165;
                ducks.add(new Duck(x, y, 0f, 7, true, random));
            }
            nextWaveAt = waveIndex * 30f;
            sound.playDuckFly();
        }

        private void updateGame(float dt) {
            levelElapsed += dt;
            if (!extraMode && level <= 2 && levelTimeLimit > 0f && levelElapsed >= levelTimeLimit) {
                failGame("Время вышло!");
                return;
            }

            if (muzzleFlash > 0f) muzzleFlash -= dt;
            if (weaponRecoil > 0f) weaponRecoil = Math.max(0f, weaponRecoil - dt * 5f);
            updateWeaponSystems(dt);
            updateBackgroundSystems(dt);
            updateBirthday(dt);
            if (crosshairTimer > 0f) crosshairTimer -= dt;
            if (playerDamageFlash > 0f) playerDamageFlash -= dt;
            if (bossDamageFlash > 0f) bossDamageFlash -= dt;

            duckSoundClock -= dt;
            if (duckSoundClock <= 0f && !ducks.isEmpty()) {
                sound.playDuckFly();
                if (random.nextFloat() < 0.72f) sound.playQuack();
                duckSoundClock = 5f + random.nextFloat() * 6f;
            }

            if (!extraMode && level == 4 && waveIndex < 5 && levelElapsed >= nextWaveAt) {
                spawnLevelFourWave();
            }

            updateDucks(dt);
            if (state != State.PLAYING) return;
            updateFallenDucks(dt);
            updateDog(dt);
            if (false && extraMode && !hasAnyWeaponAmmo()) {
                openAmmoShop();
                return;
            }

            if (extraMode) {
                updateExtraBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 3) {
                updateLargeDuckBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 5 && finalBossPhase) {
                updateEnderman(dt);
                if (state != State.PLAYING) return;
            }

            if (extraMode) {
                if (extraBossHp <= 0f) clearLevel();
            } else if (level == 1 || level == 2 || level == 5 && !finalBossPhase) {
                if (kills >= requiredKills) {
                    if (level == 5) beginEndermanPhase();
                    else clearLevel();
                } else if (!hasAnyWeaponAmmo() && level != 5 && level != 6) {
                    failGame("Патроны закончились!");
                }
            } else if (!extraMode && level == 4) {
                if (waveIndex >= 5 && ducks.isEmpty()) {
                    clearLevel();
                } else if (!hasAnyWeaponAmmo() && !ducks.isEmpty()) {
                    failGame("Патроны закончились!");
                }
            } else if (!extraMode && level == 6 && birthdayMessageTimer <= 0f
                    && birthdaySequenceStarted && dogState == 0 && !dogHasCake) {
                // The birthday scene is completed by updateBirthday after the dog returns with the cake.
            }
        }

        private void updateDucks(float dt) {
            Iterator<Duck> iterator = ducks.iterator();
            while (iterator.hasNext()) {
                Duck duck = iterator.next();
                duck.age += dt;
                if (duck.attacker) {
                    duck.attackCooldown = Math.max(0f, duck.attackCooldown - dt);
                    if (duck.retreatTimer > 0f) {
                        duck.retreatTimer -= dt;
                        duck.x += duck.retreatVx * dt;
                        duck.y += duck.retreatVy * dt;
                        duck.x = Math.max(28f, Math.min(932f, duck.x));
                        duck.y = Math.max(82f, Math.min(320f, duck.y));
                        continue;
                    }
                    float targetX = 480f;
                    float targetY = 422f;
                    float dx = targetX - duck.x;
                    float dy = targetY - duck.y;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance > 1f) {
                        float speed = 82f + Math.min(50f, extraMode ? extraLevel * 0.6f : 0f);
                        duck.x += dx / distance * speed * dt;
                        duck.y += dy / distance * speed * dt;
                    }
                    if (distance < 48f && duck.attackCooldown <= 0f) {
                        damagePlayer(1);
                        if (state != State.PLAYING) return;
                        float len = Math.max(1f, distance);
                        duck.retreatVx = -dx / len * 245f;
                        duck.retreatVy = -Math.max(0.35f, dy / len) * 150f;
                        duck.retreatTimer = 0.95f;
                        duck.attackCooldown = 2.0f;
                        duck.attacked = true;
                    }
                } else {
                    duck.x += duck.vx * dt;
                    duck.y = duck.baseY + (float) Math.sin(duck.age * 2.7f + duck.phase) * 17f;
                    if (duck.x < 42f) duck.vx = Math.abs(duck.vx);
                    if (duck.x > 918f) duck.vx = -Math.abs(duck.vx);
                }
            }
        }

        private void updateFallenDucks(float dt) {
            Iterator<FallenDuck> iterator = fallenDucks.iterator();
            while (iterator.hasNext()) {
                FallenDuck duck = iterator.next();
                if (duck.y < 414f) {
                    duck.vy += 315f * dt;
                    duck.y += duck.vy * dt;
                    duck.rotation += 210f * dt;
                    if (duck.y >= 414f) {
                        duck.y = 414f;
                        duck.vy = 0f;
                    }
                } else {
                    duck.landedTime += dt;
                    if (!duck.queued && duck.landedTime >= 0.28f) {
                        fetchQueue.add(new FetchJob(duck));
                        duck.queued = true;
                    }
                }
            }
        }

        private void updateExtraBoss(float dt) {
            bossX += bossDirection * (38f + extraLevel * 0.22f) * dt;
            if (bossX < 190f) bossDirection = 1f;
            if (bossX > 790f) bossDirection = -1f;
            bossY = 150f + (float) Math.sin(levelElapsed * 1.35f) * 35f;
            extraBossSpawnClock += dt;
            if (extraBossSpawnClock >= Math.max(2.8f, 7f - extraLevel * 0.025f) && ducks.size() < 24) {
                extraBossSpawnClock = 0f;
                int count = 1 + random.nextInt(2);
                for (int i = 0; i < count; i++) {
                    float x = bossX + random.nextFloat() * 90f - 45f;
                    float y = bossY + 35f + random.nextFloat() * 45f;
                    int hp = 2 + Math.min(16, extraLevel / 5);
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1f : -1f) * 90f, hp, random.nextFloat() < 0.3f, random));
                }
                sound.playDuckFly();
            }
            extraBossAttackClock += dt;
            if (extraBossAttackClock >= Math.max(2.4f, 6.0f - extraLevel * 0.02f)) {
                extraBossAttackClock = 0f;
                damagePlayer(3 + extraLevel / 4);
            }
        }

        private void updateLargeDuckBoss(float dt) {
            bossX += bossDirection * 44f * dt;
            if (bossX < 560f) bossDirection = 1f;
            if (bossX > 825f) bossDirection = -1f;
            bossY = 156f + (float) Math.sin(levelElapsed * 1.7f) * 26f;

            spawnClock += dt;
            if (spawnClock >= 7f && ducks.size() < 28) {
                spawnClock = 0f;
                for (int i = 0; i < 2; i++) {
                    float x = bossX + random.nextFloat() * 80f - 40f;
                    float y = bossY + 30f + random.nextFloat() * 60f;
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1 : -1) * 72f, 55, false, random));
                }
                sound.playDuckFly();
            }

            attackClock += dt;
            if (attackClock >= 6.5f) {
                attackClock = 0f;
                damagePlayer(8);
                sound.playQuack();
            }
        }

        private void beginEndermanPhase() {
            if (finalBossPhase) return;
            finalBossPhase = true;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderHp = 300f;
            ammo = Integer.MAX_VALUE;
            treesBroken = true;
            ducks.clear();
            sound.playMonsterImpact();
        }

        private void updateEnderman(float dt) {
            finalPhaseElapsed += dt;
            emergeOffset = Math.max(0f, 210f - finalPhaseElapsed * 105f);
            if (finalPhaseElapsed > 2.3f) {
                enderWalkPhase += dt;
                bossX += bossDirection * 72f * dt;
                if (bossX < 155f) bossDirection = 1f;
                if (bossX > 805f) bossDirection = -1f;
                enderTeleportClock -= dt;
                if (enderTeleportClock <= 0f) {
                    bossX = 150f + random.nextFloat() * 660f;
                    bossDirection = random.nextBoolean() ? 1f : -1f;
                    enderTeleportClock = 7f + random.nextFloat() * 4f;
                    enderTeleportFlash = 0.55f;
                    sound.playMonsterImpact();
                }
                if (enderTeleportFlash > 0f) enderTeleportFlash = Math.max(0f, enderTeleportFlash - dt);
                finalAttackClock += dt;
                if (finalAttackClock >= 2.7f) {
                    finalAttackClock = 0f;
                    damagePlayer(50);
                    sound.playMonsterImpact();
                }
            }
        }

        private void updateDog(float dt) {
            if (dogState == 0 && !fetchQueue.isEmpty()) {
                dogTargetX = fetchQueue.peek().x;
                dogState = 1;
                dogCarryCount = 0;
                dogCarryValues.clear();
                dogCarrying = false;
            }
            if (dogState == 1) {
                dogX = moveTowards(dogX, dogTargetX, 240f * dt);
                if (Math.abs(dogX - dogTargetX) < 3f) {
                    if (!fetchQueue.isEmpty()) {
                        FetchJob collected = fetchQueue.remove();
                        fallenDucks.remove(collected.duck);
                        dogCarryCount++;
                        dogCarryValues.add(collectedValueFallback(collected.duck.saleValue));
                        dogCarrying = true;
                        if (dogCarryCount < 5 && !fetchQueue.isEmpty()) {
                            dogTargetX = fetchQueue.peek().x;
                        } else {
                            dogState = 2;
                        }
                    } else {
                        dogState = 2;
                    }
                }
            } else if (dogState == 2) {
                dogX = moveTowards(dogX, 620f, 265f * dt);
                if (dogX >= 617f) {
                    basketDuckValues.addAll(dogCarryValues);
                    basketCount = basketDuckValues.size();
                    duckInventory = basketCount;
                    dogCarryValues.clear();
                    dogCarryCount = 0;
                    dogCarrying = false;
                    sound.playDogBark();
                    if (level == 6 && birthdaySequenceStarted) {
                        dogState = 3;
                    } else {
                        dogState = 0;
                    }
                }
            } else if (dogState == 3) {
                dogX = moveTowards(dogX, 1040f, 280f * dt);
                if (dogX >= 1037f) {
                    dogState = 4;
                    birthdayWaitTimer = 15f;
                }
            } else if (dogState == 4) {
                birthdayWaitTimer = Math.max(0f, birthdayWaitTimer - dt);
                if (birthdayWaitTimer <= 0f) {
                    dogHasCake = true;
                    dogState = 5;
                    dogX = 1040f;
                }
            } else if (dogState == 5) {
                dogX = moveTowards(dogX, 620f, 230f * dt);
                if (dogX <= 623f) {
                    dogState = 0;
                    birthdayMessageTimer = 8f;
                    fireworkClock = 0f;
                    spawnConfettiBurst(480f, 250f, 70);
                }
            }
            if (autoSellPending && dogState == 0 && fetchQueue.isEmpty()
                    && fallenDucks.isEmpty() && !cooking) {
                sellDucks();
                autoSellPending = false;
            }
        }

        private int collectedValueFallback(int value) {
            return Math.max(1, value);
        }

        private float moveTowards(float current, float target, float step) {
            if (current < target) return Math.min(target, current + step);
            return Math.max(target, current - step);
        }

        private void damagePlayer(int amount) {
            playerHp = Math.max(0, playerHp - amount);
            playerDamageFlash = 0.3f;
            if (playerHp <= 0) failGame("Охотник выбыл!");
        }

        private void sellDucks() {
            if (basketDuckValues.isEmpty() && cookedDucks <= 0) return;
            // Economy: raw duck = 1 gold, grilled = 10 gold.
            int total = cookedDucks * 10;
            for (int value : basketDuckValues) total += Math.max(1, value);
            salePayloadGold = total;
            // Gold is awarded when the sale drone actually leaves with the goods.
            basketDuckValues.clear();
            basketCount = 0;
            duckInventory = 0;
            cookedDucks = 0;
            saleDroneActive = true;
            salePhase = 0;
            saleAnim = 0f;
            saleY = 70f;
            saleDroneX = 1040f;
            saleDroneTimer = 5.5f;
            sound.playDroneSale();
        }

        private void sellMonsterBasket() {
            if (monsterBasketValues.isEmpty()) return;
            int total = 0;
            for (int v : monsterBasketValues) total += v;
            salePayloadGold += total;
            gold += total;
            monsterBasketValues.clear();
            monsterBasketCount = 0;
            sound.playDroneSale();
        }

        private void buyAmmo(int amount) {
            if ((selectedWeapon == WEAPON_SHOTGUN && !shotgunUnlocked)
                    || (selectedWeapon == WEAPON_BOW && !bowUnlocked)) return;
            int safeAmount = Math.max(1, Math.min(999, amount));
            int unitCost = selectedWeapon == WEAPON_BOW ? 3 : 2;
            int cost = safeAmount * unitCost;
            if (gold < cost || deliveryDroneActive) return;
            gold -= cost;
            deliveryAmmoWeapon = selectedWeapon;
            deliveryAmmoAmount = safeAmount;
            deliveryWeapon = -1;
            deliveryDroneActive = true;
            deliveryPhase = 0;
            deliveryAnim = 0f;
            deliveryY = 80f;
            deliveryDroneX = -80f;
            deliveryDroneTimer = 6f;
            sound.playDroneDelivery();
        }

        private void buySelectedWeapon() {
            if (deliveryDroneActive) return;
            int price = selectedWeapon == WEAPON_SHOTGUN ? 35 : selectedWeapon == WEAPON_BOW ? 55 : 0;
            boolean owned = selectedWeapon == WEAPON_PISTOL
                    || (selectedWeapon == WEAPON_SHOTGUN && shotgunUnlocked)
                    || (selectedWeapon == WEAPON_BOW && bowUnlocked);
            if (owned || price <= 0 || gold < price) return;
            gold -= price;
            deliveryWeapon = selectedWeapon;
            deliveryAmmoWeapon = -1;
            deliveryAmmoAmount = 0;
            deliveryDroneActive = true;
            deliveryPhase = 0;
            deliveryAnim = 0f;
            deliveryY = 80f;
            deliveryDroneX = -80f;
            deliveryDroneTimer = 7f;
            sound.playDroneDelivery();
        }

        private void completeDelivery() {
            // Called when the package is lowered into the basket — item becomes available only then.
            if (deliveryAmmoWeapon == WEAPON_PISTOL) ammo += deliveryAmmoAmount;
            else if (deliveryAmmoWeapon == WEAPON_SHOTGUN) shotgunAmmo += deliveryAmmoAmount;
            else if (deliveryAmmoWeapon == WEAPON_BOW) bowAmmo += deliveryAmmoAmount;
            if (deliveryWeapon == WEAPON_SHOTGUN) {
                shotgunUnlocked = true;
                selectedWeapon = WEAPON_SHOTGUN;
            }
            if (deliveryWeapon == WEAPON_BOW) {
                bowUnlocked = true;
                selectedWeapon = WEAPON_BOW;
            }
            deliveryAmmoWeapon = -1;
            deliveryWeapon = -1;
            deliveryAmmoAmount = 0;
            saveProgress();
            // Drone stays active until leave phase finishes.
        }

        private void startCooking() {
            if (cooking || basketDuckValues.size() < 4) return;
            for (int i = 0; i < 4; i++) basketDuckValues.remove(0);
            basketCount = basketDuckValues.size();
            duckInventory = basketCount;
            cooking = true;
            cookingTimer = 50f;
            sound.playGrillStart();
        }

        private void useDogAbility() {
            if (state != State.PLAYING || dogCooldownTimer > 0f) return;
            dogCooldownTimer = 20f;
            monsterActive = false;
            monsterFearTimer = 50f;
            monsterSpawnClock = 35f + random.nextFloat() * 25f;
            sound.playDogBark();
            if (dogState == 0) {
                dogX = Math.max(620f, dogX);
            }
        }

        private void leaveShop() {
            if (shopMidLevel) {
                if (hasAnyWeaponAmmo()) {
                    shopMidLevel = false;
                    state = State.PLAYING;
                    lastFrame = SystemClock.uptimeMillis();
                }
            } else {
                int target = shopNextLevel;
                shopMidLevel = false;
                startLevel(target);
            }
        }

        private void clearLevel() {
            if (state == State.PLAYING) {
                state = State.LEVEL_CLEAR;
                autoSellPending = true;
                if (dogState == 0 && fetchQueue.isEmpty() && fallenDucks.isEmpty() && !cooking) {
                    sellDucks();
                    autoSellPending = false;
                }
            }
        }

        private void failGame(String reason) {
            failureReason = reason;
            state = State.GAME_OVER;
        }

        private void shoot(float x, float y) {
            if (state != State.PLAYING || birthdaySequenceStarted && level == 6) return;
            if (reloading) return;
            if (!weaponHasLoadedShot()) {
                beginReload();
                return;
            }

            int weapon = selectedWeapon;
            if (weapon == WEAPON_PISTOL) pistolMagazine--;
            else if (weapon == WEAPON_SHOTGUN) shotgunMagazine--;
            else bowLoaded = false;

            muzzleFlash = weapon == WEAPON_SHOTGUN ? 0.18f : 0.11f;
            weaponRecoil = weapon == WEAPON_SHOTGUN ? 1.35f : weapon == WEAPON_BOW ? 0.55f : 1f;
            crosshairX = x;
            crosshairY = y;
            crosshairTimer = 0.7f;
            if (weapon == WEAPON_SHOTGUN) sound.playShotgunShot();
            else if (weapon == WEAPON_BOW) sound.playBowShot();
            else sound.playShot();

            if (extraMode) {
                if (distance(x, y, bossX, bossY) < 108f) {
                    extraBossHp = Math.max(0f, extraBossHp - (weapon == WEAPON_SHOTGUN ? 100f : weapon == WEAPON_BOW ? 25f : 10f));
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (extraBossHp <= 0f) clearLevel();
                }
                afterWeaponShot();
                return;
            }

            if (level == 5 && finalBossPhase) {
                if (pointInEnderman(x, y)) {
                    enderHp = Math.max(0f, enderHp - (weapon == WEAPON_SHOTGUN ? 100f : weapon == WEAPON_BOW ? 25f : 10f));
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (enderHp <= 0f) clearLevel();
                }
                afterWeaponShot();
                return;
            }

            if (level == 3 && distance(x, y, bossX, bossY) < (weapon == WEAPON_SHOTGUN ? 460f : 92f)) {
                bossDuckHp = Math.max(0f, bossDuckHp - (weapon == WEAPON_SHOTGUN ? 100f : weapon == WEAPON_BOW ? 25f : 10f));
                bossDamageFlash = 0.14f;
                sound.playQuack();
                if (bossDuckHp <= 0f) clearLevel();
                afterWeaponShot();
                return;
            }

            // Shotgun: area blast, 100 damage to every target in radius.
            // Pistol: single target 10 dmg. Crossbow: single target, kills normal ducks.
            float hitRadius = weapon == WEAPON_SHOTGUN ? 220f : 36f;
            java.util.ArrayList<Duck> toRemove = new java.util.ArrayList<>();
            Duck nearestPistol = null;
            float nearestDist = Float.MAX_VALUE;
            for (Duck duck : ducks) {
                if (isHidden(duck)) continue;
                float d = distance(x, y, duck.x, duck.y);
                if (d >= hitRadius) continue;
                if (weapon == WEAPON_SHOTGUN) {
                    duck.hp -= 100;
                    if (duck.hp <= 0) toRemove.add(duck);
                } else if (weapon == WEAPON_BOW) {
                    if (d < nearestDist) { nearestDist = d; nearestPistol = duck; }
                } else {
                    if (d < nearestDist) { nearestDist = d; nearestPistol = duck; }
                }
            }
            if (weapon != WEAPON_SHOTGUN && nearestPistol != null) {
                if (weapon == WEAPON_BOW) nearestPistol.hp = 0;
                else nearestPistol.hp -= 10;
                if (nearestPistol.hp <= 0) toRemove.add(nearestPistol);
            }
            for (Duck hit : toRemove) {
                if (!ducks.contains(hit)) continue;
                ducks.remove(hit);
                kills++;
                int value = 1; // raw duck sells for 1 gold
                fallenDucks.add(new FallenDuck(hit.x, hit.y, random, value));
                sound.playQuack();
                if (level == 6 && !extraMode) birthdaySequenceStarted = true;
            }
            // Also hit monsters in shotgun radius / crosshair
            java.util.ArrayList<Monster> deadM = new java.util.ArrayList<>();
            for (Monster mon : monsters) {
                float d = distance(x, y, mon.x, mon.y);
                float r = weapon == WEAPON_SHOTGUN ? 220f : 40f;
                if (d < r) {
                    mon.hp -= (weapon == WEAPON_SHOTGUN ? 100 : weapon == WEAPON_BOW ? 25 : 10);
                    if (mon.hp <= 0) deadM.add(mon);
                }
            }
            for (Monster mon : deadM) {
                monsters.remove(mon);
                fallenMonsters.add(new FallenMonster(mon.x, mon.y));
                sound.playMonsterHit();
            }

            afterWeaponShot();
            if (!extraMode && level == 6 && kills >= 1 && ducks.isEmpty()) {
                // Wait for the dog to retrieve the single duck and complete the birthday scene.
                return;
            }
            // Out of ammo no longer ends the level — player can buy more in-game.

        }

        private void afterWeaponShot() {
            if (selectedWeapon == WEAPON_PISTOL && pistolMagazine == 0 && ammo > 0) beginReload();
            else if (selectedWeapon == WEAPON_SHOTGUN && shotgunMagazine == 0 && shotgunAmmo > 0) beginReload();
            else if (selectedWeapon == WEAPON_BOW && !bowLoaded && bowAmmo > 0) beginReload();
        }

        private boolean weaponHasLoadedShot() {
            if (selectedWeapon == WEAPON_PISTOL) return pistolMagazine > 0;
            if (selectedWeapon == WEAPON_SHOTGUN) return shotgunMagazine > 0;
            return bowLoaded;
        }

        private boolean hasAnyWeaponAmmo() {
            boolean pistol = pistolMagazine > 0 || ammo > 0;
            boolean shotgun = shotgunUnlocked && (shotgunMagazine > 0 || shotgunAmmo > 0);
            boolean bow = bowUnlocked && (bowLoaded || bowAmmo > 0);
            return pistol || shotgun || bow;
        }

        private void beginReload() {
            if (reloading) return;
            reloadWeapon = selectedWeapon;
            if (reloadWeapon == WEAPON_PISTOL) {
                reloadFillAmount = Math.min(10 - pistolMagazine, ammo);
                if (reloadFillAmount <= 0) return;
                reloadDuration = 1.45f;
                sound.playPistolReload();
            } else if (reloadWeapon == WEAPON_SHOTGUN) {
                reloadFillAmount = Math.min(2 - shotgunMagazine, shotgunAmmo);
                if (reloadFillAmount <= 0) return;
                reloadDuration = 2.35f;
                sound.playShotgunReload();
            } else {
                if (bowLoaded || bowAmmo <= 0) return;
                reloadFillAmount = 1;
                reloadDuration = 5f;
                sound.playBowReload();
            }
            reloadTimer = reloadDuration;
            reloadAnimation = 0f;
            reloading = true;
        }

        private void updateWeaponSystems(float dt) {
            if (reloading) {
                reloadTimer = Math.max(0f, reloadTimer - dt);
                reloadAnimation += dt;
                if (reloadTimer <= 0f) {
                    if (reloadWeapon == WEAPON_PISTOL) {
                        pistolMagazine += reloadFillAmount;
                        ammo -= reloadFillAmount;
                    } else if (reloadWeapon == WEAPON_SHOTGUN) {
                        shotgunMagazine += reloadFillAmount;
                        shotgunAmmo -= reloadFillAmount;
                    } else {
                        bowAmmo--;
                        bowLoaded = true;
                    }
                    reloading = false;
                    reloadFillAmount = 0;
                }
            }
        }

        private void switchWeapon(int weapon) {
            if (weapon == WEAPON_SHOTGUN && !shotgunUnlocked) return;
            if (weapon == WEAPON_BOW && !bowUnlocked) return;
            if (weapon < WEAPON_PISTOL || weapon > WEAPON_BOW) return;
            selectedWeapon = weapon;
            if (!weaponHasLoadedShot()) beginReload();
        }

        private void updateBackgroundSystems(float dt) {
            if (dogCooldownTimer > 0f) dogCooldownTimer = Math.max(0f, dogCooldownTimer - dt);
            if (monsterFearTimer > 0f) monsterFearTimer = Math.max(0f, monsterFearTimer - dt);
            if (cooking) {
                cookingTimer = Math.max(0f, cookingTimer - dt);
                if (cookingTimer <= 0f) {
                    cooking = false;
                    cookedDucks += 4;
                    sound.playGrillDone();
                }
            }
            // --- Delivery drone: fly in → hover over basket → lower package → unlock item → leave ---
            if (deliveryDroneActive) {
                deliveryAnim += dt;
                if (deliveryPhase == 0) { // approach
                    deliveryDroneX = Math.min(160f, deliveryDroneX + 280f * dt);
                    deliveryY = 90f;
                    if (deliveryDroneX >= 158f) { deliveryPhase = 1; deliveryAnim = 0f; }
                } else if (deliveryPhase == 1) { // move to basket (x~120) and hover
                    deliveryDroneX += (120f - deliveryDroneX) * Math.min(1f, dt * 3f);
                    if (deliveryAnim > 0.6f) { deliveryPhase = 2; deliveryAnim = 0f; }
                } else if (deliveryPhase == 2) { // descend into basket
                    deliveryY = Math.min(430f, deliveryY + 160f * dt);
                    if (deliveryY >= 420f) {
                        completeDelivery();
                        deliveryPhase = 3;
                        deliveryAnim = 0f;
                    }
                } else { // leave
                    deliveryDroneX -= 320f * dt;
                    deliveryY = Math.max(60f, deliveryY - 40f * dt);
                    if (deliveryDroneX < -100f) {
                        deliveryDroneActive = false;
                        deliveryPhase = 0;
                    }
                }
            }
            // --- Sale drone: approach → descend → grab → leave with payload ---
            if (saleDroneActive) {
                saleAnim += dt;
                if (salePhase == 0) {
                    saleDroneX = Math.max(140f, saleDroneX - 300f * dt);
                    saleY = 90f;
                    if (saleDroneX <= 145f) { salePhase = 1; saleAnim = 0f; }
                } else if (salePhase == 1) {
                    saleY = Math.min(430f, saleY + 170f * dt);
                    if (saleY >= 420f) { salePhase = 2; saleAnim = 0f; }
                } else if (salePhase == 2) {
                    if (saleAnim > 0.45f) {
                        gold += salePayloadGold;
                        salePayloadGold = 0;
                        salePhase = 3;
                        saleAnim = 0f;
                        saveProgress();
                    }
                } else {
                    saleDroneX += 340f * dt;
                    saleY = Math.max(50f, saleY - 50f * dt);
                    if (saleDroneX > 1100f) {
                        saleDroneActive = false;
                        salePhase = 0;
                    }
                }
            }
            // --- Big drone: every 2 minutes collect monster basket ---
            if (state == State.PLAYING) {
                bigDroneTimer -= dt;
                if (!bigDroneActive && bigDroneTimer <= 0f) {
                    if (monsterBasketCount > 0) {
                        bigDroneActive = true;
                        bigDronePhase = 0f;
                        bigDroneAnim = 0f;
                        bigDroneX = -140f;
                    } else {
                        bigDroneTimer = 120f;
                    }
                }
                if (bigDroneActive) {
                    bigDroneAnim += dt;
                    if (bigDronePhase == 0f) {
                        bigDroneX = Math.min(200f, bigDroneX + 220f * dt);
                        if (bigDroneX >= 195f) { bigDronePhase = 1f; bigDroneAnim = 0f; }
                    } else if (bigDronePhase == 1f) {
                        if (bigDroneAnim > 1.2f) {
                            sellMonsterBasket();
                            bigDronePhase = 2f;
                            bigDroneAnim = 0f;
                        }
                    } else {
                        bigDroneX += 280f * dt;
                        if (bigDroneX > 1100f) {
                            bigDroneActive = false;
                            bigDroneTimer = 120f;
                        }
                    }
                }
            }
            // --- Multiple monsters (10-15 max), random sides/times ---
            if (state == State.PLAYING && monsterFearTimer <= 0f) {
                monsterSpawnClock -= dt;
                int cap = 10 + random.nextInt(6); // 10..15
                if (monsterSpawnClock <= 0f && monsters.size() < cap) {
                    boolean fromLeft = random.nextBoolean();
                    float mx = fromLeft ? -80f : 1040f;
                    float my = 360f + random.nextFloat() * 80f;
                    float mvx = fromLeft ? (55f + random.nextFloat() * 50f) : -(55f + random.nextFloat() * 50f);
                    monsters.add(new Monster(mx, my, mvx, fromLeft));
                    monsterSpawnClock = 4f + random.nextFloat() * 10f;
                }
                java.util.Iterator<Monster> it = monsters.iterator();
                while (it.hasNext()) {
                    Monster mon = it.next();
                    mon.x += mon.vx * dt;
                    mon.attackClock -= dt;
                    // Steal near basket zone
                    if (mon.x > 80f && mon.x < 260f && mon.attackClock <= 0f) {
                        if (!basketDuckValues.isEmpty()) {
                            basketDuckValues.remove(0);
                            basketCount = basketDuckValues.size();
                            duckInventory = basketCount;
                            sound.playMonsterImpact();
                        } else if (cookedDucks > 0) {
                            cookedDucks--;
                            sound.playMonsterImpact();
                        }
                        mon.attackClock = 2.5f + random.nextFloat();
                    }
                    if (mon.x < -120f || mon.x > 1100f) it.remove();
                }
            } else if (monsterFearTimer > 0f) {
                monsterFearTimer = Math.max(0f, monsterFearTimer - dt);
                // Flee
                for (Monster mon : monsters) {
                    mon.vx = mon.fromLeft ? -120f : 120f;
                    mon.x += mon.vx * dt;
                }
            }
            // Fallen monster corpses: dog auto-carries to monster basket when idle.
            for (int i = fallenMonsters.size() - 1; i >= 0; i--) {
                FallenMonster fm = fallenMonsters.get(i);
                fm.life -= dt;
                if (dogState == 0 && fm.life < 16f) {
                    monsterBasketValues.add(100); // 100 gold per monster
                    monsterBasketCount = monsterBasketValues.size();
                    fallenMonsters.remove(i);
                    sound.playDogBark();
                } else if (fm.life <= 0f) {
                    fallenMonsters.remove(i);
                }
            }
        }

        private void updateBirthday(float dt) {
            if (birthdayMessageTimer > 0f) {
                birthdayMessageTimer = Math.max(0f, birthdayMessageTimer - dt);
                fireworkClock -= dt;
                if (fireworkClock <= 0f) {
                    spawnConfettiBurst(90f + random.nextFloat() * 780f, 70f + random.nextFloat() * 240f, 24);
                    fireworkClock = 0.48f;
                }
                if (birthdayMessageTimer <= 0f && state == State.PLAYING) clearLevel();
            }
            for (int i = confetti.size() - 1; i >= 0; i--) {
                ConfettiPiece piece = confetti.get(i);
                piece.life -= dt;
                piece.vy += 130f * dt;
                piece.x += piece.vx * dt;
                piece.y += piece.vy * dt;
                if (piece.life <= 0f || piece.y > WORLD_H + 20f) confetti.remove(i);
            }
        }

        private void spawnConfettiBurst(float x, float y, int count) {
            int[] colors = {Color.rgb(255, 80, 90), Color.rgb(255, 213, 79), Color.rgb(74, 210, 145),
                    Color.rgb(92, 174, 255), Color.rgb(216, 120, 255), Color.WHITE};
            for (int i = 0; i < count; i++) {
                float angle = random.nextFloat() * 6.28318f;
                float speed = 65f + random.nextFloat() * 220f;
                confetti.add(new ConfettiPiece(x, y, (float) Math.cos(angle) * speed,
                        (float) Math.sin(angle) * speed - 55f, colors[random.nextInt(colors.length)]));
            }
        }
        private boolean pointInEnderman(float x, float y) {
            float left = bossX - 106f;
            float right = bossX + 106f;
            float top = 115f + emergeOffset;
            float bottom = 465f;
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private boolean isHidden(Duck duck) {
            if (treesBroken) return false;
            for (float tx : treeX) {
                if (Math.abs(duck.x - tx) < 52f && duck.y > 118f && duck.y < 275f) return true;
            }
            return false;
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN) return true;
            float x = (event.getX() - gameOffsetX) / Math.max(0.001f, gameScale);
            float y = (event.getY() - gameOffsetY) / Math.max(0.001f, gameScale);
            if (x < 0 || x > WORLD_W || y < 0 || y > WORLD_H) return true;

            switch (state) {
                case MENU:
                    if (inside(x, y, 330, 345, 630, 415)) startNewGame();
                    else if (inside(x, y, 330, 425, 630, 490)) startExtraGame();
                    else startNewGame();
                    break;
                case SHOP:
                    if (inside(x, y, 45, 330, 245, 405)) sellDucks();
                    else if (inside(x, y, 560, 272, 620, 322)) ammoPurchaseQuantity = Math.max(1, ammoPurchaseQuantity - 1);
                    else if (inside(x, y, 630, 272, 690, 322)) ammoPurchaseQuantity = Math.min(999, ammoPurchaseQuantity + 1);
                    else if (inside(x, y, 260, 330, 455, 405)) buyAmmo(ammoPurchaseQuantity);
                    else if (inside(x, y, 470, 330, 685, 405)) buySelectedWeapon();
                    else if (inside(x, y, 50, 272, 205, 322)) switchPurchaseWeapon(WEAPON_PISTOL);
                    else if (inside(x, y, 210, 272, 365, 322)) switchPurchaseWeapon(WEAPON_SHOTGUN);
                    else if (inside(x, y, 370, 272, 525, 322)) switchPurchaseWeapon(WEAPON_BOW);
                    else if (inside(x, y, 330, 435, 630, 505)) leaveShop();
                    else if (inside(x, y, 650, 435, 880, 505)) state = State.MENU;
                    break;
                case PLAYING:
                    if (inside(x, y, 825, 10, 890, 70)) {
                        state = State.PAUSED;
                    } else if (inside(x, y, 895, 10, 950, 70)) {
                        soundOn = !soundOn;
                        sound.setEnabled(soundOn);
                    } else if (inside(x, y, 18, 432, 150, 500)) {
                        switchWeapon(WEAPON_PISTOL);
                    } else if (inside(x, y, 154, 432, 300, 500)) {
                        switchWeapon(WEAPON_SHOTGUN);
                    } else if (inside(x, y, 304, 432, 454, 500)) {
                        switchWeapon(WEAPON_BOW);
                    } else if (inside(x, y, 460, 432, 580, 468)) {
                        buySelectedWeapon();
                    } else if (inside(x, y, 460, 472, 580, 508)) {
                        buyAmmo(10);
                    } else if (inside(x, y, 584, 432, 700, 468)) {
                        sellDucks();
                    } else if (inside(x, y, 584, 472, 700, 508)) {
                        startCooking();
                    } else if (inside(x, y, 800, 455, 950, 535)) {
                        useDogAbility();
                    } else {
                        shoot(x, y);
                    }
                    break;
                case PAUSED:
                    if (inside(x, y, 330, 330, 630, 410)) state = State.PLAYING;
                    else if (inside(x, y, 330, 415, 630, 485)) state = State.MENU;
                    break;
                case LEVEL_CLEAR:
                    if (inside(x, y, 330, 350, 630, 430)) {
                        if (extraMode) {
                            if (extraLevel < 100) openShop(extraLevel + 1);
                            else state = State.VICTORY;
                        } else if (level < 6) {
                            openShop(level + 1);
                        } else state = State.VICTORY;
                    }
                    break;
                case GAME_OVER:
                    if (inside(x, y, 330, 360, 630, 440)) startNewGame();
                    else if (inside(x, y, 330, 445, 630, 510)) state = State.MENU;
                    break;
                case VICTORY:
                    if (inside(x, y, 330, 360, 630, 445)) startNewGame();
                    else state = State.MENU;
                    break;
            }
            invalidate();
            return true;
        }

        private void switchPurchaseWeapon(int weapon) {
            if (weapon == WEAPON_SHOTGUN && !shotgunUnlocked) selectedWeapon = WEAPON_SHOTGUN;
            else if (weapon == WEAPON_BOW && !bowUnlocked) selectedWeapon = WEAPON_BOW;
            else if (weapon == WEAPON_PISTOL || (weapon == WEAPON_SHOTGUN && shotgunUnlocked)
                    || (weapon == WEAPON_BOW && bowUnlocked)) selectedWeapon = weapon;
            ammoPurchaseQuantity = 10;
        }

        private boolean inside(float x, float y, float left, float top, float right, float bottom) {
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private void drawWorld(Canvas canvas) {
            boolean night = level == 5 && finalBossPhase;
            drawBackground(canvas, night);

            for (Duck duck : ducks) drawDuck(canvas, duck, false);
            for (FallenDuck duck : fallenDucks) drawFallenDuck(canvas, duck);
            if (extraMode && state != State.MENU && extraBossHp > 0f) drawExtraBoss(canvas);
            if (!extraMode && level == 3 && state != State.MENU) drawLargeDuck(canvas);

            if (!treesBroken) {
                for (float tx : treeX) drawTree(canvas, tx);
            } else {
                drawBrokenForest(canvas);
            }

            if (level == 5 && finalBossPhase) drawEnderman(canvas);
            drawHunter(canvas);
            drawBasket(canvas);
            drawGrill(canvas);
            drawMonster(canvas);
            drawDog(canvas);
            drawDrones(canvas);
            drawGroundDetails(canvas);
            drawWeaponControls(canvas);
            drawDogAbilityButton(canvas);
            drawBirthdayEffects(canvas);
        }

        private void drawBackground(Canvas canvas, boolean night) {
            int[] skies = {SKY_DAY, Color.rgb(117, 167, 201), Color.rgb(193, 144, 99), Color.rgb(102, 115, 149), Color.rgb(88, 155, 137)};
            int[] grasses = {GRASS, Color.rgb(82, 126, 74), Color.rgb(141, 108, 61), Color.rgb(75, 88, 118), Color.rgb(48, 120, 102)};
            int sky = night ? Color.rgb(22, 18, 43) : (extraMode ? skies[mapTheme] : SKY_DAY);
            canvas.drawColor(sky);

            if (!night) {
                fillCircle(canvas, 820, 82, 38, Color.rgb(255, 221, 113));
                fillCircle(canvas, 810, 72, 34, Color.rgb(255, 235, 157));
                drawCloud(canvas, 150 + (float) Math.sin(menuAnim * 0.16f) * 14f, 83);
                drawCloud(canvas, 560 + (float) Math.sin(menuAnim * 0.12f) * 18f, 112);
            } else {
                fillCircle(canvas, 820, 105, 20, Color.rgb(125, 112, 170));
                for (int i = 0; i < 24; i++) {
                    float sx = (i * 137) % 950;
                    float sy = 25 + (i * 53) % 190;
                    fillRect(canvas, sx, sy, sx + 3, sy + 3, Color.rgb(213, 211, 245));
                }
            }

            int ground = night ? Color.rgb(40, 65, 44) : (extraMode ? grasses[mapTheme] : GRASS);
            fillRect(canvas, 0, 245, 960, 540, ground);
            fillRect(canvas, 0, 280, 960, 540, night ? Color.rgb(29, 54, 38) : (extraMode ? darken(grasses[mapTheme], 0.78f) : Color.rgb(63, 126, 56)));
            // Distant pine silhouettes make the forest continuous.
            for (int i = 0; i < 13; i++) {
                float x = i * 82f - 20f;
                drawPine(canvas, x, 245, 0.78f, night ? Color.rgb(23, 54, 43) : Color.rgb(50, 104, 59));
            }
            for (int i = 0; i < 22; i++) {
                float x = (i * 47f + 13f) % 960f;
                float y = 300 + (i % 4) * 28;
                fillRect(canvas, x, y, x + 3, y + 11, night ? Color.rgb(70, 107, 51) : Color.rgb(104, 162, 65));
            }

            if (night) {
                // Red-orange horizon after the sudden sunset.
                fillRect(canvas, 0, 235, 960, 248, Color.rgb(93, 43, 59));
                fillRect(canvas, 0, 248, 960, 257, Color.rgb(60, 43, 62));
            }
        }

        private int darken(int color, float factor) {
            return Color.rgb((int) (Color.red(color) * factor),
                    (int) (Color.green(color) * factor), (int) (Color.blue(color) * factor));
        }

        private void drawCloud(Canvas canvas, float x, float y) {
            int c = Color.rgb(222, 239, 226);
            fillRect(canvas, x, y, x + 82, y + 20, c);
            fillRect(canvas, x + 15, y - 13, x + 50, y + 22, c);
            fillRect(canvas, x + 45, y - 6, x + 73, y + 18, c);
        }

        private void drawPine(Canvas canvas, float x, float ground, float scale, int color) {
            float h = 100 * scale;
            fillRect(canvas, x - 4 * scale, ground - 15 * scale, x + 4 * scale, ground, Color.rgb(91, 65, 42));
            fillRect(canvas, x - 23 * scale, ground - h * 0.57f, x, ground - h * 0.18f, color);
            fillRect(canvas, x - 12 * scale, ground - h, x + 18 * scale, ground - h * 0.45f, color);
            fillRect(canvas, x, ground - h * 0.67f, x + 27 * scale, ground - h * 0.2f, color);
        }

        private void drawTree(Canvas canvas, float x) {
            // Trunk is anchored — only the canopy sways (gentle wind, no wobbling trunks).
            int trunk = Color.rgb(104, 72, 44);
            int trunkLight = Color.rgb(135, 91, 52);
            fillRect(canvas, x - 11, 200, x + 12, 465, trunk);
            fillRect(canvas, x - 6, 205, x - 1, 440, trunkLight);
            // Soft canopy sway around the top of the trunk (not the whole tree).
            float sway = (float) Math.sin(menuAnim * 1.15f + x * 0.011f) * 1.1f;
            canvas.save();
            canvas.rotate(sway, x, 210f);
            int leaf1 = Color.rgb(27, 91, 47);
            int leaf2 = Color.rgb(39, 119, 55);
            int leaf3 = Color.rgb(56, 139, 62);
            fillRect(canvas, x - 53, 178, x + 48, 232, leaf1);
            fillRect(canvas, x - 40, 143, x + 35, 207, leaf2);
            fillRect(canvas, x - 20, 125, x + 24, 178, leaf3);
            fillRect(canvas, x - 63, 205, x - 39, 225, leaf2);
            fillRect(canvas, x + 32, 196, x + 60, 220, leaf2);
            fillRect(canvas, x - 25, 154, x - 5, 174, Color.rgb(77, 157, 67));
            canvas.restore();
        }

        private void drawBrokenForest(Canvas canvas) {
            int log = Color.rgb(91, 58, 42);
            int logLight = Color.rgb(137, 91, 53);
            for (int i = 0; i < treeX.length; i++) {
                float x = treeX[i];
                fillRect(canvas, x - 75, 408 + (i % 2) * 8, x + 65, 427 + (i % 2) * 8, log);
                fillRect(canvas, x - 52, 408 + (i % 2) * 8, x + 44, 414 + (i % 2) * 8, logLight);
                fillRect(canvas, x + 42, 399, x + 65, 414, Color.rgb(38, 105, 47));
                fillRect(canvas, x - 86, 421, x - 65, 438, Color.rgb(38, 105, 47));
            }
        }

        private void drawDuck(Canvas canvas, Duck duck, boolean boss) {
            canvas.save();
            float flap = (float) Math.sin(duck.age * 10f + duck.phase) * 5f;
            canvas.translate(duck.x, duck.y);
            float perspective = 0.68f + Math.max(0f, Math.min(1f, (duck.y - 85f) / 330f)) * 0.48f;
            float scale = (boss ? 1.75f : 1f) * perspective;
            canvas.scale(scale, scale);
            int body = boss ? Color.rgb(75, 116, 43) : Color.rgb(238, 237, 211);
            int wing = boss ? Color.rgb(49, 82, 36) : Color.rgb(179, 190, 162);
            fillOval(canvas, -25, -8, 23, 18, body);
            fillOval(canvas, -12, -10 + flap, 11, 10 + flap, wing);
            fillCircle(canvas, 16, -16, 11, body);
            fillRect(canvas, 23, -16, 36, -8, Color.rgb(236, 163, 49));
            fillRect(canvas, 12, -21, 15, -18, Color.BLACK);
            fillRect(canvas, -22, 1, -28, -9, wing);
            fillRect(canvas, -18, 14, -8, 17, Color.rgb(224, 157, 46));
            fillRect(canvas, 5, 14, 15, 17, Color.rgb(224, 157, 46));
            canvas.restore();

            if (!extraMode && level == 3 && !boss && duck.hp > 0 && duck.hp < duck.maxHp) {
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x + 20, duck.y - 24, Color.rgb(50, 45, 41));
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x - 20 + 40f * duck.hp / duck.maxHp, duck.y - 24, Color.rgb(237, 76, 65));
            }
        }

        private void drawFallenDuck(Canvas canvas, FallenDuck duck) {
            canvas.save();
            canvas.rotate(duck.rotation, duck.x, duck.y);
            canvas.translate(duck.x, duck.y);
            fillOval(canvas, -24, -7, 22, 13, Color.rgb(238, 237, 211));
            fillOval(canvas, -10, -9, 12, 7, Color.rgb(179, 190, 162));
            fillCircle(canvas, 15, -13, 9, Color.rgb(238, 237, 211));
            fillRect(canvas, 22, -13, 34, -6, Color.rgb(236, 163, 49));
            fillRect(canvas, 11, -18, 14, -15, Color.BLACK);
            fillRect(canvas, -16, 11, -7, 14, Color.rgb(224, 157, 46));
            fillRect(canvas, 5, 11, 14, 14, Color.rgb(224, 157, 46));
            canvas.restore();
        }

        private void drawExtraBoss(Canvas canvas) {
            float x = bossX;
            float y = bossY;
            int[] bodies = {Color.rgb(117, 49, 45), Color.rgb(66, 72, 115), Color.rgb(74, 105, 54), Color.rgb(83, 45, 107)};
            int body = bossDamageFlash > 0 ? Color.WHITE : bodies[extraBossType];
            float pulse = (float) Math.sin(menuAnim * 4f) * 4f;
            fillOval(canvas, x - 76, y - 24 + pulse, x + 76, y + 55 + pulse, body);
            fillCircle(canvas, x - 37, y - 22 + pulse, 26, body);
            fillCircle(canvas, x + 37, y - 22 + pulse, 26, body);
            fillRect(canvas, x - 45, y - 29 + pulse, x - 20, y - 21 + pulse, Color.rgb(255, 220, 120));
            fillRect(canvas, x + 20, y - 29 + pulse, x + 45, y - 21 + pulse, Color.rgb(255, 220, 120));
            float barW = 220f;
            fillRect(canvas, x - barW / 2, y - 78, x + barW / 2, y - 66, Color.rgb(35, 29, 35));
            fillRect(canvas, x - barW / 2 + 2, y - 76, x - barW / 2 + 2 + (barW - 4) * extraBossHp / extraBossMaxHp,
                    y - 68, Color.rgb(225, 75, 64));
            drawText(canvas, "БОСС " + (int) extraBossHp + "/" + (int) extraBossMaxHp, x, y - 86, 12, GOLD, Paint.Align.CENTER);
        }

        private void drawLargeDuck(Canvas canvas) {
            Duck boss = new Duck(bossX, bossY, 0, 120, false, random);
            boss.phase = levelElapsed * 3f;
            boss.age = levelElapsed;
            drawDuck(canvas, boss, true);
            float barW = 190f;
            fillRect(canvas, bossX - barW / 2, bossY - 68, bossX + barW / 2, bossY - 56, Color.rgb(48, 39, 35));
            fillRect(canvas, bossX - barW / 2 + 2, bossY - 66,
                    bossX - barW / 2 + 2 + (barW - 4) * bossDuckHp / 120f,
                    bossY - 58, Color.rgb(232, 74, 61));
            drawText(canvas, "БОЛЬШАЯ УТКА", bossX, bossY - 78, 12, GOLD, Paint.Align.CENTER);
        }

        private void drawEnderman(Canvas canvas) {
            float yShift = emergeOffset + (finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 4f : 0f);
            float x = bossX;
            if (enderTeleportFlash > 0f) {
                int alpha = (int) (enderTeleportFlash * 210f);
                fillCircle(canvas, x, 290, 120f * enderTeleportFlash + 20f,
                        Color.argb(alpha, 142, 63, 222));
            }
            int body = bossDamageFlash > 0 ? Color.rgb(63, 43, 92) : Color.rgb(18, 16, 25);
            int edge = Color.rgb(43, 30, 61);
            // Long arms and legs, deliberately chunky like an old console sprite.
            float gait = finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 15f : 0f;
            float strike = finalAttackClock > 2.05f ? 35f : 0f;
            fillRect(canvas, x - 73 - strike, 217 + yShift, x - 48 - strike, 385 + yShift, body);
            fillRect(canvas, x + 48 + gait, 217 + yShift, x + 73 + gait + strike, 385 + yShift, body);
            fillRect(canvas, x - 29, 185 + yShift, x + 29, 388 + yShift, body);
            fillRect(canvas, x - 46, 108 + yShift, x + 46, 213 + yShift, body);
            fillRect(canvas, x - 40, 112 + yShift, x + 40, 119 + yShift, edge);
            fillRect(canvas, x - 25 - gait, 390 + yShift, x - 3 - gait, 465, body);
            fillRect(canvas, x + 4 + gait, 390 + yShift, x + 27 + gait, 465, body);
            fillRect(canvas, x - 29, 459, x - 1, 472, Color.rgb(10, 9, 16));
            fillRect(canvas, x + 2, 459, x + 32, 472, Color.rgb(10, 9, 16));
            // Purple eyes.
            fillRect(canvas, x - 31, 151 + yShift, x - 5, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x + 6, 151 + yShift, x + 32, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x - 28, 153 + yShift, x - 9, 157 + yShift, Color.rgb(244, 185, 255));
            fillRect(canvas, x + 9, 153 + yShift, x + 29, 157 + yShift, Color.rgb(244, 185, 255));

            if (finalPhaseElapsed > 1f) {
                float barW = 240f;
                fillRect(canvas, x - barW / 2, 77, x + barW / 2, 94, Color.rgb(19, 15, 26));
                fillRect(canvas, x - barW / 2 + 3, 80,
                        x - barW / 2 + 3 + (barW - 6) * enderHp / 300f, 91,
                        Color.rgb(170, 53, 208));
                drawText(canvas, "ЭНДЕРМЕН  " + (int) enderHp + " / 300", x, 66, 13, CREAM, Paint.Align.CENTER);
            }
        }

        private void drawHunter(Canvas canvas) {
            float recoil = weaponRecoil * (selectedWeapon == WEAPON_SHOTGUN ? 18f : 13f);
            float reloadPhase = reloading ? Math.min(1f, reloadAnimation / Math.max(0.01f, reloadDuration)) : 0f;
            int sleeve = playerDamageFlash > 0 ? Color.rgb(150, 42, 43) : Color.rgb(57, 69, 80);
            // Arms / sleeves
            fillRect(canvas, 330, 486, 424, 540, sleeve);
            fillRect(canvas, 536, 486, 630, 540, sleeve);

            if (selectedWeapon == WEAPON_PISTOL) {
                // Modern compact semi-auto: polymer frame + steel slide, visible barrel.
                // Grip (hands)
                fillRect(canvas, 404, 457 + recoil, 441, 490 + recoil, Color.rgb(190, 143, 108));
                fillRect(canvas, 519, 457 + recoil, 556, 490 + recoil, Color.rgb(190, 143, 108));
                // Lower frame / grip body
                fillRect(canvas, 445, 448 + recoil, 515, 512 + recoil, Color.rgb(42, 44, 48));
                fillRect(canvas, 452, 470 + recoil, 508, 508 + recoil, Color.rgb(28, 30, 34));
                // Trigger guard
                fillRect(canvas, 468, 500 + recoil, 492, 518 + recoil, Color.rgb(55, 58, 62));
                // Slide
                float slideOffset = reloading ? (float) Math.sin(reloadPhase * Math.PI) * 20f : 0f;
                fillRect(canvas, 448 - slideOffset, 398 + recoil, 512 - slideOffset, 458 + recoil, Color.rgb(88, 92, 90));
                fillRect(canvas, 452 - slideOffset, 402 + recoil, 508 - slideOffset, 420 + recoil, Color.rgb(120, 124, 118));
                // Barrel tip
                fillRect(canvas, 472 - slideOffset, 372 + recoil, 488 - slideOffset, 402 + recoil, Color.rgb(55, 58, 56));
                fillRect(canvas, 476 - slideOffset, 362 + recoil, 484 - slideOffset, 372 + recoil, Color.rgb(35, 36, 34));
                // Front sight
                fillRect(canvas, 478 - slideOffset, 356 + recoil, 482 - slideOffset, 364 + recoil, Color.rgb(200, 200, 190));
                // Dropped magazine during reload
                if (reloading && reloadPhase > 0.22f && reloadPhase < 0.82f) {
                    float magY = 505f + 28f * (float) Math.sin((reloadPhase - 0.22f) / 0.6f * Math.PI);
                    fillRect(canvas, 470, magY, 490, magY + 32f, Color.rgb(30, 32, 34));
                    fillRect(canvas, 474, magY + 4, 486, magY + 8, GOLD);
                }
            } else if (selectedWeapon == WEAPON_SHOTGUN) {
                // Classic break-action double barrel — clearly different from the pistol.
                fillRect(canvas, 405, 458 + recoil, 440, 491 + recoil, Color.rgb(190, 143, 108));
                fillRect(canvas, 520, 458 + recoil, 556, 491 + recoil, Color.rgb(190, 143, 108));
                // Wooden stock / forend
                fillRect(canvas, 400, 456 + recoil, 560, 526 + recoil, Color.rgb(110, 68, 38));
                fillRect(canvas, 420, 470 + recoil, 540, 512 + recoil, Color.rgb(86, 52, 28));
                // Receiver
                fillRect(canvas, 435, 430 + recoil, 525, 470 + recoil, Color.rgb(48, 42, 36));
                // Break-open animation: barrels tilt upward while reloading
                float open = reloading ? 36f * (float) Math.sin(reloadPhase * Math.PI) : 0f;
                // Left barrel
                fillRect(canvas, 452, 318 + recoil, 472, 438 + recoil + open * 0.15f, Color.rgb(92, 98, 96));
                fillRect(canvas, 456, 318 + recoil, 468, 330 + recoil, Color.rgb(40, 42, 40));
                // Right barrel
                fillRect(canvas, 488, 318 + recoil, 508, 438 + recoil + open * 0.15f, Color.rgb(92, 98, 96));
                fillRect(canvas, 492, 318 + recoil, 504, 330 + recoil, Color.rgb(40, 42, 40));
                // Hinge / pivot highlight
                fillRect(canvas, 468, 430 + recoil, 492, 442 + recoil, Color.rgb(160, 140, 90));
                if (reloading && reloadPhase > 0.3f && reloadPhase < 0.7f) {
                    float shellY = 445f + open * 0.4f;
                    fillRect(canvas, 440, shellY, 452, shellY + 26, Color.rgb(190, 54, 41));
                    fillRect(canvas, 482, shellY, 494, shellY + 26, Color.rgb(190, 54, 41));
                    fillRect(canvas, 440, shellY, 452, shellY + 4, GOLD);
                    fillRect(canvas, 482, shellY, 494, shellY + 4, GOLD);
                }
            } else {
                // Crossbow: stock, prod, and bolt — replaces the old bow.
                float pull = reloading ? 28f * (float) Math.sin(reloadPhase * Math.PI) : (bowLoaded ? 10f : 0f);
                paint.setStyle(Paint.Style.STROKE);
                // Crossbow prod (bow part)
                paint.setColor(Color.rgb(130, 82, 42));
                paint.setStrokeWidth(10f);
                for (int i = 0; i < 10; i++) {
                    float y1 = 340f + i * 16f;
                    float bend = 20f * (float) Math.sin(i / 9f * Math.PI);
                    canvas.drawLine(430f - bend, y1 + recoil, 480f, y1 + recoil, paint);
                    canvas.drawLine(480f, y1 + recoil, 530f + bend, y1 + recoil, paint);
                }
                // String
                paint.setColor(Color.rgb(235, 230, 200));
                paint.setStrokeWidth(2.5f);
                canvas.drawLine(430, 340 + recoil, 480 + pull, 420 + recoil, paint);
                canvas.drawLine(480 + pull, 420 + recoil, 530, 340 + recoil, paint);
                // Grip
                paint.setColor(Color.rgb(78, 50, 28));
                paint.setStrokeWidth(14f);
                canvas.drawLine(476, 405 + recoil, 484, 495 + recoil, paint);
                // Arrow
                if (bowLoaded || reloading) {
                    paint.setColor(Color.rgb(210, 205, 185));
                    paint.setStrokeWidth(3.5f);
                    canvas.drawLine(480 + pull, 360 + recoil, 480 + pull, 455 + recoil, paint);
                    fillCircle(canvas, 480 + pull, 360 + recoil, 5f, GOLD);
                    // Fletching
                    paint.setColor(Color.rgb(200, 60, 50));
                    paint.setStrokeWidth(2f);
                    canvas.drawLine(480 + pull, 448 + recoil, 474 + pull, 458 + recoil, paint);
                    canvas.drawLine(480 + pull, 448 + recoil, 486 + pull, 458 + recoil, paint);
                }
                paint.setStyle(Paint.Style.FILL);
                fillRect(canvas, 410, 462 + recoil, 446, 495 + recoil, Color.rgb(190, 143, 108));
                fillRect(canvas, 516, 462 + recoil, 551, 495 + recoil, Color.rgb(190, 143, 108));
            }

            if (muzzleFlash > 0f && selectedWeapon != WEAPON_BOW) {
                float flashY = selectedWeapon == WEAPON_SHOTGUN ? 312f : 358f;
                fillCircle(canvas, 480, flashY + recoil, 18f + muzzleFlash * 70f, Color.rgb(255, 238, 139));
                fillCircle(canvas, 480, flashY + recoil, 9f + muzzleFlash * 35f, Color.WHITE);
            }
        }

        private void drawDog(Canvas canvas) {
            float y = 461f;
            float step = dogState == 0 ? 0f : (float) Math.sin(menuAnim * 17f) * 4f;
            canvas.save();
            canvas.translate(dogX, y);
            // Body, head, ears, paws and tail.
            fillRect(canvas, -26, -22, 20, 2, Color.rgb(171, 112, 59));
            fillRect(canvas, 11, -34, 34, -10, Color.rgb(188, 132, 73));
            fillRect(canvas, 13, -43, 20, -30, Color.rgb(95, 55, 37));
            fillRect(canvas, 30, -24, 42, -17, Color.rgb(62, 42, 31));
            fillRect(canvas, -20, -1 + step, -12, 9 + step, Color.rgb(92, 60, 39));
            fillRect(canvas, 10, -1 - step, 18, 9 - step, Color.rgb(92, 60, 39));
            fillRect(canvas, -34, -30, -27, -20, Color.rgb(121, 76, 46));
            if (dogHasCake) {
                fillRect(canvas, -16, -52, 22, -37, Color.rgb(255, 224, 190));
                fillRect(canvas, -13, -61, 19, -51, Color.rgb(255, 137, 171));
                fillCircle(canvas, 3, -64, 5, Color.rgb(255, 227, 94));
            }
            if (dogCarrying) {
                for (int i = 0; i < Math.max(1, dogCarryCount); i++) {
                    float ox = -18f + i * 17f;
                    fillOval(canvas, ox - 7, -48 - (i % 2) * 3, ox + 9, -33 - (i % 2) * 3, Color.rgb(239, 235, 210));
                    fillCircle(canvas, ox + 7, -47 - (i % 2) * 3, 4, Color.rgb(239, 235, 210));
                    fillRect(canvas, ox + 10, -49 - (i % 2) * 3, ox + 15, -45 - (i % 2) * 3, Color.rgb(237, 164, 52));
                }
            }
            canvas.restore();
        }

        private void drawBasket(Canvas canvas) {
            fillRect(canvas, 590, 439, 649, 491, Color.rgb(155, 94, 43));
            fillRect(canvas, 586, 434, 653, 444, Color.rgb(205, 151, 74));
            for (int i = 0; i < 4; i++) {
                fillRect(canvas, 596 + i * 14, 445, 600 + i * 14, 488, Color.rgb(205, 147, 73));
            }
            drawText(canvas, String.valueOf(basketCount + cookedDucks), 620, 510, 16, CREAM, Paint.Align.CENTER);
        }

        private void drawGrill(Canvas canvas) {
            // Small interactive brazier near the basket.
            fillRect(canvas, 690, 470, 782, 480, Color.rgb(42, 44, 43));
            fillRect(canvas, 700, 445, 772, 474, Color.rgb(65, 63, 57));
            fillRect(canvas, 696, 440, 778, 447, Color.rgb(29, 28, 26));
            for (int i = 0; i < 5; i++) fillRect(canvas, 701 + i * 15, 444, 704 + i * 15, 474, Color.rgb(135, 128, 110));
            fillCircle(canvas, 736, 455, 10, cooking ? Color.rgb(255, 155, 47) : Color.rgb(126, 70, 38));
            if (cooking) {
                float flicker = (float) Math.sin(menuAnim * 12f) * 4f;
                fillOval(canvas, 729, 424 - flicker, 742, 450, Color.rgb(255, 101, 37));
                fillOval(canvas, 733, 432 - flicker, 740, 451, Color.rgb(255, 221, 89));
                drawText(canvas, String.format(java.util.Locale.US, "ГОТОВКА %02dс", (int) cookingTimer), 736, 415, 10, GOLD, Paint.Align.CENTER);
            } else {
                drawText(canvas, cookedDucks + "/4 ГОТОВО", 736, 415, 10, CREAM, Paint.Align.CENTER);
            }
        }

        private void drawMonster(Canvas canvas) {
            for (FallenMonster fm : fallenMonsters) {
                fillOval(canvas, fm.x - 22, fm.y - 10, fm.x + 22, fm.y + 14, Color.rgb(60, 40, 50));
                fillRect(canvas, fm.x - 8, fm.y - 18, fm.x + 8, fm.y - 6, Color.rgb(90, 50, 60));
            }
            for (Monster mon : monsters) {
                canvas.save();
                canvas.translate(mon.x, mon.y);
                fillRect(canvas, -22, -28, 22, 20, Color.rgb(70, 40, 55));
                fillRect(canvas, -14, -42, 14, -28, Color.rgb(90, 50, 65));
                fillRect(canvas, -18, -9, -10, 4, Color.rgb(42, 33, 40));
                fillRect(canvas, 10, -9, 18, 4, Color.rgb(42, 33, 40));
                fillRect(canvas, -8, -38, -2, -34, Color.rgb(255, 60, 60));
                fillRect(canvas, 2, -38, 8, -34, Color.rgb(255, 60, 60));
                canvas.restore();
            }
            if (!monsters.isEmpty()) {
                drawText(canvas, "МОНСТРЫ! СОБАКА ОТГОНЯЕТ ИХ", 480, 150, 13, Color.rgb(255, 101, 93), Paint.Align.CENTER);
            }
        }

        private void drawDrones(Canvas canvas) {
            if (deliveryDroneActive) {
                String mark = deliveryWeapon >= 0 ? "W" : "+";
                drawDrone(canvas, deliveryDroneX, deliveryY, Color.rgb(79, 190, 235), mark, menuAnim);
                // Package hanging under drone until dropped
                if (deliveryPhase < 3) {
                    fillRect(canvas, deliveryDroneX - 10, deliveryY + 18, deliveryDroneX + 10, deliveryY + 34, Color.rgb(120, 90, 50));
                }
            }
            if (saleDroneActive) {
                drawDrone(canvas, saleDroneX, saleY, Color.rgb(239, 155, 64), "$", menuAnim + 1f);
                if (salePhase >= 2) {
                    fillOval(canvas, saleDroneX - 12, saleY + 16, saleDroneX + 12, saleY + 32, Color.rgb(180, 120, 50));
                }
            }
            if (bigDroneActive) {
                drawDrone(canvas, bigDroneX, 120f, Color.rgb(160, 80, 200), "M", menuAnim + 2f);
                // larger body
                fillRect(canvas, bigDroneX - 36, 108f, bigDroneX + 36, 130f, Color.rgb(140, 60, 180));
            }
        }

        private void drawDrone(Canvas canvas, float x, float y, int bodyColor, String mark, float phase) {
            canvas.save();
            canvas.translate(x, y + (float) Math.sin(phase * 5f) * 4f);
            fillRect(canvas, -20, -5, 20, 7, bodyColor);
            fillRect(canvas, -32, -12, -18, -8, Color.rgb(47, 54, 59));
            fillRect(canvas, 18, -12, 32, -8, Color.rgb(47, 54, 59));
            fillRect(canvas, -35, -17, -15, -14, CREAM);
            fillRect(canvas, 15, -17, 35, -14, CREAM);
            fillRect(canvas, -5, 7, 5, 18, Color.rgb(78, 68, 56));
            drawText(canvas, mark, 0, 3, 12, Color.WHITE, Paint.Align.CENTER);
            canvas.restore();
        }

        private void drawWeaponControls(Canvas canvas) {
            drawButton(canvas, 18, 432, 150, 500, "ПИСТОЛЕТ", selectedWeapon == WEAPON_PISTOL ? GOLD : Color.rgb(57, 68, 66));
            drawButton(canvas, 154, 432, 300, 500, shotgunUnlocked ? "ДРОБОВИК" : "ДРОБОВИК 🔒", selectedWeapon == WEAPON_SHOTGUN ? GOLD : Color.rgb(57, 68, 66));
            drawButton(canvas, 304, 432, 454, 500, bowUnlocked ? "АРБАЛЕТ" : "АРБАЛЕТ 🔒", selectedWeapon == WEAPON_BOW ? GOLD : Color.rgb(57, 68, 66));
            // In-game economy buttons (shop screen removed)
            drawButton(canvas, 460, 432, 580, 468, "КУПИТЬ ОР.", Color.rgb(95, 76, 132));
            drawButton(canvas, 460, 472, 580, 508, "ПАТРОНЫ ×10", Color.rgb(60, 100, 120));
            drawButton(canvas, 584, 432, 700, 468, "ПРОДАТЬ", Color.rgb(120, 90, 40));
            drawButton(canvas, 584, 472, 700, 508, "МАНГАЛ", Color.rgb(100, 70, 40));
            if (reloading) {
                float ratio = 1f - reloadTimer / Math.max(0.01f, reloadDuration);
                fillRect(canvas, 470, 492, 620, 505, Color.rgb(48, 48, 43));
                fillRect(canvas, 472, 494, 472 + 146f * ratio, 503, GOLD);
                String label = reloadWeapon == WEAPON_BOW ? "ВЗВОД АРБАЛЕТА" : reloadWeapon == WEAPON_SHOTGUN ? "ЗАРЯДКА ДРОБОВИКА" : "ПЕРЕЗАРЯДКА ПИСТОЛЕТА";
                drawText(canvas, label, 545, 486, 9, CREAM, Paint.Align.CENTER);
            }
        }

        private void drawDogAbilityButton(Canvas canvas) {
            int color = dogCooldownTimer > 0f ? Color.rgb(89, 88, 79) : Color.rgb(45, 125, 75);
            drawButton(canvas, 800, 455, 950, 535,
                    dogCooldownTimer > 0f ? "ПЁС " + (int) Math.ceil(dogCooldownTimer) + "с" : "ПЁС • ОТОГНАТЬ",
                    color);
            drawText(canvas, "ОТПУГНУТЬ: " + (int) monsterFearTimer + "с", 875, 448, 9, GOLD, Paint.Align.CENTER);
        }

        private void drawBirthdayEffects(Canvas canvas) {
            for (ConfettiPiece piece : confetti) {
                paint.setColor(piece.color);
                paint.setStyle(Paint.Style.FILL);
                canvas.save();
                canvas.rotate(piece.life * 170f, piece.x, piece.y);
                canvas.drawRect(piece.x - 3, piece.y - 5, piece.x + 3, piece.y + 5, paint);
                canvas.restore();
            }
            if (birthdayMessageTimer > 0f) {
                fillRect(canvas, 0, 0, WORLD_W, WORLD_H, Color.argb(145, 10, 12, 28));
                int[] burstColors = {Color.rgb(255, 92, 93), Color.rgb(255, 218, 92), Color.rgb(107, 196, 255), Color.rgb(219, 117, 255)};
                for (int b = 0; b < 4; b++) {
                    float cx = 115f + b * 245f;
                    float cy = 105f + (b % 2) * 40f;
                    float radius = 22f + (float) Math.sin(menuAnim * 7f + b) * 8f;
                    paint.setColor(burstColors[b]);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setStrokeWidth(3f);
                    for (int ray = 0; ray < 12; ray++) {
                        float angle = (float) (ray * Math.PI / 6.0 + menuAnim * 0.45f);
                        float x1 = cx + (float) Math.cos(angle) * radius * 0.35f;
                        float y1 = cy + (float) Math.sin(angle) * radius * 0.35f;
                        float x2 = cx + (float) Math.cos(angle) * (radius + 15f);
                        float y2 = cy + (float) Math.sin(angle) * (radius + 15f);
                        canvas.drawLine(x1, y1, x2, y2, paint);
                    }
                }
                paint.setStyle(Paint.Style.FILL);
                drawText(canvas, "ДАНЯ С ДНЁМ РОЖДЕНИЯ!", 480, 245, 37, GOLD, Paint.Align.CENTER);
                // Cake drawn from simple shapes to render consistently on every Android font set.
                fillRect(canvas, 440, 292, 520, 345, Color.rgb(255, 218, 194));
                fillRect(canvas, 436, 286, 524, 300, Color.rgb(251, 139, 172));
                fillRect(canvas, 449, 345, 511, 354, Color.rgb(170, 91, 54));
                fillRect(canvas, 458, 270, 462, 288, GOLD);
                fillRect(canvas, 478, 266, 482, 288, GOLD);
                fillRect(canvas, 498, 270, 502, 288, GOLD);
                fillCircle(canvas, 460, 267, 4, Color.rgb(255, 91, 56));
                fillCircle(canvas, 480, 263, 4, Color.rgb(255, 91, 56));
                fillCircle(canvas, 500, 267, 4, Color.rgb(255, 91, 56));
                drawText(canvas, "ПОЗДРАВЛЯЕМ!", 480, 392, 18, Color.WHITE, Paint.Align.CENTER);
            }
        }

        private void drawGroundDetails(Canvas canvas) {
            for (int i = 0; i < 18; i++) {
                float x = (i * 59 + 21) % 960;
                float y = 505 + (i % 3) * 8;
                fillRect(canvas, x, y, x + 4, y + 9, Color.rgb(124, 178, 74));
            }
        }

        private void drawHud(Canvas canvas) {
            fillRect(canvas, 12, 10, 948, 72, PANEL);
            strokeRect(canvas, 12, 10, 948, 72, GOLD, 2);
            drawText(canvas, extraMode ? "БОНУС " + extraLevel + "/100" : "УРОВЕНЬ " + level + "/6", 28, 38, 18, GOLD, Paint.Align.LEFT);
            drawText(canvas, "HP", 203, 37, 15, CREAM, Paint.Align.LEFT);
            fillRect(canvas, 239, 23, 355, 43, Color.rgb(55, 48, 43));
            int healthColor = playerHp > maxHp * 0.35f ? Color.rgb(90, 190, 89) : Color.rgb(226, 75, 67);
            if (playerHp > 0) fillRect(canvas, 242, 26, 242 + 110f * playerHp / maxHp, 40, healthColor);
            drawText(canvas, playerHp + "/" + maxHp, 367, 38, 13, CREAM, Paint.Align.LEFT);

            String ammoText = selectedWeapon == WEAPON_PISTOL
                    ? pistolMagazine + "/" + ammo
                    : selectedWeapon == WEAPON_SHOTGUN ? shotgunMagazine + "/" + shotgunAmmo
                    : (bowLoaded ? "1" : "0") + "/" + bowAmmo;
            String weaponLabel = selectedWeapon == WEAPON_PISTOL ? "ПИСТОЛЕТ" : selectedWeapon == WEAPON_SHOTGUN ? "РУЖЬЁ" : "ЛУК";
            drawText(canvas, weaponLabel + " " + ammoText, 478, 38, 15, CREAM, Paint.Align.LEFT);
            if (!extraMode && (level == 1 || level == 2)) {
                int remain = Math.max(0, (int) (levelTimeLimit - levelElapsed));
                drawText(canvas, String.format(java.util.Locale.US, "%02d:%02d", remain / 60, remain % 60),
                        650, 39, 20, remain <= 20 ? Color.rgb(255, 103, 83) : GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                drawText(canvas, "ВОЛНА " + waveIndex + "/5", 645, 38, 16, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "БОСС", 650, 38, 17, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БОСС-ФИНАЛ", 650, 38, 15, GOLD, Paint.Align.CENTER);
            } else if (!extraMode) {
                drawText(canvas, "УТОК: " + kills + "/" + requiredKills, 650, 38, 15, GOLD, Paint.Align.CENTER);
            }

            drawButton(canvas, 725, 16, 815, 64, "МАГАЗИН", Color.rgb(120, 83, 35));
            drawButton(canvas, 825, 16, 886, 64, "Ⅱ", Color.rgb(71, 83, 68));
            drawButton(canvas, 895, 16, 940, 64, soundOn ? "♪" : "×", Color.rgb(71, 83, 68));
            if (extraMode) {
                drawText(canvas, "СЛУЧАЙНАЯ КАРТА • БОСС • ЗОЛОТО: " + gold, 480, 98, 14, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "У большой утки " + (int) bossDuckHp + " HP. Победи босса!", 480, 116, 14, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                String hint = waveIndex < 5 ? "Утки идут волнами. Следующая атака через 30 секунд." : "Последняя волна! Добей оставшихся уток.";
                drawText(canvas, hint, 480, 116, 13, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БЕСКОНЕЧНЫЕ ПАТРОНЫ • УРОН 4 • ОСТОРОЖНО: УДАР 50 HP", 480, 98, 13, Color.rgb(246, 205, 255), Paint.Align.CENTER);
            }
        }

        private void drawCrosshair(Canvas canvas) {
            if (crosshairTimer <= 0f) return;
            int alpha = (int) (255 * Math.min(1f, crosshairTimer / 0.25f));
            paint.setColor(Color.argb(alpha, 255, 244, 183));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            canvas.drawCircle(crosshairX, crosshairY, 17, paint);
            canvas.drawLine(crosshairX - 27, crosshairY, crosshairX - 8, crosshairY, paint);
            canvas.drawLine(crosshairX + 8, crosshairY, crosshairX + 27, crosshairY, paint);
            canvas.drawLine(crosshairX, crosshairY - 27, crosshairX, crosshairY - 8, paint);
            canvas.drawLine(crosshairX, crosshairY + 8, crosshairX, crosshairY + 27, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawStateOverlay(Canvas canvas) {
            if (state == State.LOADING) {
                overlay(canvas, 0.58f);
                panel(canvas, 240, 175, 720, 370);
                drawText(canvas, "УТИНАЯ ОХОТА", 480, 245, 36, GOLD, Paint.Align.CENTER);
                drawText(canvas, "ЗАГРУЗКА ЛЕСА...", 480, 295, 17, CREAM, Paint.Align.CENTER);
                fillRect(canvas, 340, 325, 620, 340, Color.rgb(55, 48, 43));
                fillRect(canvas, 344, 329, 344 + 272f * Math.min(1f, loadingElapsed / 2.4f), 336, GOLD);
            } else if (state == State.MENU) {
                overlay(canvas, 0.2f);
                panel(canvas, 190, 80, 770, 510);
                drawText(canvas, "УТИНАЯ ОХОТА", 480, 160, 39, GOLD, Paint.Align.CENTER);
                drawText(canvas, "RETRO FOREST ARCADE • FIRST PERSON", 480, 196, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Стреляй по уткам, уклоняйся от атак и собирай добычу.", 480, 248, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Собака приносит до пяти уток за один рейс. Собирай добычу и береги корзину!", 480, 278, 13, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 345, 630, 415, "ОСНОВНАЯ ИГРА • 6 УРОВНЕЙ", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 425, 630, 490, "ДОПОЛНИТЕЛЬНЫЕ УРОВНИ • 100", Color.rgb(103, 72, 137));
            } else if (state == State.SHOP) {
                overlay(canvas, 0.62f);
                panel(canvas, 35, 88, 925, 520);
                drawText(canvas, shopMidLevel ? "ДОСТАВКА БОЕПРИПАСОВ" : "ЛАВКА И АВИАДОСТАВКА", 480, 145, 27, GOLD, Paint.Align.CENTER);
                drawText(canvas, "В корзине: " + duckInventory + " сырых + " + cookedDucks + " готовых   •   Золото: " + gold, 480, 188, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Выбери тип боеприпасов и количество. Дрон доставит покупку автоматически.", 480, 220, 12, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 50, 272, 205, 322, "ПИСТОЛЕТ", selectedWeapon == WEAPON_PISTOL ? GOLD : Color.rgb(71, 83, 68));
                drawButton(canvas, 210, 272, 365, 322, "РУЖЬЁ", selectedWeapon == WEAPON_SHOTGUN ? GOLD : Color.rgb(71, 83, 68));
                drawButton(canvas, 370, 272, 525, 322, "ЛУК", selectedWeapon == WEAPON_BOW ? GOLD : Color.rgb(71, 83, 68));
                drawButton(canvas, 560, 272, 620, 322, "−", Color.rgb(83, 83, 73));
                drawButton(canvas, 630, 272, 690, 322, "+", Color.rgb(83, 83, 73));
                drawText(canvas, "КОЛ-ВО: " + ammoPurchaseQuantity, 785, 305, 15, GOLD, Paint.Align.CENTER);
                drawButton(canvas, 45, 330, 245, 405, "ПРОДАТЬ УТОК", Color.rgb(133, 87, 42));
                drawButton(canvas, 260, 330, 455, 405, "КУПИТЬ ПАТРОНЫ", Color.rgb(48, 105, 75));
                String weaponBuyLabel = selectedWeapon == WEAPON_PISTOL ? "ПИСТОЛЕТ ЕСТЬ" :
                        selectedWeapon == WEAPON_SHOTGUN ? (shotgunUnlocked ? "РУЖЬЁ КУПЛЕНО" : "РУЖЬЁ • 35 ЗОЛОТА") :
                        (bowUnlocked ? "ЛУК КУПЛЕН" : "ЛУК • 55 ЗОЛОТА");
                drawButton(canvas, 470, 330, 685, 405, weaponBuyLabel, Color.rgb(95, 76, 132));
                drawText(canvas, "1 патрон = 2 золота • стрела = 3 золота", 800, 365, 11, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 435, 630, 505, shopMidLevel ? "ВЕРНУТЬСЯ В УРОВЕНЬ" : "НАЧАТЬ УРОВЕНЬ", Color.rgb(43, 123, 65));
                drawButton(canvas, 650, 435, 880, 505, "В МЕНЮ", Color.rgb(83, 83, 73));
                if (deliveryDroneActive) drawText(canvas, deliveryWeapon >= 0 ? "ДРОН НЕСЁТ ОРУЖИЕ..." : "ДРОН НЕСЁТ БОЕПРИПАСЫ...", 480, 425, 12, GOLD, Paint.Align.CENTER);
            } else if (state == State.PAUSED) {
                overlay(canvas, 0.58f);
                panel(canvas, 300, 160, 660, 490);
                drawText(canvas, "ПАУЗА", 480, 230, 34, GOLD, Paint.Align.CENTER);
                drawButton(canvas, 330, 330, 630, 410, "ПРОДОЛЖИТЬ", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 415, 630, 485, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.LEVEL_CLEAR) {
                overlay(canvas, 0.48f);
                panel(canvas, 280, 150, 680, 480);
                drawText(canvas, "УРОВЕНЬ ПРОЙДЕН!", 480, 235, 31, GOLD, Paint.Align.CENTER);
                String message = extraMode ? "Босс повержен! Следующая случайная карта уже ждёт." : level == 6 ? "Праздник удался! С днём рождения, Даня!" : level == 3 ? "Большая утка побеждена!" : level == 4 ? "Все пять волн отражены!" : "Отличная охота! Пёс уже несёт добычу.";
                drawText(canvas, message, 480, 285, 14, CREAM, Paint.Align.CENTER);
                String nextLabel = extraMode ? (extraLevel < 100 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ") : (level < 6 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ");
                drawButton(canvas, 330, 350, 630, 430, nextLabel, Color.rgb(43, 123, 65));
            } else if (state == State.GAME_OVER) {
                overlay(canvas, 0.68f);
                panel(canvas, 280, 150, 680, 490);
                drawText(canvas, "ИГРА ОКОНЧЕНА", 480, 235, 31, Color.rgb(255, 112, 92), Paint.Align.CENTER);
                drawText(canvas, failureReason, 480, 285, 16, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Здоровье и патроны восстановятся при новом запуске.", 480, 315, 12, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 440, "НАЧАТЬ ЗАНОВО", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 445, 630, 510, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.VICTORY) {
                overlay(canvas, 0.58f);
                panel(canvas, 260, 140, 700, 490);
                drawText(canvas, "ПОБЕДА!", 480, 235, 42, GOLD, Paint.Align.CENTER);
                drawText(canvas, extraMode ? "Пройдены все 100 дополнительных уровней!" : "Эндермен повержен. Лес спасён, а корзина полна!", 480, 292, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Уток в корзине: " + basketCount, 480, 322, 15, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 445, "ИГРАТЬ СНОВА", Color.rgb(43, 123, 65));
            }
        }

        private void overlay(Canvas canvas, float alpha) {
            fillRect(canvas, 0, 0, WORLD_W, WORLD_H, Color.argb((int) (alpha * 255), 8, 12, 10));
        }

        private void panel(Canvas canvas, float left, float top, float right, float bottom) {
            fillRect(canvas, left, top, right, bottom, PANEL);
            strokeRect(canvas, left, top, right, bottom, GOLD, 3);
            strokeRect(canvas, left + 7, top + 7, right - 7, bottom - 7, Color.rgb(97, 105, 75), 1);
        }

        private void drawButton(Canvas canvas, float left, float top, float right, float bottom, String label, int color) {
            fillRect(canvas, left, top, right, bottom, color);
            strokeRect(canvas, left, top, right, bottom, GOLD, 2);
            drawText(canvas, label, (left + right) / 2f, (top + bottom) / 2f + 7, 17, CREAM, Paint.Align.CENTER);
        }

        private void fillRect(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(left, top, right, bottom, paint);
        }

        private void strokeRect(Canvas canvas, float left, float top, float right, float bottom, int color, float width) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(width);
            canvas.drawRect(left, top, right, bottom, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void fillCircle(Canvas canvas, float x, float y, float radius, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x, y, radius, paint);
        }

        private void fillOval(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawOval(new RectF(left, top, right, bottom), paint);
        }

        private void drawText(Canvas canvas, String text, float x, float baseline, float size, int color, Paint.Align align) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(PIXEL);
            paint.setTextSize(size);
            paint.setTextAlign(align);
            canvas.drawText(text, x, baseline, paint);
        }

        private static final class SoundEngine {
            private final SoundPool pool;
            private final int shot;
            private final int shotgunShot;
            private final int bowShot;
            private final int pistolReload;
            private final int shotgunReload;
            private final int bowReload;
            private final int droneDelivery;
            private final int droneSale;
            private final int grillStart;
            private final int grillDone;
            private final int duckFly;
            private final int quack;
            private final int bark;
            private final int monsterImpact;
            private final int monsterHit;
            private final int ambience;
            private int ambienceStream = 0;
            private boolean enabled = true;
            private boolean ambienceLoaded = false;

            SoundEngine(Context context) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attributes).build();
                shot = pool.load(context, R.raw.gunshot, 1);
                shotgunShot = pool.load(context, R.raw.shotgun_shot, 1);
                bowShot = pool.load(context, R.raw.bow_shot, 1);
                pistolReload = pool.load(context, R.raw.pistol_reload, 1);
                shotgunReload = pool.load(context, R.raw.shotgun_reload, 1);
                bowReload = pool.load(context, R.raw.bow_reload, 1);
                droneDelivery = pool.load(context, R.raw.drone_delivery, 1);
                droneSale = pool.load(context, R.raw.drone_sale, 1);
                grillStart = pool.load(context, R.raw.grill_start, 1);
                grillDone = pool.load(context, R.raw.grill_done, 1);
                duckFly = pool.load(context, R.raw.duck_fly, 1);
                quack = pool.load(context, R.raw.duck_quack, 1);
                bark = pool.load(context, R.raw.dog_bark, 1);
                monsterImpact = pool.load(context, R.raw.monster_hit, 1);
                monsterHit = pool.load(context, R.raw.monster_hit, 1);
                ambience = pool.load(context, R.raw.forest_ambience, 1);
                pool.setOnLoadCompleteListener((soundPool, sampleId, status) -> {
                    if (sampleId == ambience && status == 0) {
                        ambienceLoaded = true;
                        if (enabled) startAmbience();
                    }
                });
            }

            void setEnabled(boolean value) {
                enabled = value;
                if (!enabled) pauseAmbience();
                else startAmbience();
            }

            void startAmbience() {
                if (!enabled || !ambienceLoaded || ambienceStream != 0) return;
                ambienceStream = pool.play(ambience, 0.26f, 0.26f, 1, -1, 1f);
            }

            void pauseAmbience() {
                if (ambienceStream != 0) {
                    pool.stop(ambienceStream);
                    ambienceStream = 0;
                }
            }

            void resumeAmbience() { startAmbience(); }

            private void play(int id, float volume) {
                if (enabled && id != 0) pool.play(id, volume, volume, 2, 0, 1f);
            }

            void playShot() { play(shot, 0.8f); }
            void playShotgunShot() { play(shotgunShot, 0.86f); }
            void playBowShot() { play(bowShot, 0.8f); }
            void playPistolReload() { play(pistolReload, 0.75f); }
            void playShotgunReload() { play(shotgunReload, 0.82f); }
            void playBowReload() { play(bowReload, 0.75f); }
            void playDroneDelivery() { play(droneDelivery, 0.55f); }
            void playDroneSale() { play(droneSale, 0.55f); }
            void playGrillStart() { play(grillStart, 0.6f); }
            void playGrillDone() { play(grillDone, 0.65f); }
            void playDuckFly() { play(duckFly, 0.36f); }
            void playQuack() { play(quack, 0.55f); }
            void playDogBark() { play(bark, 0.5f); }
            void playMonsterImpact() { play(monsterImpact, 0.75f); }
            void playMonsterHit() { play(monsterHit, 0.45f); }

            void release() {
                pauseAmbience();
                pool.release();
            }
        }
    }
}
