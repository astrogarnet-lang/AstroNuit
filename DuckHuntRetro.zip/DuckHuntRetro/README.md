# Duck Hunt Retro 1.2

Android arcade game built with Java and Android Canvas. See `README_RU.md` for the full feature list and GitHub Actions build instructions.
