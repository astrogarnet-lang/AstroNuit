@echo off
setlocal
set GRADLE_VERSION=9.6.0
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set INSTALL_ROOT=%GRADLE_USER_HOME%\wrapper\dists\manual
set INSTALL_DIR=%INSTALL_ROOT%\gradle-%GRADLE_VERSION%
set ZIP_FILE=%INSTALL_ROOT%\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%INSTALL_DIR%\bin\gradle.bat" (
  if not exist "%INSTALL_ROOT%" mkdir "%INSTALL_ROOT%"
  if not exist "%ZIP_FILE%" (
    echo Downloading Gradle %GRADLE_VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash -Algorithm SHA256 '%ZIP_FILE%').Hash.ToLower(); if ($h -ne 'bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01') { Remove-Item '%ZIP_FILE%' -Force; throw 'Gradle checksum mismatch' }; Expand-Archive -Force '%ZIP_FILE%' '%INSTALL_ROOT%'"
  if errorlevel 1 exit /b 1
)
call "%INSTALL_DIR%\bin\gradle.bat" %*
endlocal
