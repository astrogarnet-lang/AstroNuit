package com.duckhunt.retro;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Duck Hunt Retro — a small, self-contained landscape arcade game.
 * All graphics are drawn with Canvas and all sound effects are bundled WAV files.
 */
public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.onHostPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.onHostResume();
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) gameView.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.handleBack();
        } else {
            super.onBackPressed();
        }
    }

    private static final class GameView extends View {
        private static final float WORLD_W = 960f;
        private static final float WORLD_H = 540f;
        private static final int SKY_DAY = Color.rgb(104, 190, 216);
        private static final int GRASS = Color.rgb(76, 139, 61);
        private static final int DARK = Color.rgb(24, 39, 30);
        private static final int PANEL = Color.rgb(24, 37, 31);
        private static final int GOLD = Color.rgb(255, 205, 75);
        private static final int CREAM = Color.rgb(248, 241, 211);
        private static final Typeface PIXEL = Typeface.create("monospace", Typeface.BOLD);

        private enum State { MENU, SHOP, PLAYING, PAUSED, LEVEL_CLEAR, GAME_OVER, VICTORY }

        private static final class Duck {
            float x;
            float y;
            float baseY;
            float vx;
            float phase;
            float age;
            int hp;
            final int maxHp;
            final boolean attacker;
            final int archetype;
            boolean attacked;
            float retreatTimer;
            float retreatVx;
            float retreatVy;
            float attackCooldown;

            Duck(float x, float y, float vx, int hp, boolean attacker, Random random) {
                this.x = x;
                this.y = y;
                this.baseY = y;
                this.vx = vx;
                this.hp = hp;
                this.maxHp = hp;
                this.attacker = attacker;
                this.archetype = random.nextInt(4);
                this.phase = random.nextFloat() * 6.28f;
                this.attackCooldown = random.nextFloat() * 1.2f;
            }
        }

        private static final class FallenDuck {
            float x;
            float y;
            float vy;
            float rotation;
            float landedTime;
            boolean queued;
            final float phase;
            FallenDuck(float x, float y, Random random) {
                this.x = x;
                this.y = y;
                this.vy = -45f;
                this.phase = random.nextFloat() * 6.28f;
            }
        }

        private static final class FetchJob {
            final float x;
            final FallenDuck duck;
            FetchJob(FallenDuck duck) {
                this.duck = duck;
                this.x = Math.max(65, Math.min(825, duck.x));
            }
        }

        private static final class BloodParticle {
            float x, y, vx, vy, life;
            BloodParticle(float x, float y, float vx, float vy) {
                this.x = x; this.y = y; this.vx = vx; this.vy = vy; this.life = 1.15f;
            }
        }

        private final Paint paint = new Paint();
        private final Random random = new Random();
        private final List<Duck> ducks = new ArrayList<>();
        private final List<FallenDuck> fallenDucks = new ArrayList<>();
        private final List<BloodParticle> bloodParticles = new ArrayList<>();
        private final ArrayDeque<FetchJob> fetchQueue = new ArrayDeque<>();
        private float[] treeX = {78f, 252f, 510f, 757f, 905f};
        private final SoundEngine sound;

        private State state = State.MENU;
        private int level = 1;
        private float playerHp = 100f;
        private int maxHp = 100;
        private int ammo = 0;
        private int basketCount = 0;
        private int duckInventory = 0;
        private int gold = 0;
        private int purchasedAmmo = 0;
        private int dogCarryCount = 0;
        private int dogCarryLimit = 3;
        private int magazineSize = 5;
        private int magazineAmmo = 5;
        private boolean reloading = false;
        private boolean doubleBarrelOwned = false;
        private boolean doubleBarrelActive = false;
        private float reloadTimer = 0f;
        private long saleCompleteAtMs = 0L;
        private int saleQuantity = 0;
        private long purchase10CompleteAtMs = 0L;
        private long purchase25CompleteAtMs = 0L;
        private boolean purchase10MidLevel = false;
        private boolean purchase25MidLevel = false;
        private boolean confirmReset = false;
        private int weatherType = 0;
        private float weatherIntensity = 0.5f;
        private float buttonFlashTimer = 0f;
        private float pressedButtonX = -1000f;
        private float pressedButtonY = -1000f;
        private int kills = 0;
        private int requiredKills = 0;
        private float levelElapsed = 0f;
        private float levelTimeLimit = 0f;
        private float bossDuckHp = 120f;
        private float enderHp = 2000f;
        private float bossX = 680f;
        private float bossY = 430f;
        private float bossDirection = -1f;
        private float spawnClock = 0f;
        private float attackClock = 0f;
        private float nextWaveAt = 0f;
        private int waveIndex = 0;
        private boolean finalBossPhase = false;
        private float finalPhaseElapsed = 0f;
        private float finalAttackClock = 0f;
        private float enderTeleportClock = 7f;
        private float enderTeleportFlash = 0f;
        private float enderWalkPhase = 0f;
        private float extraBossHp = 0f;
        private float extraBossMaxHp = 0f;
        private float extraBossAttackClock = 0f;
        private float extraBossSpawnClock = 0f;
        private int extraBossType = 0;
        private int extraLevel = 1;
        private int shopNextLevel = 1;
        private boolean extraMode = false;
        private boolean shopMidLevel = false;
        private int mapTheme = 0;
        private float weaponRecoil = 0f;
        private float bossDamageFlash = 0f;
        private float playerDamageFlash = 0f;
        private float muzzleFlash = 0f;
        private float crosshairX = -100f;
        private float crosshairY = -100f;
        private float crosshairTimer = 0f;
        private float duckSoundClock = 5f;
        private float dogX = 135f;
        private float dogTargetX = 135f;
        private int dogState = 0; // 0 idle, 1 fetch, 2 return to basket
        private boolean dogCarrying = false;
        private boolean soundOn = true;
        private boolean hostPaused = false;
        private boolean treesBroken = false;
        private String failureReason = "Попробуй ещё раз!";
        private long lastFrame = 0L;
        private float menuAnim = 0f;
        private float emergeOffset = 210f;
        private float gameScaleX = 1f;
        private float gameScaleY = 1f;
        private float gameOffsetX = 0f;
        private float gameOffsetY = 0f;

        GameView(Context context) {
            super(context);
            setFocusable(true);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            sound = new SoundEngine(context);
            lastFrame = SystemClock.uptimeMillis();
            paint.setTypeface(PIXEL);
            paint.setAntiAlias(false);
        }

        void onHostPause() {
            hostPaused = true;
            if (state == State.PLAYING) state = State.PAUSED;
            sound.pauseAmbience();
        }

        void onHostResume() {
            hostPaused = false;
            lastFrame = SystemClock.uptimeMillis();
            if (soundOn) sound.resumeAmbience();
            invalidate();
        }

        void release() {
            sound.release();
        }

        void handleBack() {
            if (state == State.PLAYING) {
                state = State.PAUSED;
            } else if (state == State.SHOP) {
                if (shopMidLevel && ammo > 0) state = State.PLAYING;
                else state = State.MENU;
            } else if (state == State.PAUSED) {
                state = State.PLAYING;
            } else if (state == State.MENU) {
                // Keep the game on its title screen; Android handles the app-level back gesture.
            } else {
                state = State.MENU;
            }
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.05f, Math.max(0f, (now - lastFrame) / 1000f));
            lastFrame = now;
            updateBackgroundTransactions();
            if (buttonFlashTimer > 0f) buttonFlashTimer = Math.max(0f, buttonFlashTimer - dt);

            if (state == State.PLAYING && !hostPaused) {
                updateGame(dt);
            } else {
                if (state == State.LEVEL_CLEAR || state == State.VICTORY || state == State.SHOP) {
                    updateFallenDucks(dt);
                    updateDog(dt);
                }
            }
            menuAnim += dt;

            gameScaleX = getWidth() / WORLD_W;
            gameScaleY = getHeight() / WORLD_H;
            gameOffsetX = 0f;
            gameOffsetY = 0f;

            canvas.drawColor(Color.BLACK);
            canvas.save();
            canvas.scale(gameScaleX, gameScaleY);

            drawWorld(canvas);
            drawHud(canvas);
            drawCrosshair(canvas);
            drawStateOverlay(canvas);
            if (playerDamageFlash > 0f && state == State.PLAYING) {
                float flashAlpha = Math.min(0.42f, playerDamageFlash * 1.2f);
                fillRect(canvas, 0, 0, WORLD_W, WORLD_H,
                        Color.argb((int) (flashAlpha * 255), 230, 20, 30));
            }

            canvas.restore();
            postInvalidateDelayed(state == State.PLAYING ? 16 : 60);
        }

        private void startNewGame() {
            basketCount = 0;
            fetchQueue.clear();
            fallenDucks.clear();
            bloodParticles.clear();
            saleCompleteAtMs = 0L;
            saleQuantity = 0;
            purchase10CompleteAtMs = 0L;
            purchase25CompleteAtMs = 0L;
            confirmReset = false;
            treeX = new float[]{78f, 252f, 510f, 757f, 905f};
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            duckInventory = 0;
            gold = 0;
            purchasedAmmo = 0;
            extraMode = false;
            extraLevel = 1;
            openShop(1);
        }

        private void startExtraGame() {
            basketCount = 0;
            duckInventory = 0;
            gold = 0;
            purchasedAmmo = 0;
            fetchQueue.clear();
            fallenDucks.clear();
            bloodParticles.clear();
            saleCompleteAtMs = 0L;
            saleQuantity = 0;
            purchase10CompleteAtMs = 0L;
            purchase25CompleteAtMs = 0L;
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            extraMode = true;
            extraLevel = 1;
            openShop(1);
        }

        private void openShop(int targetLevel) {
            shopNextLevel = targetLevel;
            shopMidLevel = false;
            state = State.SHOP;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void openAmmoShop() {
            if (!extraMode || state != State.PLAYING) return;
            shopMidLevel = true;
            shopNextLevel = extraLevel;
            state = State.SHOP;
            lastFrame = SystemClock.uptimeMillis();
        }

        private void startLevel(int newLevel) {
            if (extraMode) {
                startExtraLevel(newLevel);
                return;
            }
            level = newLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            nextWaveAt = 0f;
            waveIndex = 0;
            finalBossPhase = false;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderTeleportClock = 7f;
            enderTeleportFlash = 0f;
            enderWalkPhase = 0f;
            treesBroken = false;
            bossDamageFlash = 0f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            emergeOffset = 210f;
            bossDuckHp = 120f;
            enderHp = 2000f;
            bossX = 680f;
            bossY = 430f;
            bossDirection = -1f;
            duckSoundClock = 4f + random.nextFloat() * 3f;
            weatherType = random.nextInt(4);
            weatherIntensity = 0.35f + random.nextFloat() * 0.55f;
            reloading = false;
            reloadTimer = 0f;
            magazineSize = doubleBarrelActive ? 2 : 5;
            magazineAmmo = 0;

            if (level <= 3) {
                maxHp = 100;
            } else {
                maxHp = 500;
            }
            playerHp = maxHp;

            switch (level) {
                case 1:
                    requiredKills = 10;
                    ammo = 65;
                    levelTimeLimit = 180f;
                    spawnFriendlyDucks(10, 1, 0.28f, 0.68f);
                    break;
                case 2:
                    requiredKills = 20;
                    ammo = 75;
                    levelTimeLimit = 240f;
                    spawnFriendlyDucks(20, 3, 0.45f, 0.9f);
                    break;
                case 3:
                    requiredKills = 20;
                    ammo = 150;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(20, 55, 0.72f, 1.12f);
                    bossDuckHp = 120f;
                    break;
                case 4:
                    requiredKills = 35;
                    ammo = 270;
                    levelTimeLimit = 0f;
                    // Five attacks/waves: the first starts immediately, the next four every 30 seconds.
                    spawnLevelFourWave();
                    break;
                case 5:
                    requiredKills = 10;
                    ammo = 50;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(10, 1, 0.52f, 0.86f);
                    break;
                default:
                    level = 1;
                    startLevel(1);
                    return;
            }
            ammo += purchasedAmmo;
            purchasedAmmo = 0;
            magazineAmmo = Math.min(magazineSize, ammo);
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void startExtraLevel(int newLevel) {
            extraLevel = Math.max(1, Math.min(30, newLevel));
            level = extraLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            extraBossAttackClock = 0f;
            extraBossSpawnClock = 0f;
            extraBossHp = 120f + extraLevel * 18f;
            extraBossMaxHp = extraBossHp;
            extraBossType = random.nextInt(4);
            mapTheme = random.nextInt(5);
            weatherType = random.nextInt(4);
            weatherIntensity = 0.35f + random.nextFloat() * 0.55f;
            reloading = false;
            reloadTimer = 0f;
            magazineSize = doubleBarrelActive ? 2 : 5;
            magazineAmmo = 0;
            treesBroken = false;
            finalBossPhase = false;
            bossX = 260f + random.nextFloat() * 440f;
            bossY = 140f + random.nextFloat() * 100f;
            bossDirection = random.nextBoolean() ? 1f : -1f;
            playerHp = maxHp = 500;
            ammo = 105 + Math.min(45, extraLevel / 2) + purchasedAmmo;
            purchasedAmmo = 0;
            magazineAmmo = Math.min(magazineSize, ammo);
            levelTimeLimit = 0f;
            requiredKills = 8 + random.nextInt(7) + extraLevel / 4;
            treeX = new float[5 + random.nextInt(4)];
            for (int i = 0; i < treeX.length; i++) treeX[i] = 45f + i * (870f / Math.max(1, treeX.length - 1)) + random.nextFloat() * 26f - 13f;
            for (int i = 0; i < requiredKills; i++) {
                float x = 65f + random.nextFloat() * 830f;
                float y = 105f + random.nextFloat() * 220f;
                int hp = 2 + Math.min(16, extraLevel / 5) + random.nextInt(4);
                boolean attacker = random.nextFloat() < 0.22f;
                float speed = 0.55f + random.nextFloat() * 0.95f + extraLevel * 0.003f;
                ducks.add(new Duck(x, y, speed * 95f * (random.nextBoolean() ? 1f : -1f), hp, attacker, random));
            }
            duckSoundClock = 2f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void spawnFriendlyDucks(int count, int hp, float minSpeed, float maxSpeed) {
            for (int i = 0; i < count; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 110 + random.nextFloat() * 190;
                float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
                float direction = random.nextBoolean() ? 1f : -1f;
                ducks.add(new Duck(x, y, speed * 95f * direction, hp, false, random));
            }
        }

        private void spawnLevelFourWave() {
            if (waveIndex >= 5) return;
            waveIndex++;
            for (int i = 0; i < 7; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 95 + random.nextFloat() * 165;
                ducks.add(new Duck(x, y, 0f, 7, true, random));
            }
            nextWaveAt = waveIndex * 30f;
            sound.playDuckFly();
        }

        private void updateGame(float dt) {
            levelElapsed += dt;
            if (!extraMode && level <= 2 && levelTimeLimit > 0f && levelElapsed >= levelTimeLimit) {
                failGame("Время вышло!");
                return;
            }

            if (muzzleFlash > 0f) muzzleFlash -= dt;
            if (weaponRecoil > 0f) weaponRecoil = Math.max(0f, weaponRecoil - dt * 5f);
            if (crosshairTimer > 0f) crosshairTimer -= dt;
            if (playerDamageFlash > 0f) playerDamageFlash -= dt;
            if (reloading) {
                reloadTimer = Math.max(0f, reloadTimer - dt);
                if (reloadTimer <= 0f) {
                    reloading = false;
                    magazineAmmo = Math.min(magazineSize, ammo);
                }
            }
            updateBloodParticles(dt);
            if (bossDamageFlash > 0f) bossDamageFlash -= dt;

            duckSoundClock -= dt;
            if (duckSoundClock <= 0f && !ducks.isEmpty()) {
                sound.playDuckFly();
                if (random.nextFloat() < 0.72f) sound.playQuack();
                duckSoundClock = 5f + random.nextFloat() * 6f;
            }

            if (!extraMode && level == 4 && waveIndex < 5 && levelElapsed >= nextWaveAt) {
                spawnLevelFourWave();
            }

            updateDucks(dt);
            if (state != State.PLAYING) return;
            updateFallenDucks(dt);
            updateDog(dt);
            if (extraMode && ammo <= 0) {
                openAmmoShop();
                return;
            }

            if (extraMode) {
                updateExtraBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 3) {
                updateLargeDuckBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 5 && finalBossPhase) {
                updateEnderman(dt);
                if (state != State.PLAYING) return;
            }

            if (extraMode) {
                if (extraBossHp <= 0f) clearLevel();
            } else if (level == 1 || level == 2 || level == 5 && !finalBossPhase) {
                if (kills >= requiredKills) {
                    if (level == 5) beginEndermanPhase();
                    else clearLevel();
                } else if (ammo <= 0 && level != 5) {
                    failGame("Патроны закончились!");
                }
            } else if (!extraMode && level == 4) {
                if (waveIndex >= 5 && ducks.isEmpty()) {
                    clearLevel();
                } else if (ammo <= 0 && !ducks.isEmpty()) {
                    failGame("Патроны закончились!");
                }
            }
        }

        private void updateDucks(float dt) {
            Iterator<Duck> iterator = ducks.iterator();
            while (iterator.hasNext()) {
                Duck duck = iterator.next();
                duck.age += dt;
                if (duck.attacker) {
                    duck.attackCooldown = Math.max(0f, duck.attackCooldown - dt);
                    if (duck.retreatTimer > 0f) {
                        duck.retreatTimer -= dt;
                        duck.x += duck.retreatVx * dt;
                        duck.y += duck.retreatVy * dt;
                        duck.x = Math.max(28f, Math.min(932f, duck.x));
                        duck.y = Math.max(82f, Math.min(320f, duck.y));
                        continue;
                    }
                    float targetX = 480f;
                    float targetY = 422f;
                    float dx = targetX - duck.x;
                    float dy = targetY - duck.y;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance > 1f) {
                        float speed = 82f + Math.min(50f, extraMode ? extraLevel * 0.6f : 0f);
                        duck.x += dx / distance * speed * dt;
                        duck.y += dy / distance * speed * dt;
                    }
                    if (distance < 48f && duck.attackCooldown <= 0f) {
                        damagePlayer(1);
                        if (state != State.PLAYING) return;
                        float len = Math.max(1f, distance);
                        duck.retreatVx = -dx / len * 245f;
                        duck.retreatVy = -Math.max(0.35f, dy / len) * 150f;
                        duck.retreatTimer = 0.95f;
                        duck.attackCooldown = 2.0f;
                        duck.attacked = true;
                    }
                } else {
                    duck.x += duck.vx * dt;
                    duck.y = duck.baseY + (float) Math.sin(duck.age * 2.7f + duck.phase) * 17f;
                    if (duck.x < 42f) duck.vx = Math.abs(duck.vx);
                    if (duck.x > 918f) duck.vx = -Math.abs(duck.vx);
                }
            }
        }

        private void updateFallenDucks(float dt) {
            Iterator<FallenDuck> iterator = fallenDucks.iterator();
            while (iterator.hasNext()) {
                FallenDuck duck = iterator.next();
                if (duck.y < 414f) {
                    duck.vy += 315f * dt;
                    duck.y += duck.vy * dt;
                    duck.rotation += 210f * dt;
                    if (duck.y >= 414f) {
                        duck.y = 414f;
                        duck.vy = 0f;
                    }
                } else {
                    duck.landedTime += dt;
                    if (!duck.queued && duck.landedTime >= 0.28f) {
                        fetchQueue.add(new FetchJob(duck));
                        duck.queued = true;
                    }
                }
            }
        }

        private void updateExtraBoss(float dt) {
            bossX += bossDirection * (38f + extraLevel * 0.22f) * dt;
            if (bossX < 190f) bossDirection = 1f;
            if (bossX > 790f) bossDirection = -1f;
            bossY = 150f + (float) Math.sin(levelElapsed * 1.35f) * 35f;
            extraBossSpawnClock += dt;
            if (extraBossSpawnClock >= Math.max(2.8f, 7f - extraLevel * 0.025f) && ducks.size() < 24) {
                extraBossSpawnClock = 0f;
                int count = 1 + random.nextInt(2);
                for (int i = 0; i < count; i++) {
                    float x = bossX + random.nextFloat() * 90f - 45f;
                    float y = bossY + 35f + random.nextFloat() * 45f;
                    int hp = 2 + Math.min(16, extraLevel / 5);
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1f : -1f) * 90f, hp, random.nextFloat() < 0.3f, random));
                }
                sound.playDuckFly();
            }
            extraBossAttackClock += dt;
            if (extraBossAttackClock >= Math.max(2.4f, 6.0f - extraLevel * 0.02f)) {
                extraBossAttackClock = 0f;
                damagePlayer(3 + extraLevel / 4);
            }
        }

        private void updateLargeDuckBoss(float dt) {
            bossX += bossDirection * 44f * dt;
            if (bossX < 560f) bossDirection = 1f;
            if (bossX > 825f) bossDirection = -1f;
            bossY = 156f + (float) Math.sin(levelElapsed * 1.7f) * 26f;

            spawnClock += dt;
            if (spawnClock >= 7f && ducks.size() < 28) {
                spawnClock = 0f;
                for (int i = 0; i < 2; i++) {
                    float x = bossX + random.nextFloat() * 80f - 40f;
                    float y = bossY + 30f + random.nextFloat() * 60f;
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1 : -1) * 72f, 55, false, random));
                }
                sound.playDuckFly();
            }

            attackClock += dt;
            if (attackClock >= 6.5f) {
                attackClock = 0f;
                damagePlayer(8);
                sound.playQuack();
            }
        }

        private void beginEndermanPhase() {
            if (finalBossPhase) return;
            finalBossPhase = true;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderHp = 2000f;
            ammo = Integer.MAX_VALUE;
            magazineAmmo = doubleBarrelActive ? magazineSize : Integer.MAX_VALUE;
            reloading = false;
            treesBroken = true;
            ducks.clear();
            sound.playMonsterImpact();
        }

        private void updateEnderman(float dt) {
            finalPhaseElapsed += dt;
            emergeOffset = Math.max(0f, 210f - finalPhaseElapsed * 105f);
            if (finalPhaseElapsed > 2.3f) {
                enderWalkPhase += dt;
                bossX += bossDirection * 72f * dt;
                if (bossX < 155f) bossDirection = 1f;
                if (bossX > 805f) bossDirection = -1f;
                enderTeleportClock -= dt;
                if (enderTeleportClock <= 0f) {
                    bossX = 150f + random.nextFloat() * 660f;
                    bossDirection = random.nextBoolean() ? 1f : -1f;
                    enderTeleportClock = 7f + random.nextFloat() * 4f;
                    enderTeleportFlash = 0.55f;
                    sound.playMonsterImpact();
                }
                if (enderTeleportFlash > 0f) enderTeleportFlash = Math.max(0f, enderTeleportFlash - dt);
                finalAttackClock += dt;
                if (finalAttackClock >= 2.7f) {
                    finalAttackClock = 0f;
                    damagePlayer(50);
                    sound.playMonsterImpact();
                }
            }
        }

        private void updateDog(float dt) {
            if (dogState == 0 && !fetchQueue.isEmpty()) {
                dogTargetX = fetchQueue.peek().x;
                dogState = 1;
                dogCarryCount = 0;
                dogCarrying = false;
            }
            if (dogState == 1) {
                dogX = moveTowards(dogX, dogTargetX, 240f * dt);
                if (Math.abs(dogX - dogTargetX) < 3f) {
                    if (!fetchQueue.isEmpty()) {
                        FetchJob collected = fetchQueue.remove();
                        fallenDucks.remove(collected.duck);
                    }
                    dogCarryCount++;
                    dogCarrying = true;
                    if (dogCarryCount < dogCarryLimit && !fetchQueue.isEmpty()) {
                        dogTargetX = fetchQueue.peek().x;
                    } else {
                        dogState = 2;
                    }
                }
            } else if (dogState == 2) {
                dogX = moveTowards(dogX, 850f, 265f * dt);
                if (dogX >= 847f) {
                    basketCount += dogCarryCount;
                    duckInventory += dogCarryCount;
                    dogCarryCount = 0;
                    dogState = 0;
                    dogCarrying = false;
                    sound.playDogBark();
                }
            }
        }

        private float moveTowards(float current, float target, float step) {
            if (current < target) return Math.min(target, current + step);
            return Math.max(target, current - step);
        }

        private void damagePlayer(int amount) {
            // Keep fractional health so +20% is exact even for 1-damage enemies.
            float amplifiedDamage = amount * 1.20f;
            playerHp = Math.max(0f, playerHp - amplifiedDamage);
            playerDamageFlash = 0.3f;
            if (playerHp <= 0) failGame("Охотник выбыл!");
        }

        private void sellDucks() {
            if (duckInventory <= 0 || saleCompleteAtMs > 0L) return;
            saleQuantity = duckInventory;
            duckInventory = 0;
            saleCompleteAtMs = System.currentTimeMillis() + 30_000L;
        }

        private void buyAmmo(int amount) {
            long now = System.currentTimeMillis();
            int cost = amount * 2;
            if (gold < cost) return;
            if (amount == 10) {
                if (purchase10CompleteAtMs > now) return;
                gold -= cost;
                purchase10MidLevel = shopMidLevel;
                purchase10CompleteAtMs = now + 60_000L;
            } else if (amount == 25) {
                if (purchase25CompleteAtMs > now) return;
                gold -= cost;
                purchase25MidLevel = shopMidLevel;
                purchase25CompleteAtMs = now + 60_000L;
            }
        }

        private void updateBackgroundTransactions() {
            long now = System.currentTimeMillis();
            if (saleCompleteAtMs > 0L && now >= saleCompleteAtMs) {
                gold += saleQuantity * 10;
                saleQuantity = 0;
                saleCompleteAtMs = 0L;
            }
            if (purchase10CompleteAtMs > 0L && now >= purchase10CompleteAtMs) {
                if (purchase10MidLevel) ammo += 10;
                else purchasedAmmo += 10;
                purchase10CompleteAtMs = 0L;
            }
            if (purchase25CompleteAtMs > 0L && now >= purchase25CompleteAtMs) {
                if (purchase25MidLevel) ammo += 25;
                else purchasedAmmo += 25;
                purchase25CompleteAtMs = 0L;
            }
        }

        private int secondsRemaining(long completeAt) {
            if (completeAt <= 0L) return 0;
            return Math.max(0, (int) Math.ceil((completeAt - System.currentTimeMillis()) / 1000.0));
        }

        private void buyDoubleBarrelOrSelect() {
            if (!doubleBarrelOwned) {
                if (gold < 150) return;
                gold -= 150;
                doubleBarrelOwned = true;
            }
            doubleBarrelActive = !doubleBarrelActive;
            magazineSize = doubleBarrelActive ? 2 : 5;
            magazineAmmo = 0;
            reloading = false;
            reloadTimer = 0f;
        }

        private void upgradeDog() {
            if (dogCarryLimit >= 5 || gold < 100) return;
            gold -= 100;
            dogCarryLimit = 5;
        }

        private void beginReload() {
            if (reloading || ammo <= 0) return;
            reloading = true;
            reloadTimer = doubleBarrelActive ? 12f : 5f;
        }

        private void updateBloodParticles(float dt) {
            Iterator<BloodParticle> iterator = bloodParticles.iterator();
            while (iterator.hasNext()) {
                BloodParticle particle = iterator.next();
                particle.life -= dt;
                particle.x += particle.vx * dt;
                particle.y += particle.vy * dt;
                particle.vy += 115f * dt;
                if (particle.life <= 0f) iterator.remove();
            }
        }

        private void spawnBlood(float x, float y) {
            for (int i = 0; i < 9; i++) {
                float angle = random.nextFloat() * 6.28318f;
                float speed = 18f + random.nextFloat() * 68f;
                bloodParticles.add(new BloodParticle(x, y,
                        (float) Math.cos(angle) * speed,
                        (float) Math.sin(angle) * speed - 22f));
            }
        }

        private void resetProgress() {
            gold = 0;
            basketCount = 0;
            duckInventory = 0;
            purchasedAmmo = 0;
            dogCarryLimit = 3;
            doubleBarrelOwned = false;
            doubleBarrelActive = false;
            ammo = 0;
            magazineAmmo = 5;
            magazineSize = 5;
            reloading = false;
            reloadTimer = 0f;
            saleCompleteAtMs = 0L;
            saleQuantity = 0;
            purchase10CompleteAtMs = 0L;
            purchase25CompleteAtMs = 0L;
            extraLevel = 1;
            level = 1;
            kills = 0;
            requiredKills = 0;
            playerHp = 100;
            maxHp = 100;
            dogState = 0;
            dogCarryCount = 0;
            dogCarrying = false;
            dogX = 135f;
            confirmReset = false;
            ducks.clear();
            fallenDucks.clear();
            bloodParticles.clear();
            fetchQueue.clear();
            state = State.MENU;
            lastFrame = SystemClock.uptimeMillis();
        }

        private void leaveShop() {
            if (purchase10CompleteAtMs > System.currentTimeMillis() || purchase25CompleteAtMs > System.currentTimeMillis()) return;
            if (shopMidLevel) {
                if (ammo > 0) {
                    shopMidLevel = false;
                    state = State.PLAYING;
                    lastFrame = SystemClock.uptimeMillis();
                }
            } else {
                int target = shopNextLevel;
                shopMidLevel = false;
                startLevel(target);
            }
        }

        private void clearLevel() {
            if (state == State.PLAYING) state = State.LEVEL_CLEAR;
        }

        private void failGame(String reason) {
            failureReason = reason;
            state = State.GAME_OVER;
        }

        private void shoot(float x, float y) {
            if (state != State.PLAYING || reloading) return;
            if (level == 5 && finalBossPhase) {
                if (enderHp <= 0f) return;
                if (doubleBarrelActive && magazineAmmo <= 0) {
                    beginReload();
                    return;
                }
            } else if (ammo <= 0 || magazineAmmo <= 0) {
                beginReload();
                return;
            }

            if (level == 5 && finalBossPhase) {
                if (doubleBarrelActive) magazineAmmo--;
            } else {
                ammo--;
                magazineAmmo--;
            }
            final int shotDamage = doubleBarrelActive ? 150 : 10;
            muzzleFlash = 0.11f;
            weaponRecoil = 1f;
            crosshairX = x;
            crosshairY = y;
            crosshairTimer = 0.7f;
            sound.playShot();

            if (extraMode) {
                if (distance(x, y, bossX, bossY) < 108f) {
                    extraBossHp = Math.max(0f, extraBossHp - shotDamage);
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (extraBossHp <= 0f) clearLevel();
                    if (magazineAmmo <= 0 && ammo > 0) beginReload();
                    return;
                }
            }

            if (level == 5 && finalBossPhase) {
                if (pointInEnderman(x, y)) {
                    enderHp = Math.max(0f, enderHp - (doubleBarrelActive ? 150f : 4f));
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (enderHp <= 0f) state = State.VICTORY;
                }
                if (doubleBarrelActive && magazineAmmo <= 0 && state == State.PLAYING) beginReload();
                return;
            }

            if (!extraMode && level == 3 && distance(x, y, bossX, bossY) < 92f) {
                bossDuckHp = Math.max(0f, bossDuckHp - shotDamage);
                bossDamageFlash = 0.14f;
                sound.playQuack();
                if (bossDuckHp <= 0f) clearLevel();
                if (magazineAmmo <= 0 && ammo > 0) beginReload();
                if (ammo <= 0 && state == State.PLAYING) failGame("Патроны закончились!");
                return;
            }

            Duck hit = null;
            float nearest = Float.MAX_VALUE;
            for (Duck duck : ducks) {
                if (isHidden(duck)) continue;
                float d = distance(x, y, duck.x, duck.y);
                if (d < 33f && d < nearest) {
                    nearest = d;
                    hit = duck;
                }
            }

            if (hit != null) {
                hit.hp -= shotDamage;
                if (hit.hp <= 0) {
                    ducks.remove(hit);
                    kills++;
                    fallenDucks.add(new FallenDuck(hit.x, hit.y, random));
                    spawnBlood(hit.x, hit.y);
                    sound.playQuack();
                }
            }

            if (magazineAmmo <= 0 && ammo > 0) beginReload();
            if (!extraMode && (level == 1 || level == 2 || level == 3 || level == 4) && ammo <= 0 && state == State.PLAYING) {
                boolean objectiveAlreadyMet = (level == 1 || level == 2) && kills >= requiredKills;
                objectiveAlreadyMet = objectiveAlreadyMet || (level == 4 && waveIndex >= 5 && ducks.isEmpty());
                boolean canStillProgress = level == 4 && waveIndex < 5;
                if (!objectiveAlreadyMet && !canStillProgress) failGame("Патроны закончились!");
            }
        }

        private boolean pointInEnderman(float x, float y) {
            float left = bossX - 106f;
            float right = bossX + 106f;
            float top = 115f + emergeOffset;
            float bottom = 465f;
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private boolean isHidden(Duck duck) {
            if (treesBroken) return false;
            for (float tx : treeX) {
                if (Math.abs(duck.x - tx) < 52f && duck.y > 118f && duck.y < 275f) return true;
            }
            return false;
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN) return true;
            float x = (event.getX() - gameOffsetX) / Math.max(0.001f, gameScaleX);
            float y = (event.getY() - gameOffsetY) / Math.max(0.001f, gameScaleY);
            if (x < 0 || x > WORLD_W || y < 0 || y > WORLD_H) return true;
            pressedButtonX = x;
            pressedButtonY = y;
            buttonFlashTimer = 0.18f;
            if (confirmReset) {
                if (inside(x, y, 310, 300, 470, 370)) resetProgress();
                else if (inside(x, y, 490, 300, 650, 370)) confirmReset = false;
                invalidate();
                return true;
            }

            switch (state) {
                case MENU:
                    if (inside(x, y, 250, 255, 710, 320)) startNewGame();
                    else if (inside(x, y, 250, 330, 710, 395)) startExtraGame();
                    else if (inside(x, y, 320, 420, 640, 478)) confirmReset = true;
                    break;
                case SHOP:
                    if (inside(x, y, 70, 260, 330, 330)) buyAmmo(10);
                    else if (inside(x, y, 565, 260, 835, 330)) buyAmmo(25);
                    else if (inside(x, y, 70, 350, 445, 415)) buyDoubleBarrelOrSelect();
                    else if (inside(x, y, 460, 350, 835, 415)) upgradeDog();
                    else if (inside(x, y, 330, 435, 630, 500)) leaveShop();
                    else if (shopMidLevel && inside(x, y, 70, 435, 300, 500)) sellDucks();
                    else if (!shopMidLevel && inside(x, y, 70, 435, 300, 500)) state = State.MENU;
                    break;
                case PLAYING:
                    if (inside(x, y, 825, 10, 890, 70)) {
                        state = State.PAUSED;
                    } else if (inside(x, y, 895, 10, 950, 70)) {
                        soundOn = !soundOn;
                        sound.setEnabled(soundOn);
                    } else if (extraMode && inside(x, y, 725, 12, 815, 68)) {
                        openAmmoShop();
                    } else if ((duckInventory > 0 || saleCompleteAtMs > 0L) && inside(x, y, 700, 78, 815, 120)) {
                        sellDucks();
                    } else {
                        shoot(x, y);
                    }
                    break;
                case PAUSED:
                    if (inside(x, y, 330, 330, 630, 410)) state = State.PLAYING;
                    else if (inside(x, y, 330, 415, 630, 485)) state = State.MENU;
                    break;
                case LEVEL_CLEAR:
                    if (inside(x, y, 330, 350, 630, 430)) {
                        if (extraMode) {
                            if (extraLevel < 30) openShop(extraLevel + 1);
                            else state = State.VICTORY;
                        } else if (level < 5) {
                            openShop(level + 1);
                        } else state = State.VICTORY;
                    }
                    break;
                case GAME_OVER:
                    if (inside(x, y, 330, 360, 630, 440)) startNewGame();
                    else if (inside(x, y, 330, 445, 630, 510)) state = State.MENU;
                    break;
                case VICTORY:
                    if (inside(x, y, 330, 360, 630, 445)) startNewGame();
                    else state = State.MENU;
                    break;
            }
            invalidate();
            return true;
        }

        private boolean inside(float x, float y, float left, float top, float right, float bottom) {
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private void drawWorld(Canvas canvas) {
            boolean night = level == 5 && finalBossPhase;
            drawBackground(canvas, night);
            if (extraMode && state != State.MENU) drawExtraMapLandmarks(canvas);

            for (Duck duck : ducks) drawDuck(canvas, duck, false);
            for (FallenDuck duck : fallenDucks) drawFallenDuck(canvas, duck);
            drawBloodParticles(canvas);
            drawWeather(canvas);
            if (extraMode && state != State.MENU && extraBossHp > 0f) drawExtraBoss(canvas);
            if (!extraMode && level == 3 && state != State.MENU) drawLargeDuck(canvas);

            if (!treesBroken) {
                for (float tx : treeX) drawTree(canvas, tx);
            } else {
                drawBrokenForest(canvas);
            }

            if (level == 5 && finalBossPhase) drawEnderman(canvas);
            drawHunter(canvas);
            drawBasket(canvas);
            drawDog(canvas);
            drawGroundDetails(canvas);
        }

        private void drawBackground(Canvas canvas, boolean night) {
            int[] skies = {SKY_DAY, Color.rgb(117, 167, 201), Color.rgb(193, 144, 99), Color.rgb(102, 115, 149), Color.rgb(88, 155, 137)};
            int[] grasses = {GRASS, Color.rgb(82, 126, 74), Color.rgb(141, 108, 61), Color.rgb(75, 88, 118), Color.rgb(48, 120, 102)};
            int sky = night ? Color.rgb(22, 18, 43) : (extraMode ? skies[mapTheme] : SKY_DAY);
            canvas.drawColor(sky);

            if (!night) {
                fillCircle(canvas, 820, 82, 38, Color.rgb(255, 221, 113));
                fillCircle(canvas, 810, 72, 34, Color.rgb(255, 235, 157));
                drawCloud(canvas, 150 + (float) Math.sin(menuAnim * 0.16f) * 14f, 83);
                drawCloud(canvas, 560 + (float) Math.sin(menuAnim * 0.12f) * 18f, 112);
            } else {
                fillCircle(canvas, 820, 105, 20, Color.rgb(125, 112, 170));
                for (int i = 0; i < 24; i++) {
                    float sx = (i * 137) % 950;
                    float sy = 25 + (i * 53) % 190;
                    fillRect(canvas, sx, sy, sx + 3, sy + 3, Color.rgb(213, 211, 245));
                }
            }

            int ground = night ? Color.rgb(40, 65, 44) : (extraMode ? grasses[mapTheme] : GRASS);
            fillRect(canvas, 0, 245, 960, 540, ground);
            fillRect(canvas, 0, 280, 960, 540, night ? Color.rgb(29, 54, 38) : (extraMode ? darken(grasses[mapTheme], 0.78f) : Color.rgb(63, 126, 56)));
            // Distant pine silhouettes make the forest continuous.
            for (int i = 0; i < 13; i++) {
                float x = i * 82f - 20f;
                drawPine(canvas, x, 245, 0.78f, night ? Color.rgb(23, 54, 43) : Color.rgb(50, 104, 59));
            }
            for (int i = 0; i < 22; i++) {
                float x = (i * 47f + 13f) % 960f;
                float y = 300 + (i % 4) * 28;
                fillRect(canvas, x, y, x + 3, y + 11, night ? Color.rgb(70, 107, 51) : Color.rgb(104, 162, 65));
            }

            if (night) {
                // Red-orange horizon after the sudden sunset.
                fillRect(canvas, 0, 235, 960, 248, Color.rgb(93, 43, 59));
                fillRect(canvas, 0, 248, 960, 257, Color.rgb(60, 43, 62));
            }
        }

        private void drawExtraMapLandmarks(Canvas canvas) {
            // Five distinct layouts, not just palette swaps: swamp, quarry, ruins,
            // crystal grove and the default deep forest.
            if (mapTheme == 1) {
                // Swamp: water channels, lily pads and reed clusters.
                fillOval(canvas, 35, 378, 310, 472, Color.rgb(42, 86, 76));
                fillOval(canvas, 590, 390, 925, 486, Color.rgb(38, 77, 71));
                for (int i = 0; i < 8; i++) {
                    float x = 70 + i * 28f;
                    fillOval(canvas, x, 400 + (i % 3) * 17, x + 23, 409 + (i % 3) * 17, Color.rgb(109, 151, 75));
                    paint.setColor(Color.rgb(163, 179, 111)); paint.setStrokeWidth(3f);
                    canvas.drawLine(x + 9, 409 + (i % 3) * 17, x + 5, 374 + (i % 3) * 17, paint);
                }
                for (int i = 0; i < 7; i++) {
                    float x = 620 + i * 37f;
                    paint.setColor(Color.rgb(158, 171, 101)); paint.setStrokeWidth(3f);
                    canvas.drawLine(x, 438, x - 9, 390 - (i % 3) * 10, paint);
                    canvas.drawLine(x + 3, 438, x + 13, 397 - (i % 2) * 13, paint);
                }
            } else if (mapTheme == 2) {
                // Rocky ravine: high rock walls and scattered boulders.
                fillRect(canvas, 0, 224, 72, 416, Color.rgb(88, 78, 68));
                fillRect(canvas, 888, 210, 960, 426, Color.rgb(84, 75, 67));
                for (int i = 0; i < 6; i++) {
                    float y = 250 + i * 27f;
                    fillRect(canvas, 0, y, 45 + (i % 3) * 8, y + 12, Color.rgb(124, 108, 89));
                    fillRect(canvas, 915 - (i % 3) * 8, y + 5, 960, y + 18, Color.rgb(119, 101, 83));
                }
                fillOval(canvas, 130, 422, 245, 480, Color.rgb(112, 101, 86));
                fillOval(canvas, 720, 430, 855, 485, Color.rgb(102, 91, 78));
                fillOval(canvas, 410, 446, 500, 481, Color.rgb(126, 113, 92));
            } else if (mapTheme == 3) {
                // Ancient ruins: broken columns and a stone arch across the back.
                int stone = Color.rgb(131, 126, 105);
                fillRect(canvas, 90, 204, 126, 381, stone);
                fillRect(canvas, 77, 194, 139, 211, Color.rgb(163, 154, 126));
                fillRect(canvas, 81, 376, 135, 390, Color.rgb(97, 96, 83));
                fillRect(canvas, 807, 184, 844, 389, stone);
                fillRect(canvas, 795, 174, 856, 191, Color.rgb(163, 154, 126));
                fillRect(canvas, 790, 385, 861, 399, Color.rgb(97, 96, 83));
                fillRect(canvas, 116, 206, 821, 220, Color.rgb(105, 105, 92));
                fillRect(canvas, 116, 220, 130, 253, Color.rgb(105, 105, 92));
                fillRect(canvas, 806, 220, 821, 251, Color.rgb(105, 105, 92));
                fillRect(canvas, 306, 411, 361, 427, Color.rgb(135, 128, 108));
                fillRect(canvas, 590, 430, 651, 446, Color.rgb(135, 128, 108));
            } else if (mapTheme == 4) {
                // Crystal grove: large faceted crystal clusters and glowing cores.
                int[] crystal = {Color.rgb(75, 210, 205), Color.rgb(148, 116, 232), Color.rgb(86, 174, 239)};
                for (int i = 0; i < 6; i++) {
                    float x = 65 + i * 165f;
                    float base = 456 - (i % 2) * 18f;
                    paint.setColor(crystal[i % crystal.length]); paint.setStrokeWidth(7f); paint.setStrokeCap(Paint.Cap.SQUARE);
                    canvas.drawLine(x, base, x + 16, base - 86 - (i % 3) * 17, paint);
                    canvas.drawLine(x + 16, base - 86 - (i % 3) * 17, x + 34, base, paint);
                    canvas.drawLine(x + 16, base - 86 - (i % 3) * 17, x + 16, base, paint);
                    fillCircle(canvas, x + 16, base - 38, 5, Color.rgb(193, 246, 255));
                }
            }
        }

        private int darken(int color, float factor) {
            return Color.rgb((int) (Color.red(color) * factor),
                    (int) (Color.green(color) * factor), (int) (Color.blue(color) * factor));
        }

        private String weatherName() {
            switch (weatherType) {
                case 1: return "ДОЖДЬ";
                case 2: return "СНЕГ";
                case 3: return "ТУМАН";
                default: return "ЯСНО";
            }
        }

        private void drawWeather(Canvas canvas) {
            if (weatherType == 1) {
                paint.setColor(Color.argb((int) (90 * weatherIntensity), 190, 218, 238));
                paint.setStrokeWidth(1.4f);
                for (int i = 0; i < 90; i++) {
                    float x = (i * 83f + menuAnim * (125f + i % 4 * 17f)) % WORLD_W;
                    float y = (i * 47f + menuAnim * 250f) % 500f;
                    canvas.drawLine(x, y, x - 8, y + 22, paint);
                }
            } else if (weatherType == 2) {
                for (int i = 0; i < 65; i++) {
                    float x = (i * 137f + (float) Math.sin(menuAnim * 0.7f + i) * 16f) % WORLD_W;
                    float y = (i * 61f + menuAnim * (22f + i % 5 * 5f)) % WORLD_H;
                    fillCircle(canvas, x, y, 1.5f + (i % 3) * 0.7f, Color.rgb(240, 246, 245));
                }
            } else if (weatherType == 3) {
                int alpha = (int) (25 + weatherIntensity * 35);
                fillRect(canvas, 0, 230, WORLD_W, 330, Color.argb(alpha, 218, 224, 214));
                fillRect(canvas, 0, 360, WORLD_W, 450, Color.argb(alpha / 2, 218, 224, 214));
            }
        }

        private void drawBloodParticles(Canvas canvas) {
            for (BloodParticle particle : bloodParticles) {
                int alpha = (int) (220f * Math.min(1f, particle.life));
                fillCircle(canvas, particle.x, particle.y, 2.2f + particle.life * 1.5f,
                        Color.argb(alpha, 135, 22, 27));
            }
        }

        private void drawCloud(Canvas canvas, float x, float y) {
            int c = Color.rgb(222, 239, 226);
            fillRect(canvas, x, y, x + 82, y + 20, c);
            fillRect(canvas, x + 15, y - 13, x + 50, y + 22, c);
            fillRect(canvas, x + 45, y - 6, x + 73, y + 18, c);
        }

        private void drawPine(Canvas canvas, float x, float ground, float scale, int color) {
            float h = 100 * scale;
            fillRect(canvas, x - 4 * scale, ground - 15 * scale, x + 4 * scale, ground, Color.rgb(91, 65, 42));
            fillRect(canvas, x - 23 * scale, ground - h * 0.57f, x, ground - h * 0.18f, color);
            fillRect(canvas, x - 12 * scale, ground - h, x + 18 * scale, ground - h * 0.45f, color);
            fillRect(canvas, x, ground - h * 0.67f, x + 27 * scale, ground - h * 0.2f, color);
        }

        private void drawTree(Canvas canvas, float x) {
            // Tree trunks and crowns are anchored; wind does not bend the trunk.
            int trunk = Color.rgb(104, 72, 44);
            int leaf1 = Color.rgb(27, 91, 47);
            int leaf2 = Color.rgb(39, 119, 55);
            int leaf3 = Color.rgb(56, 139, 62);
            fillRect(canvas, x - 11, 200, x + 12, 465, trunk);
            fillRect(canvas, x - 6, 205, x - 1, 440, Color.rgb(135, 91, 52));
            fillRect(canvas, x - 53, 178, x + 48, 232, leaf1);
            fillRect(canvas, x - 40, 143, x + 35, 207, leaf2);
            fillRect(canvas, x - 20, 125, x + 24, 178, leaf3);
            fillRect(canvas, x - 63, 205, x - 39, 225, leaf2);
            fillRect(canvas, x + 32, 196, x + 60, 220, leaf2);
            fillRect(canvas, x - 25, 154, x - 5, 174, Color.rgb(77, 157, 67));
        }

        private void drawBrokenForest(Canvas canvas) {
            int log = Color.rgb(91, 58, 42);
            int logLight = Color.rgb(137, 91, 53);
            for (int i = 0; i < treeX.length; i++) {
                float x = treeX[i];
                fillRect(canvas, x - 75, 408 + (i % 2) * 8, x + 65, 427 + (i % 2) * 8, log);
                fillRect(canvas, x - 52, 408 + (i % 2) * 8, x + 44, 414 + (i % 2) * 8, logLight);
                fillRect(canvas, x + 42, 399, x + 65, 414, Color.rgb(38, 105, 47));
                fillRect(canvas, x - 86, 421, x - 65, 438, Color.rgb(38, 105, 47));
            }
        }

        private void drawDuck(Canvas canvas, Duck duck, boolean boss) {
            canvas.save();
            float flap = (float) Math.sin(duck.age * 10f + duck.phase) * 5f;
            canvas.translate(duck.x, duck.y);
            float perspective = 0.68f + Math.max(0f, Math.min(1f, (duck.y - 85f) / 330f)) * 0.48f;
            float scale = (boss ? 1.75f : 1f) * perspective;
            canvas.scale(scale, scale);
            int body = boss ? Color.rgb(75, 116, 43) : Color.rgb(238, 237, 211);
            int wing = boss ? Color.rgb(49, 82, 36) : Color.rgb(179, 190, 162);
            if (!boss && extraMode && duck.archetype == 1) {
                // Razor crow: narrow black body, swept wings and hooked beak.
                body = Color.rgb(37, 43, 52); wing = Color.rgb(88, 104, 125);
                fillOval(canvas, -28, -7, 24, 13, body);
                fillRect(canvas, -18, -21 + flap, 18, -4 + flap, wing);
                fillCircle(canvas, 17, -15, 9, body);
                fillRect(canvas, 23, -16, 39, -11, Color.rgb(235, 150, 47));
                fillCircle(canvas, 19, -18, 2, Color.rgb(247, 70, 56));
                fillRect(canvas, -25, 6, -12, 10, body);
                fillRect(canvas, 2, 12, 10, 17, Color.rgb(180, 123, 48));
            } else if (!boss && extraMode && duck.archetype == 2) {
                // Armoured marsh drake: plated shell and dorsal spikes.
                body = Color.rgb(73, 115, 98); wing = Color.rgb(157, 178, 144);
                fillOval(canvas, -30, -13, 28, 18, body);
                fillRect(canvas, -23, -21 + flap, 18, -4 + flap, wing);
                fillCircle(canvas, 18, -19, 12, body);
                fillRect(canvas, 26, -19, 40, -12, Color.rgb(216, 128, 45));
                for (int k = 0; k < 4; k++) fillRect(canvas, -20 + k * 11, -20, -14 + k * 11, -29, Color.rgb(210, 218, 190));
                fillRect(canvas, 13, -23, 16, -20, Color.BLACK);
                fillRect(canvas, -17, 14, -5, 19, Color.rgb(229, 164, 55));
            } else if (!boss && extraMode && duck.archetype == 3) {
                // Bog crawler bird: low body, long legs and luminous eyes.
                body = Color.rgb(84, 95, 44); wing = Color.rgb(133, 151, 58);
                fillOval(canvas, -28, -4, 25, 19, body);
                fillOval(canvas, -13, -13 + flap, 15, 8 + flap, wing);
                fillCircle(canvas, 17, -15, 10, body);
                fillRect(canvas, 23, -14, 35, -8, Color.rgb(226, 125, 41));
                fillRect(canvas, 13, -19, 17, -15, Color.rgb(250, 229, 92));
                fillRect(canvas, -20, 13, -16, 28, body);
                fillRect(canvas, 9, 13, 13, 28, body);
            } else {
                fillOval(canvas, -25, -8, 23, 18, body);
                fillOval(canvas, -12, -10 + flap, 11, 10 + flap, wing);
                fillCircle(canvas, 16, -16, 11, body);
                fillRect(canvas, 23, -16, 36, -8, Color.rgb(236, 163, 49));
                fillRect(canvas, 12, -21, 15, -18, Color.BLACK);
                fillRect(canvas, -22, 1, -28, -9, wing);
                fillRect(canvas, -18, 14, -8, 17, Color.rgb(224, 157, 46));
                fillRect(canvas, 5, 14, 15, 17, Color.rgb(224, 157, 46));
            }
            canvas.restore();

            if (!extraMode && level == 3 && !boss && duck.hp > 0 && duck.hp < duck.maxHp) {
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x + 20, duck.y - 24, Color.rgb(50, 45, 41));
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x - 20 + 40f * duck.hp / duck.maxHp, duck.y - 24, Color.rgb(237, 76, 65));
            }
        }

        private void drawFallenDuck(Canvas canvas, FallenDuck duck) {
            canvas.save();
            canvas.rotate(duck.rotation, duck.x, duck.y);
            canvas.translate(duck.x, duck.y);
            fillOval(canvas, -24, -7, 22, 13, Color.rgb(238, 237, 211));
            fillOval(canvas, -10, -9, 12, 7, Color.rgb(179, 190, 162));
            fillCircle(canvas, 15, -13, 9, Color.rgb(238, 237, 211));
            fillRect(canvas, 22, -13, 34, -6, Color.rgb(236, 163, 49));
            fillRect(canvas, 11, -18, 14, -15, Color.BLACK);
            fillRect(canvas, -16, 11, -7, 14, Color.rgb(224, 157, 46));
            fillRect(canvas, 5, 11, 14, 14, Color.rgb(224, 157, 46));
            canvas.restore();
        }

        private void drawExtraBoss(Canvas canvas) {
            float x = bossX;
            float y = bossY;
            int body = bossDamageFlash > 0 ? Color.WHITE : new int[]{
                    Color.rgb(112, 58, 42), Color.rgb(72, 83, 105),
                    Color.rgb(68, 105, 62), Color.rgb(93, 53, 124)
            }[extraBossType];
            float pulse = (float) Math.sin(menuAnim * 4f) * 4f;
            if (extraBossType == 0) {
                // Root boar: bulky quadruped, tusks, snout and heavy legs.
                fillOval(canvas, x - 90, y - 28 + pulse, x + 82, y + 58 + pulse, body);
                fillCircle(canvas, x + 63, y - 13 + pulse, 35, body);
                fillCircle(canvas, x + 80, y + 4 + pulse, 14, Color.rgb(181, 105, 75));
                fillRect(canvas, x + 48, y + 14 + pulse, x + 58, y + 42 + pulse, Color.rgb(236, 215, 177));
                fillRect(canvas, x + 83, y + 12 + pulse, x + 91, y + 35 + pulse, Color.rgb(236, 215, 177));
                for (int leg = -1; leg <= 1; leg += 2) fillRect(canvas, x + leg * 54, y + 40 + pulse, x + leg * 43, y + 79 + pulse, body);
                fillRect(canvas, x + 55, y - 20 + pulse, x + 64, y - 12 + pulse, Color.rgb(255, 230, 130));
            } else if (extraBossType == 1) {
                // Iron sentinel: squared armour, shoulder blocks and visor.
                fillRect(canvas, x - 58, y - 56 + pulse, x + 58, y + 58 + pulse, body);
                fillRect(canvas, x - 83, y - 38 + pulse, x - 54, y + 28 + pulse, Color.rgb(46, 55, 77));
                fillRect(canvas, x + 54, y - 38 + pulse, x + 83, y + 28 + pulse, Color.rgb(46, 55, 77));
                fillRect(canvas, x - 40, y - 88 + pulse, x + 40, y - 52 + pulse, body);
                fillRect(canvas, x - 28, y - 75 + pulse, x - 7, y - 66 + pulse, Color.rgb(96, 225, 246));
                fillRect(canvas, x + 7, y - 75 + pulse, x + 28, y - 66 + pulse, Color.rgb(96, 225, 246));
                fillRect(canvas, x - 30, y + 58 + pulse, x - 12, y + 85 + pulse, body);
                fillRect(canvas, x + 12, y + 58 + pulse, x + 30, y + 85 + pulse, body);
            } else if (extraBossType == 2) {
                // Thorn spider: central abdomen, eight articulated legs and fangs.
                fillOval(canvas, x - 48, y - 26 + pulse, x + 48, y + 43 + pulse, body);
                fillCircle(canvas, x, y - 34 + pulse, 29, Color.rgb(49, 70, 43));
                for (int leg = 0; leg < 4; leg++) {
                    float yy = y - 18 + leg * 17 + pulse;
                    float reach = 86 + leg * 7;
                    paint.setColor(body); paint.setStrokeWidth(9); paint.setStrokeCap(Paint.Cap.ROUND);
                    canvas.drawLine(x - 28, yy, x - reach, yy - 27 + leg * 15, paint);
                    canvas.drawLine(x + 28, yy, x + reach, yy - 27 + leg * 15, paint);
                }
                fillCircle(canvas, x - 12, y - 40 + pulse, 6, Color.rgb(255, 76, 58));
                fillCircle(canvas, x + 12, y - 40 + pulse, 6, Color.rgb(255, 76, 58));
                fillRect(canvas, x - 12, y + 23 + pulse, x - 5, y + 44 + pulse, Color.rgb(209, 224, 142));
                fillRect(canvas, x + 5, y + 23 + pulse, x + 12, y + 44 + pulse, Color.rgb(209, 224, 142));
            } else {
                // Wraith: floating tapered body, wide spectral wings and trailing tendrils.
                fillOval(canvas, x - 39, y - 64 + pulse, x + 39, y + 48 + pulse, body);
                fillCircle(canvas, x, y - 70 + pulse, 28, body);
                for (int wing = -1; wing <= 1; wing += 2) {
                    fillOval(canvas, x + wing * 75 - 28, y - 27 + pulse, x + wing * 30, y + 18 + pulse, Color.rgb(126, 82, 161));
                    fillRect(canvas, x + wing * 82 - 6, y - 9 + pulse, x + wing * 23, y + 2 + pulse, Color.rgb(158, 115, 192));
                }
                fillRect(canvas, x - 17, y - 80 + pulse, x - 6, y - 69 + pulse, Color.rgb(235, 220, 255));
                fillRect(canvas, x + 6, y - 80 + pulse, x + 17, y - 69 + pulse, Color.rgb(235, 220, 255));
                fillRect(canvas, x - 26, y + 39 + pulse, x - 13, y + 85 + pulse, body);
                fillRect(canvas, x + 11, y + 39 + pulse, x + 24, y + 85 + pulse, body);
            }
            float barW = 220f;
            fillRect(canvas, x - barW / 2, y - 78, x + barW / 2, y - 66, Color.rgb(35, 29, 35));
            fillRect(canvas, x - barW / 2 + 2, y - 76, x - barW / 2 + 2 + (barW - 4) * extraBossHp / extraBossMaxHp,
                    y - 68, Color.rgb(225, 75, 64));
            String[] bossNames = {"КОРНЕВОЙ ВЕПРЬ", "ЖЕЛЕЗНЫЙ СТРАЖ", "ШИПАСТЫЙ ПАУК", "ПРИЗРАК ТРЯСИНЫ"};
            drawText(canvas, bossNames[extraBossType] + " • " + (int) extraBossHp + "/" + (int) extraBossMaxHp, x, y - 102, 11, GOLD, Paint.Align.CENTER);
        }

        private void drawLargeDuck(Canvas canvas) {
            Duck boss = new Duck(bossX, bossY, 0, 120, false, random);
            boss.phase = levelElapsed * 3f;
            boss.age = levelElapsed;
            drawDuck(canvas, boss, true);
            float barW = 190f;
            fillRect(canvas, bossX - barW / 2, bossY - 68, bossX + barW / 2, bossY - 56, Color.rgb(48, 39, 35));
            fillRect(canvas, bossX - barW / 2 + 2, bossY - 66,
                    bossX - barW / 2 + 2 + (barW - 4) * bossDuckHp / 120f,
                    bossY - 58, Color.rgb(232, 74, 61));
            drawText(canvas, "БОЛЬШАЯ УТКА", bossX, bossY - 78, 12, GOLD, Paint.Align.CENTER);
        }

        private void drawEnderman(Canvas canvas) {
            float yShift = emergeOffset + (finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 4f : 0f);
            float x = bossX;
            if (enderTeleportFlash > 0f) {
                int alpha = (int) (enderTeleportFlash * 210f);
                fillCircle(canvas, x, 290, 120f * enderTeleportFlash + 20f,
                        Color.argb(alpha, 142, 63, 222));
            }
            int body = bossDamageFlash > 0 ? Color.rgb(63, 43, 92) : Color.rgb(18, 16, 25);
            int edge = Color.rgb(43, 30, 61);
            // Long arms and legs, deliberately chunky like an old console sprite.
            float gait = finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 15f : 0f;
            float strike = finalAttackClock > 2.05f ? 35f : 0f;
            fillRect(canvas, x - 73 - strike, 217 + yShift, x - 48 - strike, 385 + yShift, body);
            fillRect(canvas, x + 48 + gait, 217 + yShift, x + 73 + gait + strike, 385 + yShift, body);
            fillRect(canvas, x - 29, 185 + yShift, x + 29, 388 + yShift, body);
            fillRect(canvas, x - 46, 108 + yShift, x + 46, 213 + yShift, body);
            fillRect(canvas, x - 40, 112 + yShift, x + 40, 119 + yShift, edge);
            fillRect(canvas, x - 25 - gait, 390 + yShift, x - 3 - gait, 465, body);
            fillRect(canvas, x + 4 + gait, 390 + yShift, x + 27 + gait, 465, body);
            fillRect(canvas, x - 29, 459, x - 1, 472, Color.rgb(10, 9, 16));
            fillRect(canvas, x + 2, 459, x + 32, 472, Color.rgb(10, 9, 16));
            // Purple eyes.
            fillRect(canvas, x - 31, 151 + yShift, x - 5, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x + 6, 151 + yShift, x + 32, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x - 28, 153 + yShift, x - 9, 157 + yShift, Color.rgb(244, 185, 255));
            fillRect(canvas, x + 9, 153 + yShift, x + 29, 157 + yShift, Color.rgb(244, 185, 255));

            if (finalPhaseElapsed > 1f) {
                float barW = 240f;
                fillRect(canvas, x - barW / 2, 77, x + barW / 2, 94, Color.rgb(19, 15, 26));
                fillRect(canvas, x - barW / 2 + 3, 80,
                        x - barW / 2 + 3 + (barW - 6) * enderHp / 2000f, 91,
                        Color.rgb(170, 53, 208));
                drawText(canvas, "ЭНДЕРМЕН  " + (int) enderHp + " / 2000", x, 66, 13, CREAM, Paint.Align.CENTER);
            }
        }

        private void drawHunter(Canvas canvas) {
            // First-person view: forearms, stock and barrel frame the bottom of the screen.
            float recoil = weaponRecoil * 15f;
            float reloadTilt = reloading ? (float) Math.sin((double) (5f - reloadTimer) * 6f) * 22f : 0f;
            int sleeve = playerDamageFlash > 0 ? Color.rgb(150, 42, 43) : Color.rgb(57, 69, 80);
            fillRect(canvas, 330, 486, 424, 540, sleeve);
            fillRect(canvas, 536, 486, 630, 540, sleeve);
            fillRect(canvas, 399, 455 + recoil, 561, 525 + recoil, Color.rgb(86, 56, 35));
            canvas.save();
            canvas.rotate(reloadTilt, 480, 478);
            fillRect(canvas, 438, 426 + recoil, 522, 505 + recoil, Color.rgb(48, 45, 43));
            if (doubleBarrelActive) {
                fillRect(canvas, 456, 383 + recoil, 478, 470 + recoil, Color.rgb(76, 79, 77));
                fillRect(canvas, 482, 383 + recoil, 504, 470 + recoil, Color.rgb(76, 79, 77));
                fillRect(canvas, 459, 354 + recoil, 479, 432 + recoil, Color.rgb(111, 116, 111));
                fillRect(canvas, 481, 354 + recoil, 501, 432 + recoil, Color.rgb(111, 116, 111));
                fillRect(canvas, 461, 352 + recoil, 477, 410 + recoil, Color.rgb(35, 36, 34));
                fillRect(canvas, 483, 352 + recoil, 499, 410 + recoil, Color.rgb(35, 36, 34));
            } else {
                fillRect(canvas, 458, 383 + recoil, 502, 470 + recoil, Color.rgb(76, 79, 77));
                fillRect(canvas, 468, 354 + recoil, 492, 432 + recoil, Color.rgb(111, 116, 111));
                fillRect(canvas, 473, 352 + recoil, 487, 410 + recoil, Color.rgb(35, 36, 34));
            }
            canvas.restore();
            if (reloading) {
                float progress = 1f - reloadTimer / (doubleBarrelActive ? 12f : 5f);
                fillRect(canvas, 530, 405 - progress * 55f, 540, 425 - progress * 55f, Color.rgb(215, 178, 91));
                drawText(canvas, "ПЕРЕЗАРЯДКА", 480, 335, 11, GOLD, Paint.Align.CENTER);
            }
            // Hands around the weapon.
            fillRect(canvas, 404, 457 + recoil, 441, 490 + recoil, Color.rgb(190, 143, 108));
            fillRect(canvas, 519, 457 + recoil, 556, 490 + recoil, Color.rgb(190, 143, 108));
            if (muzzleFlash > 0f) {
                fillCircle(canvas, 480, 342 + recoil, 18f + muzzleFlash * 70f, Color.rgb(255, 238, 139));
                fillCircle(canvas, 480, 342 + recoil, 9f + muzzleFlash * 35f, Color.WHITE);
            }
        }

        private void drawDog(Canvas canvas) {
            float y = 461f;
            float step = dogState == 0 ? 0f : (float) Math.sin(menuAnim * 17f) * 4f;
            canvas.save();
            canvas.translate(dogX, y);
            // Body, head, ears, paws and tail.
            fillRect(canvas, -26, -22, 20, 2, Color.rgb(171, 112, 59));
            fillRect(canvas, 11, -34, 34, -10, Color.rgb(188, 132, 73));
            fillRect(canvas, 13, -43, 20, -30, Color.rgb(95, 55, 37));
            fillRect(canvas, 30, -24, 42, -17, Color.rgb(62, 42, 31));
            fillRect(canvas, -20, -1 + step, -12, 9 + step, Color.rgb(92, 60, 39));
            fillRect(canvas, 10, -1 - step, 18, 9 - step, Color.rgb(92, 60, 39));
            fillRect(canvas, -34, -30, -27, -20, Color.rgb(121, 76, 46));
            if (dogCarrying) {
                for (int i = 0; i < Math.max(1, dogCarryCount); i++) {
                    float ox = -18f + i * 17f;
                    fillOval(canvas, ox - 7, -48 - (i % 2) * 3, ox + 9, -33 - (i % 2) * 3, Color.rgb(239, 235, 210));
                    fillCircle(canvas, ox + 7, -47 - (i % 2) * 3, 4, Color.rgb(239, 235, 210));
                    fillRect(canvas, ox + 10, -49 - (i % 2) * 3, ox + 15, -45 - (i % 2) * 3, Color.rgb(237, 164, 52));
                }
            }
            canvas.restore();
        }

        private void drawBasket(Canvas canvas) {
            fillRect(canvas, 858, 439, 917, 491, Color.rgb(155, 94, 43));
            fillRect(canvas, 854, 434, 921, 444, Color.rgb(205, 151, 74));
            for (int i = 0; i < 4; i++) {
                fillRect(canvas, 864 + i * 14, 445, 868 + i * 14, 488, Color.rgb(205, 147, 73));
            }
            drawText(canvas, String.valueOf(basketCount), 887, 510, 16, CREAM, Paint.Align.CENTER);
        }

        private void drawGroundDetails(Canvas canvas) {
            for (int i = 0; i < 18; i++) {
                float x = (i * 59 + 21) % 960;
                float y = 505 + (i % 3) * 8;
                fillRect(canvas, x, y, x + 4, y + 9, Color.rgb(124, 178, 74));
            }
        }

        private void drawHud(Canvas canvas) {
            fillRect(canvas, 12, 10, 948, 72, PANEL);
            strokeRect(canvas, 12, 10, 948, 72, GOLD, 2);
            drawText(canvas, extraMode ? "БОНУС " + extraLevel + "/30" : "УРОВЕНЬ " + level + "/5", 28, 38, 18, GOLD, Paint.Align.LEFT);
            drawText(canvas, "HP", 203, 37, 15, CREAM, Paint.Align.LEFT);
            fillRect(canvas, 239, 23, 355, 43, Color.rgb(55, 48, 43));
            int healthColor = playerHp > maxHp * 0.35f ? Color.rgb(90, 190, 89) : Color.rgb(226, 75, 67);
            if (playerHp > 0) fillRect(canvas, 242, 26, 242 + 110f * playerHp / maxHp, 40, healthColor);
            drawText(canvas, (int) Math.ceil(playerHp) + "/" + maxHp, 367, 38, 13, CREAM, Paint.Align.LEFT);

            String ammoText = ammo == Integer.MAX_VALUE ? "∞" : String.valueOf(ammo);
            drawText(canvas, "ПАТР: " + ammoText, 445, 38, 15, CREAM, Paint.Align.LEFT);
            drawText(canvas, doubleBarrelActive ? "ДВУХСТВОЛКА" : "РУЖЬЁ", 445, 57, 10, GOLD, Paint.Align.LEFT);
            if (reloading) {
                drawText(canvas, "ПЕРЕЗАРЯДКА " + String.format(java.util.Locale.US, "%.1f", reloadTimer) + "с", 585, 38, 12, Color.rgb(255, 190, 96), Paint.Align.CENTER);
            } else {
                drawText(canvas, "МАГ: " + (magazineAmmo == Integer.MAX_VALUE ? "∞" : magazineAmmo + "/" + magazineSize), 585, 38, 12, CREAM, Paint.Align.CENTER);
            }
            if (!extraMode && (level == 1 || level == 2)) {
                int remain = Math.max(0, (int) (levelTimeLimit - levelElapsed));
                drawText(canvas, String.format(java.util.Locale.US, "%02d:%02d", remain / 60, remain % 60),
                        650, 39, 20, remain <= 20 ? Color.rgb(255, 103, 83) : GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                drawText(canvas, "ВОЛНА " + waveIndex + "/5", 645, 38, 16, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "БОСС", 650, 38, 17, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БОСС-ФИНАЛ", 650, 38, 15, GOLD, Paint.Align.CENTER);
            } else if (!extraMode) {
                drawText(canvas, "УТОК: " + kills + "/" + requiredKills, 650, 38, 15, GOLD, Paint.Align.CENTER);
            }

            if (extraMode) drawButton(canvas, 725, 16, 815, 64, "МАГАЗИН", Color.rgb(120, 83, 35));
            if (duckInventory > 0 || saleCompleteAtMs > 0L) {
                String saleLabel = saleCompleteAtMs > 0L ? "ПРОДАЖА " + secondsRemaining(saleCompleteAtMs) + "с" : "ПРОДАТЬ";
                drawButton(canvas, 700, 78, 815, 120, saleLabel, Color.rgb(133, 87, 42));
            }
            drawButton(canvas, 825, 16, 886, 64, "Ⅱ", Color.rgb(71, 83, 68));
            drawButton(canvas, 895, 16, 940, 64, soundOn ? "♪" : "×", Color.rgb(71, 83, 68));
            if (extraMode) {
                drawText(canvas, "СЛУЧАЙНАЯ КАРТА • БОСС • ЗОЛОТО: " + gold + " • " + weatherName(), 410, 98, 12, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "У большой утки " + (int) bossDuckHp + " HP. " + weatherName(), 480, 98, 13, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                String hint = waveIndex < 5 ? "Утки идут волнами. Следующая атака через 30 секунд." : "Последняя волна! Добей оставшихся уток.";
                drawText(canvas, hint, 480, 98, 13, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БЕСКОНЕЧНЫЕ ПАТРОНЫ • УРОН 4 (150 ДВУХСТВОЛКА) • УДАР 60 HP", 480, 98, 11, Color.rgb(246, 205, 255), Paint.Align.CENTER);
            }
        }

        private void drawCrosshair(Canvas canvas) {
            if (crosshairTimer <= 0f) return;
            int alpha = (int) (255 * Math.min(1f, crosshairTimer / 0.25f));
            paint.setColor(Color.argb(alpha, 255, 244, 183));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            canvas.drawCircle(crosshairX, crosshairY, 17, paint);
            canvas.drawLine(crosshairX - 27, crosshairY, crosshairX - 8, crosshairY, paint);
            canvas.drawLine(crosshairX + 8, crosshairY, crosshairX + 27, crosshairY, paint);
            canvas.drawLine(crosshairX, crosshairY - 27, crosshairX, crosshairY - 8, paint);
            canvas.drawLine(crosshairX, crosshairY + 8, crosshairX, crosshairY + 27, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawStateOverlay(Canvas canvas) {
            if (state == State.MENU) {
                overlay(canvas, 0.2f);
                panel(canvas, 165, 50, 795, 525);
                drawText(canvas, "УТИНАЯ ОХОТА", 480, 125, 39, GOLD, Paint.Align.CENTER);
                drawText(canvas, "RETRO FOREST ARCADE • FIRST PERSON", 480, 160, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Стреляй по врагам, уклоняйся от атак и собирай добычу.", 480, 205, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Пёс переносит до " + dogCarryLimit + " уток за рейс. Продажа: 10 золота за утку.", 480, 232, 13, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 250, 255, 710, 320, "ОСНОВНАЯ ИГРА • 5 УРОВНЕЙ", Color.rgb(43, 123, 65));
                drawButton(canvas, 250, 330, 710, 395, "ДОПОЛНИТЕЛЬНЫЕ УРОВНИ • 30", Color.rgb(103, 72, 137));
                drawButton(canvas, 320, 420, 640, 478, "СБРОСИТЬ ПРОГРЕСС", Color.rgb(115, 57, 52));
                if (confirmReset) {
                    overlay(canvas, 0.70f);
                    panel(canvas, 240, 205, 720, 410);
                    drawText(canvas, "СБРОСИТЬ ВЕСЬ ПРОГРЕСС?", 480, 270, 22, GOLD, Paint.Align.CENTER);
                    drawText(canvas, "Золото, улучшения и добыча будут удалены.", 480, 295, 13, CREAM, Paint.Align.CENTER);
                    drawButton(canvas, 310, 320, 470, 385, "ДА, СБРОСИТЬ", Color.rgb(130, 55, 48));
                    drawButton(canvas, 490, 320, 650, 385, "ОТМЕНА", Color.rgb(63, 96, 72));
                }
            } else if (state == State.SHOP) {
                overlay(canvas, 0.58f);
                panel(canvas, 80, 70, 880, 520);
                drawText(canvas, shopMidLevel ? "ЗАКУПКА БОЕПРИПАСОВ" : "ЛАВКА ПЕРЕД УРОВНЕМ", 480, 135, 27, GOLD, Paint.Align.CENTER);
                drawText(canvas, "Уток в корзине: " + duckInventory + "   •   Золото: " + gold + "   •   Продажа: 10 золота/утка", 480, 185, 13, CREAM, Paint.Align.CENTER);
                String shopAmmo = shopMidLevel ? String.valueOf(ammo) : String.valueOf(purchasedAmmo) + " доп.";
                drawText(canvas, "Патроны: " + shopAmmo + "   •   1 патрон = 2 золота. Заказ выполняется 60 секунд.", 480, 212, 13, CREAM, Paint.Align.CENTER);
                String tenLabel = purchase10CompleteAtMs > 0L ? "+10 ПАТРОНОВ • " + secondsRemaining(purchase10CompleteAtMs) + "с" : "+10 ПАТРОНОВ • 20 ЗОЛОТА";
                String twentyFiveLabel = purchase25CompleteAtMs > 0L ? "+25 ПАТРОНОВ • " + secondsRemaining(purchase25CompleteAtMs) + "с" : "+25 ПАТРОНОВ • 50 ЗОЛОТА";
                drawButton(canvas, 70, 260, 330, 330, tenLabel, Color.rgb(48, 105, 75));
                drawButton(canvas, 565, 260, 835, 330, twentyFiveLabel, Color.rgb(48, 105, 75));
                String weaponLabel = doubleBarrelOwned ? (doubleBarrelActive ? "ВЫБРАНА ДВУХСТВОЛКА" : "ВЫБРАТЬ ДВУХСТВОЛКУ") : "КУПИТЬ ДВУХСТВОЛКУ • 150 ЗОЛОТА";
                String dogLabel = dogCarryLimit >= 5 ? "ПЁС УЖЕ НЕСЁТ 5 УТОК" : "УЛУЧШИТЬ ПЁСА • 100 ЗОЛОТА (5 УТОК)";
                drawButton(canvas, 70, 350, 445, 415, weaponLabel, Color.rgb(104, 76, 127));
                drawButton(canvas, 460, 350, 835, 415, dogLabel, Color.rgb(112, 83, 42));
                drawButton(canvas, 330, 435, 630, 500, shopMidLevel ? "ВЕРНУТЬСЯ В УРОВЕНЬ" : "НАЧАТЬ УРОВЕНЬ", Color.rgb(43, 123, 65));
                String bottomLeftLabel = shopMidLevel
                        ? (saleCompleteAtMs > 0L ? "ПРОДАЖА " + secondsRemaining(saleCompleteAtMs) + "с" : "ПРОДАТЬ ДОБЫЧУ")
                        : "В МЕНЮ";
                drawButton(canvas, 70, 435, 300, 500, bottomLeftLabel, shopMidLevel ? Color.rgb(133, 87, 42) : Color.rgb(83, 83, 73));
            } else if (state == State.PAUSED) {
                overlay(canvas, 0.58f);
                panel(canvas, 300, 160, 660, 490);
                drawText(canvas, "ПАУЗА", 480, 230, 34, GOLD, Paint.Align.CENTER);
                drawButton(canvas, 330, 330, 630, 410, "ПРОДОЛЖИТЬ", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 415, 630, 485, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.LEVEL_CLEAR) {
                overlay(canvas, 0.48f);
                panel(canvas, 280, 150, 680, 480);
                drawText(canvas, "УРОВЕНЬ ПРОЙДЕН!", 480, 235, 31, GOLD, Paint.Align.CENTER);
                String message = extraMode ? "Босс повержен! Следующая случайная карта уже ждёт." : level == 3 ? "Большая утка побеждена!" : level == 4 ? "Все пять волн отражены!" : "Отличная охота! Пёс уже несёт добычу.";
                drawText(canvas, message, 480, 285, 14, CREAM, Paint.Align.CENTER);
                String nextLabel = extraMode ? (extraLevel < 30 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ") : (level < 5 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ");
                drawButton(canvas, 330, 350, 630, 430, nextLabel, Color.rgb(43, 123, 65));
            } else if (state == State.GAME_OVER) {
                overlay(canvas, 0.68f);
                panel(canvas, 280, 150, 680, 490);
                drawText(canvas, "ИГРА ОКОНЧЕНА", 480, 235, 31, Color.rgb(255, 112, 92), Paint.Align.CENTER);
                drawText(canvas, failureReason, 480, 285, 16, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Здоровье и патроны восстановятся при новом запуске.", 480, 315, 12, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 440, "НАЧАТЬ ЗАНОВО", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 445, 630, 510, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.VICTORY) {
                overlay(canvas, 0.58f);
                panel(canvas, 260, 140, 700, 490);
                drawText(canvas, "ПОБЕДА!", 480, 235, 42, GOLD, Paint.Align.CENTER);
                drawText(canvas, extraMode ? "Пройдены все 30 дополнительных уровней!" : "Эндермен повержен. Лес спасён, а корзина полна!", 480, 292, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Уток в корзине: " + basketCount, 480, 322, 15, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 445, "ИГРАТЬ СНОВА", Color.rgb(43, 123, 65));
            }
        }

        private void overlay(Canvas canvas, float alpha) {
            fillRect(canvas, 0, 0, WORLD_W, WORLD_H, Color.argb((int) (alpha * 255), 8, 12, 10));
        }

        private void panel(Canvas canvas, float left, float top, float right, float bottom) {
            fillRect(canvas, left, top, right, bottom, PANEL);
            strokeRect(canvas, left, top, right, bottom, GOLD, 3);
            strokeRect(canvas, left + 7, top + 7, right - 7, bottom - 7, Color.rgb(97, 105, 75), 1);
        }

        private void drawButton(Canvas canvas, float left, float top, float right, float bottom, String label, int color) {
            boolean pressed = buttonFlashTimer > 0f && inside(pressedButtonX, pressedButtonY, left, top, right, bottom);
            int face = pressed ? lighten(color, 1.28f) : color;
            float offset = pressed ? 2f : 0f;
            fillRect(canvas, left, top + offset, right, bottom + offset, face);
            strokeRect(canvas, left, top + offset, right, bottom + offset, pressed ? Color.WHITE : GOLD, pressed ? 3 : 2);
            paint.setTypeface(PIXEL);
            float maxWidth = right - left - 16f;
            float textSize = 17f;
            paint.setTextSize(textSize);
            while (paint.measureText(label) > maxWidth && textSize > 9f) {
                textSize -= 1f;
                paint.setTextSize(textSize);
            }
            drawText(canvas, label, (left + right) / 2f, (top + bottom) / 2f + 6f + offset, textSize, CREAM, Paint.Align.CENTER);
        }

        private int lighten(int color, float factor) {
            return Color.rgb(Math.min(255, (int) (Color.red(color) * factor)),
                    Math.min(255, (int) (Color.green(color) * factor)),
                    Math.min(255, (int) (Color.blue(color) * factor)));
        }

        private void fillRect(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(left, top, right, bottom, paint);
        }

        private void strokeRect(Canvas canvas, float left, float top, float right, float bottom, int color, float width) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(width);
            canvas.drawRect(left, top, right, bottom, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void fillCircle(Canvas canvas, float x, float y, float radius, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x, y, radius, paint);
        }

        private void fillOval(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawOval(new RectF(left, top, right, bottom), paint);
        }

        private void drawText(Canvas canvas, String text, float x, float baseline, float size, int color, Paint.Align align) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(PIXEL);
            paint.setTextSize(size);
            paint.setTextAlign(align);
            canvas.drawText(text, x, baseline, paint);
        }

        private static final class SoundEngine {
            private final SoundPool pool;
            private final int shot;
            private final int duckFly;
            private final int quack;
            private final int bark;
            private final int monsterImpact;
            private final int monsterHit;
            private final int ambience;
            private int ambienceStream = 0;
            private boolean enabled = true;
            private boolean ambienceLoaded = false;

            SoundEngine(Context context) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attributes).build();
                shot = pool.load(context, R.raw.gunshot, 1);
                duckFly = pool.load(context, R.raw.duck_fly, 1);
                quack = pool.load(context, R.raw.duck_quack, 1);
                bark = pool.load(context, R.raw.dog_bark, 1);
                monsterImpact = pool.load(context, R.raw.monster_hit, 1);
                monsterHit = pool.load(context, R.raw.monster_hit, 1);
                ambience = pool.load(context, R.raw.forest_ambience, 1);
                pool.setOnLoadCompleteListener((soundPool, sampleId, status) -> {
                    if (sampleId == ambience && status == 0) {
                        ambienceLoaded = true;
                        if (enabled) startAmbience();
                    }
                });
            }

            void setEnabled(boolean value) {
                enabled = value;
                if (!enabled) pauseAmbience();
                else startAmbience();
            }

            void startAmbience() {
                if (!enabled || !ambienceLoaded || ambienceStream != 0) return;
                ambienceStream = pool.play(ambience, 0.26f, 0.26f, 1, -1, 1f);
            }

            void pauseAmbience() {
                if (ambienceStream != 0) {
                    pool.stop(ambienceStream);
                    ambienceStream = 0;
                }
            }

            void resumeAmbience() { startAmbience(); }

            private void play(int id, float volume) {
                if (enabled && id != 0) pool.play(id, volume, volume, 2, 0, 1f);
            }

            void playShot() { play(shot, 0.8f); }
            void playDuckFly() { play(duckFly, 0.36f); }
            void playQuack() { play(quack, 0.55f); }
            void playDogBark() { play(bark, 0.5f); }
            void playMonsterImpact() { play(monsterImpact, 0.75f); }
            void playMonsterHit() { play(monsterHit, 0.45f); }

            void release() {
                pauseAmbience();
                pool.release();
            }
        }
    }
}
