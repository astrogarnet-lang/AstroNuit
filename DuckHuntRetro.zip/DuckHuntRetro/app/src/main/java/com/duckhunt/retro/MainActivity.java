package com.duckhunt.retro;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Duck Hunt Retro — a small, self-contained landscape arcade game.
 * All graphics are drawn with Canvas and all sound effects are bundled WAV files.
 */
public class MainActivity extends Activity {
    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        if (gameView != null) gameView.onHostPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.onHostResume();
    }

    @Override
    protected void onDestroy() {
        if (gameView != null) gameView.release();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (gameView != null) {
            gameView.handleBack();
        } else {
            super.onBackPressed();
        }
    }

    private static final class GameView extends View {
        private static final float WORLD_W = 960f;
        private static final float WORLD_H = 540f;
        private static final int SKY_DAY = Color.rgb(104, 190, 216);
        private static final int GRASS = Color.rgb(76, 139, 61);
        private static final int DARK = Color.rgb(24, 39, 30);
        private static final int PANEL = Color.rgb(24, 37, 31);
        private static final int GOLD = Color.rgb(255, 205, 75);
        private static final int CREAM = Color.rgb(248, 241, 211);
        private static final Typeface PIXEL = Typeface.create("monospace", Typeface.BOLD);

        private enum State { MENU, SHOP, PLAYING, PAUSED, LEVEL_CLEAR, GAME_OVER, VICTORY }

        private static final class Duck {
            float x;
            float y;
            float baseY;
            float vx;
            float phase;
            float age;
            int hp;
            final int maxHp;
            final boolean attacker;
            boolean attacked;
            float retreatTimer;
            float retreatVx;
            float retreatVy;
            float attackCooldown;

            Duck(float x, float y, float vx, int hp, boolean attacker, Random random) {
                this.x = x;
                this.y = y;
                this.baseY = y;
                this.vx = vx;
                this.hp = hp;
                this.maxHp = hp;
                this.attacker = attacker;
                this.phase = random.nextFloat() * 6.28f;
                this.attackCooldown = random.nextFloat() * 1.2f;
            }
        }

        private static final class FallenDuck {
            float x;
            float y;
            float vy;
            float rotation;
            float landedTime;
            boolean queued;
            final float phase;
            FallenDuck(float x, float y, Random random) {
                this.x = x;
                this.y = y;
                this.vy = -45f;
                this.phase = random.nextFloat() * 6.28f;
            }
        }

        private static final class FetchJob {
            final float x;
            final FallenDuck duck;
            FetchJob(FallenDuck duck) {
                this.duck = duck;
                this.x = Math.max(65, Math.min(825, duck.x));
            }
        }

        private final Paint paint = new Paint();
        private final Random random = new Random();
        private final List<Duck> ducks = new ArrayList<>();
        private final List<FallenDuck> fallenDucks = new ArrayList<>();
        private final ArrayDeque<FetchJob> fetchQueue = new ArrayDeque<>();
        private float[] treeX = {78f, 252f, 510f, 757f, 905f};
        private final SoundEngine sound;

        private State state = State.MENU;
        private int level = 1;
        private int playerHp = 100;
        private int maxHp = 100;
        private int ammo = 0;
        private int basketCount = 0;
        private int duckInventory = 0;
        private int gold = 0;
        private int purchasedAmmo = 0;
        private int dogCarryCount = 0;
        private int kills = 0;
        private int requiredKills = 0;
        private float levelElapsed = 0f;
        private float levelTimeLimit = 0f;
        private float bossDuckHp = 120f;
        private float enderHp = 300f;
        private float bossX = 680f;
        private float bossY = 430f;
        private float bossDirection = -1f;
        private float spawnClock = 0f;
        private float attackClock = 0f;
        private float nextWaveAt = 0f;
        private int waveIndex = 0;
        private boolean finalBossPhase = false;
        private float finalPhaseElapsed = 0f;
        private float finalAttackClock = 0f;
        private float enderTeleportClock = 7f;
        private float enderTeleportFlash = 0f;
        private float enderWalkPhase = 0f;
        private float extraBossHp = 0f;
        private float extraBossMaxHp = 0f;
        private float extraBossAttackClock = 0f;
        private float extraBossSpawnClock = 0f;
        private int extraBossType = 0;
        private int extraLevel = 1;
        private int shopNextLevel = 1;
        private boolean extraMode = false;
        private boolean shopMidLevel = false;
        private int mapTheme = 0;
        private float weaponRecoil = 0f;
        private float bossDamageFlash = 0f;
        private float playerDamageFlash = 0f;
        private float muzzleFlash = 0f;
        private float crosshairX = -100f;
        private float crosshairY = -100f;
        private float crosshairTimer = 0f;
        private float duckSoundClock = 5f;
        private float dogX = 135f;
        private float dogTargetX = 135f;
        private int dogState = 0; // 0 idle, 1 fetch, 2 return to basket
        private boolean dogCarrying = false;
        private boolean soundOn = true;
        private boolean hostPaused = false;
        private boolean treesBroken = false;
        private String failureReason = "Попробуй ещё раз!";
        private long lastFrame = 0L;
        private float menuAnim = 0f;
        private float emergeOffset = 210f;
        private float gameScale = 1f;
        private float gameOffsetX = 0f;
        private float gameOffsetY = 0f;

        GameView(Context context) {
            super(context);
            setFocusable(true);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            sound = new SoundEngine(context);
            lastFrame = SystemClock.uptimeMillis();
            paint.setTypeface(PIXEL);
            paint.setAntiAlias(false);
        }

        void onHostPause() {
            hostPaused = true;
            if (state == State.PLAYING) state = State.PAUSED;
            sound.pauseAmbience();
        }

        void onHostResume() {
            hostPaused = false;
            lastFrame = SystemClock.uptimeMillis();
            if (soundOn) sound.resumeAmbience();
            invalidate();
        }

        void release() {
            sound.release();
        }

        void handleBack() {
            if (state == State.PLAYING) {
                state = State.PAUSED;
            } else if (state == State.SHOP) {
                if (shopMidLevel && ammo > 0) state = State.PLAYING;
                else state = State.MENU;
            } else if (state == State.PAUSED) {
                state = State.PLAYING;
            } else if (state == State.MENU) {
                // Keep the game on its title screen; Android handles the app-level back gesture.
            } else {
                state = State.MENU;
            }
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            long now = SystemClock.uptimeMillis();
            float dt = Math.min(0.05f, Math.max(0f, (now - lastFrame) / 1000f));
            lastFrame = now;

            if (state == State.PLAYING && !hostPaused) {
                updateGame(dt);
            } else {
                if (state == State.LEVEL_CLEAR || state == State.VICTORY || state == State.SHOP) {
                    updateFallenDucks(dt);
                    updateDog(dt);
                }
            }
            menuAnim += dt;

            float sx = getWidth() / WORLD_W;
            float sy = getHeight() / WORLD_H;
            gameScale = Math.min(sx, sy);
            gameOffsetX = (getWidth() - WORLD_W * gameScale) * 0.5f;
            gameOffsetY = (getHeight() - WORLD_H * gameScale) * 0.5f;

            canvas.drawColor(Color.BLACK);
            canvas.save();
            canvas.translate(gameOffsetX, gameOffsetY);
            canvas.scale(gameScale, gameScale);

            drawWorld(canvas);
            drawHud(canvas);
            drawCrosshair(canvas);
            drawStateOverlay(canvas);
            if (playerDamageFlash > 0f && state == State.PLAYING) {
                float flashAlpha = Math.min(0.42f, playerDamageFlash * 1.2f);
                fillRect(canvas, 0, 0, WORLD_W, WORLD_H,
                        Color.argb((int) (flashAlpha * 255), 230, 20, 30));
            }

            canvas.restore();
            postInvalidateDelayed(state == State.PLAYING ? 16 : 60);
        }

        private void startNewGame() {
            basketCount = 0;
            fetchQueue.clear();
            fallenDucks.clear();
            treeX = new float[]{78f, 252f, 510f, 757f, 905f};
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            duckInventory = 0;
            gold = 0;
            purchasedAmmo = 0;
            extraMode = false;
            extraLevel = 1;
            openShop(1);
        }

        private void startExtraGame() {
            basketCount = 0;
            duckInventory = 0;
            gold = 0;
            purchasedAmmo = 0;
            fetchQueue.clear();
            fallenDucks.clear();
            dogX = 135f;
            dogTargetX = 135f;
            dogState = 0;
            dogCarrying = false;
            dogCarryCount = 0;
            extraMode = true;
            extraLevel = 1;
            openShop(1);
        }

        private void openShop(int targetLevel) {
            shopNextLevel = targetLevel;
            shopMidLevel = false;
            state = State.SHOP;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void openAmmoShop() {
            if (!extraMode || state != State.PLAYING) return;
            shopMidLevel = true;
            shopNextLevel = extraLevel;
            state = State.SHOP;
            lastFrame = SystemClock.uptimeMillis();
        }

        private void startLevel(int newLevel) {
            if (extraMode) {
                startExtraLevel(newLevel);
                return;
            }
            level = newLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            nextWaveAt = 0f;
            waveIndex = 0;
            finalBossPhase = false;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderTeleportClock = 7f;
            enderTeleportFlash = 0f;
            enderWalkPhase = 0f;
            treesBroken = false;
            bossDamageFlash = 0f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            emergeOffset = 210f;
            bossDuckHp = 120f;
            enderHp = 300f;
            bossX = 680f;
            bossY = 430f;
            bossDirection = -1f;
            duckSoundClock = 4f + random.nextFloat() * 3f;

            if (level <= 3) {
                maxHp = 100;
            } else {
                maxHp = 500;
            }
            playerHp = maxHp;

            switch (level) {
                case 1:
                    requiredKills = 10;
                    ammo = 65;
                    levelTimeLimit = 180f;
                    spawnFriendlyDucks(10, 1, 0.28f, 0.68f);
                    break;
                case 2:
                    requiredKills = 20;
                    ammo = 75;
                    levelTimeLimit = 240f;
                    spawnFriendlyDucks(20, 3, 0.45f, 0.9f);
                    break;
                case 3:
                    requiredKills = 20;
                    ammo = 150;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(20, 55, 0.72f, 1.12f);
                    bossDuckHp = 120f;
                    break;
                case 4:
                    requiredKills = 35;
                    ammo = 270;
                    levelTimeLimit = 0f;
                    // Five attacks/waves: the first starts immediately, the next four every 30 seconds.
                    spawnLevelFourWave();
                    break;
                case 5:
                    requiredKills = 10;
                    ammo = 50;
                    levelTimeLimit = 0f;
                    spawnFriendlyDucks(10, 1, 0.52f, 0.86f);
                    break;
                default:
                    level = 1;
                    startLevel(1);
                    return;
            }
            ammo += purchasedAmmo;
            purchasedAmmo = 0;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void startExtraLevel(int newLevel) {
            extraLevel = Math.max(1, Math.min(100, newLevel));
            level = extraLevel;
            state = State.PLAYING;
            levelElapsed = 0f;
            kills = 0;
            ducks.clear();
            spawnClock = 0f;
            attackClock = 0f;
            extraBossAttackClock = 0f;
            extraBossSpawnClock = 0f;
            extraBossHp = 120f + extraLevel * 18f;
            extraBossMaxHp = extraBossHp;
            extraBossType = random.nextInt(4);
            mapTheme = random.nextInt(5);
            treesBroken = false;
            finalBossPhase = false;
            bossX = 260f + random.nextFloat() * 440f;
            bossY = 140f + random.nextFloat() * 100f;
            bossDirection = random.nextBoolean() ? 1f : -1f;
            playerHp = maxHp = 500;
            ammo = 55 + Math.min(45, extraLevel / 2) + purchasedAmmo;
            purchasedAmmo = 0;
            levelTimeLimit = 0f;
            requiredKills = 8 + random.nextInt(7) + extraLevel / 4;
            treeX = new float[5 + random.nextInt(4)];
            for (int i = 0; i < treeX.length; i++) treeX[i] = 45f + i * (870f / Math.max(1, treeX.length - 1)) + random.nextFloat() * 26f - 13f;
            for (int i = 0; i < requiredKills; i++) {
                float x = 65f + random.nextFloat() * 830f;
                float y = 105f + random.nextFloat() * 220f;
                int hp = 2 + Math.min(16, extraLevel / 5) + random.nextInt(4);
                boolean attacker = random.nextFloat() < 0.22f;
                float speed = 0.55f + random.nextFloat() * 0.95f + extraLevel * 0.003f;
                ducks.add(new Duck(x, y, speed * 95f * (random.nextBoolean() ? 1f : -1f), hp, attacker, random));
            }
            duckSoundClock = 2f;
            playerDamageFlash = 0f;
            muzzleFlash = 0f;
            lastFrame = SystemClock.uptimeMillis();
            invalidate();
        }

        private void spawnFriendlyDucks(int count, int hp, float minSpeed, float maxSpeed) {
            for (int i = 0; i < count; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 110 + random.nextFloat() * 190;
                float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
                float direction = random.nextBoolean() ? 1f : -1f;
                ducks.add(new Duck(x, y, speed * 95f * direction, hp, false, random));
            }
        }

        private void spawnLevelFourWave() {
            if (waveIndex >= 5) return;
            waveIndex++;
            for (int i = 0; i < 7; i++) {
                float x = 70 + random.nextFloat() * 820;
                float y = 95 + random.nextFloat() * 165;
                ducks.add(new Duck(x, y, 0f, 7, true, random));
            }
            nextWaveAt = waveIndex * 30f;
            sound.playDuckFly();
        }

        private void updateGame(float dt) {
            levelElapsed += dt;
            if (!extraMode && level <= 2 && levelTimeLimit > 0f && levelElapsed >= levelTimeLimit) {
                failGame("Время вышло!");
                return;
            }

            if (muzzleFlash > 0f) muzzleFlash -= dt;
            if (weaponRecoil > 0f) weaponRecoil = Math.max(0f, weaponRecoil - dt * 5f);
            if (crosshairTimer > 0f) crosshairTimer -= dt;
            if (playerDamageFlash > 0f) playerDamageFlash -= dt;
            if (bossDamageFlash > 0f) bossDamageFlash -= dt;

            duckSoundClock -= dt;
            if (duckSoundClock <= 0f && !ducks.isEmpty()) {
                sound.playDuckFly();
                if (random.nextFloat() < 0.72f) sound.playQuack();
                duckSoundClock = 5f + random.nextFloat() * 6f;
            }

            if (!extraMode && level == 4 && waveIndex < 5 && levelElapsed >= nextWaveAt) {
                spawnLevelFourWave();
            }

            updateDucks(dt);
            if (state != State.PLAYING) return;
            updateFallenDucks(dt);
            updateDog(dt);
            if (extraMode && ammo <= 0) {
                openAmmoShop();
                return;
            }

            if (extraMode) {
                updateExtraBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 3) {
                updateLargeDuckBoss(dt);
                if (state != State.PLAYING) return;
            } else if (!extraMode && level == 5 && finalBossPhase) {
                updateEnderman(dt);
                if (state != State.PLAYING) return;
            }

            if (extraMode) {
                if (extraBossHp <= 0f) clearLevel();
            } else if (level == 1 || level == 2 || level == 5 && !finalBossPhase) {
                if (kills >= requiredKills) {
                    if (level == 5) beginEndermanPhase();
                    else clearLevel();
                } else if (ammo <= 0 && level != 5) {
                    failGame("Патроны закончились!");
                }
            } else if (!extraMode && level == 4) {
                if (waveIndex >= 5 && ducks.isEmpty()) {
                    clearLevel();
                } else if (ammo <= 0 && !ducks.isEmpty()) {
                    failGame("Патроны закончились!");
                }
            }
        }

        private void updateDucks(float dt) {
            Iterator<Duck> iterator = ducks.iterator();
            while (iterator.hasNext()) {
                Duck duck = iterator.next();
                duck.age += dt;
                if (duck.attacker) {
                    duck.attackCooldown = Math.max(0f, duck.attackCooldown - dt);
                    if (duck.retreatTimer > 0f) {
                        duck.retreatTimer -= dt;
                        duck.x += duck.retreatVx * dt;
                        duck.y += duck.retreatVy * dt;
                        duck.x = Math.max(28f, Math.min(932f, duck.x));
                        duck.y = Math.max(82f, Math.min(320f, duck.y));
                        continue;
                    }
                    float targetX = 480f;
                    float targetY = 422f;
                    float dx = targetX - duck.x;
                    float dy = targetY - duck.y;
                    float distance = (float) Math.sqrt(dx * dx + dy * dy);
                    if (distance > 1f) {
                        float speed = 82f + Math.min(50f, extraMode ? extraLevel * 0.6f : 0f);
                        duck.x += dx / distance * speed * dt;
                        duck.y += dy / distance * speed * dt;
                    }
                    if (distance < 48f && duck.attackCooldown <= 0f) {
                        damagePlayer(1);
                        if (state != State.PLAYING) return;
                        float len = Math.max(1f, distance);
                        duck.retreatVx = -dx / len * 245f;
                        duck.retreatVy = -Math.max(0.35f, dy / len) * 150f;
                        duck.retreatTimer = 0.95f;
                        duck.attackCooldown = 2.0f;
                        duck.attacked = true;
                    }
                } else {
                    duck.x += duck.vx * dt;
                    duck.y = duck.baseY + (float) Math.sin(duck.age * 2.7f + duck.phase) * 17f;
                    if (duck.x < 42f) duck.vx = Math.abs(duck.vx);
                    if (duck.x > 918f) duck.vx = -Math.abs(duck.vx);
                }
            }
        }

        private void updateFallenDucks(float dt) {
            Iterator<FallenDuck> iterator = fallenDucks.iterator();
            while (iterator.hasNext()) {
                FallenDuck duck = iterator.next();
                if (duck.y < 414f) {
                    duck.vy += 315f * dt;
                    duck.y += duck.vy * dt;
                    duck.rotation += 210f * dt;
                    if (duck.y >= 414f) {
                        duck.y = 414f;
                        duck.vy = 0f;
                    }
                } else {
                    duck.landedTime += dt;
                    if (!duck.queued && duck.landedTime >= 0.28f) {
                        fetchQueue.add(new FetchJob(duck));
                        duck.queued = true;
                    }
                }
            }
        }

        private void updateExtraBoss(float dt) {
            bossX += bossDirection * (38f + extraLevel * 0.22f) * dt;
            if (bossX < 190f) bossDirection = 1f;
            if (bossX > 790f) bossDirection = -1f;
            bossY = 150f + (float) Math.sin(levelElapsed * 1.35f) * 35f;
            extraBossSpawnClock += dt;
            if (extraBossSpawnClock >= Math.max(2.8f, 7f - extraLevel * 0.025f) && ducks.size() < 24) {
                extraBossSpawnClock = 0f;
                int count = 1 + random.nextInt(2);
                for (int i = 0; i < count; i++) {
                    float x = bossX + random.nextFloat() * 90f - 45f;
                    float y = bossY + 35f + random.nextFloat() * 45f;
                    int hp = 2 + Math.min(16, extraLevel / 5);
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1f : -1f) * 90f, hp, random.nextFloat() < 0.3f, random));
                }
                sound.playDuckFly();
            }
            extraBossAttackClock += dt;
            if (extraBossAttackClock >= Math.max(2.4f, 6.0f - extraLevel * 0.02f)) {
                extraBossAttackClock = 0f;
                damagePlayer(3 + extraLevel / 4);
            }
        }

        private void updateLargeDuckBoss(float dt) {
            bossX += bossDirection * 44f * dt;
            if (bossX < 560f) bossDirection = 1f;
            if (bossX > 825f) bossDirection = -1f;
            bossY = 156f + (float) Math.sin(levelElapsed * 1.7f) * 26f;

            spawnClock += dt;
            if (spawnClock >= 7f && ducks.size() < 28) {
                spawnClock = 0f;
                for (int i = 0; i < 2; i++) {
                    float x = bossX + random.nextFloat() * 80f - 40f;
                    float y = bossY + 30f + random.nextFloat() * 60f;
                    ducks.add(new Duck(x, y, (random.nextBoolean() ? 1 : -1) * 72f, 55, false, random));
                }
                sound.playDuckFly();
            }

            attackClock += dt;
            if (attackClock >= 6.5f) {
                attackClock = 0f;
                damagePlayer(8);
                sound.playQuack();
            }
        }

        private void beginEndermanPhase() {
            if (finalBossPhase) return;
            finalBossPhase = true;
            finalPhaseElapsed = 0f;
            finalAttackClock = 0f;
            enderHp = 300f;
            ammo = Integer.MAX_VALUE;
            treesBroken = true;
            ducks.clear();
            sound.playMonsterImpact();
        }

        private void updateEnderman(float dt) {
            finalPhaseElapsed += dt;
            emergeOffset = Math.max(0f, 210f - finalPhaseElapsed * 105f);
            if (finalPhaseElapsed > 2.3f) {
                enderWalkPhase += dt;
                bossX += bossDirection * 72f * dt;
                if (bossX < 155f) bossDirection = 1f;
                if (bossX > 805f) bossDirection = -1f;
                enderTeleportClock -= dt;
                if (enderTeleportClock <= 0f) {
                    bossX = 150f + random.nextFloat() * 660f;
                    bossDirection = random.nextBoolean() ? 1f : -1f;
                    enderTeleportClock = 7f + random.nextFloat() * 4f;
                    enderTeleportFlash = 0.55f;
                    sound.playMonsterImpact();
                }
                if (enderTeleportFlash > 0f) enderTeleportFlash = Math.max(0f, enderTeleportFlash - dt);
                finalAttackClock += dt;
                if (finalAttackClock >= 2.7f) {
                    finalAttackClock = 0f;
                    damagePlayer(50);
                    sound.playMonsterImpact();
                }
            }
        }

        private void updateDog(float dt) {
            if (dogState == 0 && !fetchQueue.isEmpty()) {
                dogTargetX = fetchQueue.peek().x;
                dogState = 1;
                dogCarryCount = 0;
                dogCarrying = false;
            }
            if (dogState == 1) {
                dogX = moveTowards(dogX, dogTargetX, 240f * dt);
                if (Math.abs(dogX - dogTargetX) < 3f) {
                    if (!fetchQueue.isEmpty()) {
                        FetchJob collected = fetchQueue.remove();
                        fallenDucks.remove(collected.duck);
                    }
                    dogCarryCount++;
                    dogCarrying = true;
                    if (dogCarryCount < 3 && !fetchQueue.isEmpty()) {
                        dogTargetX = fetchQueue.peek().x;
                    } else {
                        dogState = 2;
                    }
                }
            } else if (dogState == 2) {
                dogX = moveTowards(dogX, 850f, 265f * dt);
                if (dogX >= 847f) {
                    basketCount += dogCarryCount;
                    duckInventory += dogCarryCount;
                    dogCarryCount = 0;
                    dogState = 0;
                    dogCarrying = false;
                    sound.playDogBark();
                }
            }
        }

        private float moveTowards(float current, float target, float step) {
            if (current < target) return Math.min(target, current + step);
            return Math.max(target, current - step);
        }

        private void damagePlayer(int amount) {
            playerHp = Math.max(0, playerHp - amount);
            playerDamageFlash = 0.3f;
            if (playerHp <= 0) failGame("Охотник выбыл!");
        }

        private void sellDucks() {
            if (duckInventory <= 0) return;
            gold += duckInventory * 3;
            duckInventory = 0;
        }

        private void buyAmmo(int amount) {
            int cost = amount * 2;
            if (gold >= cost) {
                gold -= cost;
                if (shopMidLevel) {
                    if (ammo != Integer.MAX_VALUE) ammo += amount;
                } else {
                    purchasedAmmo += amount;
                }
            }
        }

        private void leaveShop() {
            if (shopMidLevel) {
                if (ammo > 0) {
                    shopMidLevel = false;
                    state = State.PLAYING;
                    lastFrame = SystemClock.uptimeMillis();
                }
            } else {
                int target = shopNextLevel;
                shopMidLevel = false;
                startLevel(target);
            }
        }

        private void clearLevel() {
            if (state == State.PLAYING) state = State.LEVEL_CLEAR;
        }

        private void failGame(String reason) {
            failureReason = reason;
            state = State.GAME_OVER;
        }

        private void shoot(float x, float y) {
            if (state != State.PLAYING) return;
            if (level == 5 && finalBossPhase) {
                if (enderHp <= 0f) return;
            } else if (ammo <= 0) {
                return;
            }

            if (!(level == 5 && finalBossPhase)) ammo--;
            muzzleFlash = 0.11f;
            weaponRecoil = 1f;
            crosshairX = x;
            crosshairY = y;
            crosshairTimer = 0.7f;
            sound.playShot();

            if (extraMode) {
                if (distance(x, y, bossX, bossY) < 108f) {
                    extraBossHp = Math.max(0f, extraBossHp - 10f);
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (extraBossHp <= 0f) clearLevel();
                    return;
                }
            }

            if (level == 5 && finalBossPhase) {
                if (pointInEnderman(x, y)) {
                    enderHp = Math.max(0f, enderHp - 4f);
                    bossDamageFlash = 0.16f;
                    sound.playMonsterHit();
                    if (enderHp <= 0f) state = State.VICTORY;
                }
                return;
            }

            if (!extraMode && level == 3 && distance(x, y, bossX, bossY) < 92f) {
                bossDuckHp = Math.max(0f, bossDuckHp - 10f);
                bossDamageFlash = 0.14f;
                sound.playQuack();
                if (bossDuckHp <= 0f) clearLevel();
                if (ammo <= 0 && state == State.PLAYING) failGame("Патроны закончились!");
                return;
            }

            Duck hit = null;
            float nearest = Float.MAX_VALUE;
            for (Duck duck : ducks) {
                if (isHidden(duck)) continue;
                float d = distance(x, y, duck.x, duck.y);
                if (d < 33f && d < nearest) {
                    nearest = d;
                    hit = duck;
                }
            }

            if (hit != null) {
                hit.hp -= 10;
                if (hit.hp <= 0) {
                    ducks.remove(hit);
                    kills++;
                    fallenDucks.add(new FallenDuck(hit.x, hit.y, random));
                    sound.playQuack();
                }
            }

            if (!extraMode && (level == 1 || level == 2 || level == 3 || level == 4) && ammo <= 0 && state == State.PLAYING) {
                boolean objectiveAlreadyMet = (level == 1 || level == 2) && kills >= requiredKills;
                objectiveAlreadyMet = objectiveAlreadyMet || (level == 4 && waveIndex >= 5 && ducks.isEmpty());
                boolean canStillProgress = level == 4 && waveIndex < 5;
                if (!objectiveAlreadyMet && !canStillProgress) failGame("Патроны закончились!");
            }
        }

        private boolean pointInEnderman(float x, float y) {
            float left = bossX - 106f;
            float right = bossX + 106f;
            float top = 115f + emergeOffset;
            float bottom = 465f;
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private boolean isHidden(Duck duck) {
            if (treesBroken) return false;
            for (float tx : treeX) {
                if (Math.abs(duck.x - tx) < 52f && duck.y > 118f && duck.y < 275f) return true;
            }
            return false;
        }

        private float distance(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() != MotionEvent.ACTION_DOWN) return true;
            float x = (event.getX() - gameOffsetX) / Math.max(0.001f, gameScale);
            float y = (event.getY() - gameOffsetY) / Math.max(0.001f, gameScale);
            if (x < 0 || x > WORLD_W || y < 0 || y > WORLD_H) return true;

            switch (state) {
                case MENU:
                    if (inside(x, y, 330, 345, 630, 415)) startNewGame();
                    else if (inside(x, y, 330, 425, 630, 490)) startExtraGame();
                    else startNewGame();
                    break;
                case SHOP:
                    if (inside(x, y, 70, 330, 330, 405)) sellDucks();
                    else if (inside(x, y, 350, 330, 545, 405)) buyAmmo(10);
                    else if (inside(x, y, 565, 330, 835, 405)) buyAmmo(25);
                    else if (inside(x, y, 330, 420, 630, 490)) leaveShop();
                    else if (inside(x, y, 70, 420, 300, 490)) state = State.MENU;
                    break;
                case PLAYING:
                    if (inside(x, y, 825, 10, 890, 70)) {
                        state = State.PAUSED;
                    } else if (inside(x, y, 895, 10, 950, 70)) {
                        soundOn = !soundOn;
                        sound.setEnabled(soundOn);
                    } else if (extraMode && inside(x, y, 725, 12, 815, 68)) {
                        openAmmoShop();
                    } else {
                        shoot(x, y);
                    }
                    break;
                case PAUSED:
                    if (inside(x, y, 330, 330, 630, 410)) state = State.PLAYING;
                    else if (inside(x, y, 330, 415, 630, 485)) state = State.MENU;
                    break;
                case LEVEL_CLEAR:
                    if (inside(x, y, 330, 350, 630, 430)) {
                        if (extraMode) {
                            if (extraLevel < 100) openShop(extraLevel + 1);
                            else state = State.VICTORY;
                        } else if (level < 5) {
                            openShop(level + 1);
                        } else state = State.VICTORY;
                    }
                    break;
                case GAME_OVER:
                    if (inside(x, y, 330, 360, 630, 440)) startNewGame();
                    else if (inside(x, y, 330, 445, 630, 510)) state = State.MENU;
                    break;
                case VICTORY:
                    if (inside(x, y, 330, 360, 630, 445)) startNewGame();
                    else state = State.MENU;
                    break;
            }
            invalidate();
            return true;
        }

        private boolean inside(float x, float y, float left, float top, float right, float bottom) {
            return x >= left && x <= right && y >= top && y <= bottom;
        }

        private void drawWorld(Canvas canvas) {
            boolean night = level == 5 && finalBossPhase;
            drawBackground(canvas, night);

            for (Duck duck : ducks) drawDuck(canvas, duck, false);
            for (FallenDuck duck : fallenDucks) drawFallenDuck(canvas, duck);
            if (extraMode && state != State.MENU && extraBossHp > 0f) drawExtraBoss(canvas);
            if (!extraMode && level == 3 && state != State.MENU) drawLargeDuck(canvas);

            if (!treesBroken) {
                for (float tx : treeX) drawTree(canvas, tx);
            } else {
                drawBrokenForest(canvas);
            }

            if (level == 5 && finalBossPhase) drawEnderman(canvas);
            drawHunter(canvas);
            drawBasket(canvas);
            drawDog(canvas);
            drawGroundDetails(canvas);
        }

        private void drawBackground(Canvas canvas, boolean night) {
            int[] skies = {SKY_DAY, Color.rgb(117, 167, 201), Color.rgb(193, 144, 99), Color.rgb(102, 115, 149), Color.rgb(88, 155, 137)};
            int[] grasses = {GRASS, Color.rgb(82, 126, 74), Color.rgb(141, 108, 61), Color.rgb(75, 88, 118), Color.rgb(48, 120, 102)};
            int sky = night ? Color.rgb(22, 18, 43) : (extraMode ? skies[mapTheme] : SKY_DAY);
            canvas.drawColor(sky);

            if (!night) {
                fillCircle(canvas, 820, 82, 38, Color.rgb(255, 221, 113));
                fillCircle(canvas, 810, 72, 34, Color.rgb(255, 235, 157));
                drawCloud(canvas, 150 + (float) Math.sin(menuAnim * 0.16f) * 14f, 83);
                drawCloud(canvas, 560 + (float) Math.sin(menuAnim * 0.12f) * 18f, 112);
            } else {
                fillCircle(canvas, 820, 105, 20, Color.rgb(125, 112, 170));
                for (int i = 0; i < 24; i++) {
                    float sx = (i * 137) % 950;
                    float sy = 25 + (i * 53) % 190;
                    fillRect(canvas, sx, sy, sx + 3, sy + 3, Color.rgb(213, 211, 245));
                }
            }

            int ground = night ? Color.rgb(40, 65, 44) : (extraMode ? grasses[mapTheme] : GRASS);
            fillRect(canvas, 0, 245, 960, 540, ground);
            fillRect(canvas, 0, 280, 960, 540, night ? Color.rgb(29, 54, 38) : (extraMode ? darken(grasses[mapTheme], 0.78f) : Color.rgb(63, 126, 56)));
            // Distant pine silhouettes make the forest continuous.
            for (int i = 0; i < 13; i++) {
                float x = i * 82f - 20f;
                drawPine(canvas, x, 245, 0.78f, night ? Color.rgb(23, 54, 43) : Color.rgb(50, 104, 59));
            }
            for (int i = 0; i < 22; i++) {
                float x = (i * 47f + 13f) % 960f;
                float y = 300 + (i % 4) * 28;
                fillRect(canvas, x, y, x + 3, y + 11, night ? Color.rgb(70, 107, 51) : Color.rgb(104, 162, 65));
            }

            if (night) {
                // Red-orange horizon after the sudden sunset.
                fillRect(canvas, 0, 235, 960, 248, Color.rgb(93, 43, 59));
                fillRect(canvas, 0, 248, 960, 257, Color.rgb(60, 43, 62));
            }
        }

        private int darken(int color, float factor) {
            return Color.rgb((int) (Color.red(color) * factor),
                    (int) (Color.green(color) * factor), (int) (Color.blue(color) * factor));
        }

        private void drawCloud(Canvas canvas, float x, float y) {
            int c = Color.rgb(222, 239, 226);
            fillRect(canvas, x, y, x + 82, y + 20, c);
            fillRect(canvas, x + 15, y - 13, x + 50, y + 22, c);
            fillRect(canvas, x + 45, y - 6, x + 73, y + 18, c);
        }

        private void drawPine(Canvas canvas, float x, float ground, float scale, int color) {
            float h = 100 * scale;
            fillRect(canvas, x - 4 * scale, ground - 15 * scale, x + 4 * scale, ground, Color.rgb(91, 65, 42));
            fillRect(canvas, x - 23 * scale, ground - h * 0.57f, x, ground - h * 0.18f, color);
            fillRect(canvas, x - 12 * scale, ground - h, x + 18 * scale, ground - h * 0.45f, color);
            fillRect(canvas, x, ground - h * 0.67f, x + 27 * scale, ground - h * 0.2f, color);
        }

        private void drawTree(Canvas canvas, float x) {
            float sway = (float) Math.sin(menuAnim * 1.3f + x * 0.014f) * 2.2f;
            canvas.save();
            canvas.rotate(sway, x, 220f);
            int trunk = Color.rgb(104, 72, 44);
            int leaf1 = Color.rgb(27, 91, 47);
            int leaf2 = Color.rgb(39, 119, 55);
            int leaf3 = Color.rgb(56, 139, 62);
            fillRect(canvas, x - 11, 200, x + 12, 465, trunk);
            fillRect(canvas, x - 6, 205, x - 1, 440, Color.rgb(135, 91, 52));
            fillRect(canvas, x - 53, 178, x + 48, 232, leaf1);
            fillRect(canvas, x - 40, 143, x + 35, 207, leaf2);
            fillRect(canvas, x - 20, 125, x + 24, 178, leaf3);
            fillRect(canvas, x - 63, 205, x - 39, 225, leaf2);
            fillRect(canvas, x + 32, 196, x + 60, 220, leaf2);
            fillRect(canvas, x - 25, 154, x - 5, 174, Color.rgb(77, 157, 67));
            canvas.restore();
        }

        private void drawBrokenForest(Canvas canvas) {
            int log = Color.rgb(91, 58, 42);
            int logLight = Color.rgb(137, 91, 53);
            for (int i = 0; i < treeX.length; i++) {
                float x = treeX[i];
                fillRect(canvas, x - 75, 408 + (i % 2) * 8, x + 65, 427 + (i % 2) * 8, log);
                fillRect(canvas, x - 52, 408 + (i % 2) * 8, x + 44, 414 + (i % 2) * 8, logLight);
                fillRect(canvas, x + 42, 399, x + 65, 414, Color.rgb(38, 105, 47));
                fillRect(canvas, x - 86, 421, x - 65, 438, Color.rgb(38, 105, 47));
            }
        }

        private void drawDuck(Canvas canvas, Duck duck, boolean boss) {
            canvas.save();
            float flap = (float) Math.sin(duck.age * 10f + duck.phase) * 5f;
            canvas.translate(duck.x, duck.y);
            float perspective = 0.68f + Math.max(0f, Math.min(1f, (duck.y - 85f) / 330f)) * 0.48f;
            float scale = (boss ? 1.75f : 1f) * perspective;
            canvas.scale(scale, scale);
            int body = boss ? Color.rgb(75, 116, 43) : Color.rgb(238, 237, 211);
            int wing = boss ? Color.rgb(49, 82, 36) : Color.rgb(179, 190, 162);
            fillOval(canvas, -25, -8, 23, 18, body);
            fillOval(canvas, -12, -10 + flap, 11, 10 + flap, wing);
            fillCircle(canvas, 16, -16, 11, body);
            fillRect(canvas, 23, -16, 36, -8, Color.rgb(236, 163, 49));
            fillRect(canvas, 12, -21, 15, -18, Color.BLACK);
            fillRect(canvas, -22, 1, -28, -9, wing);
            fillRect(canvas, -18, 14, -8, 17, Color.rgb(224, 157, 46));
            fillRect(canvas, 5, 14, 15, 17, Color.rgb(224, 157, 46));
            canvas.restore();

            if (!extraMode && level == 3 && !boss && duck.hp > 0 && duck.hp < duck.maxHp) {
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x + 20, duck.y - 24, Color.rgb(50, 45, 41));
                fillRect(canvas, duck.x - 20, duck.y - 28, duck.x - 20 + 40f * duck.hp / duck.maxHp, duck.y - 24, Color.rgb(237, 76, 65));
            }
        }

        private void drawFallenDuck(Canvas canvas, FallenDuck duck) {
            canvas.save();
            canvas.rotate(duck.rotation, duck.x, duck.y);
            canvas.translate(duck.x, duck.y);
            fillOval(canvas, -24, -7, 22, 13, Color.rgb(238, 237, 211));
            fillOval(canvas, -10, -9, 12, 7, Color.rgb(179, 190, 162));
            fillCircle(canvas, 15, -13, 9, Color.rgb(238, 237, 211));
            fillRect(canvas, 22, -13, 34, -6, Color.rgb(236, 163, 49));
            fillRect(canvas, 11, -18, 14, -15, Color.BLACK);
            fillRect(canvas, -16, 11, -7, 14, Color.rgb(224, 157, 46));
            fillRect(canvas, 5, 11, 14, 14, Color.rgb(224, 157, 46));
            canvas.restore();
        }

        private void drawExtraBoss(Canvas canvas) {
            float x = bossX;
            float y = bossY;
            int[] bodies = {Color.rgb(117, 49, 45), Color.rgb(66, 72, 115), Color.rgb(74, 105, 54), Color.rgb(83, 45, 107)};
            int body = bossDamageFlash > 0 ? Color.WHITE : bodies[extraBossType];
            float pulse = (float) Math.sin(menuAnim * 4f) * 4f;
            fillOval(canvas, x - 76, y - 24 + pulse, x + 76, y + 55 + pulse, body);
            fillCircle(canvas, x - 37, y - 22 + pulse, 26, body);
            fillCircle(canvas, x + 37, y - 22 + pulse, 26, body);
            fillRect(canvas, x - 45, y - 29 + pulse, x - 20, y - 21 + pulse, Color.rgb(255, 220, 120));
            fillRect(canvas, x + 20, y - 29 + pulse, x + 45, y - 21 + pulse, Color.rgb(255, 220, 120));
            float barW = 220f;
            fillRect(canvas, x - barW / 2, y - 78, x + barW / 2, y - 66, Color.rgb(35, 29, 35));
            fillRect(canvas, x - barW / 2 + 2, y - 76, x - barW / 2 + 2 + (barW - 4) * extraBossHp / extraBossMaxHp,
                    y - 68, Color.rgb(225, 75, 64));
            drawText(canvas, "БОСС " + (int) extraBossHp + "/" + (int) extraBossMaxHp, x, y - 86, 12, GOLD, Paint.Align.CENTER);
        }

        private void drawLargeDuck(Canvas canvas) {
            Duck boss = new Duck(bossX, bossY, 0, 120, false, random);
            boss.phase = levelElapsed * 3f;
            boss.age = levelElapsed;
            drawDuck(canvas, boss, true);
            float barW = 190f;
            fillRect(canvas, bossX - barW / 2, bossY - 68, bossX + barW / 2, bossY - 56, Color.rgb(48, 39, 35));
            fillRect(canvas, bossX - barW / 2 + 2, bossY - 66,
                    bossX - barW / 2 + 2 + (barW - 4) * bossDuckHp / 120f,
                    bossY - 58, Color.rgb(232, 74, 61));
            drawText(canvas, "БОЛЬШАЯ УТКА", bossX, bossY - 78, 12, GOLD, Paint.Align.CENTER);
        }

        private void drawEnderman(Canvas canvas) {
            float yShift = emergeOffset + (finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 4f : 0f);
            float x = bossX;
            if (enderTeleportFlash > 0f) {
                int alpha = (int) (enderTeleportFlash * 210f);
                fillCircle(canvas, x, 290, 120f * enderTeleportFlash + 20f,
                        Color.argb(alpha, 142, 63, 222));
            }
            int body = bossDamageFlash > 0 ? Color.rgb(63, 43, 92) : Color.rgb(18, 16, 25);
            int edge = Color.rgb(43, 30, 61);
            // Long arms and legs, deliberately chunky like an old console sprite.
            float gait = finalPhaseElapsed > 2.3f ? (float) Math.sin(enderWalkPhase * 9f) * 15f : 0f;
            float strike = finalAttackClock > 2.05f ? 35f : 0f;
            fillRect(canvas, x - 73 - strike, 217 + yShift, x - 48 - strike, 385 + yShift, body);
            fillRect(canvas, x + 48 + gait, 217 + yShift, x + 73 + gait + strike, 385 + yShift, body);
            fillRect(canvas, x - 29, 185 + yShift, x + 29, 388 + yShift, body);
            fillRect(canvas, x - 46, 108 + yShift, x + 46, 213 + yShift, body);
            fillRect(canvas, x - 40, 112 + yShift, x + 40, 119 + yShift, edge);
            fillRect(canvas, x - 25 - gait, 390 + yShift, x - 3 - gait, 465, body);
            fillRect(canvas, x + 4 + gait, 390 + yShift, x + 27 + gait, 465, body);
            fillRect(canvas, x - 29, 459, x - 1, 472, Color.rgb(10, 9, 16));
            fillRect(canvas, x + 2, 459, x + 32, 472, Color.rgb(10, 9, 16));
            // Purple eyes.
            fillRect(canvas, x - 31, 151 + yShift, x - 5, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x + 6, 151 + yShift, x + 32, 160 + yShift, Color.rgb(186, 80, 255));
            fillRect(canvas, x - 28, 153 + yShift, x - 9, 157 + yShift, Color.rgb(244, 185, 255));
            fillRect(canvas, x + 9, 153 + yShift, x + 29, 157 + yShift, Color.rgb(244, 185, 255));

            if (finalPhaseElapsed > 1f) {
                float barW = 240f;
                fillRect(canvas, x - barW / 2, 77, x + barW / 2, 94, Color.rgb(19, 15, 26));
                fillRect(canvas, x - barW / 2 + 3, 80,
                        x - barW / 2 + 3 + (barW - 6) * enderHp / 300f, 91,
                        Color.rgb(170, 53, 208));
                drawText(canvas, "ЭНДЕРМЕН  " + (int) enderHp + " / 300", x, 66, 13, CREAM, Paint.Align.CENTER);
            }
        }

        private void drawHunter(Canvas canvas) {
            // First-person view: forearms, stock and barrel frame the bottom of the screen.
            float recoil = weaponRecoil * 15f;
            int sleeve = playerDamageFlash > 0 ? Color.rgb(150, 42, 43) : Color.rgb(57, 69, 80);
            fillRect(canvas, 330, 486, 424, 540, sleeve);
            fillRect(canvas, 536, 486, 630, 540, sleeve);
            fillRect(canvas, 399, 455 + recoil, 561, 525 + recoil, Color.rgb(86, 56, 35));
            fillRect(canvas, 438, 426 + recoil, 522, 505 + recoil, Color.rgb(48, 45, 43));
            fillRect(canvas, 458, 383 + recoil, 502, 470 + recoil, Color.rgb(76, 79, 77));
            fillRect(canvas, 468, 354 + recoil, 492, 432 + recoil, Color.rgb(111, 116, 111));
            fillRect(canvas, 473, 352 + recoil, 487, 410 + recoil, Color.rgb(35, 36, 34));
            // Hands around the weapon.
            fillRect(canvas, 404, 457 + recoil, 441, 490 + recoil, Color.rgb(190, 143, 108));
            fillRect(canvas, 519, 457 + recoil, 556, 490 + recoil, Color.rgb(190, 143, 108));
            if (muzzleFlash > 0f) {
                fillCircle(canvas, 480, 342 + recoil, 18f + muzzleFlash * 70f, Color.rgb(255, 238, 139));
                fillCircle(canvas, 480, 342 + recoil, 9f + muzzleFlash * 35f, Color.WHITE);
            }
        }

        private void drawDog(Canvas canvas) {
            float y = 461f;
            float step = dogState == 0 ? 0f : (float) Math.sin(menuAnim * 17f) * 4f;
            canvas.save();
            canvas.translate(dogX, y);
            // Body, head, ears, paws and tail.
            fillRect(canvas, -26, -22, 20, 2, Color.rgb(171, 112, 59));
            fillRect(canvas, 11, -34, 34, -10, Color.rgb(188, 132, 73));
            fillRect(canvas, 13, -43, 20, -30, Color.rgb(95, 55, 37));
            fillRect(canvas, 30, -24, 42, -17, Color.rgb(62, 42, 31));
            fillRect(canvas, -20, -1 + step, -12, 9 + step, Color.rgb(92, 60, 39));
            fillRect(canvas, 10, -1 - step, 18, 9 - step, Color.rgb(92, 60, 39));
            fillRect(canvas, -34, -30, -27, -20, Color.rgb(121, 76, 46));
            if (dogCarrying) {
                for (int i = 0; i < Math.max(1, dogCarryCount); i++) {
                    float ox = -18f + i * 17f;
                    fillOval(canvas, ox - 7, -48 - (i % 2) * 3, ox + 9, -33 - (i % 2) * 3, Color.rgb(239, 235, 210));
                    fillCircle(canvas, ox + 7, -47 - (i % 2) * 3, 4, Color.rgb(239, 235, 210));
                    fillRect(canvas, ox + 10, -49 - (i % 2) * 3, ox + 15, -45 - (i % 2) * 3, Color.rgb(237, 164, 52));
                }
            }
            canvas.restore();
        }

        private void drawBasket(Canvas canvas) {
            fillRect(canvas, 858, 439, 917, 491, Color.rgb(155, 94, 43));
            fillRect(canvas, 854, 434, 921, 444, Color.rgb(205, 151, 74));
            for (int i = 0; i < 4; i++) {
                fillRect(canvas, 864 + i * 14, 445, 868 + i * 14, 488, Color.rgb(205, 147, 73));
            }
            drawText(canvas, String.valueOf(basketCount), 887, 510, 16, CREAM, Paint.Align.CENTER);
        }

        private void drawGroundDetails(Canvas canvas) {
            for (int i = 0; i < 18; i++) {
                float x = (i * 59 + 21) % 960;
                float y = 505 + (i % 3) * 8;
                fillRect(canvas, x, y, x + 4, y + 9, Color.rgb(124, 178, 74));
            }
        }

        private void drawHud(Canvas canvas) {
            fillRect(canvas, 12, 10, 948, 72, PANEL);
            strokeRect(canvas, 12, 10, 948, 72, GOLD, 2);
            drawText(canvas, extraMode ? "БОНУС " + extraLevel + "/100" : "УРОВЕНЬ " + level + "/5", 28, 38, 18, GOLD, Paint.Align.LEFT);
            drawText(canvas, "HP", 203, 37, 15, CREAM, Paint.Align.LEFT);
            fillRect(canvas, 239, 23, 355, 43, Color.rgb(55, 48, 43));
            int healthColor = playerHp > maxHp * 0.35f ? Color.rgb(90, 190, 89) : Color.rgb(226, 75, 67);
            if (playerHp > 0) fillRect(canvas, 242, 26, 242 + 110f * playerHp / maxHp, 40, healthColor);
            drawText(canvas, playerHp + "/" + maxHp, 367, 38, 13, CREAM, Paint.Align.LEFT);

            String ammoText = ammo == Integer.MAX_VALUE ? "∞" : String.valueOf(ammo);
            drawText(canvas, "ПАТР: " + ammoText, 478, 38, 17, CREAM, Paint.Align.LEFT);
            if (!extraMode && (level == 1 || level == 2)) {
                int remain = Math.max(0, (int) (levelTimeLimit - levelElapsed));
                drawText(canvas, String.format(java.util.Locale.US, "%02d:%02d", remain / 60, remain % 60),
                        650, 39, 20, remain <= 20 ? Color.rgb(255, 103, 83) : GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                drawText(canvas, "ВОЛНА " + waveIndex + "/5", 645, 38, 16, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "БОСС", 650, 38, 17, GOLD, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БОСС-ФИНАЛ", 650, 38, 15, GOLD, Paint.Align.CENTER);
            } else if (!extraMode) {
                drawText(canvas, "УТОК: " + kills + "/" + requiredKills, 650, 38, 15, GOLD, Paint.Align.CENTER);
            }

            if (extraMode) drawButton(canvas, 725, 16, 815, 64, "МАГАЗИН", Color.rgb(120, 83, 35));
            drawButton(canvas, 825, 16, 886, 64, "Ⅱ", Color.rgb(71, 83, 68));
            drawButton(canvas, 895, 16, 940, 64, soundOn ? "♪" : "×", Color.rgb(71, 83, 68));
            if (extraMode) {
                drawText(canvas, "СЛУЧАЙНАЯ КАРТА • БОСС • ЗОЛОТО: " + gold, 480, 98, 14, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 3) {
                drawText(canvas, "У большой утки " + (int) bossDuckHp + " HP. Победи босса!", 480, 98, 14, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 4) {
                String hint = waveIndex < 5 ? "Утки идут волнами. Следующая атака через 30 секунд." : "Последняя волна! Добей оставшихся уток.";
                drawText(canvas, hint, 480, 98, 13, CREAM, Paint.Align.CENTER);
            } else if (!extraMode && level == 5 && finalBossPhase) {
                drawText(canvas, "БЕСКОНЕЧНЫЕ ПАТРОНЫ • УРОН 4 • ОСТОРОЖНО: УДАР 50 HP", 480, 98, 13, Color.rgb(246, 205, 255), Paint.Align.CENTER);
            }
        }

        private void drawCrosshair(Canvas canvas) {
            if (crosshairTimer <= 0f) return;
            int alpha = (int) (255 * Math.min(1f, crosshairTimer / 0.25f));
            paint.setColor(Color.argb(alpha, 255, 244, 183));
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.5f);
            canvas.drawCircle(crosshairX, crosshairY, 17, paint);
            canvas.drawLine(crosshairX - 27, crosshairY, crosshairX - 8, crosshairY, paint);
            canvas.drawLine(crosshairX + 8, crosshairY, crosshairX + 27, crosshairY, paint);
            canvas.drawLine(crosshairX, crosshairY - 27, crosshairX, crosshairY - 8, paint);
            canvas.drawLine(crosshairX, crosshairY + 8, crosshairX, crosshairY + 27, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawStateOverlay(Canvas canvas) {
            if (state == State.MENU) {
                overlay(canvas, 0.2f);
                panel(canvas, 190, 80, 770, 510);
                drawText(canvas, "УТИНАЯ ОХОТА", 480, 160, 39, GOLD, Paint.Align.CENTER);
                drawText(canvas, "RETRO FOREST ARCADE • FIRST PERSON", 480, 196, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Стреляй по уткам, уклоняйся от атак и собирай добычу.", 480, 248, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Собака приносит до трёх уток за один рейс.", 480, 278, 14, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 345, 630, 415, "ОСНОВНАЯ ИГРА • 5 УРОВНЕЙ", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 425, 630, 490, "ДОПОЛНИТЕЛЬНЫЕ УРОВНИ • 100", Color.rgb(103, 72, 137));
            } else if (state == State.SHOP) {
                overlay(canvas, 0.58f);
                panel(canvas, 110, 105, 850, 505);
                drawText(canvas, shopMidLevel ? "БОЕПРИПАСЫ ЗАКОНЧИЛИСЬ" : "ЛАВКА ПЕРЕД УРОВНЕМ", 480, 175, 27, GOLD, Paint.Align.CENTER);
                drawText(canvas, "Уток в корзине: " + duckInventory + "   •   Золото: " + gold + "   •   1 утка = 3 золота", 480, 225, 14, CREAM, Paint.Align.CENTER);
                String shopAmmo = shopMidLevel ? String.valueOf(ammo) : String.valueOf(purchasedAmmo) + " доп.";
                drawText(canvas, "Патроны: " + shopAmmo + "   •   1 патрон = 2 золота", 480, 254, 14, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 70, 330, 330, 405, "ПРОДАТЬ ВСЕХ УТОК", Color.rgb(133, 87, 42));
                drawButton(canvas, 350, 330, 545, 405, "+10 ПАТРОНОВ • 20 ЗОЛОТА", Color.rgb(48, 105, 75));
                drawButton(canvas, 565, 330, 835, 405, "+25 ПАТРОНОВ • 50 ЗОЛОТА", Color.rgb(48, 105, 75));
                drawButton(canvas, 330, 420, 630, 490, shopMidLevel ? "ВЕРНУТЬСЯ В УРОВЕНЬ" : "НАЧАТЬ УРОВЕНЬ", Color.rgb(43, 123, 65));
                drawButton(canvas, 70, 420, 300, 490, "В МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.PAUSED) {
                overlay(canvas, 0.58f);
                panel(canvas, 300, 160, 660, 490);
                drawText(canvas, "ПАУЗА", 480, 230, 34, GOLD, Paint.Align.CENTER);
                drawButton(canvas, 330, 330, 630, 410, "ПРОДОЛЖИТЬ", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 415, 630, 485, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.LEVEL_CLEAR) {
                overlay(canvas, 0.48f);
                panel(canvas, 280, 150, 680, 480);
                drawText(canvas, "УРОВЕНЬ ПРОЙДЕН!", 480, 235, 31, GOLD, Paint.Align.CENTER);
                String message = extraMode ? "Босс повержен! Следующая случайная карта уже ждёт." : level == 3 ? "Большая утка побеждена!" : level == 4 ? "Все пять волн отражены!" : "Отличная охота! Пёс уже несёт добычу.";
                drawText(canvas, message, 480, 285, 14, CREAM, Paint.Align.CENTER);
                String nextLabel = extraMode ? (extraLevel < 100 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ") : (level < 5 ? "СЛЕДУЮЩИЙ УРОВЕНЬ" : "ЗАВЕРШИТЬ");
                drawButton(canvas, 330, 350, 630, 430, nextLabel, Color.rgb(43, 123, 65));
            } else if (state == State.GAME_OVER) {
                overlay(canvas, 0.68f);
                panel(canvas, 280, 150, 680, 490);
                drawText(canvas, "ИГРА ОКОНЧЕНА", 480, 235, 31, Color.rgb(255, 112, 92), Paint.Align.CENTER);
                drawText(canvas, failureReason, 480, 285, 16, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Здоровье и патроны восстановятся при новом запуске.", 480, 315, 12, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 440, "НАЧАТЬ ЗАНОВО", Color.rgb(43, 123, 65));
                drawButton(canvas, 330, 445, 630, 510, "В ГЛАВНОЕ МЕНЮ", Color.rgb(83, 83, 73));
            } else if (state == State.VICTORY) {
                overlay(canvas, 0.58f);
                panel(canvas, 260, 140, 700, 490);
                drawText(canvas, "ПОБЕДА!", 480, 235, 42, GOLD, Paint.Align.CENTER);
                drawText(canvas, extraMode ? "Пройдены все 100 дополнительных уровней!" : "Эндермен повержен. Лес спасён, а корзина полна!", 480, 292, 14, CREAM, Paint.Align.CENTER);
                drawText(canvas, "Уток в корзине: " + basketCount, 480, 322, 15, CREAM, Paint.Align.CENTER);
                drawButton(canvas, 330, 360, 630, 445, "ИГРАТЬ СНОВА", Color.rgb(43, 123, 65));
            }
        }

        private void overlay(Canvas canvas, float alpha) {
            fillRect(canvas, 0, 0, WORLD_W, WORLD_H, Color.argb((int) (alpha * 255), 8, 12, 10));
        }

        private void panel(Canvas canvas, float left, float top, float right, float bottom) {
            fillRect(canvas, left, top, right, bottom, PANEL);
            strokeRect(canvas, left, top, right, bottom, GOLD, 3);
            strokeRect(canvas, left + 7, top + 7, right - 7, bottom - 7, Color.rgb(97, 105, 75), 1);
        }

        private void drawButton(Canvas canvas, float left, float top, float right, float bottom, String label, int color) {
            fillRect(canvas, left, top, right, bottom, color);
            strokeRect(canvas, left, top, right, bottom, GOLD, 2);
            drawText(canvas, label, (left + right) / 2f, (top + bottom) / 2f + 7, 17, CREAM, Paint.Align.CENTER);
        }

        private void fillRect(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawRect(left, top, right, bottom, paint);
        }

        private void strokeRect(Canvas canvas, float left, float top, float right, float bottom, int color, float width) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(width);
            canvas.drawRect(left, top, right, bottom, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void fillCircle(Canvas canvas, float x, float y, float radius, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x, y, radius, paint);
        }

        private void fillOval(Canvas canvas, float left, float top, float right, float bottom, int color) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            canvas.drawOval(new RectF(left, top, right, bottom), paint);
        }

        private void drawText(Canvas canvas, String text, float x, float baseline, float size, int color, Paint.Align align) {
            paint.setColor(color);
            paint.setStyle(Paint.Style.FILL);
            paint.setTypeface(PIXEL);
            paint.setTextSize(size);
            paint.setTextAlign(align);
            canvas.drawText(text, x, baseline, paint);
        }

        private static final class SoundEngine {
            private final SoundPool pool;
            private final int shot;
            private final int duckFly;
            private final int quack;
            private final int bark;
            private final int monsterImpact;
            private final int monsterHit;
            private final int ambience;
            private int ambienceStream = 0;
            private boolean enabled = true;
            private boolean ambienceLoaded = false;

            SoundEngine(Context context) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build();
                pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attributes).build();
                shot = pool.load(context, R.raw.gunshot, 1);
                duckFly = pool.load(context, R.raw.duck_fly, 1);
                quack = pool.load(context, R.raw.duck_quack, 1);
                bark = pool.load(context, R.raw.dog_bark, 1);
                monsterImpact = pool.load(context, R.raw.monster_hit, 1);
                monsterHit = pool.load(context, R.raw.monster_hit, 1);
                ambience = pool.load(context, R.raw.forest_ambience, 1);
                pool.setOnLoadCompleteListener((soundPool, sampleId, status) -> {
                    if (sampleId == ambience && status == 0) {
                        ambienceLoaded = true;
                        if (enabled) startAmbience();
                    }
                });
            }

            void setEnabled(boolean value) {
                enabled = value;
                if (!enabled) pauseAmbience();
                else startAmbience();
            }

            void startAmbience() {
                if (!enabled || !ambienceLoaded || ambienceStream != 0) return;
                ambienceStream = pool.play(ambience, 0.26f, 0.26f, 1, -1, 1f);
            }

            void pauseAmbience() {
                if (ambienceStream != 0) {
                    pool.stop(ambienceStream);
                    ambienceStream = 0;
                }
            }

            void resumeAmbience() { startAmbience(); }

            private void play(int id, float volume) {
                if (enabled && id != 0) pool.play(id, volume, volume, 2, 0, 1f);
            }

            void playShot() { play(shot, 0.8f); }
            void playDuckFly() { play(duckFly, 0.36f); }
            void playQuack() { play(quack, 0.55f); }
            void playDogBark() { play(bark, 0.5f); }
            void playMonsterImpact() { play(monsterImpact, 0.75f); }
            void playMonsterHit() { play(monsterHit, 0.45f); }

            void release() {
                pauseAmbience();
                pool.release();
            }
        }
    }
}
