import '../data/knowledge_db.dart';

/// Local AI core: RAG + offline scientific responder.
/// Architecture is ready for a future on-device LLM backend.
class LocalCore {
  LocalCore._();
  static final LocalCore instance = LocalCore._();

  bool get modelLoaded => false; // future: GGUF / llama.cpp

  String get statusRu => modelLoaded
      ? 'Локальная модель загружена'
      : 'Режим базы знаний + локальный ассистент (модель подключится отдельно)';

  String get statusEn => modelLoaded
      ? 'Local model loaded'
      : 'Knowledge-base assistant mode (model plugs in later)';

  Future<String> reply(String userMessage, {String languageCode = 'ru'}) async {
    final q = userMessage.trim();
    if (q.isEmpty) {
      return languageCode == 'ru' ? 'Пустой запрос.' : 'Empty request.';
    }

    final hits = await KnowledgeDb.instance.search(q, limit: 5);
    final builtin = _builtinNotes(q, languageCode);

    final buf = StringBuffer();
    if (languageCode == 'ru') {
      buf.writeln('### Ответ AstroNuit');
      buf.writeln();
      if (hits.isNotEmpty) {
        buf.writeln(
            'Нашёл релевантные фрагменты в вашей научной библиотеке (${hits.length}):');
        buf.writeln();
        for (var i = 0; i < hits.length; i++) {
          final h = hits[i];
          final title = h['title'] ?? 'документ';
          final content = (h['content'] as String).trim();
          final snippet = content.length > 420
              ? '${content.substring(0, 420)}…'
              : content;
          buf.writeln('**[${i + 1}] $title**');
          buf.writeln(snippet);
          buf.writeln();
        }
        buf.writeln(
            '_Сводка:_ опирайтесь на цитаты выше. Если нужно уточнение — задайте более узкий вопрос или добавьте материалы в Библиотеку.');
      } else {
        buf.writeln(builtin);
        buf.writeln();
        buf.writeln(
            '_В библиотеке пока нет подходящих фрагментов. Импортируйте TXT/MD/заметки в разделе «Файлы» или «Библиотека» — ответы станут точнее._');
      }
      if (!modelLoaded) {
        buf.writeln();
        buf.writeln(
            '⚙️ Локальная нейросеть ещё не подключена: сейчас работает поисковый ассистент по вашей базе. Веса модели можно будет загрузить на следующем этапе.');
      }
    } else {
      buf.writeln('### AstroNuit answer');
      buf.writeln();
      if (hits.isNotEmpty) {
        buf.writeln(
            'Relevant fragments from your science library (${hits.length}):');
        buf.writeln();
        for (var i = 0; i < hits.length; i++) {
          final h = hits[i];
          final title = h['title'] ?? 'document';
          final content = (h['content'] as String).trim();
          final snippet = content.length > 420
              ? '${content.substring(0, 420)}…'
              : content;
          buf.writeln('**[${i + 1}] $title**');
          buf.writeln(snippet);
          buf.writeln();
        }
        buf.writeln(
            '_Summary:_ use the quotes above. Ask a narrower question or add materials to the Library for better answers.');
      } else {
        buf.writeln(builtin);
        buf.writeln();
        buf.writeln(
            '_No matching fragments in the library yet. Import TXT/MD notes in Files or Library to improve answers._');
      }
      if (!modelLoaded) {
        buf.writeln();
        buf.writeln(
            '⚙️ Local neural net is not wired yet: this is a knowledge-base assistant. Model weights can be loaded in a later stage.');
      }
    }
    return buf.toString().trim();
  }

  String _builtinNotes(String q, String lang) {
    final lower = q.toLowerCase();
    final ru = lang == 'ru';
    if (lower.contains('интеграл') || lower.contains('integral')) {
      return ru
          ? 'Интеграл — предел сумм (Риман/Лебег). Для практики: разбейте задачу на табличный интеграл + замену переменной. Если пришлёте формулу текстом — разберём шаги.'
          : 'An integral is a limit of sums (Riemann/Lebesgue). Split into a table integral plus substitution. Paste a formula as text for step-by-step help.';
    }
    if (lower.contains('квадратн') || lower.contains('quadratic')) {
      return ru
          ? 'Квадратное уравнение ax²+bx+c=0: дискриминант D=b²-4ac; корни (-b±√D)/(2a) при D≥0. Приведите коэффициенты — посчитаем точно.'
          : 'Quadratic ax²+bx+c=0: discriminant D=b²-4ac; roots (-b±√D)/(2a) for D≥0. Share coefficients for an exact solution.';
    }
    if (lower.contains('python') || lower.contains('код') || lower.contains('code')) {
      return ru
          ? 'Могу помочь со структурой алгоритма и псевдокодом. Полный программный агент с запуском кода — следующий модуль. Опишите задачу и ограничения.'
          : 'I can help with algorithm structure and pseudocode. A full coding agent with execution is the next module. Describe the task and constraints.';
    }
    return ru
        ? 'Я локальный научно-технический ассистент AstroNuit. Сейчас отвечаю по вашей базе знаний и встроенным заметкам. Добавьте материалы в библиотеку для более точных ответов по вашим данным.'
        : 'I am AstroNuit, a local scientific assistant. I answer from your knowledge base and built-in notes. Add materials to the library for more precise answers.';
  }
}
