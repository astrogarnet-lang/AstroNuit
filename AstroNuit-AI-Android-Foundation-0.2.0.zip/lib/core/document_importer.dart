import 'dart:convert';
import 'dart:io';

import '../data/knowledge_db.dart';

class ImportResult {
  const ImportResult({
    required this.title,
    required this.chars,
    required this.documentId,
  });
  final String title;
  final int chars;
  final int documentId;
}

class DocumentImporter {
  /// Import raw text (from file picker bytes or paste).
  static Future<ImportResult> importText({
    required String title,
    required String content,
    String sourcePath = '',
    String mime = 'text/plain',
  }) async {
    final cleaned = content.trim();
    if (cleaned.isEmpty) {
      throw Exception('Пустой документ');
    }
    final id = await KnowledgeDb.instance.addDocument(
      title: title,
      content: cleaned,
      sourcePath: sourcePath,
      mime: mime,
    );
    return ImportResult(title: title, chars: cleaned.length, documentId: id);
  }

  static Future<ImportResult> importFile(File file) async {
    final name = file.uri.pathSegments.isNotEmpty
        ? file.uri.pathSegments.last
        : 'document';
    final lower = name.toLowerCase();
    if (lower.endsWith('.txt') ||
        lower.endsWith('.md') ||
        lower.endsWith('.csv') ||
        lower.endsWith('.json') ||
        lower.endsWith('.dart') ||
        lower.endsWith('.py') ||
        lower.endsWith('.tex')) {
      final content = await file.readAsString();
      return importText(title: name, content: content, sourcePath: file.path);
    }
    // Best-effort binary: try UTF-8 decode
    final bytes = await file.readAsBytes();
    try {
      final content = utf8.decode(bytes, allowMalformed: true);
      // Strip obvious binary noise
      final printable = content.replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F]'), ' ');
      if (printable.trim().length < 40) {
        throw Exception(
            'Формат «$name» пока читается ограниченно. Сохраните как TXT/MD или вставьте текст.');
      }
      return importText(
        title: name,
        content: printable,
        sourcePath: file.path,
        mime: 'application/octet-stream',
      );
    } catch (e) {
      throw Exception(
          'Не удалось прочитать «$name». Поддерживаются TXT, MD, CSV, JSON, код; PDF/DOCX — через вставку текста на этом этапе.');
    }
  }
}
