import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(
      join(root, 'timecontrol.db'),
      version: 3,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, version) async {
        await _createV1(db);
        await _createV2(db);
        await _createV3(db);
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) await _createV2(db);
        if (oldVersion < 3) await _createV3(db);
      },
    );
    return _db!;
  }

  Future<void> _createV1(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS participants(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        role TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL,
        archived INTEGER NOT NULL DEFAULT 0,
        deleted INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS work_sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        participant_id INTEGER NOT NULL,
        check_in INTEGER NOT NULL,
        check_out INTEGER,
        note TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL,
        FOREIGN KEY(participant_id) REFERENCES participants(id)
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS audit_log(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_type TEXT NOT NULL,
        entity_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        details TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_sessions_participant ON work_sessions(participant_id)');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_sessions_checkin ON work_sessions(check_in)');
  }

  Future<void> _createV2(Database db) async {
    try {
      await db.execute(
          "ALTER TABLE work_sessions ADD COLUMN note TEXT NOT NULL DEFAULT ''");
    } catch (_) {}

    await db.execute('''
      CREATE TABLE IF NOT EXISTS groups(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        created_at INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS group_members(
        group_id INTEGER NOT NULL,
        participant_id INTEGER NOT NULL,
        PRIMARY KEY(group_id, participant_id),
        FOREIGN KEY(group_id) REFERENCES groups(id) ON DELETE CASCADE,
        FOREIGN KEY(participant_id) REFERENCES participants(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS day_status(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        participant_id INTEGER NOT NULL,
        day_key TEXT NOT NULL,
        status TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        created_at INTEGER NOT NULL,
        UNIQUE(participant_id, day_key),
        FOREIGN KEY(participant_id) REFERENCES participants(id)
      )
    ''');
  }

  Future<void> _audit(
    DatabaseExecutor db,
    String type,
    int id,
    String action, [
    String details = '',
  ]) async {
    await db.insert('audit_log', {
      'entity_type': type,
      'entity_id': id,
      'action': action,
      'details': details,
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<List<Map<String, dynamic>>> people({
    String search = '',
    bool archived = false,
    int? groupId,
  }) async {
    final db = await database;
    final q = '%${search.trim()}%';
    if (groupId == null) {
      return db.query(
        'participants',
        where:
            'deleted = 0 AND archived = ? AND (first_name LIKE ? OR last_name LIKE ? OR role LIKE ? OR phone LIKE ?)',
        whereArgs: [archived ? 1 : 0, q, q, q, q],
        orderBy: 'first_name COLLATE NOCASE, last_name COLLATE NOCASE',
      );
    }
    return db.rawQuery('''
      SELECT p.* FROM participants p
      INNER JOIN group_members gm ON gm.participant_id = p.id
      WHERE p.deleted = 0 AND p.archived = ?
        AND gm.group_id = ?
        AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.role LIKE ? OR p.phone LIKE ?)
      ORDER BY p.first_name COLLATE NOCASE, p.last_name COLLATE NOCASE
    ''', [archived ? 1 : 0, groupId, q, q, q, q]);
  }

  Future<int> savePerson(Map<String, dynamic> p) async {
    final db = await database;
    final now = DateTime.now().millisecondsSinceEpoch;
    return db.transaction((txn) async {
      if (p['id'] == null) {
        final id = await txn.insert('participants', {
          'first_name': p['first_name'],
          'last_name': p['last_name'],
          'phone': p['phone'] ?? '',
          'role': p['role'] ?? '',
          'created_at': now,
          'archived': 0,
          'deleted': 0,
        });
        await _audit(txn, 'participant', id, 'create');
        return id;
      } else {
        await txn.update(
          'participants',
          {
            'first_name': p['first_name'],
            'last_name': p['last_name'],
            'phone': p['phone'] ?? '',
            'role': p['role'] ?? '',
          },
          where: 'id = ?',
          whereArgs: [p['id']],
        );
        await _audit(txn, 'participant', p['id'] as int, 'update');
        return p['id'] as int;
      }
    });
  }

  Future<void> setArchived(int id, bool archived) async {
    final db = await database;
    await db.update(
      'participants',
      {'archived': archived ? 1 : 0},
      where: 'id = ?',
      whereArgs: [id],
    );
    await _audit(db, 'participant', id, archived ? 'archive' : 'unarchive');
  }

  Future<void> softDelete(int id) async {
    final db = await database;
    await db.update(
      'participants',
      {'deleted': 1, 'archived': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
    await _audit(db, 'participant', id, 'soft_delete');
  }

  Future<List<Map<String, dynamic>>> groups() async {
    final db = await database;
    return db.rawQuery('''
      SELECT g.*, COUNT(gm.participant_id) AS member_count
      FROM groups g
      LEFT JOIN group_members gm ON gm.group_id = g.id
      GROUP BY g.id
      ORDER BY g.name COLLATE NOCASE
    ''');
  }

  Future<int> createGroup(String name) async {
    final db = await database;
    final id = await db.insert('groups', {
      'name': name.trim(),
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
    await _audit(db, 'group', id, 'create', name);
    return id;
  }

  Future<void> renameGroup(int id, String name) async {
    final db = await database;
    await db.update(
      'groups',
      {'name': name.trim()},
      where: 'id = ?',
      whereArgs: [id],
    );
    await _audit(db, 'group', id, 'rename', name);
  }

  Future<void> deleteGroup(int id) async {
    final db = await database;
    await db.delete('group_members', where: 'group_id = ?', whereArgs: [id]);
    await db.delete('groups', where: 'id = ?', whereArgs: [id]);
    await _audit(db, 'group', id, 'delete');
  }

  Future<List<int>> groupMemberIds(int groupId) async {
    final db = await database;
    final rows = await db.query(
      'group_members',
      columns: ['participant_id'],
      where: 'group_id = ?',
      whereArgs: [groupId],
    );
    return rows.map((r) => r['participant_id'] as int).toList();
  }

  Future<void> setGroupMembers(int groupId, List<int> participantIds) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete(
        'group_members',
        where: 'group_id = ?',
        whereArgs: [groupId],
      );
      for (final pid in participantIds) {
        await txn.insert('group_members', {
          'group_id': groupId,
          'participant_id': pid,
        });
      }
      await _audit(
        txn,
        'group',
        groupId,
        'set_members',
        'count=${participantIds.length}',
      );
    });
  }

  String dayKey(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> checkIn(int participantId, {String note = ''}) async {
    final db = await database;
    final open = await db.query(
      'work_sessions',
      where: 'participant_id = ? AND check_out IS NULL',
      whereArgs: [participantId],
    );
    if (open.isNotEmpty) {
      throw Exception('У участника уже есть открытая сессия');
    }
    final now = DateTime.now();
    final id = await db.insert('work_sessions', {
      'participant_id': participantId,
      'check_in': now.millisecondsSinceEpoch,
      'check_out': null,
      'note': note,
      'created_at': now.millisecondsSinceEpoch,
    });
    await db.insert(
      'day_status',
      {
        'participant_id': participantId,
        'day_key': dayKey(now),
        'status': 'present',
        'note': note,
        'created_at': now.millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    await _audit(db, 'session', id, 'check_in');
  }

  Future<void> checkOut(int participantId) async {
    final db = await database;
    final open = await db.query(
      'work_sessions',
      where: 'participant_id = ? AND check_out IS NULL',
      whereArgs: [participantId],
      orderBy: 'check_in DESC',
      limit: 1,
    );
    if (open.isEmpty) {
      throw Exception('Нет открытой сессии');
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    final id = open.first['id'] as int;
    final checkIn = open.first['check_in'] as int;
    if (now < checkIn) {
      throw Exception('Отрицательная продолжительность запрещена');
    }
    await db.update(
      'work_sessions',
      {'check_out': now},
      where: 'id = ?',
      whereArgs: [id],
    );
    await _audit(db, 'session', id, 'check_out');
  }

  Future<void> markAbsent(
    int participantId,
    DateTime day, {
    String note = '',
  }) async {
    final db = await database;
    final key = dayKey(day);
    final start = DateTime(day.year, day.month, day.day).millisecondsSinceEpoch;
    final end =
        DateTime(day.year, day.month, day.day + 1).millisecondsSinceEpoch;
    final open = await db.query(
      'work_sessions',
      where:
          'participant_id = ? AND check_out IS NULL AND check_in >= ? AND check_in < ?',
      whereArgs: [participantId, start, end],
    );
    for (final s in open) {
      await db.update(
        'work_sessions',
        {'check_out': s['check_in']},
        where: 'id = ?',
        whereArgs: [s['id']],
      );
    }
    await db.insert(
      'day_status',
      {
        'participant_id': participantId,
        'day_key': key,
        'status': 'absent',
        'note': note,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    await _audit(db, 'day_status', participantId, 'absent', key);
  }

  Future<void> markPresent(
    int participantId,
    DateTime day, {
    String note = '',
  }) async {
    final db = await database;
    final key = dayKey(day);
    await db.insert(
      'day_status',
      {
        'participant_id': participantId,
        'day_key': key,
        'status': 'present',
        'note': note,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    final now = DateTime.now();
    if (dayKey(now) == key) {
      final open = await db.query(
        'work_sessions',
        where: 'participant_id = ? AND check_out IS NULL',
        whereArgs: [participantId],
      );
      if (open.isEmpty) {
        await checkIn(participantId, note: note);
        return;
      }
    }
    await _audit(db, 'day_status', participantId, 'present', key);
  }

  Future<void> updateSession({
    required int sessionId,
    required int checkIn,
    int? checkOut,
    String note = '',
  }) async {
    if (checkOut != null && checkOut < checkIn) {
      throw Exception('Уход не может быть раньше прихода');
    }
    final db = await database;
    await db.update(
      'work_sessions',
      {
        'check_in': checkIn,
        'check_out': checkOut,
        'note': note,
      },
      where: 'id = ?',
      whereArgs: [sessionId],
    );
    await _audit(db, 'session', sessionId, 'edit', note);
  }

  Future<void> deleteSession(int sessionId) async {
    final db = await database;
    await db.delete('work_sessions', where: 'id = ?', whereArgs: [sessionId]);
    await _audit(db, 'session', sessionId, 'delete');
  }

  Future<void> setDayNote(int participantId, DateTime day, String note) async {
    final db = await database;
    final key = dayKey(day);
    final existing = await db.query(
      'day_status',
      where: 'participant_id = ? AND day_key = ?',
      whereArgs: [participantId, key],
    );
    if (existing.isEmpty) {
      await db.insert('day_status', {
        'participant_id': participantId,
        'day_key': key,
        'status': 'unknown',
        'note': note,
        'created_at': DateTime.now().millisecondsSinceEpoch,
      });
    } else {
      await db.update(
        'day_status',
        {'note': note},
        where: 'participant_id = ? AND day_key = ?',
        whereArgs: [participantId, key],
      );
    }
  }

  Future<List<Map<String, dynamic>>> openSessions() async {
    final db = await database;
    return db.rawQuery('''
      SELECT s.*, p.first_name, p.last_name FROM work_sessions s
      INNER JOIN participants p ON p.id = s.participant_id
      WHERE s.check_out IS NULL AND p.deleted = 0
      ORDER BY s.check_in DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> attendanceBoard(
    DateTime day, {
    int? groupId,
    String search = '',
  }) async {
    final db = await database;
    final key = dayKey(day);
    final start = DateTime(day.year, day.month, day.day).millisecondsSinceEpoch;
    final end =
        DateTime(day.year, day.month, day.day + 1).millisecondsSinceEpoch;
    final q = '%${search.trim()}%';

    final people = groupId == null
        ? await db.query(
            'participants',
            where:
                'deleted = 0 AND archived = 0 AND (first_name LIKE ? OR last_name LIKE ? OR role LIKE ?)',
            whereArgs: [q, q, q],
            orderBy: 'first_name COLLATE NOCASE, last_name COLLATE NOCASE',
          )
        : await db.rawQuery('''
            SELECT p.* FROM participants p
            INNER JOIN group_members gm ON gm.participant_id = p.id
            WHERE p.deleted = 0 AND p.archived = 0 AND gm.group_id = ?
              AND (p.first_name LIKE ? OR p.last_name LIKE ? OR p.role LIKE ?)
            ORDER BY p.first_name COLLATE NOCASE, p.last_name COLLATE NOCASE
          ''', [groupId, q, q, q]);

    final result = <Map<String, dynamic>>[];
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    for (final p in people) {
      final pid = p['id'] as int;
      final sessions = await db.query(
        'work_sessions',
        where:
            'participant_id = ? AND check_in < ? AND (check_out IS NULL OR check_out > ?)',
        whereArgs: [pid, end, start],
        orderBy: 'check_in ASC',
      );
      final statusRows = await db.query(
        'day_status',
        where: 'participant_id = ? AND day_key = ?',
        whereArgs: [pid, key],
        limit: 1,
      );

      var millis = 0;
      var hasOpen = false;
      for (final s in sessions) {
        final ci = s['check_in'] as int;
        // A day explicitly marked absent must not add attendance time.
        final sessionDay = dayKey(DateTime.fromMillisecondsSinceEpoch(ci));
        final absent = await db.query('day_status',
            columns: ['status'],
            where: 'participant_id = ? AND day_key = ?',
            whereArgs: [pid, sessionDay], limit: 1);
        if (absent.isNotEmpty && absent.first['status'] == 'absent') continue;
        final co = s['check_out'] as int?;
        final segStart = ci < start ? start : ci;
        final segEnd = co == null
            ? (nowMs < end ? nowMs : end)
            : (co > end ? end : co);
        if (segEnd > segStart) millis += segEnd - segStart;
        if (co == null) hasOpen = true;
      }

      var status = 'none';
      var note = '';
      if (statusRows.isNotEmpty) {
        status = statusRows.first['status'] as String? ?? 'none';
        note = statusRows.first['note'] as String? ?? '';
      } else if (sessions.isNotEmpty) {
        status = 'present';
      }

      final visitCount = Sqflite.firstIntValue(await db.rawQuery('''
        SELECT COUNT(*) FROM (
          SELECT DISTINCT day FROM (
            SELECT date(check_in/1000, 'unixepoch', 'localtime') AS day
            FROM work_sessions WHERE participant_id = ?
            UNION
            SELECT day_key AS day FROM day_status
            WHERE participant_id = ? AND status = 'present'
          )
        )
      ''', [pid, pid])) ?? 0;

      result.add({
        ...p,
        'status': status,
        'note': note,
        'sessions': sessions,
        'hours': millis / 3600000.0,
        'hasOpen': hasOpen ? 1 : 0,
        'visitCount': visitCount,
      });
    }
    return result;
  }

  Future<void> _createV3(Database db) async {
    await db.execute(
      'CREATE TABLE IF NOT EXISTS manager_log('
      'id INTEGER PRIMARY KEY AUTOINCREMENT,'
      'day_key TEXT NOT NULL,'
      'start_ms INTEGER NOT NULL,'
      'end_ms INTEGER,'
      'actions TEXT NOT NULL DEFAULT \'\','
      'created_at INTEGER NOT NULL'
      ')',
    );
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_manager_day ON manager_log(day_key)');
  }

  Future<List<Map<String, dynamic>>> monthlyPeopleStats(DateTime month) async {
    final db = await database;
    final start = DateTime(month.year, month.month, 1).millisecondsSinceEpoch;
    final end = DateTime(month.year, month.month + 1, 1).millisecondsSinceEpoch;
    final people = await db.query(
      'participants',
      where: 'deleted = 0 AND archived = 0',
      orderBy: 'first_name COLLATE NOCASE, last_name COLLATE NOCASE',
    );
    final result = <Map<String, dynamic>>[];
    for (final p in people) {
      final pid = p['id'] as int;
      final sessions = await db.query(
        'work_sessions',
        where:
            'participant_id = ? AND check_in < ? AND (check_out IS NULL OR check_out > ?)',
        whereArgs: [pid, end, start],
        orderBy: 'check_in ASC',
      );
      var millis = 0;
      final presentDays = <String>{};
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      for (final s in sessions) {
        final ci = s['check_in'] as int;
        final co = s['check_out'] as int?;
        final segStart = ci < start ? start : ci;
        final segEnd = co == null
            ? (nowMs < end ? nowMs : end)
            : (co > end ? end : co);
        if (segEnd > segStart) {
          millis += segEnd - segStart;
          presentDays.add(dayKey(DateTime.fromMillisecondsSinceEpoch(ci)));
        }
      }
      final statusDays = await db.rawQuery(
        'SELECT day_key FROM day_status WHERE participant_id = ? AND status = ? AND day_key >= ? AND day_key < ?',
        [
          pid,
          'present',
          dayKey(DateTime(month.year, month.month, 1)),
          dayKey(DateTime(month.year, month.month + 1, 1)),
        ],
      );
      for (final r in statusDays) {
        presentDays.add(r['day_key'] as String);
      }
      result.add({
        ...p,
        'hours': millis / 3600000.0,
        'daysPresent': presentDays.length,
        'presentDayKeys': presentDays.toList()..sort(),
      });
    }
    return result;
  }

  Future<List<Map<String, dynamic>>> personMonthDays(
      int participantId, DateTime month) async {
    final db = await database;
    final start = DateTime(month.year, month.month, 1);
    final end = DateTime(month.year, month.month + 1, 1);
    final days = <Map<String, dynamic>>[];
    for (var d = start; d.isBefore(end); d = d.add(const Duration(days: 1))) {
      final key = dayKey(d);
      final dayStart = d.millisecondsSinceEpoch;
      final dayEnd = d.add(const Duration(days: 1)).millisecondsSinceEpoch;
      final sessions = await db.query(
        'work_sessions',
        where:
            'participant_id = ? AND check_in < ? AND (check_out IS NULL OR check_out > ?)',
        whereArgs: [participantId, dayEnd, dayStart],
        orderBy: 'check_in ASC',
      );
      var millis = 0;
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      for (final s in sessions) {
        final ci = s['check_in'] as int;
        final co = s['check_out'] as int?;
        final segStart = ci < dayStart ? dayStart : ci;
        final segEnd = co == null
            ? (nowMs < dayEnd ? nowMs : dayEnd)
            : (co > dayEnd ? dayEnd : co);
        if (segEnd > segStart) millis += segEnd - segStart;
      }
      final st = await db.query(
        'day_status',
        where: 'participant_id = ? AND day_key = ?',
        whereArgs: [participantId, key],
        limit: 1,
      );
      // Absent means zero attendance, regardless of any recorded session.
      if (st.isNotEmpty && st.first['status'] == 'absent') millis = 0;
      var status = 'none';
      var note = '';
      if (st.isNotEmpty) {
        status = st.first['status'] as String? ?? 'none';
        note = st.first['note'] as String? ?? '';
      } else if (sessions.isNotEmpty) {
        status = 'present';
      }
      if (status == 'none' && sessions.isEmpty) continue;
      days.add({
        'day_key': key,
        'date_ms': dayStart,
        'status': status,
        'note': note,
        'hours': millis / 3600000.0,
        'sessions': sessions,
      });
    }
    return days;
  }

  Future<List<Map<String, dynamic>>> managerLogs({String? dayKeyFilter}) async {
    final db = await database;
    if (dayKeyFilter == null) {
      return db.query('manager_log', orderBy: 'start_ms DESC');
    }
    return db.query(
      'manager_log',
      where: 'day_key = ?',
      whereArgs: [dayKeyFilter],
      orderBy: 'start_ms DESC',
    );
  }

  Future<int> saveManagerLog({
    int? id,
    required DateTime day,
    required int startMs,
    int? endMs,
    required String actions,
  }) async {
    final db = await database;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (id == null) {
      return db.insert('manager_log', {
        'day_key': dayKey(day),
        'start_ms': startMs,
        'end_ms': endMs,
        'actions': actions,
        'created_at': now,
      });
    }
    await db.update(
      'manager_log',
      {
        'day_key': dayKey(day),
        'start_ms': startMs,
        'end_ms': endMs,
        'actions': actions,
      },
      where: 'id = ?',
      whereArgs: [id],
    );
    return id;
  }

  Future<void> deleteManagerLog(int id) async {
    final db = await database;
    await db.delete('manager_log', where: 'id = ?', whereArgs: [id]);
  }

  Future<double> managerHoursInMonth(DateTime month) async {
    final db = await database;
    final start = DateTime(month.year, month.month, 1).millisecondsSinceEpoch;
    final end = DateTime(month.year, month.month + 1, 1).millisecondsSinceEpoch;
    final rows = await db.query(
      'manager_log',
      where: 'start_ms < ? AND (end_ms IS NULL OR end_ms > ?)',
      whereArgs: [end, start],
    );
    var millis = 0;
    final nowMs = DateTime.now().millisecondsSinceEpoch;
    for (final r in rows) {
      final a = r['start_ms'] as int;
      final b = r['end_ms'] as int? ?? nowMs;
      final segStart = a < start ? start : a;
      final segEnd = b > end ? end : b;
      if (segEnd > segStart) millis += segEnd - segStart;
    }
    return millis / 3600000.0;
  }

  Future<Map<String, dynamic>> summary() async {
    final db = await database;
    final people = Sqflite.firstIntValue(await db.rawQuery(
            'SELECT COUNT(*) FROM participants WHERE deleted = 0 AND archived = 0')) ??
        0;
    final present = Sqflite.firstIntValue(await db.rawQuery(
            'SELECT COUNT(DISTINCT participant_id) FROM work_sessions WHERE check_out IS NULL')) ??
        0;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).millisecondsSinceEpoch;
    final end =
        DateTime(now.year, now.month, now.day + 1).millisecondsSinceEpoch;
    final rows = await db.rawQuery('''
      SELECT COALESCE(SUM(
        MAX(0, MIN(COALESCE(check_out, ?), ?) - MAX(check_in, ?))
      ), 0) AS millis
      FROM work_sessions WHERE check_in < ? AND (check_out IS NULL OR check_out > ?)
    ''', [now.millisecondsSinceEpoch, end, start, end, start]);
    final millis = (rows.first['millis'] as num?)?.toInt() ?? 0;
    final groups = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COUNT(*) FROM groups')) ??
        0;
    return {
      'people': people,
      'present': present,
      'todayHours': (millis / 3600000).toStringAsFixed(1),
      'groups': groups,
    };
  }
}
