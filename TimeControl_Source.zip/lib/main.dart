import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'data/app_database.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ru');
  await AppDatabase.instance.database;
  runApp(const TimeControlApp());
}

const emerald = Color(0xFF10B981);
const bg = Color(0xFF0B0F0E);
const panel = Color(0xFF151C19);

class TimeControlApp extends StatelessWidget {
  const TimeControlApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'TimeControl',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(
            seedColor: emerald,
            brightness: Brightness.dark,
            surface: panel,
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: bg,
            foregroundColor: Colors.white,
            elevation: 0,
          ),
          cardTheme: CardThemeData(
            color: panel,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
              side: const BorderSide(color: Color(0xFF26332D)),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide.none,
            ),
          ),
          navigationBarTheme: NavigationBarThemeData(
            backgroundColor: panel,
            indicatorColor: const Color(0xFF174B39),
            labelTextStyle: WidgetStateProperty.resolveWith((states) {
              return TextStyle(
                fontSize: 10,
                fontWeight: states.contains(WidgetState.selected)
                    ? FontWeight.w700
                    : FontWeight.w500,
              );
            }),
          ),
          useMaterial3: true,
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  int refreshKey = 0;
  void refresh() => setState(() => refreshKey++);

  @override
  Widget build(BuildContext context) {
    final pages = [
      OverviewPage(key: ValueKey('o-$refreshKey'), onChanged: refresh),
      PeoplePage(key: ValueKey('p-$refreshKey'), onChanged: refresh),
      AttendancePage(key: ValueKey('a-$refreshKey'), onChanged: refresh),
      GroupsPage(key: ValueKey('g-$refreshKey'), onChanged: refresh),
      StatsPage(key: ValueKey('s-$refreshKey')),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(
              icon: Icon(Icons.grid_view_rounded), label: 'Обзор'),
          NavigationDestination(
              icon: Icon(Icons.groups_2_outlined), label: 'Люди'),
          NavigationDestination(
              icon: Icon(Icons.fact_check_outlined), label: 'Учёт'),
          NavigationDestination(
              icon: Icon(Icons.folder_shared_outlined), label: 'Группы'),
          NavigationDestination(
              icon: Icon(Icons.bar_chart_rounded), label: 'Отчёты'),
        ],
      ),
    );
  }
}

Widget pageTitle(String title, {String? subtitle}) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title,
            style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.white54)),
        ],
      ]),
    );

Widget metric(String label, String value, IconData icon,
        {Color color = emerald}) =>
    Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 10),
          Text(value,
              style:
                  const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          Text(label,
              style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ]),
      ),
    );

// ---------------------------------------------------------------------------
// Overview
// ---------------------------------------------------------------------------

class OverviewPage extends StatefulWidget {
  final VoidCallback onChanged;
  const OverviewPage({super.key, required this.onChanged});
  @override
  State<OverviewPage> createState() => _OverviewPageState();
}

class _OverviewPageState extends State<OverviewPage> {
  Map<String, dynamic> summary = {};
  List<Map<String, dynamic>> active = [];
  bool loading = true;
  String? error;

  Future<void> load() async {
    try {
      final s = await AppDatabase.instance.summary();
      final a = await AppDatabase.instance.openSessions();
      if (!mounted) return;
      setState(() {
        summary = s;
        active = a;
        loading = false;
        error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('EEEE, d MMMM yyyy', 'ru').format(DateTime.now());
    return RefreshIndicator(
      onRefresh: load,
      child: ListView(children: [
        pageTitle('Обзор', subtitle: dateStr),
        if (loading)
          const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (error != null)
          Padding(
            padding: const EdgeInsets.all(20),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Ошибка загрузки: $error',
                    style: const TextStyle(color: Colors.redAccent)),
              ),
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Column(children: [
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.4,
                children: [
                  metric('Участников', '${summary['people'] ?? 0}', Icons.groups),
                  metric('Сейчас на месте', '${summary['present'] ?? 0}',
                      Icons.work_history),
                  metric('Групп', '${summary['groups'] ?? 0}',
                      Icons.folder_shared_outlined,
                      color: Colors.amber),
                  metric('Часов сегодня', '${summary['todayHours'] ?? '0.0'}',
                      Icons.schedule),
                ],
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Открытые сессии',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      if (active.isEmpty)
                        const Text('Сейчас никто не отмечен как пришедший',
                            style: TextStyle(color: Colors.white54))
                      else
                        ...active.map((s) => ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: const CircleAvatar(
                                backgroundColor: Color(0xFF174B39),
                                child: Icon(Icons.person, color: emerald),
                              ),
                              title: Text(
                                  '${s['first_name']} ${s['last_name']}'),
                              subtitle: Text(
                                  'Пришёл: ${DateFormat('HH:mm').format(DateTime.fromMillisecondsSinceEpoch(s['check_in'] as int))}'),
                            )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Row(children: [
                    Icon(Icons.offline_bolt, color: emerald),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                          'Все данные хранятся локально. Интернет не требуется.'),
                    ),
                  ]),
                ),
              ),
              const SizedBox(height: 24),
            ]),
          ),
      ]),
    );
  }
}

// ---------------------------------------------------------------------------
// People
// ---------------------------------------------------------------------------

class PeoplePage extends StatefulWidget {
  final VoidCallback onChanged;
  const PeoplePage({super.key, required this.onChanged});
  @override
  State<PeoplePage> createState() => _PeoplePageState();
}

class _PeoplePageState extends State<PeoplePage> {
  List<Map<String, dynamic>> items = [];
  final search = TextEditingController();
  bool archived = false;
  bool loading = true;

  Future<void> load() async {
    final list = await AppDatabase.instance
        .people(search: search.text, archived: archived);
    if (!mounted) return;
    setState(() {
      items = list;
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    load();
    search.addListener(load);
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  Future<void> edit([Map<String, dynamic>? p]) async {
    final first = TextEditingController(text: p?['first_name']?.toString() ?? '');
    final last = TextEditingController(text: p?['last_name']?.toString() ?? '');
    final role = TextEditingController(text: p?['role']?.toString() ?? '');
    final phone = TextEditingController(text: p?['phone']?.toString() ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(p == null ? 'Новый участник' : 'Изменить участника'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: first,
                decoration: const InputDecoration(labelText: 'Имя *')),
            const SizedBox(height: 8),
            TextField(
                controller: last,
                decoration: const InputDecoration(labelText: 'Фамилия *')),
            const SizedBox(height: 8),
            TextField(
                controller: role,
                decoration:
                    const InputDecoration(labelText: 'Должность / роль')),
            const SizedBox(height: 8),
            TextField(
                controller: phone,
                decoration: const InputDecoration(labelText: 'Телефон'),
                keyboardType: TextInputType.phone),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Сохранить')),
        ],
      ),
    );
    if (ok != true) return;
    if (first.text.trim().isEmpty || last.text.trim().isEmpty) return;
    await AppDatabase.instance.savePerson({
      if (p != null) 'id': p['id'],
      'first_name': first.text.trim(),
      'last_name': last.text.trim(),
      'role': role.text.trim(),
      'phone': phone.text.trim(),
    });
    await load();
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => edit(),
          icon: const Icon(Icons.person_add),
          label: const Text('Добавить'),
        ),
        body: Column(children: [
          pageTitle('Люди',
              subtitle: '${items.length} участников в списке'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextField(
              controller: search,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Поиск по имени, фамилии, роли',
              ),
            ),
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Активные'),
                    icon: Icon(Icons.check, size: 16)),
                ButtonSegment(value: true, label: Text('Архив')),
              ],
              selected: {archived},
              onSelectionChanged: (v) {
                setState(() => archived = v.first);
                load();
              },
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : items.isEmpty
                    ? const Center(
                        child: Text('Список пуст',
                            style: TextStyle(color: Colors.white54)))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 88),
                        itemCount: items.length,
                        itemBuilder: (_, i) {
                          final p = items[i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: const CircleAvatar(
                                backgroundColor: Color(0xFF174B39),
                                child: Icon(Icons.person, color: emerald),
                              ),
                              title: Text(
                                  '${p['first_name']} ${p['last_name']}'),
                              subtitle: Text(
                                (p['role'] as String?)?.isNotEmpty == true
                                    ? p['role'] as String
                                    : 'Без роли',
                              ),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) async {
                                  if (v == 'edit') {
                                    await edit(p);
                                  } else if (v == 'archive') {
                                    await AppDatabase.instance.setArchived(
                                        p['id'] as int, !archived);
                                    await load();
                                    widget.onChanged();
                                  } else if (v == 'delete') {
                                    await AppDatabase.instance
                                        .softDelete(p['id'] as int);
                                    await load();
                                    widget.onChanged();
                                  }
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Изменить')),
                                  PopupMenuItem(
                                      value: 'archive',
                                      child: Text(archived
                                          ? 'Вернуть из архива'
                                          : 'В архив')),
                                  const PopupMenuItem(
                                      value: 'delete',
                                      child: Text('Удалить')),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ]),
      );
}

// ---------------------------------------------------------------------------
// Attendance
// ---------------------------------------------------------------------------

class AttendancePage extends StatefulWidget {
  final VoidCallback onChanged;
  const AttendancePage({super.key, required this.onChanged});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  DateTime day = DateTime.now();
  int? groupId;
  List<Map<String, dynamic>> groups = [];
  List<Map<String, dynamic>> board = [];
  final search = TextEditingController();
  bool loading = true;
  String? error;

  Future<void> load() async {
    try {
      final g = await AppDatabase.instance.groups();
      final b = await AppDatabase.instance.attendanceBoard(
        day,
        groupId: groupId,
        search: search.text,
      );
      if (!mounted) return;
      setState(() {
        groups = g;
        board = b;
        loading = false;
        error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();
    load();
    search.addListener(load);
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  Future<void> pickDay() async {
    final d = await showDatePicker(
      context: context,
      initialDate: day,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) {
      setState(() => day = d);
      await load();
    }
  }

  Future<void> present(Map<String, dynamic> row) async {
    try {
      await AppDatabase.instance.markPresent(row['id'] as int, day);
      await load();
      widget.onChanged();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> absent(Map<String, dynamic> row) async {
    try {
      await AppDatabase.instance.markAbsent(row['id'] as int, day);
      await load();
      widget.onChanged();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> editNote(Map<String, dynamic> row) async {
    final c = TextEditingController(text: row['note']?.toString() ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Заметка'),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Комментарий за день'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Сохранить')),
        ],
      ),
    );
    if (ok != true) return;
    await AppDatabase.instance
        .setDayNote(row['id'] as int, day, c.text.trim());
    await load();
  }

  Future<void> editHours(Map<String, dynamic> row) async {
    final sessions =
        (row['sessions'] as List?)?.cast<Map<String, dynamic>>() ?? [];
    if (sessions.isEmpty) {
      // Create a manual completed session for the day.
      final start = DateTime(day.year, day.month, day.day, 9);
      final end = DateTime(day.year, day.month, day.day, 18);
      final inCtrl = TextEditingController(text: DateFormat('HH:mm').format(start));
      final outCtrl = TextEditingController(text: DateFormat('HH:mm').format(end));
      final noteCtrl = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Добавить часы'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
                controller: inCtrl,
                decoration: const InputDecoration(labelText: 'Приход (ЧЧ:ММ)')),
            const SizedBox(height: 8),
            TextField(
                controller: outCtrl,
                decoration: const InputDecoration(labelText: 'Уход (ЧЧ:ММ)')),
            const SizedBox(height: 8),
            TextField(
                controller: noteCtrl,
                decoration: const InputDecoration(labelText: 'Заметка')),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Отмена')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Сохранить')),
          ],
        ),
      );
      if (ok != true) return;
      try {
        final ci = _parseDayTime(day, inCtrl.text.trim());
        final co = _parseDayTime(day, outCtrl.text.trim());
        await AppDatabase.instance.markPresent(row['id'] as int, day);
        // Insert via updateSession after check-in is awkward; use raw path:
        final open = await AppDatabase.instance.openSessions();
        final mine = open.where((s) => s['participant_id'] == row['id']).toList();
        if (mine.isNotEmpty) {
          await AppDatabase.instance.updateSession(
            sessionId: mine.first['id'] as int,
            checkIn: ci,
            checkOut: co,
            note: noteCtrl.text.trim(),
          );
        }
        await load();
        widget.onChanged();
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('$e')));
      }
      return;
    }

    final s = sessions.last;
    final inCtrl = TextEditingController(
        text: DateFormat('HH:mm')
            .format(DateTime.fromMillisecondsSinceEpoch(s['check_in'] as int)));
    final outCtrl = TextEditingController(
        text: s['check_out'] == null
            ? ''
            : DateFormat('HH:mm').format(
                DateTime.fromMillisecondsSinceEpoch(s['check_out'] as int)));
    final noteCtrl =
        TextEditingController(text: s['note']?.toString() ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Редактировать часы'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
              controller: inCtrl,
              decoration: const InputDecoration(labelText: 'Приход (ЧЧ:ММ)')),
          const SizedBox(height: 8),
          TextField(
              controller: outCtrl,
              decoration: const InputDecoration(
                  labelText: 'Уход (ЧЧ:ММ, пусто = открыта)')),
          const SizedBox(height: 8),
          TextField(
              controller: noteCtrl,
              decoration: const InputDecoration(labelText: 'Заметка')),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Сохранить')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final ci = _parseDayTime(day, inCtrl.text.trim());
      final coText = outCtrl.text.trim();
      final co = coText.isEmpty ? null : _parseDayTime(day, coText);
      await AppDatabase.instance.updateSession(
        sessionId: s['id'] as int,
        checkIn: ci,
        checkOut: co,
        note: noteCtrl.text.trim(),
      );
      await load();
      widget.onChanged();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  int _parseDayTime(DateTime d, String hhmm) {
    final parts = hhmm.split(':');
    if (parts.length != 2) throw Exception('Формат времени ЧЧ:ММ');
    final h = int.parse(parts[0]);
    final m = int.parse(parts[1]);
    return DateTime(d.year, d.month, d.day, h, m).millisecondsSinceEpoch;
  }

  Color statusColor(String status) {
    switch (status) {
      case 'present':
        return emerald;
      case 'absent':
        return Colors.redAccent;
      default:
        return Colors.white38;
    }
  }

  String statusLabel(String status) {
    switch (status) {
      case 'present':
        return 'Пришёл';
      case 'absent':
        return 'Не пришёл';
      default:
        return 'Нет отметки';
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateLabel = DateFormat('d MMMM yyyy, EEEE', 'ru').format(day);
    return Column(children: [
      pageTitle('Посещаемость', subtitle: dateLabel),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: pickDay,
              icon: const Icon(Icons.calendar_today, size: 16),
              label: Text(DateFormat('dd.MM.yyyy').format(day)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: InputDecorator(
              decoration: const InputDecoration(
                contentPadding:
                    EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<int?>(
                  value: groupId,
                  isExpanded: true,
                  isDense: true,
                  items: [
                    const DropdownMenuItem<int?>(
                        value: null, child: Text('Все группы')),
                    ...groups.map((g) => DropdownMenuItem<int?>(
                          value: g['id'] as int,
                          child: Text('${g['name']}'),
                        )),
                  ],
                  onChanged: (v) {
                    setState(() => groupId = v);
                    load();
                  },
                ),
              ),
            ),
          ),
        ]),
      ),
      const SizedBox(height: 8),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: TextField(
          controller: search,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'Поиск участника',
          ),
        ),
      ),
      const SizedBox(height: 8),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : error != null
                ? Center(
                    child: Text('Ошибка: $error',
                        style: const TextStyle(color: Colors.redAccent)))
                : board.isEmpty
                    ? const Center(
                        child: Text(
                            'Нет участников. Добавьте людей во вкладке «Люди».',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white54)))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: board.length,
                        itemBuilder: (_, i) {
                          final row = board[i];
                          final status = row['status'] as String? ?? 'none';
                          final hours = (row['hours'] as num?)?.toDouble() ?? 0;
                          final visits = row['visitCount'] ?? 0;
                          final sessions = (row['sessions'] as List?) ?? [];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 10),
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(children: [
                                    CircleAvatar(
                                      backgroundColor: statusColor(status)
                                          .withValues(alpha: 0.2),
                                      child: Icon(Icons.person,
                                          color: statusColor(status)),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            '${row['first_name']} ${row['last_name']}',
                                            style: const TextStyle(
                                                fontWeight: FontWeight.w700),
                                          ),
                                          Text(
                                            '${statusLabel(status)} · ${hours.toStringAsFixed(1)} ч · визитов: $visits',
                                            style: TextStyle(
                                              color: statusColor(status),
                                              fontSize: 12,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ]),
                                  if ((row['note'] as String?)?.isNotEmpty ==
                                      true) ...[
                                    const SizedBox(height: 6),
                                    Text('📝 ${row['note']}',
                                        style: const TextStyle(
                                            color: Colors.white60,
                                            fontSize: 12)),
                                  ],
                                  if (sessions.isNotEmpty) ...[
                                    const SizedBox(height: 6),
                                    Text(
                                      sessions.map((s) {
                                        final m = s as Map;
                                        final a = DateFormat('HH:mm').format(
                                            DateTime.fromMillisecondsSinceEpoch(
                                                m['check_in'] as int));
                                        final b = m['check_out'] == null
                                            ? '…'
                                            : DateFormat('HH:mm').format(
                                                DateTime
                                                    .fromMillisecondsSinceEpoch(
                                                        m['check_out'] as int));
                                        return '$a–$b';
                                      }).join('  ·  '),
                                      style: const TextStyle(
                                          color: Colors.white54, fontSize: 11),
                                    ),
                                  ],
                                  const SizedBox(height: 10),
                                  Wrap(spacing: 8, runSpacing: 8, children: [
                                    FilledButton.tonal(
                                      onPressed: () => present(row),
                                      child: const Text('Пришёл(а)'),
                                    ),
                                    OutlinedButton(
                                      onPressed: () => absent(row),
                                      child: const Text('Не пришёл(а)'),
                                    ),
                                    IconButton(
                                      tooltip: 'Часы',
                                      onPressed: () => editHours(row),
                                      icon: const Icon(Icons.schedule),
                                    ),
                                    IconButton(
                                      tooltip: 'Заметка',
                                      onPressed: () => editNote(row),
                                      icon: const Icon(Icons.sticky_note_2_outlined),
                                    ),
                                  ]),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
      ),
    ]);
  }
}

// ---------------------------------------------------------------------------
// Groups
// ---------------------------------------------------------------------------

class GroupsPage extends StatefulWidget {
  final VoidCallback onChanged;
  const GroupsPage({super.key, required this.onChanged});
  @override
  State<GroupsPage> createState() => _GroupsPageState();
}

class _GroupsPageState extends State<GroupsPage> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;

  Future<void> load() async {
    final list = await AppDatabase.instance.groups();
    if (!mounted) return;
    setState(() {
      items = list;
      loading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> create() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Новая группа'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(labelText: 'Название'),
          autofocus: true,
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Отмена')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Создать')),
        ],
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    try {
      await AppDatabase.instance.createGroup(c.text.trim());
      await load();
      widget.onChanged();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> manageMembers(Map<String, dynamic> g) async {
    final all = await AppDatabase.instance.people();
    final selected =
        (await AppDatabase.instance.groupMemberIds(g['id'] as int)).toSet();
    if (!mounted) return;
    final result = await showDialog<Set<int>>(
      context: context,
      builder: (ctx) {
        final local = {...selected};
        return StatefulBuilder(
          builder: (ctx, setLocal) => AlertDialog(
            title: Text('Участники: ${g['name']}'),
            content: SizedBox(
              width: double.maxFinite,
              height: 360,
              child: all.isEmpty
                  ? const Center(child: Text('Нет людей'))
                  : ListView(
                      children: all
                          .map((p) => CheckboxListTile(
                                value: local.contains(p['id'] as int),
                                title: Text(
                                    '${p['first_name']} ${p['last_name']}'),
                                onChanged: (v) {
                                  setLocal(() {
                                    if (v == true) {
                                      local.add(p['id'] as int);
                                    } else {
                                      local.remove(p['id'] as int);
                                    }
                                  });
                                },
                              ))
                          .toList(),
                    ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Отмена')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, local),
                  child: const Text('Сохранить')),
            ],
          ),
        );
      },
    );
    if (result == null) return;
    await AppDatabase.instance
        .setGroupMembers(g['id'] as int, result.toList());
    await load();
    widget.onChanged();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: create,
          icon: const Icon(Icons.create_new_folder_outlined),
          label: const Text('Группа'),
        ),
        body: Column(children: [
          pageTitle('Группы',
              subtitle: 'Объединяйте участников для учёта посещаемости'),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : items.isEmpty
                    ? const Center(
                        child: Text('Пока нет групп',
                            style: TextStyle(color: Colors.white54)))
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 88),
                        itemCount: items.length,
                        itemBuilder: (_, i) {
                          final g = items[i];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: const CircleAvatar(
                                backgroundColor: Color(0xFF174B39),
                                child: Icon(Icons.folder_shared,
                                    color: emerald),
                              ),
                              title: Text('${g['name']}'),
                              subtitle: Text(
                                  'Участников: ${g['member_count'] ?? 0}'),
                              trailing: PopupMenuButton<String>(
                                onSelected: (v) async {
                                  if (v == 'members') {
                                    await manageMembers(g);
                                  } else if (v == 'delete') {
                                    final ok = await showDialog<bool>(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        title: const Text('Удалить группу?'),
                                        content: Text(
                                            'Группа «${g['name']}» будет удалена. Участники останутся.'),
                                        actions: [
                                          TextButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, false),
                                              child: const Text('Отмена')),
                                          FilledButton(
                                              onPressed: () =>
                                                  Navigator.pop(ctx, true),
                                              child: const Text('Удалить')),
                                        ],
                                      ),
                                    );
                                    if (ok == true) {
                                      await AppDatabase.instance
                                          .deleteGroup(g['id'] as int);
                                      await load();
                                      widget.onChanged();
                                    }
                                  }
                                },
                                itemBuilder: (_) => const [
                                  PopupMenuItem(
                                      value: 'members',
                                      child: Text('Участники')),
                                  PopupMenuItem(
                                      value: 'delete',
                                      child: Text('Удалить')),
                                ],
                              ),
                              onTap: () => manageMembers(g),
                            ),
                          );
                        },
                      ),
          ),
        ]),
      );
}

// ---------------------------------------------------------------------------
// Stats
// ---------------------------------------------------------------------------

class StatsPage extends StatefulWidget {
  const StatsPage({super.key});
  @override
  State<StatsPage> createState() => _StatsPageState();
}

class _StatsPageState extends State<StatsPage> {
  Map<String, dynamic> data = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    AppDatabase.instance.summary().then((v) {
      if (mounted) {
        setState(() {
          data = v;
          loading = false;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) => ListView(children: [
        pageTitle('Статистика', subtitle: 'Сводка по локальным данным'),
        if (loading)
          const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: CircularProgressIndicator()),
          )
        else
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              metric('Всего участников', '${data['people'] ?? 0}', Icons.groups),
              metric('Открытые сессии', '${data['present'] ?? 0}', Icons.timer),
              metric('Групп', '${data['groups'] ?? 0}',
                  Icons.folder_shared_outlined),
              metric('Часов сегодня', '${data['todayHours'] ?? '0.0'}',
                  Icons.schedule),
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Графики и расширенные отчёты будут добавлены на следующих этапах.',
                    style: TextStyle(color: Colors.white60),
                  ),
                ),
              ),
            ]),
          ),
      ]);
}
